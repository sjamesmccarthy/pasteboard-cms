<?php

/*
// -------------------------------------------------------------------
// v_error ()
// -------------------------------------------------------------------
// Creates a basic HTML template for error messages
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// $ERROR_MSG[]
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/
?>

Error 404 - Page Not Found
Views should not return any variables. They simply format the page for
presentation to the browser. There may be some javascript and css included. 

<?=$ERROR_MSG; ?>

<?php
/* End of file */
/* Location: ./pb-views/v_error.php */
?>