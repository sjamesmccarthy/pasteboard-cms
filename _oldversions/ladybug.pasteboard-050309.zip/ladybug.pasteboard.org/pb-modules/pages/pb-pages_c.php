<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		start_c.php
 * @DESC		initializes the pasteboard system
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	none
 */
 
# load the page data and review to controller

/*
switch($arg) 
{
	//inside here call the models
	//return to view
}

$layout = array('body_template' => 'assign_writer'
		               ,'writers' => $cache_writer_results #$cache_writer_results
		               ,'content_id' => $content_ids
		               ,'content_group' => $content_group 
		               ,'category' => $cache_writer_results['category_title']
		               ,'writer_states' => $writer_states 
		               ,'catgory_flag' => $catgory_flag 
		               ,'total_word_count' => $total_word_count 
		               ,'questions' => $questions
		               ,'pay_types' => $pay_types 
		               ,'desired_writer_id' => $desired_writer
					   ,'ongoing' => $ongoing
					   ,'editors' => $editors					   
		               );
*/

/* End of file */
/* Location: ./pb-controllers/pb-admin_c.php */