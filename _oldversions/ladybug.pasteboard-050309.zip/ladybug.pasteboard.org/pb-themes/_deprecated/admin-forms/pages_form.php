<?

function display_form($MODE, $PAGE_OBJ ='') {
	// $mode: 1 = add; 2 = edit
	GLOBAL $CONFIG;
	
	switch($MODE) { 
	
		case "1":
		$action ="create";
		$mode = "Adding Page"; 
		$FILE_FIELD_NEW = "<input type=\"text\" name=\"xml\" maxlength=\"20\" style=\"width: 15%; height:20px; font-size: 10pt;\">";
		$FILEMAPPING = '<p><b>Filename</b><br />' . PB_ROOT . 'pages/ ' . $FILE_FIELD_NEW . ' .xml (MAXLENGTH: 20 characters)</p>';
		break;
		
		case "2":
		$action ="update";
		
	    if($PAGE_OBJ->status == "published") {
	        $mode = "Editing Page<!--: $PAGE_OBJ->title--><br /><span style=\"margin-left: 20px; font-size: small\">&raquo; <a target=\"_new\" href=\"$CONFIG[SITE_URL]/?p=$PAGE_OBJ[XML]\">preview this page</a> (opens new window)</span>";
	    } 
	    #else {
	    #    $mode = "Editing: $PAGE_OBJ->title";   
	    #}
	  
		$FILE_FIELD_UPDATE = "
		<p style=\"font-size: 10pt; color: #CCC;\">
		<b>Filename (20 character max)</b><br />
		<input type=\"text\" name=\"xml\" maxlength=\"20\" style=\"width: 100%; height:20px; font-size: 10pt; color: #CCC;\" value=\"$PAGE_OBJ[XML].xml\" READONLY>
		</p>";
	
		$CONTENT = htmlentities($PAGE_OBJ->content);
		break;
		
		default:
		break;
	
	}
	
	$textbox = "
	<form id=\"pages_form\" action=\"?form=pages&m=$action\" method=\"post\">
	<div id=\"content\"><!-- content -->
	
	<h1>$mode</h1>
	<p>$FILEMAPPING</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Title</b><br />
	<input type=\"text\" name=\"title\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$PAGE_OBJ->title\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Content</b><br />
	<textarea name=\"content\" class=\"pages_form\">$CONTENT</textarea>
	</p>

	<p style=\"font-size: 10pt;\">
	<b>Meta-Description</b> (250 characters)<br />
	<input type=\"text\" name=\"meta_description\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$PAGE_OBJ->meta_description\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Meta-Keywords</b> (about 20, comma separated)<br />
	<input type=\"text\" name=\"meta_keywords\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$PAGE_OBJ->meta_keywords\"><br />
	<!-- <input type=\"checkbox\" name=\"apply_to_tags\" value=\"1\"> Use as <b>Tags</b> -->
	</p>
	
	$FILE_FIELD_UPDATE
	
	<p>
	<input type=\"submit\" value=\"Save Page\" style=\"font-size: 14pt;\">
	<input type=\"button\" value=\"Cancel\" style=\"font-size: 14pt;\" onclick=\"location.href='?form=pages';\">
	</p>
	
	</div><!-- content -->";
	
// SIDEBAR AREA
// INIT ARRAYS FOR OPTIONS
$statusList = array('published','hidden','system');
$pageTypeList = array('xhtml','php');

$templateList = get_pages(ABSPATH . PB_ROOT . TEMPLATEPATH);
$pageCSSList = get_pages(ABSPATH . PB_ROOT . THEMESPATH . 'css/');
$categoryList = array('none');
$robotsList = array('all','Index','No-Follow','none');
$sitemapIndex = array('Included', 'Excluded');

$textbox .="<div id=\"sidebar\"><!-- sidebar -->";


$textbox .= "
<div id=\"sidebar_details\">
<p class=\"heading\">PAGES (Options)</p>";

# PAGE OPTIONS

if($MODE == 2) {

$textbox .= "
<p>
<a onclick=\"return confirm('Are you sure you want to delete?')\" href=\"?form=pages&m=delete&xml=$PAGE_OBJ[XML]\">Delete This Page</a><br />
<a href=\"?form=pages&m=rename&xml=$PAGE_OBJ[XML]\">Rename This File</a><br />
<a target=\"_new\" href=\"$CONFIG[SITE_URL]/?p=$PAGE_OBJ[XML]\">Preview This Page</a>
</p>
";
}

$textbox .= "
<p>
<a href=\"?form=pages&m=history&xml=$PAGE_OBJ[XML]\">Show Backup History</a><br />
<!-- <a href=\"?form=pages\">Show All Pages</a><br /> -->
<a href=\"?form=pages\">Cancel</a><br />
</p>
</div>

<!-- <div id=\"sidebar_details\"> -->
<!-- <p class=\"heading\">PAGE STATUS</p> -->
<!-- </div> -->

<div id=\"sidebar_details\">
<p class=\"heading\">PAGE DETAILS</p>
<p>
<b>Last modified on</b><br />";

// LAST MODIFIED DATE
if(!$PAGE_OBJ->lastupdate) {
$lastupdate = MYSQLDATETIME;
} else { $lastupdate = $PAGE_OBJ->lastupdate; }

$textbox .= "
$lastupdate
<input type=\"hidden\" name=\"lastupdate\" value=\"$lastupdate\">
</p>

<p>
<b>Author</b><br />
$PAGE_OBJ->author
";

if(!$PAGE_OBJ->author) {
$textbox .= "$_SESSION[firstname] $_SESSION[lastname]";
$textbox .= "<input type=\"hidden\" name=\"author\" value=\"$_SESSION[firstname] $_SESSION[lastname]\">";
} else {
$textbox .= "<input type=\"hidden\" name=\"author\" value=\"$PAGE_OBJ->author\">";
}

$textbox .= "
<input type=\"hidden\" name=\"username\" value=\"$_SESSION[username]\">
<input type=\"hidden\" name=\"userid\" value=\"$_SESSION[id]\">
</p>

<p>
<!-- <select name=\"status\"> -->
<b>Page Status</b><br />
<select name=\"status\"> 
";

# PAGE STATUS MENU
foreach ($statusList as $key=>$value) {
	
	#if($PAGE_OBJ->status == $value) { $SEL = "CHECKED"; } else { unset($SEL); }
	#if($MODE == 1 && $value == "published") { $SEL = "CHECKED"; }
	
	#$textbox .= "<input type=\"radio\" $SEL name=\"status\" value=\"$value\" />" . ucfirst($value) . "<br />";
	#$textbox .= "<option $SEL value=\"$value\">" . strtoupper($value) . "</option>";
	
	if($PAGE_OBJ->statusList == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\">" . strtoupper($value) . "</option>";

}

$textbox .= "
</select> 
</p>

<p>
<b>Sitemap</b><br />
<select name=\"sitemapindex\">";

# sitemapIndex MENU
foreach ($sitemapIndex as $key=>$value) {
	
	if($PAGE_OBJ->sitemapindex == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\">" . strtoupper($value) . "</option>";

}

$textbox .= "
</select>
</p>

<p>
<b>Type</b><br />
<select name=\"type\">";

# PAGE TYPE MENU
foreach ($pageTypeList as $key=>$value) {
	
	if($PAGE_OBJ->type == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\">" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>

<p>
<b>Template</b><br />
<select name=\"template\">
$CONFIG[THEME]--<br />
";

# TEMPLATE MENU
foreach ($templateList as $theme_key => $template_name) {

	if($PAGE_OBJ->template == $template_name) { $SEL = "SELECTED"; } else { unset($SEL); }
	if($PAGE_OBJ->template != $template_name) { $nomatch++; }
	$textbox .= "<option $SEL value=\"$template_name\">" . $template_name . "</option>";
	$count++;
	
}
	
	if($MODE == 1 || $nomatch == $count) { 
	$textbox .= "<option SELECTED value=\"\">- - -</option>"; }
	
$textbox .= "
</select>
</p>

<p>
<b>Alt CSS file</b><br />
<select name=\"pagecss\">";

# PAGE_CSS MENU
$i=0;

foreach ($pageCSSList as $key=>$value) {
	
	// For backwards compatibility with XML files where "none" is stored.
	// Should be okay to remove in next major release
	if($PAGE_OBJ->pagecss == "none") { $PAGE_OBJ->pagecss = ""; }
	
	$cssfile = split('\.', $value);
	$tempfile = split('\.', $templateList[$i]);
	$i++;
	
	if($cssfile[0] == $tempfile[0]) { $minus++; } else {
	if($PAGE_OBJ->pagecss == $value) { $SEL = "SELECTED"; } else { unset($SEL);}
	$textbox .= "<option $SEL value=\"$value\">" . $value . "</option>";
	}
	
}	
	if(($count - $minus) == 0) { $none = " (none found)";  $SEL="SELECTED"; } 
	else { unset($SEL); }
	  
	if($MODE == 1 || $PAGE_OBJ->pagecss == "") {  
	$SEL = "SELECTED";
	} else { unset($SEL); }
	
	$textbox .= "<option $SEL value=\"\">- - -$none</option>";
		
$textbox .= "
</select>
</p>

<p>
<b>Category</b><br /> 
<select name=\"category\">
";

# CATEGORY MENU
foreach ($categoryList as $key=>$value) {
	
	if($PAGE_OBJ->category) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\">" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>

<p>
<b>Robots</b><br /> 
<select name=\"meta_robots\">
";

# ROBOTS MENU
foreach ($robotsList as $key=>$value) {
	
	if($PAGE_OBJ->meta_robots == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\">" . strtoupper($value) . "</option>";
}

$textbox .= "
</select>
</p>

<p><b>Tags</b><br />
<textarea name=\"tags\" cols=\"20\" row=\"5\">$PAGE_OBJ->meta_keywords</textarea><br />
<!-- <input type=\"checkbox\" name=\"apply_to_keywords\" value=\"1\"> Use as <b>Meta-Keywords</b> -->
</p>

</div>

</div><!-- sidebar -->
</form>
";

	return($textbox);
}

?>