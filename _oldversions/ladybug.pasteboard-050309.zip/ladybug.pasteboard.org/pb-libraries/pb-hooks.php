<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		pb-hooks.php
 * @DESC		a set of functions that are called from the template/view levels
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	none
 */
 
function get_header($FILE = 'header.php') {
   
    $HEADER_FILE = ABSPATH . PB_ROOT . THEMESPATH . 'includes/' . $FILE;
    if (file_exists($HEADER_FILE)) {
		include_once($HEADER_FILE);
    } else {
		#log to debug();
		error(206, 'File Not Found', 'pb-common.php', $HEADER_FILE);
    }
    
}

function get_footer($FILE = 'footer.php') {   
	
	$FOOTER_FILE = ABSPATH . PB_ROOT . THEMESPATH . 'includes/' . $FILE;
    if (file_exists($FOOTER_FILE)) {
		include_once($FOOTER_FILE);
    } else {
		#log to debug();
		error(218, 'File Not Found', 'pb-common.php', $FOOTER_FILE);
    }
    
}
 
/* End of file */
/* Location: ./pb-content/config/pb-configsite.php */
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */