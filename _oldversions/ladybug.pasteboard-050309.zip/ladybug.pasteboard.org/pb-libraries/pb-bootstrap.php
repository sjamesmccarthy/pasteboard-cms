<?php 

/**
 * @FILE		boostrap_c.php
 * @DESC		initializes the pasteboard system
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	pb_autoload, pb_boostrap, pb_router
 */

/******************************************************************
* Function Name: pb_bootstrap
* Parameters: $autoload(array)
* Description: Autoloads library files so there isn't a mess of require 
			   statements on the page, as well as setting files. Then
			   it passes eveything back to the index Front-End_Controller.
* Return type: TRUE
*******************************************************************/ 
function pb_bootstrap() 
{
	error_reporting(E_ALL);	
	require('pb-config.php');
	
	pb_autoload($autoload_f,0);	
	pb_debug_add($pb, '01', 'pb_bootstrap.v(' . PB_VERSION . ')');
	pb_timerOn($pb, 'bootstrap');
	pb_site_setup($pb);
	pb_useragent($pb);
	
	# This isn't part of the bootstrap, but rather page router
	session_start();
	ob_start();
	#pb_router(); # just hand the request to the correct controller; that's all.
	pb_timerOff($pb, 'bootstrap');	
	pb_timerReset($pb,'ALL');	
	pb_debug_dump($pb);
	ob_end_flush();	
}
/******************************************************************
* Function Name: pb_autoload
* Parameters: $autoload_f(array)
* Description: Autoloads a batch of library files
* Return type: TRUE
*******************************************************************/ 
function pb_autoload($autoload_f,$mode='0')
{
	
		foreach ($autoload_f as $key=>$value)
		{
			
			foreach($autoload_f[$key] as $filename) 
			{
				
				$required_file = PB_ROOT . $key . DS . $filename . LIBEXT;
				if(file_exists($required_file))
				{
					require($required_file);
				} else {
					#log_error
				}
			}
			
		}
		
	return(TRUE);	
}

/******************************************************************
* Function Name: pb_router
* Parameters: $type
* Description: Displays the kind of page to be displayed. Two most common types would
* be ADMIN and PAGES, but with the other modules you could have BLOG, REVIEW, ARTICLE.
* It will then be routed to the appropriate CONTROLLER.
* Return type: TRUE
*******************************************************************/ 
function pb_router($type='page') 
{
	
	#whoami ? check subdomain and load site settings
	#$exp = explode('.', $_SERVER['HTTP_HOST']) ;
	#$site = $exp[0];
	
/** from drupal bootstrap file, line 293
function drupal_valid_http_host($host) {
  return preg_match('/^\[?(?:[a-z0-9-:\]_]+\.?)+$/', $host);
}
 * Loads the configuration and sets the base URL, cookie domain, and
 * session name correctly.
 function conf_init() {
	*/
	
	#require('SITE_CONFIG');
	
	pb_debug_add('03', 'pb_router.display()');
	
	#switch is no longer needed if routing based on URL or argument (c)ontroller.
	switch($type) 
	{
	
	case "page":
		
		global $SHOW;
		preint_r($timers);
		
		$SHOW = content_loader();
		css_loader();
		helpers_loader();
		template_loader();
		
		break;
		
	case "admin":
		
		#require(PB_MODELS . DS . 'pb_admin-m.php');
		print "admin.load";
		break;
		
	}

}


/* End of file */
/* Location: ./pb-controllers/bootstrap_c.php */ 