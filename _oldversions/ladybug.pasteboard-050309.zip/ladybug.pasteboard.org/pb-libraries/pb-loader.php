<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		loader_m.php
 * @DESC		loader model: content, css, template, helpers
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com 
 * @FUNCTIONS	
 */
 
 function content_loader() 
{
	
	if(!$_GET[page] || !$_GET[p]) { $_GET[page] = "home"; }
	// Can use ?page or ?p to load the page, so lets check
	if($_GET[p]) $_GET[page] = $_GET[p];

// LOAD THE CONTENT PAGE //
// Check to see if the file exists and then parse the XML //
	$XML_FILE = PB_ROOT . PB_CONTENT . PB_PAGES . $_GET[page] . ".xml";
	
	if(VERSIONOFPHP == 5) {
		if(file_exists($XML_FILE)) {
		$PAGE_OBJ = xmlp5($XML_FILE);
		} else {
		    if(USE404 == "on") {
		    $PAGE_OBJ = xmlp5(PB_ROOT . PB_CONTENT . PB_PAGES . '404.xml');
		    } else {
    	    error(28, 'XML File Not Found', 'pb-content_loader.php', $XML_FILE); 
		    } 
		}
	} else {
		$PAGE_OBJ = xmlp4($XML_FILE);
	}
	
	
	// LOAD EACH XML ELEMENT INTO VARIABLE
	foreach ($PAGE_OBJ as $key => $value) { 
		${strtoupper($key)} = $value;
		$SHOW[strtoupper($key)] .= $PAGE_OBJ->$key;
	}
	
	// SCRUB DATA
	#$SHOW[TITLE] = preg_replace('/&/i', '&amp;', $SHOW[TITLE]);
	$SHOW[TITLE] = htmlentities($SHOW[TITLE]);
	$SHOW[CONTENT] = html_entity_decode($SHOW[CONTENT]);
	#$SHOW[CONTENT] = preg_replace('/&/i', '&amp;', $SHOW[CONTENT]);
		
    // CHECK PAGE STATUS
    if($SHOW[STATUS] == "archived" || $SHOW[STATUS] == "draft" || $SHOW[STATUS] == "hidden") {
         error(48, 'UNABLE TO DISPLAY CONTENT<br />it may be archived or saved as draft', 'pb-content_loader.php', $XML_FILE); 
    }   
    
// SEARCH FOR TEMPLATESNIPS AND REPLACE WITH RESULTS FROM SNIP
	//include( PB_ROOT . PB_LIBRARIES . "pb-helpers_loader.php");
	
	return($SHOW);
}

function css_loader() 
 {
 	global $SHOW;
 			
 // REMOVE the .ext on the end of the file. 
 //	$TEMPLATE_SPLIT = split("\.", $TEMPLATE); 
 //	$TEMPLATE = $TEMPLATE_SPLIT[0];
	
// LOAD THE DEFAULT CSS FILE //
// Check to see if there is a page css file to use //
// looks relatvie to server_root
    
    $CSS_FILE = PB_ROOT . PB_CONTENT . PB_THEMES . THEME . "/css/" . $SHOW[TEMPLATE] . ".css";
	
	if(file_exists($CSS_FILE)) 
	{ 
		$SHOW[CSSFILE] = DS . PB_CONTENT . PB_THEMES . THEME . "/css/" . $SHOW[TEMPLATE] . ".css";
	} else {
	    error(26, 'CSS File Not Found', 'pb-css_loader.php', $CSS_FILE);
	}
	
	// LOAD PAGE CSS IF SPECIFIED AND IF EXISTS
    $PAGE_CSS_FILE = PB_ROOT . PB_CONTENT . PB_ROOT . PB_CONTENT . PB_THEMES . THEME . "/css/" . $SHOW[PAGECSS];
    
 	if($PAGECSS && $PAGECSS != "none") 
 	{
    	
    	if(file_exists($PAGE_CSS_FILE)) 
    	{ 
    		$SHOW[PAGE_CSS] = "@import url(" . PB_ROOT . PB_CONTENT . PB_THEMES . THEME . "/css/" . $SHOW[PAGECSS] . ");";
    	} else {
    	  error(36, 'PAGE-CSS File Not Found', 'pb-css_loader.php', $PAGE_CSS_FILE);   
    	}
    	
	}
// END //
		
}

function helpers_loader()
{

	global $SHOW;
	
// SEARCH FOR CONTENTSIPS AND REPLACE WITH RESULTS FROM SNIP
		#$do = preg_match_all("/{php}(.*){\/php}/U", $CONTENT, $matches); #old structure prior to v1.0.5
		$do = preg_match_all("/\<\?(.*)\?\>/U", $SHOW[CONTENT], $matches);		
			# ("|<[^>]+>(.*)</[^>]+>|U",
			
		foreach ($matches[1] as $key => $value) {  
		
		if($do == true) {
		$functionCall = split("\(", $value);
		$functionName = trim($functionCall[0]);
		$functionParams = substr_replace($functionCall[1],"",-3);
		
		if($functionParams == 0) { $functionParams == ""; }
		
		$CONTENTSNIP_FILE = PB_ROOT . PB_HELPERS . $functionName . ".php";
		
		if(file_exists($CONTENTSNIP_FILE)) {
			include_once($CONTENTSNIP_FILE);
			$returned_value = $functionName($functionParams);
		} else {
			// Eventually log to errors()
		}
		
		// REPLACE THE FUNCTION RESULT IN THE CONTENT VARIABLE

		#$str=$CONTENT; # old content; changing variable to avoid confusion in next statement		
		$CONTENT = str_replace("<? $functionName($functionParams); ?>", $returned_value, $SHOW[CONTENT]); # new content
		$SHOW[CONTENT] = $CONTENT;
		}
		
		}
// END //
}

function template_loader() 
 {
 	
 	global $SHOW;
 	
// LOAD THE TEMPLATE //
// Check to see if there is an alternative template to use //
	
    $TEMPLATE_FILE = PB_ROOT . PB_CONTENT . PB_THEMES . THEME . DS . PB_TEMPLATES . $SHOW[TEMPLATE] . TPLEXT;
    
	if(file_exists($TEMPLATE_FILE)) {  
	    include($TEMPLATE_FILE);
	    #print $LICENSE; 
	} else {
	    error(25, 'File Not Found', 'pb-template_loader.php', $TEMPLATE_FILE);
	}

   
// END // 
  
// SEARCH FOR TEMPLATESNIPS AND REPLACE WITH RESULTS FROM SNIP
// include(ABSPATH . "pb-library/pb-templatesnips_loader.php");
// END //

	return(TRUE);
}