<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		system.php
 * @DESC		contains functions for system-level actions such as file locking,
 			    timer (start/stop), preint_r (print_r replacement), log, user_agent (also config - @array),			
				is_{type}, etc.
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	TRUE
 */

/******************************************************************
* Function Name: pb_timerOn
* Parameters: $tName
* Description: Starts a timer
* Return type: $timers_array
*******************************************************************/ 
function pb_timerOn(&$pb, $tName) 
{	
	
	$stimer = explode( ' ', microtime() );
	$stimer = $stimer[1] + $stimer[0];
	$pb['TIMERS'][$tName] = $stimer;
	
	pb_debug_add(&$pb, '02', 'pb_timer.on(' . $tName . ')');
}

/******************************************************************
* Function Name: pb_timerOff
* Parameters: $tName
* Description: Stops a timer
* Return type: $timer array
*******************************************************************/ 
function pb_timerOff(&$pb, $tName) 
{
	$stimer = (int) $pb['TIMERS'][$tName];
			
	$etimer = explode( ' ', microtime() );
	$etimer = $etimer[1] + $etimer[0];
	$pb['TIMERS'][$tName] = round(($etimer-$stimer), 3);
	
	$pb['TIMERS_RESULT'][$tName] = $pb['TIMERS'][$tName];
	pb_debug_add($pb, '03', 'pb_timer.off(' . $tName . ')');
}

/******************************************************************
* Function Name: pb_timerReset
* Parameters: $tName
* Description: Resets a timer array; if left without args = ALL
* Return type: NULL
*******************************************************************/ 
function pb_timerReset(&$pb, $tName='ALL')
{
	$rTimer = split(',', $tName);
	
	if($rTimer[0] === "ALL") 
	{
		foreach($pb['TIMERS'] as $key => $value)
	 	{
	 		unset($pb['TIMERS'][$key]);
	 		$pb['TIMERS'] = 'reset_ALL';
	 	}
	} else {
		foreach($rTimer as $i) { unset($pb['TIMERS'][$i]); }
	}
	
	pb_debug_add($pb, '04', 'pb_timer.reset(' . $tName . ')');
}

/******************************************************************
* Function Name: pb_site_setup
* Parameters: $pb
* Description: Figures out the site to load and includes settings
* Return type: TRUE
*******************************************************************/ 
function pb_site_setup(&$pb) 
{ 	
	$site = parse_url($_SERVER['HTTP_HOST']);
	$pb['SITE_INFO'] = $site;

		if(file_exists(PB_ROOT . PB_SITES . $pb['SITE_INFO']['path'] . DS . 'configsite.php'))
		{
			$pb['SITE_INFO']['is_custom'] = 'TRUE';
			$pb['SITE_INFO']['config_valid'] = 'TRUE';
			require(PB_ROOT . PB_SITES . $pb['SITE_INFO']['path'] . DS . 'configsite.php');
			pb_debug_add($pb, '08', 'pb_site_setup.config.loaded(' . $pb['SITE_INFO']['path'] . ')');
		} else {
			if(file_exists(PB_ROOT . PB_SITES . 'default' . DS . 'configsite.php'))
			{
				$pb['SITE_INFO']['is_default'] = 'TRUE';
				$pb['SITE_INFO']['config_valid'] = 'TRUE';
				$pb['SITE_INFO']['path'] = 'default';
				require(PB_ROOT . PB_SITES . $pb['SITE_INFO']['path'] . DS . 'configsite.php');
				pb_debug_add($pb, '07', 'pb_site_setup.config.loaded(' . $pb['SITE_INFO']['path'] . ')');
			}
		}
	
	pb_debug_add($pb, '05', 'pb_site_setup.done(' . $pb['SITE_INFO']['path'] . ')');
}

/******************************************************************
* Function Name: preint_r
* Parameters: $value
* Description: Formats print_r with <pre> statement to make pretty
* Return type: TRUE
*******************************************************************/ 
function preint_r($value, $ret=FALSE) 
{
	
	if($ret == FALSE) 
	{
		print "<pre>";
		print_r($value);
		print "</pre>";
	} else {
		$str = print_r($value);
		return($str);
	}
	
}

/******************************************************************
* Function Name: maintenance
* Parameters: $value
* Description: forces site ro display a static maintenance page (not part of theme engine)
* Return type: TRUE
*******************************************************************/ 
function pb_maintenance() 
{
	
	if(MAINTENANCE == TRUE) 
	{	
		header('Location: maintenance.php');
	}
}

/******************************************************************
* Function Name: pb_useragent
* Parameters: 
* Description: Cleans URI of any strange characters.
* files if necessary.
* Return type: TRUE
*******************************************************************/ 
function pb_useragent(&$pb)
{
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$pb['SITE_INFO']['agent'] = $useragent;
	# use codeignitor as example to set $browser, $version, $platform, $mobile;
	# put into the pb_array
	pb_debug_add($pb, '06', 'pb_useragent.found(' . ')');

}

/******************************************************************
* Function Name: pb_debug_add
* Parameters: 
* Description: Displays simple debug 
* files if necessary.
* Return type: TRUE
*******************************************************************/ 
function pb_debug_add(&$pb, $ecode, $emsg)
{
	if(isSet($pb['DEBUG'])) { $i = count($pb['DEBUG']); } else { $i=0; }
	$pb['DEBUG']['c_' . $i] = $emsg . ".(e" . $ecode . ")";
}

/******************************************************************
* Function Name: pb_debug_show
* Parameters: 
* Description: Displays simple debug 
* files if necessary.
* Return type: TRUE
*******************************************************************/ 
function pb_debug_dump(&$pb)
{	
	print PB_NAME . " | " . date("F j, Y, g:i a") . "<hr />";
	preint_r($pb);
	print "<hr />";
	print "scaffolding complete";
}

/* End of file */
/* Location: ./pb-libraries/pb-system.php */