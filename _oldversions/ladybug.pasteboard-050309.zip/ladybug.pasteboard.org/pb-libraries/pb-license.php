<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		start_c.php
 * @DESC		initializes the pasteboard system
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	none
 */
 
 function license() {
    GLOBAL $TEMPLATE;
        
        $CON = "\n\n<!-- powered by " . strtoupper(PB_NAME) . " -->\n";
        $CON .= "<!-- (c)opyright " . date(Y) . ", " . PB_DEVELOPER . " -->\n";
        $CON .= "<!-- " . THEME . "/" . $TEMPLATE . ".tpl -->\n";
        $CON .= "<!-- v. " . PB_VERSION . " -->\n";
        
        return($CON);
        
}

/* End of file */
/* Location: ./pb-content/config/pb-configsite.php */
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */