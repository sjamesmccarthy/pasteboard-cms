#Main table that stores content
DROP TABLE IF EXISTS `pb_pages`;
create table pb_pages(
	pages_id int(10) NOT NULL AUTO_INCREMENT,
	fk_user_id INT(10),
	pages_title VARCHAR(255),
	pages_body LONGTEXT,
	pages_css VARCHAR(255),
	pages_template VARCHAR(255),
	pages_status INT(4),
	pages_lastupate DATETIME,
	pages_password VARCHAR(64),	
	PRIMARY KEY (pages_id)
) Type=MyISAM comment 'stores content';

#Keyword taxonomy
DROP TABLE IF EXISTS `pb_keywords`;
create table pb_keywords(
	keywords_id INT(10) NOT NULL AUTO_INCREMENT,
	keywords_name VARCHAR(255),
	PRIMARY KEY (keywords_id)
) Type=MyISAM comment 'taxonomy dictionary';

#Keyword taxonomy relationships
DROP TABLE IF EXISTS `pb_keywords_taxonomy`;
create table pb_keywords_taxonomy(
	fk_keywords_id INT(10) NOT NULL AUTO_INCREMENT,
	fk_pages_id INT(10)
) Type=MyISAM comment 'taxonomy link table';

#(http-equiv/name/scheme) http://www.w3schools.com/tags/tag_meta.asp
DROP TABLE IF EXISTS `pb_pages_meta`;
create table pb_pages_meta(
	pages_meta_id INT(10) NOT NULL AUTO_INCREMENT,
	fk_pages_id INT(10),
	pages_meta_key VARCHAR(255), 
	pages_meta_value LONGTEXT,
	pages_meta_active INT(1),	
	PRIMARY KEY (pages_meta_id)
) Type=MyISAM comment 'meta data for pages';

#Limit history in CONFIG_SETTING (50 revisions).
DROP TABLE IF EXISTS `pb_pages_history`;
create table pb_pages_history(
	pages_history_id INT(10),
	fk_pages_id INT(10),
	fk_user_id INT(10),
	pages_history_title VARCHAR(255),
	pages_history_body LONGTEXT,
	pages_history_css VARCHAR(255),
	pages_history_template VARCHAR(255),
	pages_history_status INT(4),
	pages_history_lastupate DATETIME,
	pages_history_password VARCHAR(64),	
	PRIMARY KEY (pages_history_id)
) Type=MyISAM comment 'history_pages for backup';

#(http-equiv/name/scheme) http://www.w3schools.com/tags/tag_meta.asp
DROP TABLE IF EXISTS `pb_pages_history_meta`;
create table pb_pages_history_meta(
	pages_history_meta_id INT(10) NOT NULL AUTO_INCREMENT,
	fk_pages_id INT(10),
	pages_history_meta_key VARCHAR(255), 
	pages_history_meta_value LONGTEXT,
	pages_history_meta_active INT(1),	
	PRIMARY KEY (pages_history_meta_id)
) Type=MyISAM comment 'history_meta data for backup';

#pb_users
DROP TABLE IF EXISTS `pb_users`;
create table pb_users(
	user_id int(10) NOT NULL AUTO_INCREMENT,
	fk_roles_id INT(10),
	user_login VARCHAR(32),
	user_password VARCHAR(64),
	user_email VARCHAR(255),
	user_first_nameVARCHAR(255),
	user_last_name VARCHAR(255),
	user_activation_key VARCHAR(64),
	user_registered DATETIME,
	user_hint VARCHAR(255),
	user_hint_answer LONGTEXT,
	user_status INT(1),
	user_last_login DATETIME,
	PRIMARY KEY (user_id)
) Type=MyISAM comment 'list of all users regardless of role';

#pb_users_roles: Budda(rwx+), Admin(rwx), Editor(rw+), Writer(rw-), User(r--), Vendor, Advertiser, Partner
DROP TABLE IF EXISTS `pb_users_roles`;
create table pb_users_roles(
	roles_id INT(10) NOT NULL AUTO_INCREMENT,
	fk_user_id INT(10),
	roles_r INT(1),
	roles_w INT(1),
	roles_x INT(1),
	roles_b INT(1),
	PRIMARY KEY (roles_id)	
) Type=MyISAM comment 'roles and permissions for users';

#pb_users_meta
DROP TABLE IF EXISTS `pb_users_meta`;
create table pb_users_meta(
	users_meta_id INT(10) NOT NULL AUTO_INCREMENT,
	fk_user_id INT(10),
	users_meta_key VARCHAR(255),
	users_meta_value LONGTEXT,
	users_meta_active INT(1), 
	PRIMARY KEY (users_meta_id)
) Type=MyISAM comment 'meta data for users';

