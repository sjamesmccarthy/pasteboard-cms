<?

/*
    
MAILTO=yourname@yourdomain.com
41 04 * * 1 /save/whales -v 
The above crontab will execute the script "whales -v" from your "/save" directory every Monday morning at 4:41AM.

0 0 * * * /file = midnight of everyday of every month.

*   *   *   *   *  command to be executed
-   -   -   -   -
|   |   |   |   |
|   |   |   |   +----- day of week (0 - 6) (Sunday=0)
|   |   |   +------- month (1 - 12)
|   |   +--------- day of month (1 - 31)
|   +----------- hour (0 - 23)
+------------- min (0 - 59)

*/

/* End of file */
/* Location: ./pb-scripts/cron.php */