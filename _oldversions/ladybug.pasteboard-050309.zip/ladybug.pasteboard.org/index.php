<? 

/** 
 * @FILE		index.php
 * @DESC		short and sweet, loads the front-end-controller 
 * @PACKAGE		PASTEBOARD
 * @COPYRIGHT	See license.pdf
 */

define('PB-START', 'TRUE');

# Load the front-end-controller
require('./pb-libraries/pb-bootstrap.php');
pb_bootstrap();

/* End of file */
/* Location: index.php */