<?php

if ( ! defined('PB-START')) exit('No direct script access allowed');

/*
// -------------------------------------------------------------------
// SNIP_CHECKLOGIN()
// -------------------------------------------------------------------
// Returns a different thank you result so this thankyou.xml file can
// be utilized as a template for multiple forms. 
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// <? snip_thankyouresponse(contact); ?>
// snip_thankyouresponse(file_name)
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/

function snip_thankyouresponse($param = '0') {
 		
 		# put a file in the plugin folder that stores return information 
 		# to make each for use a single thankyou.xml template and not have
 		# to reproduce extraineous code.
 		
		fopen(pathtofile . '_thankyou.php');
		# redirect /?p=thankyou&form=contact
 		# pathtodir ABSPATH . PBROOT . 'plugins/' . $_REQUEST[form] . '_mgr/' 
 		# file $_REQUEST[form] . '_thankyou.php'
 		
 			
 		# readfile()
 		# return filecontent() through $snippet
 		
 		if($_REQUEST[form]  == "share") {
 		$snippet = "Thanks for sharing karenskommune.org with your friends!";
 		}
 		if($_REQUEST[form]  == "contact") {
 		$snippet = "Someone will return your message via email or phone as quickly as possible.";
 		}
 		 	
 	return($snippet);
 	// Returns the output of the snippet to pb-contentsnips_loader.php
 	
 }

/* End of file */
/* Location: ./pb-content/library/snip_thankyouresponse.php */