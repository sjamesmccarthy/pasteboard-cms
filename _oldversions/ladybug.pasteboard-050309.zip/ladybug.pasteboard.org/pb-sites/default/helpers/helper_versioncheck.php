<?

if ( ! defined('PB-START')) exit('No direct script access allowed');

/*
// -------------------------------------------------------------------
// snip_versioncheck()
// -------------------------------------------------------------------
// This file basically checks version against an RSS file on the
// pasteboard server.
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// <? snip_versioncheck(); ?>
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/

function snip_versioncheck($param) {
    GLOBAL $CONFIG;
    
$page_content = "PACKAGE: " . PB_NAME . "<br /><br />Site: " . $CONFIG[SITE_NAME] . "<br />Your Version: " . PB_VERSION;
$page_content .= "<br />";

#$url = 'http://www.pasteboard.org/pb-rss/updater.xml';
$xmlpage = file_get_contents(PB_GETVERSIONURL);
		
		// FOR PHP5
		$PAGE_OBJ = new SimpleXMLElement($xmlpage);
		$CURRENT_VERSION = $PAGE_OBJ->version;
		
		// FOR PHP4
		// NOT AVAILABLE AT THIS TIME
		
		// CHECK VERSIONING
		if($PAGE_OBJ->version == PB_VERSION) { 
		$h="150px";
		$STATUS="CURRENT - NO UPDATES AVAILABLE"; $color = "#006600"; $colorfill = "#99CC99"; 
		}		
		else { 
		$h="180px";
		$STATUS="<b>UPDATE AVAILABLE to VERSION " . $PAGE_OBJ->version . "</b>"; $color = "#CC0000"; $colorfill = "#FF9999";
		$STATUS .= "<br /><p style=\"font-size: 9pt;\">visit pasteboard.org to <a href=\"" . $PAGE_OBJ->download . "\">download this version</a> or <a href=\"/?p=contact\">contact</a> your sales representative</p>";
		}

$page_content .= "<br />$STATUS <br />";

echo "<style type=\"text/css\">
<!--
#box { 
	width:738px;
	height: $h;
	padding: 15px;
	margin: 0;
	border-top: 1px solid $color;
	border-right: 1px solid $color;
	border-bottom: 1px solid $color;
	border-left: 1px solid $color;
	background: $colorfill;
}
#box p {
	margin: 5px;
}
-->
</style>";
$snippet = "<p><!-- --></p><div id=\"box\"><p>$page_content</p></div><p><!-- --></p>";

return($snippet);
}

/* End of file */
/* Location: ./pb-content/snip_versioncheck.php */