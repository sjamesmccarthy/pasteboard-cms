<?php

if ( ! defined('PB-START')) exit('No direct script access allowed');

/*
// -------------------------------------------------------------------
// SNIP_EXAMPLE()
// -------------------------------------------------------------------
// This file is an example structure of a user-code-snippet. 
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// <? snip_example(hw); ?>
// snip_example = name of corresponding function and file
// (hw) = parameters passed to function separated by comma
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/

 function helper_example($param) {
 	
 		GLOBAL $CONFIG; 
 		switch($param) {
		
		case "hw":
		$snippet = "content_helpers =TRUE | ";
		$snippet .= "Version " . PB_VERSION . " (ladybug)<br />website for " . SITE_COMPANY_NAME;
		break;
 		
 		default:
 		$snippet = "Error : snip_example ($param)";
 		break;
 	}
 	
 	return($snippet);
 	// Returns the output of the snippet to pb-contentsnips_loader.php
 	
 }

/* End of file */
/* Location: ./pb-content/library/snip_example.php */