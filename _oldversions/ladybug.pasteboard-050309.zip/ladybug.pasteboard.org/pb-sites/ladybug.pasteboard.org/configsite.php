<?php 
if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		pb-configsite.php
 * @DESC		site specific configurations settings.
				This file defines configuration data for the website, NOT for 
				pasteboard and stores the data in a define('] array that can be
				easily passed through the framework, applications, plugins, etc.
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 * @FUNCTIONS	none
 * @USAGE		Modifications of this file can be done through the /admin area.
				However, the /admin area only supports the variables below. If you
				add any new vairables to the array they will be erased if the /admin
				tool is used to change anything.
 * @HISTORY		SJM - 04/02/09 - Made define statements so no worry about variable scope		
 				SJM - 01/06/09 - Added new header/footer comments
 */
 
define('SITE_COMPANY_NAME', 'pasteboard Group');
define('SITE_COMPANY_CONTACT_NAME', 'James McCarthy');
define('SITE_COMPANY_CONTACT_EMAIL', 'jmccarthy@projectwebstart.com');
define('SITE_COMPANY_CONTACT_PHONE', '(775) 815-9726');
define('SITE_NAME', 'pasteboard.cms LADYBUG build');
define('SITE_SUPPORTEMAIL', 'webemail@pasteboard.org');
define('SITE_URL', 'http://ladybug.pasteboard.org');
define('SITE_DIR', 'sites/_pasteboard-dev-alpha/');
define('GOOGLE_ANALYTICS', '');
define('GOOGLE_SITE_VALIDATION', '');
define('GOOGLE_SITEMAP', '');
define('GOOGLE_ADS', '');
define('YAHOO_SITEMAP', '');
define('DB_NAME', 'pasteboardev');
define('DB_HOST', 'pasteboard.org');
define('DB_USER', 'pasteboard');
define('DB_PSWD', 'kandl3x+en1d');
define('SERIALHASH', '09-16-08-16:43');
define('HTACCESS', 'public-access');
define('DEBUG', 'on');
define('THEME', 'pasteboard_v2');
define('ADMINTHEME', 'purple_haze');
define('USE404', 'on');
define('USEBACKUP', 'on');
define('SITE_LANGUAGE', 'en-us');
define('ROBOTS_FILE', 'allow_robots');
date_default_timezone_set('America/Los_Angeles');

/* End of file */
/* Location: ./pb-config/pb-configsite.php */