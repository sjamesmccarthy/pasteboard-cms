<?
$arr = parse_url($_SERVER['HTTP_HOST']);
print "<pre>";
print_r($arr);
?>