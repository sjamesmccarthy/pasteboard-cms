function error_chk() 
{

var missing = "";
var ve = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/

if(!document.forms[0].name.value || document.forms[0].name.value == 'name') { missing += " \n- Your Name"; }
if(!document.forms[0].subject.value) { missing += " \n- Your Subject"; }

if (!document.forms[0].email.value.match(ve)) { 
missing += " \n- Email Bad or Missing"; }

if( missing ){ 
alert ("Missing entries for the following fields:\n" + missing )
return false;
}
	
}	