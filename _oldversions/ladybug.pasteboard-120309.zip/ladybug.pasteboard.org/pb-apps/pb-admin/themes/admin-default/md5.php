<?

if($_POST) {
	$SN = md5($_POST[string]);
	#$SN = join("-", str_split($SN, 4));
	#$SN = strtoupper($SN);
	
	print "<p>MD5 Hash:<br />" . $SN . "</p>";
	#print "<p>Creating a serial number really does nothing. You still need to contact your webmaster. You had fun though, right?</p><p><a href=\"/pb-admin/\">Back Home</a></p>";
	
} else {

print <<<END
<form action="md5.php" method="post" name="md5form" id="md5form">
<p><label for="email">String:</label><br />
<input type="text" name="string" size="50">
<input name="Submit" type="submit" class="button" value="Serialize" /></p>
</form>
END;

}
 
?>


