<?

/**
 * @FILE		admin-functions.php
 * @DESC		commonly used functions for admin area
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5 
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */

function outputXML($XML_FILE) {

	#$_POST[content] =htmlentities($_POST[content]);
	$_POST[content] =stripslashes($_POST[content]);
	
	$_POST[content] = ms_charfix($_POST[content]);
	$_POST[title] =htmlentities($_POST[title]);
  		
	// FORMAT THE XML FILE HERE
	ksort($_POST); // Just sorting alphabetically by key
		
	$NewXMLfile = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n";
	$NewXMLfile .= "<page>\n";
		
	foreach ($_POST as $key=>$value) {
			
	if($key == "content") { $CDATA_OPEN ="<![CDATA["; $CDATA_CLOSE ="]]>"; } 
	else { unset($CDATA_OPEN); unset($CDATA_CLOSE); }
			
	if($key == "lastupdate") { $value = MYSQLDATETIME; } 
						
	$NewXMLfile .= "<$key>$CDATA_OPEN" . $value . "$CDATA_CLOSE</$key>\n";
	}
		
	$NewXMLfile .= "</page>";
		
	// REWRITE THE FILE
	$fh = fopen($XML_FILE, "w");
	$result = fwrite($fh, $NewXMLfile);
  	fclose($fh); 

}

function ms_charfix($string) {
		// replaces Extended ASCII Codes with html_equivs (MS Word Fix)
        $trans_array = array();
        for ($i=128; $i<255; $i++) {
           $trans_array[chr($i)] = "&#" . $i . ";";
        }

        $ms_fixed = strtr($string, $trans_array);

        return $ms_fixed; 
}

function versioncheck() {

    # Turn off errors so that it won't show the URL not found error
    error_reporting(0);
    
    if( false == ($xmlpage=file_get_contents( PB_GETVERSIONURL ))) {
        $NEWVERSION = "1|Failed";  
    } else {
	#$xmlpage = file_get_contents(PB_GETVERSIONURL);
	
	// FOR PHP5 ONLY; NEED TO UPGRADE FOR PHP4 SUPPORT
	$PAGE_OBJ = new SimpleXMLElement($xmlpage);
	$CURRENT_VERSION = $PAGE_OBJ->version;
	settype($CURRENT_VERSION, "int");
		
	// CHECK VERSIONING
	if($CURRENT_VERSION >PB_VERSION) {
	    $NEWVERSION = "0|$CURRENT_VERSION"; 		
	}		
	else { 
	    $NEWVERSION = "1|$CURRENT_VERSION"; 
	}

    }
	return($NEWVERSION);	
}

function build_subnav() {
	
	$FORM_FILE = ABSPATH . "pb-admin/admin-forms/" . $_GET[form] . "_subnav.php";

	if(file_exists($FORM_FILE)) {
		include_once($FORM_FILE);
	} else {
		// Eventually log to errors()
	}
	
}

function build_form($FILE) {
	
	if(count($_GET == 0) && !$FILE) { $FILE = "dashboard"; }
	
	$FORM_FILE = ABSPATH . "pb-admin/admin-forms/" . $FILE . ".php";
		
		if(file_exists($FORM_FILE)) {
			include_once($FORM_FILE);
		} else {
			// Eventually log to errors()
			echo "File Not Found: $FORM_FILE";
		}
		
	
}

function get_pages($DIR) {

	// GET THE DIRECTORY LISTING OF THE /pages DIRECTORY
	$handle=opendir($DIR);
	
	while(false!==($file=readdir($handle))){
	
		// put this into an exceptions array
		if($file != "." && $file != ".."){
		$files[]="$file";
		}
	}
	closedir($handle);
	if(isSet($files)) { sort($files); }
	
	return($files);
	
}

function build_sysadmin() {
	GLOBAL $CONFIG;
	
	${strtoupper($_GET[form])} = "SELECTED";
	
	print " &raquo;
	<select id=\"options\" name=\"sysadmin\" onchange=\"location.href=('" . $CONFIG[SITE_URL];
	print "/pb-admin/?form=' + document.forms[0].options.value);\">"; 
	print "
	<option $SYSADMIN value=\"dashboard\">SYSADMIN TOOLS</option>
	<option $SYSADMIN value=\"dashboard\">- - - - - - - -</option>
	<option $USRMGT value=\"usrmgt\">Manage Users</option>
	<option $CONFIGSETTINGS value=\"configsettings\">Configuration Settings</option>
	</select>";
}

?>