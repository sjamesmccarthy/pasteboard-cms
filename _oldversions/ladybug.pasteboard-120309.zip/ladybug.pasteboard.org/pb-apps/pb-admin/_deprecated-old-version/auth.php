<?
session_start();
require("admin-library/admin-start.php");
require_once('admin-library/admin-authenticate.php');

#include file to login.php @ theme level
include("admin-themes/" . $CONFIG[ADMINTHEME] . "/login.php");

?>