<?
GLOBAL $CONFIG;

if(!$CONFIG[GOOGLE_ADS]) { $CONFIG[GOOGLE_ADS]= "not installed | <a target=\"_new\" href=\"https://www.google.com/adsense/g-app-single-1\">Signup Free</a>"; }
if(!$CONFIG[GOOGLE_ANALYTICS]) { $CONFIG[GOOGLE_ANALYTICS]= "not activated | <a target=\"_new\" href=\"https://www.google.com/accounts/NewAccount?service=analytics&hl=en&continue=http://www.google.com/analytics/home/%3Fet%3Dreset\">Signup Free</a>"; }
if(!$CONFIG[GOOGLE_SITE_VALIDATION]) { $CONFIG[GOOGLE_SITE_VALIDATION] = "not found"; } 

$result =versioncheck();
$NEWVERSION = split("\|", $result);
	if($NEWVERSION[0] == 0) {
		$VERSIONRESULT ="<b style=\"font-size: small; background: yellow;\">UPDATE AVAILABLE to v.$NEWVERSION[1]</b>";
	} else {
		$VERSIONRESULT ="Your version is up-to-date";
	}
	
$textbox = "
<div id=\"content\"> <!-- content -->
";
	
$textbox .= "
<h1>welcome to " . PB_NAME . " </h1>
<p class=\"title\">The easiest and most affordable way to get your business online.</p>";
$textbox .= "
<ul>
<p>Use these links to get started</p>
<li> <a href=\"?form=pages&m=add\">Create a new web page</a></li>
<li> <a href=\"?form=pages\">Edit an existing webapge</a></li>
<li> <a href=\"?form=profile\">Update your profile or change your password</a></li>
<li> <a href=\"http://analytics.google.com\">Check your Google Analytics Account</a></li>
</ul>

<ul>
<p>Support Links</p>
<li> <a href=\"files/pasteboard_manual.pdf\">Read pasteboard.cms user manual (PDF 1.1MB)</a></li>
<li> <a href=\"http://groups.google.com/group/pasteboard?hl=en\">Join pasteboard's google group for support</a>
<li> <a href=\"/?p=contact\">Email us (Create a Support Ticket)</a></li>
</ul>

<ul>
<p>Earn Maintenance Credit!</p>
<li> <a href=\"http://www.projectwebstart.com/?p=getpaid50bucks\">Earn $50 in maintenance credit &mdash; Referr a friend!</a></li>
</ul>


<div id=\"referr\">
<script src=\"admin-js/err_contact.js\"  type=\"text/javascript\"></script>

<form action=\"../pb-content/plugins/contact_mgr/contact_mgr.php\" method=\"post\" id=\"contact_form\" onsubmit=\"return error_chk('contact_form');\">

<fieldset>
<!-- recipient anti-spam format: username@domain.com = username;mac-dot-com -->
<input type=\"hidden\" name=\"recipient\" value=\"james.mccarthy;mac-dot-com\" />
<input type=\"hidden\" name=\"redirect\" value=\"/pb-admin/\" />
<input type=\"hidden\" name=\"subject\" value=\"Lets Meet and talk web stuff (pb-dashboard)\" />
<input type=\"hidden\" name=\"email\" value=\"noemail@domain.com\" />

<input type=\"text\" name=\"name\" size=\"15\" value=\"name\" onclick=\"this.form.name.value='';\" /> <input type=\"text\" name=\"note\" size=\"15\" value=\"email or phone\" onclick=\"this.form.note.value='';\" /> <input type=\"submit\" value=\"Send Your Referral\" />
</fieldset>

</form>
</div><!-- id:referr -->
";

/*
$textbox .= "<h3>Development Blog</h3>
<p>Currently, there is no blog available. Once the blog is available you will be able to read the latest news about the " . PB_NAME . "and other content about publishing online.</p>
<p>";
$textbox .= "<h3>Cookie Jar </h3>
<p>Here is a little random quote from the cookie jar.</p>
";
*/

// PULL IN THE RELEASE FEED from pasteboard.org/_dashboard
	$xmlpage = file_get_contents('http://www.pasteboard.org/_dashboard/releasenotes.xml');
		
	// FOR PHP5 ONLY; NEED TO UPGRADE FOR PHP4 SUPPORT
	$xml = new SimpleXMLElement($xmlpage);
	
	$textbox .= "<div id=\"releasenotes\">";
	$textbox .=  "<ul><p>Release Notes for v." . $xml->version . "<br />";
	$textbox .= $VERSIONRESULT . "</p>";
	foreach($xml->notes[0] as $result)
	{
		$textbox .= "<li>";
		$textbox .=  $result->type . " / " . $result->change;
		$textbox .=  "</li>";
	}

	$textbox .= "</ul>";
	$textbox .= "</div><!-- id:releasenotes -->";

$textbox .= "</div><!-- id:content -->";

$textbox .= "
<div id=\"sidebar\"> <!-- sidebar -->
<div id=\"sidebar_details\">
<p class=\"heading\">SITE INFORMATION</p>
<p>" . 
PB_NAME . " v" . PB_VERSION .
"</p>

<p class=\"versioncheck\">
$VERSIONRESULT
</p>
<hr />

<p>
<b>Site Name</b><br />
$CONFIG[SITE_NAME]
</p>

<p>
<b>Support Email</b><br /> " . substr($CONFIG[SITE_SUPPORTEMAIL], 0,-8) . "...
</p>

<p>
<b>Site URL</b><br />" . substr($CONFIG[SITE_URL], 11) . "
</p>

<p>
<b>Active Theme (PAGES)</b><br />
$CONFIG[THEME]
</p>

<p>
<b>Active Theme (Admin)</b><br />
$CONFIG[ADMINTHEME]
</p>

<p>
<b>Site Language</b><br />
$CONFIG[SITE_LANGUAGE]
</p>

<hr />

<p>
<b>Google Analytics</b><br />
$CONFIG[GOOGLE_ANALYTICS]
</p>

<p>
<b>Google AdSense</b><br />
$CONFIG[GOOGLE_ADS]
</p>

<p>
<b>Google Verification Key</b><br />
$CONFIG[GOOGLE_SITE_VALIDATION]
</p>
</div> 

</div><!-- sidebar -->";

print $textbox;
?>