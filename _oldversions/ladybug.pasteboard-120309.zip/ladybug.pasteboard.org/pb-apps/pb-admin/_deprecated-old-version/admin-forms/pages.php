<?
		
switch($_GET[m]) {

	case "add":
		require_once(ABSPATH . 'pb-admin/admin-forms/pages_form.php');
		$result = display_form('1');
		print $result;
		break;
	
	case "edit":
		
		// MOVE THIS INTO A FUNCTION, OR DOES THAT ALREADY EXIST?
		$XML_FILE = ABSPATH . PB_ROOT . 'pages/' . $_GET[xml] . '.xml';
	
		if(VERSIONOFPHP == 5) {
			$PAGE_OBJ = xmlp5($XML_FILE);
		} else {
			$PAGE_OBJ = xmlp4($XML_FILE);
		}
		
		$PAGE_OBJ[XML] = $_GET[xml];
		require_once(ABSPATH . 'pb-admin/admin-forms/pages_form.php');
		$page = display_form('2', $PAGE_OBJ);
		print $page;
		break;
	
	case "create":
		$result = create_pages();
		break;
		
	case "update":
		$result = update_pages();
		break;
	
	case "delete":
		$result = delete_pages();
		break;
	
	case "history":
        $dirList = get_pages(ABSPATH . PB_ROOT . 'pages_history/');
		$result = history_pages($dirList);
		break;
	
	case "rename":
		$result = rename_pages();
		break;
	
	default:
		require_once(ABSPATH . 'pb-admin/admin-forms/pages_list.php');
		$dirList = get_pages(ABSPATH . PAGESPATH);
		$result = display_listings($dirList);
		print $result;
		break;
	
}

function history_pages($dirList) {
    
    switch($_GET[a]) {
        
        case "preview":
            $XML_SPLIT = split("_", $_GET[xml]);
            $XML = split("\.", $XML_SPLIT[0]);
            
            $PAGE_LOAD = file_get_contents(ABSPATH . PB_ROOT . '/pages_history/' . $_GET[xml]);
            $CONTENT =htmlentities($PAGE_LOAD, ENT_QUOTES);
            $CONTENT =str_replace("\n", "<br />", $CONTENT);
            
            print "
            <div id=\"content\">
            <a href=\"?form=pages&m=history&xml=$XML[0]\">Cancel</a> | <a href=\"?form=pages&m=history&a=restore&xml=$_GET[xml]\">Restore</a> | <b>$_GET[xml]</b><br />
            This view is only intended as a raw source code view to determine if this is the file you wish to restore.
            <hr />
            <div id=\"preview_zone\">
            $CONTENT
            </div>
            
            </div>
            ";
            
            
            exit;
            break;
            
        case "restore":
            print "<div id=\"content\">restoring file $_GET[xml]";
            $RESTORE_FILE = ABSPATH . PB_ROOT . 'pages_history/' . $_GET[xml];
            $REPLACE_FILE = split("_", $_GET[xml]);
            $REPLACE_FILE = ABSPATH . PB_ROOT . 'pages/' . $REPLACE_FILE[0];
            copy($RESTORE_FILE, $REPLACE_FILE);
            unlink($RESTORE_FILE);
            print "<br />restored<br /><a href=\"?form=pages\">back to pages</a></div>";
            exit;
            break;
        
        case "delete":         
            // CHECK THAT FILE EXISTS
            print "<div id=\"content\">deleting file $_GET[xml]";
            $DELETE_FILE = ABSPATH . PB_ROOT . 'pages_history/' . $_GET[xml];
            unlink($DELETE_FILE);
            print "<br />deleted<br /><a href=\"?form=pages\">back to pages</a></div>";
            exit;
            break;
        
        case "clear":
           
            print "<div id=\"content\">
            <p>clearing (removing) Backup history for $_GET[xml].xml<br />";
            
            foreach ($dirList as $key=>$value) {
            // GET DIR LISTING OF ALL WITH FILE NAME, PUT INTO ARRAY
                if (preg_match("/$_GET[xml].xml/i", $value)) { 
                unlink(ABSPATH . PB_ROOT . 'pages_history/' . $value);
                }
            }
            
            print "<b>success</b></p><p><a href=\"?form=pages\">back to pages</a></p></div>";
            exit;
            break;
        
        case "clear-all":
           
            print "<div id=\"content\">
            <p><b>clearing (deleting) backup history for everything</b><br />";
            
            foreach ($dirList as $key=>$value) {
                unlink(ABSPATH . PB_ROOT . 'pages_history/' . $value);
                print "<span style=\"font-size: xx-small\">removed $value -- </span>";
                $i++;
            }
            
            print "<b>success ($i files)</b></p><p><a href=\"?form=pages\">back to pages</a></p></div>";
            exit;
            break;
            
        default:
        
         GLOBAL $CONFIG;
    	if(isSet($dirList)) { asort($dirList); }
    
    echo "
	<div id=\"content\"><!-- content -->
	<h1>History for: $_GET[xml].xml </h1>
	<p class=\"title\">Historical pages can be viewed, restored or deleted.</p>";
	
    echo "
    <table width=\"100%\">
    <tr align=\"center\" bgcolor=\"#000\" style=\"background: #000000; color:white;\">
    <th width=\"50%\" align=\"left\">Filename</th>
    <th width=\"25%\">Date & Time</th>
    <th width=\"25%\">Action</th>
    </tr>";
    
    if(isSet($dirList)) {
        arsort($dirList);
        
        foreach($dirList as $key=>$value) {
          
            if (preg_match("/$_GET[xml].xml/i", $value)) {  
               $ORIGINAL_FILE = $value;
               $value_split = split("_", $value);
               
               print "<tr bgcolor=\"#CCCCCC\" align=\"center\">
               <td width=\"50%\" align=\"left\" style=\"padding: 10px\"><a href=\"?form=pages&m=history&a=preview&xml=$value\">$value_split[0]</a><br /><span style=\"font-size: 8pt;\">file: $value</span></td>
               <td width=\"25%\" style=\"padding: 5px; font-size: 10px;\">$value_split[1] $value_split[2]</td>
               <td width=\"25%\" style=\"padding: 5px\"><a onclick=\"return confirm('Are you sure you want to restore this file?')\"href=\"?form=pages&m=history&a=restore&xml=$value\">restore</a> | <a onclick=\"return confirm('Are you sure you want to delete?')\" href=\"?form=pages&m=history&a=delete&xml=$value\">delete</a></td>
               </tr>";
                
               $count++;
            } 
             
        }
    }
    
        if($count == 0) { 
            print "<tr>
           <td colspan=\"3\"><p style=\"margin-top: 10px;\"><b>No backup files found</b><br />This could be because you haven't edited the file, <b>$_GET[xml].xml</b>, since creating it, or your \"PAGES Backup\" setting is turned off.</td>
           </tr>";
        }
    
    echo "
    </table>
    
    <div>
    <p>&nbsp;</p>
    </div>
    
    </div>
    ";  
    
    print "
    <div id=\"sidebar\"> <!-- sidebar -->
    <div id=\"sidebar_details\">
    <p class=\"heading\">PAGES (History View)</p>
    
    <p>
    <a href=\"?form=pages\">Cancel</a><br />
    <a onclick=\"return confirm('Are you sure you want to clear this history?')\" href=\"?form=pages&m=history&a=clear&xml=$_GET[xml]\">Clear This Backup History</a>
    </p>
    <!-- <p style=\"font-size: 8pt; margin-left: 20px; margin-top: -15px;\">(no other histories will be effected)</p> -->
    </p>
    </div>
    </div>";
    
        break;    
    }


}

function create_pages() {
	
	// CHECK TO SEE IF FILENAME WAS ENTERED
	if(!$_POST[xml]) { $_POST[xml] = time(); }
	
	// CLEAN FILE NAME OF SPACES AND SYMBOLS
	$_POST[xml] = preg_replace("/[^a-zA-Z0-9s]/", "", $_POST[xml]);
		
	// CREATE FILE FOR outputXML
	$ORIGINAL_FILE = ABSPATH . PB_ROOT . 'pages/' . $_POST[xml] . '.xml';
			
	// ERROR CHECK FORM QUICKLY; no VALUES MUST EQUAL NULL VALUES
	foreach ($_POST as $key=>$value) {
		if(!$_POST[$key]) { $_POST[$key] = "";}
	}
	
	// USE THE outputXML function in admin-functions.php
	outputXML($ORIGINAL_FILE); 
			
	// SEND BACK TO PAGES INDEX
	header('location:?form=pages');
	exit;

}

function rename_pages() {
	
	if($_GET[a] == "true") {
		
		// CHECK TO SEE IF FILE EXTENSION EXISTS IF SO REMOVE IT
		$result = explode('.', $_POST[NFILE]);
		if($result[1]) { $_POST[NFILE] = $result[0]; }
		
		// CLEAN FILE NAME OF SPACES AND SYMBOLS
		$_POST[NFILE] = preg_replace("/[^a-zA-Z0-9s]/", "", $result[0]);
		
		$ORIGINAL_FILE = ABSPATH . PB_ROOT . 'pages/' . $_POST[OFILE] . '.xml';
		$NEW_FILE = ABSPATH . PB_ROOT . 'pages/' . $_POST[NFILE] . '.xml';
		
		// MAKE SURE THAT THERE IS AN ORIGINAL NAME
		if(file_exists($ORIGINAL_FILE)) {
			rename($ORIGINAL_FILE, $NEW_FILE);
			header('location:?form=pages');
		} else {
			echo "<div id=\"content\">
			Could not rename the file.
			</div>";
		}
		
	}
	else {	
	
		echo "
		<form id=\"rename_pages\" action=\"?form=pages&m=rename&a=true\" method=\"post\">
		<input type=\"hidden\" name=\"OFILE\" value=\"$_GET[xml]\">
		
		<div id=\"content\">
		<p>
		Renaming file: $_GET[xml]
		</p>
		
		<p>
		New name for this file: <input type=\"text\" name=\"NFILE\" size=\"20\" maxlength=\"20\">
		(required: .xml file extension)</p>
		
		<p>
		<input type=\"submit\" value=\"Rename File\">
		<input type=\"button\" value=\"Cancel\" onclick=\"location.href='?form=pages';\">
		</p>
		
		</div>
		</form>";
		exit;
	}
}

function update_pages() {
    
    GLOBAL $CONFIG;
    
	// FIRST COPY THE FILE INTO BACKUP_DIR: pages_history
	$BACKUP_DATE = str_replace(' ', '_', MYSQLDATETIME);
	$BACKUP_FILE = ABSPATH . PB_ROOT . 'pages_history/' . $_POST[xml] . '_' . $BACKUP_DATE;
	$ORIGINAL_FILE = ABSPATH . PB_ROOT . 'pages/' . $_POST[xml];

	// CREATE THE COPY OF THE FILE NOW
	if($CONFIG[USEBACKUP] == 'on') {
	    $do = copy($ORIGINAL_FILE, $BACKUP_FILE);
	}
	 
	// OPEN THE FILE UP IF IT EXISTS
	if(file_exists($ORIGINAL_FILE)) {
		
		// USE THE outputXML function in admin-functions.php
		outputXML($ORIGINAL_FILE);  		
		
  		// SEND BACK TO THE PAGES INDEX
  		header('location:?form=pages');

	} else {
		echo "Broke; no file found";
		die;
	}

}

function delete_pages() {
	
	$XML_FILE = ABSPATH . PB_ROOT . 'pages/' . $_GET[xml] . '.xml';

	// CHECK TO SEE IF FILE EXISTS
	if(file_exists($XML_FILE)) {
	
		// FIRST COPY THE FILE INTO BACKUP_DIR: pages_history
		$BACKUP_DATE = str_replace(' ', '_', MYSQLDATETIME);
		$BACKUP_FILE = ABSPATH . PB_ROOT . 'pages_history/' . $_GET[xml] . '_' . $BACKUP_DATE . '.deleted';
		
		#print "<div id=\"content\"><p>$ORIGINAL_FILE</p><p>$BACKUP_FILE</p></div>";
		$do = copy($XML_FILE, $BACKUP_FILE);
		
		unlink($XML_FILE);
		
	} else {
	$err= "no file exists";
	}
	
	// SEND BACK TO THE PAGES INDEX
  	header('location:?form=pages');
  		
}
?>