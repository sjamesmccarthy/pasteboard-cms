<?

function display_listings($pluginList) {
	
	$count=count($pluginList);
	
	// THIS IS WHERE THE PAGE WILL BE GENERATED (should this be in a template)
	$textbox = "
	<div id=\"content\"> <!-- content -->
	<h1>Plugin Management: $count found</h1>
	<p class=\"title\">Plugins extend and expand the functionality of Pasteboard.</p>
	
	<!-- <form>
	<input type=\"file\" name=\"plugin_upload\" size=\"30\"/>
	<input type=\"submit\" value=\"Install PlugIn\" />
	</form>
	<p>Plugins need to be in ZIP format</p>
	-->
	";

	$textbox .= "<table width=\"100%\" border=\"0\" cellpadding=\"5\">";
	$textbox .= "
	<tr bgcolor=\"#000000\" align=\"center\" style=\"background: #000000; color:white;\">
	<th width=\"30%\">Plugin Name</th>
	<th width=\"5%\">V</th>
	<th width=\"65%\">Plugin Description</th>
	</tr>";
		
	foreach ($pluginList as $key=>$value) {
		
		$fileList = get_pages(ABSPATH . PLUGINSPATH . $value);
		$XML_FILE = ABSPATH . PLUGINSPATH . $value . "/package.xml";
			
			if(VERSIONOFPHP == 5) {
				$PAGE_OBJ = xmlp5($XML_FILE);
			} else {
				$PAGE_OBJ = xmlp4($XML_FILE);
			}
			
			$textbox .= "
			<tr bgcolor=\"#CCCCCC\" align=\"left\" class=\"pagelist\">
			<td width=\"30%\"><a href=\"?form=plugins&m=detail\">$PAGE_OBJ->name</a></td>
			<td width=\"5%\" align=\"center\">$PAGE_OBJ->version</td>
			<td width=\"65%\">$PAGE_OBJ->description</td>
			</tr>";
		
	}

	$textbox .= "</table>";
	
	$textbox .= "
	<!-- <p style=\"padding: 5px;\">To edit a page, click on the <b>Page Title</b> above.</p> -->
	</div> <!-- content -->";
	
// SIDEBAR AREA
$textbox .= "
<div id=\"sidebar\"> <!-- sidebar -->
<div id=\"sidebar_details\">
<p class=\"heading\">PLUGINS (Index View)</p>

<p style=\"margin-left: 5px;\">
This area displays all the plugins for your site and what their status is. Plugins can be installed, edited and removed from this page.</p>
</div>

<div id=\"sidebar_details\">
<p class=\"heading\">OPTIONS</p>
<p style=\"margin-left: 5px;\">
Add New Plugin<br />
Find New Plugins<br />
Develop Your Own Plugin

</p>
</div>
</div> <!-- sidebar -->";

	return($textbox);
}

?>