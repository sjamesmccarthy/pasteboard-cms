<?
GLOBAL $CONFIG;

$textbox .= "
<div id=\"content\"> <!-- content -->
<h1>SEO (Search Engine Optimization)</h1>
<p class=\"title\">Is the process of improving the percentage of traffic to your web site from search engines through \"organic\" or \"algorithmic\" search results for targeted keywords. Typically, the higher your web site is presented in the Search Engine Results Pages (SERPS) means the higher it \"ranks\" and results in more searchers visiting your web site.</p>

<p>
Why is this important? Because it's the most popular way visitors will find your web site outside of discovering your web site URL (e.g., http://www.yourdomain.com) on a business card or other traditional advertising collateral. 
</p>

<p>Good SEO includes the following:</p>

<ul style=\"list-style: square;\">
    <li> Review of your site content or structure</li>
    <li> Technical advice on website development: for example, hosting, redirects, error pages, use of JavaScript</li>
    <li> Content development</li>
    <li> Managment online business development campaigns</li>
    <li> Keyword research</li>
    <li> SEO training</li>
    <li> Expertise in specific markets and geographies</li>
</ul>

<p>
As you decide whether you want to take on the time-consuming task of SEO, which is an ongoing, monthly (if not weekly or daily at first) chore, then use the links in the sub-navigation to help you.</p>

<p>Our SEO packages have been developed specifically for small business and local SEO, targeting the visitor whom lives in your geographic area. Read more about our <a target=\"_new\" href=\"http://www.projectwebstart.com/?p=seomarketing\">SEO Marketing services for Small Business</a> and <a target=\"_new\" href=\"http://www.projectwebstart.com/?p=contact\">contact us</a> for more information.</p>

<p>
Remember, getting a website is just the first half of the process. Marketing it on and offline oftens differentiates the successful from the not-so-successful.
</p>

</div> <!-- content -->";

// SIDEBAR AREA
if(!$CONFIG[GOOGLE_ANALYTICS]) { $CONFIG[GOOGLE_ANALYTICS]= "not activated | <a target=\"_new\" href=\"https://www.google.com/accounts/NewAccount?service=analytics&hl=en&continue=http://www.google.com/analytics/home/%3Fet%3Dreset\">Signup Free</a>"; }

$textbox .= "
<div id=\"sidebar\"> <!-- sidebar -->
<div id=\"sidebar_details\">
<p class=\"heading\">SEO (Website)</p>

<!-- <p style=\"margin-left: 5px;\">
Get discovered! The only way people will find your website is if you actively tell them about it!</p> -->

<p>
<b>Google Analytics</b><br />
$CONFIG[GOOGLE_ANALYTICS]
</p>

<p>
<b>ROBOTS.txt</b><br />
($CONFIG[ROBOTS_FILE]) | <a href=\"?form=settings#robots\">Change</a>
</p>
<!--
<form action=\"?form=settings&m=robots\" method=\"post\">

<p>
<b>ROBOTS.txt</b><br />
<select onchange=\"document.form.submit();\" name=\"ROBOTS_FILE\">
<option value=
";

$robots = array('block_robots','allow_robots');

# USE ROBOTS FILE
foreach ($robots as $key=>$value) {
	
	if($CONFIG[ROBOTS_FILE] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>

</form>
-->

</div>

<div id=\"sidebar_details\">
<p class=\"heading\">OPTIONS</p>
<p>
Rebuild Sitemap<br />
View Sitemap<br />
<a target=\"_new\" href=\"http://www.alexa.com/data/details/traffic_details/" . substr($CONFIG[SITE_URL], 11) . "\">Alexa Rating</a><br />
</p>
<!--
<p>
<a target=\"_new\" href=\"http://www.google.com/addurl/\">Submit->Google</a><br />
<a target=\"_new\" href=\"https://siteexplorer.search.yahoo.com/submit\">Submit->Yahoo!</a><br />
<a target=\"_new\" href=\"http://search.live.com/docs/submit.aspx\">Submit->MSN</a><br />
</p>
-->
</div>
</div> <!-- sidebar -->";

print $textbox;
?>