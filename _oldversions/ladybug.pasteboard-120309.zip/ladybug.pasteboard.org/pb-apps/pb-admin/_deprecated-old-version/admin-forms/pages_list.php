<?

function display_listings($pageList) {
	
	$count=count($pageList);
	
	// THIS IS WHERE THE PAGE WILL BE GENERATED (should this be in a template)
	$textbox = "
	<div id=\"content\"><!-- content -->
	<h1>Pages: $count <!-- (out of $_SESSION[SERIALLIMIT]) --></h1>
	<p class=\"title\">Pages can be created, edited, archived, and saved for later.</p>";

	$textbox .= "<table width=\"100%\" border=\"0\">";
	$textbox .= "<tr width=\"15%\" bgcolor=\"#000000\" align=\"center\" style=\"background: #000000; color:white;\"><th style=\"padding: 5px;\">LASTUPDATE</th><th width=\"40%\" align=\"left\">&nbsp;PAGE TITLE</th><th width=\"15%\">AUTHOR</th><th width=\"15%\">STATUS</th><th width=\"15%\">TYPE</th></tr>";
		
	foreach ($pageList as $key=>$value) {
		$FILENAME = split("\.", $value);
		$XML_FILE = ABSPATH . PB_ROOT . 'pages/' . $value;
			
			if(VERSIONOFPHP == 5) {
			$PAGE_OBJ = xmlp5($XML_FILE);
			} else {
			$PAGE_OBJ = xmlp4($XML_FILE);
			}
			
			# 2008-06-25 18:48:36
			$dateFormat_split = split(" ", $PAGE_OBJ->lastupdate);
			$dateFormat_split_date = split("-", $dateFormat_split[0]);
			$dateFormat = "$dateFormat_split_date[1]/$dateFormat_split_date[2]/$dateFormat_split_date[0]";
			
		$textbox .= "<tr bgcolor=\"#CCCCCC\" align=\"center\" class=\"pagelist\"><td width=\"15%\">$dateFormat</td><td align=\"left\" style=\"padding: 5px;\" width=\"40%\"><p style=\"margin:0; padding:0;\"><a href=\"?form=pages&m=edit&xml=$FILENAME[0]\" title=\"$PAGE_OBJ->title\">" . substr($PAGE_OBJ->title, 0,30) . "</a></p><p style=\"margin:0; padding:0; font-size: 8pt;\">file: $value</p></td><td width=\"15%\">$PAGE_OBJ->username</td><td width=\"15%\">$PAGE_OBJ->status</td><td width=\"15%\">$PAGE_OBJ->type</td></tr>";
	}

	$textbox .= "</table>";
	
	$textbox .= "
	<p style=\"padding: 5px;\">To edit a page, click on the <b>Page Title</b> above.</p>
	</div> <!-- content -->";
	
// SIDEBAR AREA
$textbox .= "
<div id=\"sidebar\"> <!-- sidebar -->
<div id=\"sidebar_details\">
<p class=\"heading\">PAGES (Index View)</p>

<p>
This area displays all the web pages on your site and what their status is. Pages can be Published, in Draft or Archived. 
</p>
</div>

<div id=\"sidebar_details\">
<p class=\"heading\">OPTIONS</p>
<p>
<a href=\"?form=pages&m=add\">Add New Page</a><br />
<!-- <a href=\"?form=pages&m=history\">View Backup History</a> -->
</p>
</div> 
</div><!-- sidebar -->";

	return($textbox);
}

?>