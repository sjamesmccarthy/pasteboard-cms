<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-bootsrap.php
 * A process controller to the front-end controller (index.php) that
 * loads all framework libraries and hands site & page data to viewer.
  *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */
 
/* Get ready, set, go!  Hang on, this could be Mr. Toad's wild ride through 
 * a maze of programming fun, but we hope not there isn't too much smoke and mirrors.
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @return  TRUE
 */
function _bootstrap(&$pb)         
{    
    $pb['LOG']['buffer'][] = 'info|_bootstrap Initialized';
    $pb['LOG']['id'] = date("YmdHis");
     
	__frameworktimer($pb,1); 
    __loadlibrary($pb,0); // load required framework libraries
    __sitewhoami($pb); // determine the website being used, set CONFIG items for site-specifics
    __initlog($pb); // initializes the log file (creates if not found)
    
    _init_session($pb); // initializes the PHP _SESSION var, does a few DB actions too
    _useragent($pb); // determine users platform and browser
	_dbopen($pb); // establish a persistent connection to the mysql database     
    __routepage($pb); // determines the appropriate module, such as: admin, pages, reviews, forum, maintenance, etc.

        // load data
        // load layout (structure/theme)
        // render page
    
    _display($pb); // whala! you have a webpage 
    _dbclose($pb); // close the db connection
	__frameworktimer($pb,0);
	
	preint_r($pb); // just dump the $pb array (dev only) REMOVE THIS WHEN DONE DEV or wrap in DEBUG flag.
}

 /* System Timer, independent of benchmark library
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @param	str     $toggle     Toggles between start(1) and stop(0)
 * @return  the time in seconds
 */
function __frameworktimer(&$pb, $toggle=1) 
{
    $button = microtime(TRUE); // only works with PHP5
            
    // 1=on AND 0=off
    switch($toggle)
    {
        case "1":
        $pb['BENCHMARK']['__framework'] = $button;
        break;
        
        case "0":
        $start_time = (int) $pb['BENCHMARK']['__framework'];
        $pb['BENCHMARK']['__framework'] = round(($button-$start_time), 3);
        break;
        
        default:
        //log error
        break;
    }
    
}

/* Load the config file for the specific site. Remember the default site is in the /sites/default folder.
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @return  TRUE
 */
function __sitewhoami(&$pb) 
{ 	
    $site_url = parse_url($_SERVER['HTTP_HOST']);
    $pb['SITE_INFO']['base_url'] = 'http://' . $site_url['path']; 
 
    $sites_base = PB_ROOT . PB_SITES_PATH;
    
		if(file_exists($sites_base . $site_url['path'] . '/' .'configsite.php'))
		{
			$pb['SITE_INFO']['is_custom'] = '(TRUE)';	
            $pb['SITE_INFO']['site'] = $site_url['path'];            
            $pb['SITE_INFO']['config_file_path'] = $site_config_file = $sites_base . $site_url['path'] . '/' .'configsite.php';
            
		} else {
            $pb['SITE_INFO']['is_custom'] = '(FALSE = NO CONFIGSITE FILE FOUND)';	
			if(file_exists($sites_base . 'default' . '/' .'configsite.php'))
			{
				$pb['SITE_INFO']['is_default'] = '(TRUE)';
                $pb['SITE_INFO']['site'] = 'default'; // overwriting for default site
                $pb['SITE_INFO']['config_file_path'] = $sites_base . 'default' . '/' .'configsite.php';
			}
		}
    
    require($pb['SITE_INFO']['config_file_path']);

    $pb['SITE_INFO']['timezone'] = date_default_timezone_get();
    $pb['LOG']['buffer'][] = 'info|set_timezone: ' . $pb['SITE_INFO']['timezone'];
    $pb['LOG']['buffer'][] = 'info|_sitewhoami: ' . $pb['SITE_INFO']['site'] . ' Initialized';
}

/* Autoloads the required library files. 
 * @since	0.1.0
 * @param	array   $autoload_f     array that contains files to autoload
 * @param 	int     $mode           not used now, unsure of original purpose
 * @return  TRUE
 */
function __loadlibrary(&$pb,$mode='0')
{       
        foreach ($pb['AUTOLOAD'] as $key=>$value) 
        {
            $i=0; // init var for count
            $file_index=''; // init var so that it can be concatenated during the loop
            $files_not_loaded=''; // init var
        
            foreach ($pb['AUTOLOAD'][$key] as $filename)
            {
                $required_file = PB_ROOT . $key . '/' . $filename . '.php';
                    if(file_exists($required_file))
                    {
                        require($required_file);
                        $file_index .= $filename . '|';
                        unset($pb['AUTOLOAD'][$key][$i]);
                        $pb['LOG']['buffer'][] = 'info|' . $key . ' file loaded: ' . $filename;
                        $i++;
                    } else {
                        #system log_error
                        unset($pb['AUTOLOAD'][$key][$i]);
                        $files_not_loaded .= $filename . '|';
                        $pb['LOG']['buffer'][] = 'error|' . $key . ' file not found: ' . $filename;
                    }
            }
            $pb['AUTOLOAD'][$key]['loaded'] = $i;
            $pb['AUTOLOAD'][$key]['file_index'] = substr($file_index,0,-1);
            if(!empty($files_not_loaded)) $pb['AUTOLOAD'][$key]['errors'] = substr($files_not_loaded,0,-1); 
        }
        
	return(TRUE);	
}

/* Get ready, set, go!  Hang on, this could be Mr. Toad's wild ride through 
 * a maze of programming fun, but we hope not there isn't too much smoke and mirrors.
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @return  TRUE
 */
function __initlog(&$pb)
{   
    if(PB_LOG_STATUS == TRUE) 
    {
        $logfile_dir = PB_ROOT . PB_SITES_PATH . $pb['SITE_INFO']['site'] . '/' . PB_LOG_PATH;
        $logfile = $logfile_dir . 'log-' . date ('mdy') . '.php';
               
		// check to see if the DIRECTORY exists (not the file)
        if(file_exists($logfile_dir)) 
        {
            $pb['LOG']['dir'] = 'TRUE';            
            if(file_exists($logfile)) // now we check the file
            {
                $pb['LOG']['file_exist'] = 'TRUE';
            } else {
                fopen($logfile, CREATE_WRITE_TOP);               
            }
            $pb['LOG']['path'] = $logfile;
        }
        
        // check to see if it is writable.
        if(is_writable($logfile))
        {
            $pb['LOG']['is_writable'] = 'TRUE';
        }
        else {
            $pb['LOG']['is_writable'] = 'FALSE, FIXED';
            chmod($logfile, 0777); 
        }
        
        $i=1; // init incrementor var
        foreach ($pb['LOG']['buffer'] as $entry) 
        {
            $entry = split('\|', $entry);
            log_msg($pb, $entry[0],$entry[1]);
        }
        
        unset($pb['LOG']['buffer']);
    } 
}

/* whatami? maintenance, page, blog, review, article, forum, etc.
 * first three params are: [c] controller, [m] model/function, [i] id.
 * these can be customized to something else in the configsite.php file.
 *
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 */
function __routepage(&$pb) 
{
	pb_benchmark($pb,'lib_routepage',1); // timer-on
	__urisegment($pb);  // creates pb->VARS->_GET array, plus populates super-global _GET array  
    __maintenance($pb); // load maintenance page if TRUE and returns 
    // if(CACHE_ENGINE == TRUE) { __cached($pb); } // checks to see if the page is cached; if so loads that instead
    // route to correct app view (admin, page, blog, etc) This is where content is fetched
	sleep(1);
    pb_benchmark($pb,'lib_routepage',0); // timer-off
}

/* Can We Build It! Yes We Can!
 * But setup an orange construction zone for non admin users while development
 * is in progress.
 * @since	0.1.0
 */
function __maintenance(&$pb) 
{
	 if(MAINTENANCE === 0) 
    {
        #if $_SESSION == admin; verify user as admin THEN _passthru with notice displayed
        #as a NOTIFICATION BOX only. 
        #$layout = array(
		#	'view'		=>	'maintenance',
		#	'admin'		=>	'TRUE' (FALSE)
		#	);
		#display($layout);
    }
}

/* Parsing the URL whether it is using mod_rewrite or standard $_GET query string
 * If mod_rewrite is enabled it will write values to $pb['VARS'] array and to the super-global $_GET
 * If using standard QUERY_STRING all values will be rewritten to $_GET 
 *
 * without mod_rewrite:
 * http://ladybug.pasteboard.org/?c=module&m=action&i=23&color=green&where=reno&limit=31,60
 *
 * with mod_rewrite:
 * http://ladybug.pasteboard.org/module/action/23/?&color=green&where=reno&limit=31,60
 *
 * First 3 params are required: c=module / f=function_action / i=id 
 * (these can be reassigned in configsite.php)
 *
 * @since	0.1.0
 */
function __urisegment(&$pb) 
{   
    $pb['ROUTER']['uri_path'] = $_SERVER['REQUEST_URI'];
	$pb['ROUTER']['is_front'] = 'UNDEFINED';
	
	// if URI include .php then locate script and run it; otherwise move on
	if (preg_match("/\.php/i", $pb['ROUTER']['uri_path'])) 
	{
	
		$script_name = substr($_SERVER['REQUEST_URI'], 1);
		$exec_path = PB_ROOT . PB_SITES_PATH . $pb['SITE_INFO']['site'] . '/' . PB_SCRIPTS_PATH . $script_name;
		if(file_exists($exec_path)) 
		{ 
			include($exec_path); 
		} else {
			print "The script, " . $script_name . ", does not exist";
			exit;
		}

	}
	
    if($_SERVER['REQUEST_URI'] == '/' || $_SERVER['REQUEST_URI'] == '/?')
    {    
         $pb['ROUTER']['uri_path'] = $_SERVER['REQUEST_URI'];
         $pb['ROUTER']['is_front'] = TRUE . '(TRUE)';
         
    } else {
		
			$i=0;
			$pb['VARS']['_GET'] = array();
			$pb['ROUTER']['is_front'] = FALSE . '(FALSE)';
			$pb['ROUTER']['mod_rewrite_path'] = FALSE . '(FALSE)'; 
			$keys = array(1=>CONTROLLER_TRIG, FUNCTION_TRIG, ID_TRIG);
			foreach ($keys as $newelement) { $pb['VARS']['_GET'][$newelement] = ''; } // not the best solution, but works for now. 

			foreach (explode('/', $_SERVER['REQUEST_URI']) as $value)
			{
				if(trim($value) != '') 
				{
					if (preg_match("/\?/i", $value)) 
					{
						parse_str(substr($value, 1), $parse_split);
						$pb['VARS']['_GET'] = array_merge($pb['VARS']['_GET'], $parse_split);
						$_GET = array_merge($_GET, $parse_split);                        
					} else {
						$pb['ROUTER']['mod_rewrite_path'] = TRUE . '(TRUE)';
							if($i <= count($keys)) 
							{                                                   
								$pb['VARS']['_GET'][$keys[$i]] = $value;
								$_GET[$keys[$i]] = $value;
							
							} else {
								$pb['VARS']['_GET'][$value] = $value;
								$_GET[$value] = $value;
							}   
					}
				}    
			$i++;        
			}
    }
	
	log_msg($pb, 'info', '_urisegment Initialized|is_front=' . $pb['ROUTER']['is_front']);
}
/* End of file */
/* Location: ./pb-libraries/pb-bootstrap.php */ 