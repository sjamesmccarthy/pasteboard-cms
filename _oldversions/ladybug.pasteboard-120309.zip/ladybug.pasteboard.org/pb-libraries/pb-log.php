<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-log.php
 * Contains functions for system-level logging. Originally located in the pb-system.php library
 * it was moved into its own library file for safer public inclusion.
 *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */

/* Does the actual writing to the log file. 
 * Note: The initializer for the logging system is located in the bootstrap.
 * That function makes sure that directory and files, based on SITE, exist before getting to this point.
 *
 * @since	0.1.0
 * @param	str     $level          1 = Error Messages (including PHP errors)
                                    2 = Debug Messages
                                    3 = Informational Messages
                                    4 = All Messages
 * @param   str     $msg            description of the log entry. keep it short, long log entries suck.
 * @param   str     $php_error      spits out the php error message if it exists, will also change $level to 1
 */
 
 /** 
 * We will set the error handler to call back the funtion CUSTOM_ERROR that is inside this file.
 * The reason for that is to just pretty-up a line of text for the log file; nothing else fancy going on.
 * FATAL_ERRORS will not be logged
 */
set_error_handler("custom_error");
 
function log_msg(&$pb, $level='error', $msg)
{			
		$level = strtoupper($level);
        $msg_str = $pb['LOG']['id'] . " -- " . is_IP() . " - $level -- " . DATE_MYSQL . " --> $msg\n";
       
		if(PB_LOG_STATUS == TRUE)
		{
			#if(is_writable($pb['LOG']['path']))
			#{
				$fp = fopen($pb['LOG']['path'], APPEND_WRITE_BOTTOM);
				flock($fp, LOCK_EX);	
				fwrite($fp, $msg_str);
				flock($fp, LOCK_UN);
				fclose($fp);
			#} else {
			#	echo "log file: " . $pb['LOG']['path'] . "is not writable<hr />";
			#}
		}
		
		if($level == "ERROR") 
		{
			print '<div style="color: #000000; background: #FF9999; border: 1px solid #FF0000; width: 100%; padding: 10px; margin: 5px;">' . $msg_str . '</div>';
        }
		
		return($msg_str);
}

function custom_error($errno, $errstr, $errfile, $errline)
{
    global $pb;

    switch($errno)
    {
    
    case "2":
    $errname = 'E_WARNING';
    break;
    
    case "8":
    $errname = 'E_NOTICE';
    break;

    case "256":
    $errname = 'E_USER_ERROR';
    break;

    case "512":
    $errname = 'E_USER_WARNING';
    break;
 
    case "1024":
    $errname = 'E_USER_NOTICE';
    break;

    case "4096":
    $errname = 'E_RECOVERABLE_ERROR';
    break;

    case "8191":
    $errname = 'E_ALL';
    break;
    
    default:
    $errname ='UNKNOWN_ERROR_TYPE';
    break;
    
    }
    
    $msg =  "[$errno, $errname] $errstr [$errfile, $errline]";
    log_msg($pb, 'error', $msg);
}

/* End of file */
/* Location: ./pb-libraries/pb-system.php */