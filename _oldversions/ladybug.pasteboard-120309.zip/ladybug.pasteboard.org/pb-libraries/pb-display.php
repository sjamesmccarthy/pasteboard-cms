<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-render.php
 * Contains functions for building the page and displaying it.
 *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */
 
/* Too many times have a wished the print_r statement would have a (MAKE_PRETTY) flag.
 * now it does! but needs to  be referenced preint_r.
 *
 * @since	0.1.0
 * @param	array   $value        the array that needs Pretty'ing
 * @return  str     $str          the array print_r'd smashed between <pre></pre>
 */
function _display(&$pb)
{
	
	if(OUTPUT_BUFFER === TRUE) ob_start();
    
	/* 
	1. Validate THEME in configsite.php
	2. Validate VIEW in THEME passed by $layout[view]
	3. Parse the VIEW file for helpers, etc. into $rendered_page
	4. print $rendered_page
	*/
    
	if(OUTPUT_BUFFER === TRUE) ob_end_flush();	
}

  
/* End of file */
/* Location: ./pb-libraries/pb-system.php */