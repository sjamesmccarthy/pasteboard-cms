<?

/**
 * @FILE		pb-css_loader.php
 * @DESC		Process CSS file(s)
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */
 
 function css_loader() 
 {
 	global $SHOW;
 			
 // REMOVE the .ext on the end of the file. 
 //	$TEMPLATE_SPLIT = split("\.", $TEMPLATE); 
 //	$TEMPLATE = $TEMPLATE_SPLIT[0];
	
// LOAD THE DEFAULT CSS FILE //
// Check to see if there is a page css file to use //
// looks relatvie to server_root
    
    $CSS_FILE = PB_ROOT . PB_CONTENT . PB_THEMES . THEME . "/css/" . $SHOW[TEMPLATE] . ".css";
	
	if(file_exists($CSS_FILE)) 
	{ 
		$SHOW[CSSFILE] = DS . PB_CONTENT . PB_THEMES . THEME . "/css/" . $SHOW[TEMPLATE] . ".css";
	} else {
	    error(26, 'CSS File Not Found', 'pb-css_loader.php', $CSS_FILE);
	}
	
	// LOAD PAGE CSS IF SPECIFIED AND IF EXISTS
    $PAGE_CSS_FILE = PB_ROOT . PB_CONTENT . PB_ROOT . PB_CONTENT . PB_THEMES . THEME . "/css/" . $SHOW[PAGECSS];
    
 	if($PAGECSS && $PAGECSS != "none") 
 	{
    	
    	if(file_exists($PAGE_CSS_FILE)) 
    	{ 
    		$SHOW[PAGE_CSS] = "@import url(" . PB_ROOT . PB_CONTENT . PB_THEMES . THEME . "/css/" . $SHOW[PAGECSS] . ");";
    	} else {
    	  error(36, 'PAGE-CSS File Not Found', 'pb-css_loader.php', $PAGE_CSS_FILE);   
    	}
    	
	}
// END //
		
}
?>