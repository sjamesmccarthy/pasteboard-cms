<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-bootsrap.php
 * A process controller to the front-end controller (index.php) that
 * loads all framework libraries and hands site & page data to viewer.
  *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */
 
/* Get ready, set, go!  Hang on, this could be Mr. Toad's wild ride through 
 * a maze of programming fun, but we hope not there isn't too much smoke and mirrors.
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @return  TRUE
 */
function _bootstrap(&$pb)         
{   

    $pb['LOG']['buffer'][] = 'info|_bootstrap Initialized';
     
	$pb['BENCHMARK'] 	=	__framework_timer($pb,1); 
    $pb['AUTOLOAD']		=	__load_library($pb,0); // load required framework libraries
    $pb['SITE_INFO']	=	__sitewhoami($pb); // determine the website being used, set CONFIG items for site-specifics
    $pb['LOG']			=	__init_log($pb); // initializes the log file (creates if not found)
    $pb['VARS'] 		= 	__uri_segment($pb);  // creates pb->VARS->_GET array, plus populates super-global _GET array  
    $pb['SESSION'] 		= 	_init_session($pb); // initializes the PHP _SESSION var, does a few DB actions too
    $pb['USER_AGENT']	=	_useragent($pb); // determine users platform and browser
	$pb['DATABASE']		=	_dbopen($pb); // establish a persistent connection to the mysql database     
    $pb['ROUTER']		=	__routepage($pb); // determines the appropriate module, such as: admin, pages, reviews, forum, maintenance, etc.
    $pb['DATABASE']		=	_dbclose($pb); // close the db connection
	$DISPLAY_OUTPUT		=	_display($pb); // whala! you have a webpage 
	$pb['BENCHMARKS']	=	__framework_timer($pb,0);
	
	if(DIAGNOSTICS == TRUE)
	{
		ksort($pb);
		preint_r($pb); // just dump the $pb array (dev only) REMOVE THIS WHEN DONE DEV or wrap in DEBUG flag.
	}
	
	// print $DISPLAY_OUTPUT
	exit;
}

 /* System Timer, independent of benchmark library
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @param	str     $toggle     Toggles between start(1) and stop(0)
 * @return  the time in seconds
 */
function __framework_timer(&$pb, $toggle=1) 
{
    $button = microtime(TRUE); // only works with PHP5
            
    // 1=on AND 0=off
    switch($toggle)
    {
        case "1":
        $pb['BENCHMARK']['__framework'] = $button;
        break;
        
        case "0":
        $start_time = (int) $pb['BENCHMARK']['__framework'];
        $pb['BENCHMARK']['__framework'] = round(($button-$start_time), 3);
        break;
        
        default:
        //log error
        break;
    }
    
	return($pb['BENCHMARK']);
}

/* Load the config file for the specific site. Remember the default site is in the /sites/default folder.
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @return  TRUE
 */
function __sitewhoami(&$pb) 
{ 	
    $site_url = parse_url($_SERVER['HTTP_HOST']);
    $pb['SITE_INFO']['base_url'] = 'http://' . $site_url['path']; 
 
    $sites_base = PB_ROOT . PB_SITES_PATH;
    
		if(file_exists($sites_base . $site_url['path'] . '/' .'configsite.php'))
		{
			$pb['SITE_INFO']['is_custom'] = '(TRUE)';	
            $pb['SITE_INFO']['site'] = $site_url['path'];            
            $pb['SITE_INFO']['config_file_path'] = $site_config_file = $sites_base . $site_url['path'] . '/' .'configsite.php';
            
		} else {
            $pb['SITE_INFO']['is_custom'] = '(FALSE = NO CONFIGSITE FILE FOUND)';	
			if(file_exists($sites_base . 'default' . '/' .'configsite.php'))
			{
				$pb['SITE_INFO']['is_default'] = '(TRUE)';
                $pb['SITE_INFO']['site'] = 'default'; // overwriting for default site
                $pb['SITE_INFO']['config_file_path'] = $sites_base . 'default' . '/' .'configsite.php';
			}
		}
    
    require($pb['SITE_INFO']['config_file_path']);

    $pb['SITE_INFO']['timezone'] = date_default_timezone_get();
    $pb['LOG']['buffer'][] = 'info|_set_timezone: ' . $pb['SITE_INFO']['timezone'];
    $pb['LOG']['buffer'][] = 'info|_sitewhoami: ' . $pb['SITE_INFO']['site'] . ' Initialized';
	
	return($pb['SITE_INFO']);
}

/* Autoloads the required library files. 
 * @since	0.1.0
 * @param	array   $autoload_f     array that contains files to autoload
 * @param 	int     $mode           not used now, unsure of original purpose
 * @return  TRUE
 */
function __load_library(&$pb,$mode='0')
{       
        foreach ($pb['AUTOLOAD'] as $key=>$value) 
        {
            $i=0; // init var for count
            $file_index=''; // init var so that it can be concatenated during the loop
            $files_not_loaded=''; // init var
        
            foreach ($pb['AUTOLOAD'][$key] as $filename)
            {
                $required_file = PB_ROOT . $key . '/' . $filename . '.php';
                    if(file_exists($required_file))
                    {
                        require($required_file);
                        $file_index .= $filename . '|';
                        unset($pb['AUTOLOAD'][$key][$i]);
                        $pb['LOG']['buffer'][] = 'INCLUDE|' . 'library: ' . $filename;
                        $i++;
                    } else {
                        #system log_error
                        unset($pb['AUTOLOAD'][$key][$i]);
                        $files_not_loaded .= $filename . '|';
                        $pb['LOG']['buffer'][] = 'error|' . $key . ' file not found: ' . $filename;
											}
            }
            $pb['AUTOLOAD'][$key]['loaded'] = $i;
            $pb['AUTOLOAD'][$key]['file_index'] = substr($file_index,0,-1);
            if(!empty($files_not_loaded)) $pb['AUTOLOAD'][$key]['errors'] = substr($files_not_loaded,0,-1); 
        }
        
	return($pb['AUTOLOAD']);	
}

/* Get ready, set, go!  Hang on, this could be Mr. Toad's wild ride through 
 * a maze of programming fun, but we hope not there isn't too much smoke and mirrors.
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @return  TRUE
 */
function __init_log(&$pb)
{   
    $pb['LOG']['id'] = date("YmdHis");
	
    if(PB_LOG_STATUS == TRUE) 
    {
        $logfile_dir = PB_ROOT . PB_SITES_PATH . $pb['SITE_INFO']['site'] . '/' . PB_LOG_PATH;
        $logfile = $logfile_dir . 'log-' . date ('mdy') . '.php';

		// check to see if the DIRECTORY exists (not the file)
        if(file_exists($logfile_dir)) 
        {
            $pb['LOG']['dir'] = 'TRUE';            
            if(file_exists($logfile)) // now we check the file
            {
                $pb['LOG']['file_exist'] = 'TRUE';
            } else {
                fopen($logfile, CREATE_WRITE_TOP);               
            }
            $pb['LOG']['path'] = $logfile;
        }
        
        // check to see if it is writable.
        if(is_writable($logfile))
        {
            $pb['LOG']['is_writable'] = 'TRUE';
        }
        else {
            $pb['LOG']['is_writable'] = 'FALSE, FIXED';
            chmod($logfile, 0777); 
        }
        
        $i=1; // init incrementor var
        foreach ($pb['LOG']['buffer'] as $entry) 
        {
            $entry = split('\|', $entry);
			if($entry[0] != "error")
			{
				log_msg($pb, $entry[0],$entry[1]);
			} else {
				log_err(&$pb, 'PRELOAD_BUFFER', __FUNCTION__, __LINE__, __FILE__, $entry[1]);
			}
        }
        
        unset($pb['LOG']['buffer']);
    }

	return($pb['LOG']);
}

/* Parsing the URL whether it is using mod_rewrite or standard $_GET query string
 * If mod_rewrite is enabled it will write values to $pb['VARS'] array and to the super-global $_GET
 * If using standard QUERY_STRING all values will be rewritten to $_GET 
 *
 * without mod_rewrite:
 * http://ladybug.pasteboard.org/?c=module&m=action&i=23&color=green&where=reno&limit=31,60
 *
 * with mod_rewrite:
 * http://ladybug.pasteboard.org/module/action/23/?&color=green&where=reno&limit=31,60
 *
 * First 3 params are required: c=module / f=function_action / i=id 
 * (these can be reassigned in configsite.php)
 *
 * @since	0.1.0
 */
function __uri_segment(&$pb, $ext_script = FALSE) 
{   
    $pb['ROUTER']['uri_path'] = $_SERVER['REQUEST_URI'];
	$pb['ROUTER']['is_front'] = 'UNDEFINED';
	$URI_elements = explode('/', $pb['ROUTER']['uri_path']);
	$URI_elements = array_filter($URI_elements);
	$e=0; // for errors array element
	
	// if URI include .php then locate element in URI array and run it; otherwise move on
	if (preg_match("/\.php/i", $pb['ROUTER']['uri_path'])) 
	{
		$ext_script = TRUE;
		foreach($URI_elements as $key => $value)
		{
			if(preg_match("/\.php/i", $value))
			{
			$script_name = $value;
			}
		}
		
		$exec_path = PB_ROOT . PB_SITES_PATH . $pb['SITE_INFO']['site'] . '/' . PB_SCRIPTS_PATH . $script_name;
		if(file_exists($exec_path)) 
		{ 
			include($exec_path); 
		} else {
			log_err(&$pb, 'URI_SEGMENTING', __FUNCTION__, __LINE__, __FILE__, 'Script Not Found: ');

		}

	}
	
	// Checks to see if this is the homepage
    if($_SERVER['REQUEST_URI'] == '/' || $_SERVER['REQUEST_URI'] == '/?')
    {    
         $pb['ROUTER']['uri_path'] = $_SERVER['REQUEST_URI'];
         $pb['ROUTER']['is_front'] = 'TRUE';
         
    } else {
	// Not the homepage so lets check out the URI and make some decisions
		
		if($ext_script == FALSE) 
		{
		
			$i=1;
			$pb['VARS']['_GET'] = array();
			$pb['ROUTER']['is_front'] = 'FALSE'; 
			$keys = array(1=>CONTROLLER_TRIG, FUNCTION_TRIG, ID_TRIG);
			
			// init the TRIG array elements; nothing else
			foreach ($keys as $newelement) 
			{ 
				$pb['VARS']['_GET'][$newelement] = ''; 
			} 
			
			foreach ($URI_elements as $value)
			{
				$duplicate = FALSE;
				
				if(trim($value) != '') 
				{
					// if there is faux query_string data appended to the URI split apart in name/value pairs
					if (preg_match("/\?/i", $value)) 
					{	
						$parse_split = array();
						$pb['ROUTER']['query_string'] = 'TRUE';
						$pb['ROUTER']['r_type'] ='QRY';
						parse_str(substr($value, 1), $parse_split);
						$pb['VARS']['_GET'] = array_merge($pb['VARS']['_GET'], $parse_split);
						$_GET = array_merge($_GET, $parse_split);   

					// otherwise treat like a regular / separated URI and segment
					} else {
						$pb['ROUTER']['uri_segmenting'] ='TRUE';
						$pb['ROUTER']['r_type'] ='URI';
							if($i <= count($keys)) 
							{   
								// this is one of the TRIG keys
								$pb['VARS']['_GET'][$keys[$i]] = $value;
								$_GET[$keys[$i]] = $value;
							
							} else {
								
								// this is a parameter. make sure the parameter IS_NOT a TRIG key
								if(array_key_exists($value, $pb['VARS']['_GET']))
								{
									log_err(&$pb, 'URI_SEGMENTING', __FUNCTION__, __LINE__, __FILE__, 'Duplicate KEY found');
									$duplicate = TRUE;
								}
								
								if($duplicate == TRUE) 
								{
									$key_value = $value . '_DUPLICATE';
								}
								else {
									$key_value = $value;
								}
								
								$pb['VARS']['_GET'][$key_value] = $value;
								$_GET[$key_value] = $value;
							}   
					}
				}    
			$i++;        
			}
		}	
    }
	
	log_msg($pb, 'info', '_urisegment Initialized');
	log_msg($pb, 'info', '_urisegment is_front=' . $pb['ROUTER']['is_front']);
	
	return($pb['VARS']);
}
	
/* End of file */
/* Location: ./pb-libraries/pb-bootstrap.php */ 