<?php 

/**
 * pb-router.php
 * Determines the type of document that needs to be displayed and loads
 * the correct module (application).
 *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */

/* whatami? maintenance, page, blog, review, article, forum, etc.
 * first three params are: [c] controller, [m] model/function, [i] id.
 * these can be customized to something else in the configsite.php file.
 *
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 */
function _routepage(&$pb) 
{
	pb_benchmark($pb,'lib_routepage',1); // timer-on
	__urisegment($pb);  // creates pb->VARS->_GET array, plus populates super-global _GET array  
    __maintenance($pb); // load maintenance page if TRUE and returns 
    // if(CACHE_ENGINE == TRUE) { __cached($pb); } // checks to see if the page is cached; if so loads that instead
    // route to correct app view (admin, page, blog, etc) This is where content is fetched
	sleep(1);
    pb_benchmark($pb,'lib_routepage',0); // timer-off
}

/* Can We Build It! Yes We Can!
 * But setup an orange construction zone for non admin users while development
 * is in progress.
 * @since	0.1.0
 */
function __maintenance(&$pb) 
{
	 if(MAINTENANCE === 0) 
    {
        #if $_SESSION == admin; verify user as admin THEN _passthru with notice displayed
        #as a NOTIFICATION BOX only. 
        #$layout = array(
		#	'view'		=>	'maintenance',
		#	'admin'		=>	'TRUE' (FALSE)
		#	);
		#display($layout);
    }
}

/* Parsing the URL whether it is using mod_rewrite or standard $_GET query string
 * If mod_rewrite is enabled it will write values to $pb['VARS'] array and to the super-global $_GET
 * If using standard QUERY_STRING all values will be rewritten to $_GET 
 *
 * without mod_rewrite:
 * http://ladybug.pasteboard.org/?c=module&m=action&i=23&color=green&where=reno&limit=31,60
 *
 * with mod_rewrite:
 * http://ladybug.pasteboard.org/module/action/23/?&color=green&where=reno&limit=31,60
 *
 * First 3 params are required: c=module / f=function_action / i=id 
 * (these can be reassigned in configsite.php)
 *
 * @since	0.1.0
 */
function __urisegment(&$pb) 
{   
    $pb['ROUTER']['uri_path'] = $_SERVER['REQUEST_URI'];
	$pb['ROUTER']['is_front'] = 'UNDEFINED';
	
	// if URI include .php then locate script and run it; otherwise move on
	if (preg_match("/\.php/i", $pb['ROUTER']['uri_path'])) 
	{
	
		$script_name = substr($_SERVER['REQUEST_URI'], 1);
		$exec_path = PB_ROOT . PB_SITES_PATH . $pb['SITE_INFO']['site'] . '/' . PB_SCRIPTS_PATH . $script_name;
		if(file_exists($exec_path)) 
		{ 
			include($exec_path); 
		} else {
			print "The script, " . $script_name . ", does not exist";
			exit;
		}

	}
	
    if($_SERVER['REQUEST_URI'] == '/' || $_SERVER['REQUEST_URI'] == '/?')
    {    
         $pb['ROUTER']['uri_path'] = $_SERVER['REQUEST_URI'];
         $pb['ROUTER']['is_front'] = TRUE . '(TRUE)';
         
    } else {
		
			$i=0;
			$pb['VARS']['_GET'] = array();
			$pb['ROUTER']['is_front'] = FALSE . '(FALSE)';
			$pb['ROUTER']['mod_rewrite_path'] = FALSE . '(FALSE)'; 
			$keys = array(1=>CONTROLLER_TRIG, FUNCTION_TRIG, ID_TRIG);
			foreach ($keys as $newelement) { $pb['VARS']['_GET'][$newelement] = ''; } // not the best solution, but works for now. 

			foreach (explode('/', $_SERVER['REQUEST_URI']) as $value)
			{
				if(trim($value) != '') 
				{
					if (preg_match("/\?/i", $value)) 
					{
						parse_str(substr($value, 1), $parse_split);
						$pb['VARS']['_GET'] = array_merge($pb['VARS']['_GET'], $parse_split);
						$_GET = array_merge($_GET, $parse_split);                        
					} else {
						$pb['ROUTER']['mod_rewrite_path'] = TRUE . '(TRUE)';
							if($i <= count($keys)) 
							{                                                   
								$pb['VARS']['_GET'][$keys[$i]] = $value;
								$_GET[$keys[$i]] = $value;
							
							} else {
								$pb['VARS']['_GET'][$value] = $value;
								$_GET[$value] = $value;
							}   
					}
				}    
			$i++;        
			}
    }
	
	log_msg($pb, 'info', '_urisegment Initialized|is_front=' . $pb['ROUTER']['is_front']);
}

/* End of file */
/* Location: ./pb-libraries/pb-router.php */ 
