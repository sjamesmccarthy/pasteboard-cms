<?php

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-database.php
 * Creates a persistent connection to the mysql database using the credentials
 * as found in the sites config settings file.
 *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */

# Goals of library file is to build a query string using easy-to-read formatting.

# db_select('@array_of_fields');
# db_from('TABLE_NAME');
# db_where('$key','$value');

# see DB_active_rec.php
# E:\PROJECTS\CODE_SNIPS\CMS_MODELS\CodeIgniter_1.7.1\system\database\

/* Get ready, set, go!  
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @return  TRUE
 */
function db_select(&$pb) 
{
	#return 
}

function db_from(&$pb) 
{
	#return 
}

function db_join(&$pb) 
{
	#return 
}

function db_where(&$pb) 
{
	#return 
}

function db_like(&$pb) 
{
	#return 
}

function db_groupby(&$pb) 
{
	#return 
}

function db_orderby(&$pb) 
{
	#return 
}

function db_limit(&$pb) 
{
	#return 
}

function db_count(&$pb) 
{
	#return 
}

function db_insertid(&$pb) 
{
	#return 
}

function db_empty(&$pb) 
{
	#return 
}

function db_insert(&$pb) 
{
	#return 
}

function db_update(&$pb) 
{
	#return 
}

function db_delete(&$pb) 
{
	#return 
}

function db_sql(&$pb) 
{
	#return 
}

function _dbopen(&$pb) 
{
	pb_benchmark($pb, 'lib_database', 1);
	
	$pb['DATABASE']['CON'] = mysql_pconnect(DB_HOST, DB_USER, DB_PSWD);	
	if(!$pb['DATABASE']['CON'])  { print "failed: mysql_pconnect()"; }

	$DBH = mysql_select_db(DB_NAME, $pb['DATABASE']['CON']) or die("Couldn't select database");

	$pb['DATABASE']['name'] = DB_NAME;
	$pb['DATABASE']['con_type'] = 'mysql_pconnect';
	
	pb_benchmark($pb, 'lib_database', 0);
	#return($pb['DATABASE']['CON']);
}

function _dbclose(&$pb) 
{
    mysql_close($pb['DATABASE']['CON']);
    $pb['DATABASE']['sql'] = '(empty)';
}

function query_raw(&$pb) {
    
	$sql_result = mysql_query($sql,$pb['DATABASE']['CON']);
	return($sql_result);
	
}
	
// END // 