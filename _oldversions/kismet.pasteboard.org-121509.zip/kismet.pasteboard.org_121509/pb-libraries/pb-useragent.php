<?php

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		pb-useragent.php
 * @DESC		opens a persistent connection to database
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 * @FUNCTIONS	none
 */

function is_browser(&$pb) 
{
	#return 
}

function is_platform(&$pb) 
{
	#return 
}

function is_IE6(&$pb) 
{
	#return 
}

/******************************************************************
* Function Name: pb_useragent
* Parameters: 
* Description: Cleans URI of any strange characters.
* files if necessary.
* Return type: TRUE
*******************************************************************/ 
function _useragent(&$pb)
{	
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$pb['USERAGENT']['agent_str'] = $useragent;
	
	$useragents_file = PB_ROOT . PB_CONFIG_PATH . 'useragents-config.php';
	
	if(file_exists($useragents_file))
	{
		require($useragents_file);
	} else {
		#log
	}
	
	// browser & version
	if (is_array($web_browsers) && count($web_browsers > 0))
	{
		foreach ($web_browsers as $key => $val)
		{	
			if (preg_match("|" . $key . ".*?([0-9\.]+)|i", $useragent, $match))
			{
				$pb['USERAGENT']['name'] = $val;
				$pb['USERAGENT']['version'] = $match[1];
				
				if(preg_match("/MSIE 6.0/i", $match[0]))
				{
					// is_IE6
					$pb['USERAGENT']['is_IE6'] = 'TRUE';
					log_msg($pb, 'warning', '_isMSIE6: ' . $pb['USERAGENT']['is_IE6']);
				} else {
					$pb['USERAGENT']['is_IE6'] = 'FALSE';
				}
			
			break;
			}
		}
	} else {
		#log
	}
	
	// os version & platform
	if (is_array($os_platforms) && count($os_platforms > 0))
	{
		foreach ($os_platforms as $key => $val)
		{		
			if (preg_match("|" . $key . "|i", $useragent))
			{
				$pb['USERAGENT']['os_platform'] = $val;
				break;
			}
		}
	} else {
		#log
	}

	// is_mobile TRUE/FALSE
	// will need to add this in later
	$pb['USERAGENT']['is_Mobile'] = 'UNDEFINED';
	log_msg($pb, 'info', '_useragent: ' . $pb['USERAGENT']['name'] . ' ' . $pb['USERAGENT']['version']);
	
	return(TRUE);
	
}

/**
	 * Set the Mobile Device
	 *
	 * @access	private
	 * @return	bool
*/		
function is_mobile()
	{
		if (is_array($this->mobiles) AND count($this->mobiles) > 0)
		{		
			foreach ($this->mobiles as $key => $val)
			{
				if (FALSE !== (strpos(strtolower($this->agent), $key)))
				{
					$this->is_mobile = TRUE;
					$this->mobile = $val;
					return TRUE;
				}
			}
		}	
		return FALSE;
	}
	
function is_IP()
{
	$whoareyou = $_SERVER["REMOTE_ADDR"];
	$pb['USER_AGENT']['IP'] = $whoareyou;
	return($whoareyou);
}

/* End of file */
/* Location: ./pb-libraries/pb-useragent.php */ 