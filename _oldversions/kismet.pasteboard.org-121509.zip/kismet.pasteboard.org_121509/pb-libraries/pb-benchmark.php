<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-benchmark.php
 * A library file containing benchmark (timer) functions.
 *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */
 
 /* Calculates the time based on microtime() or returns the current Unix timestamp with microseconds.
 * @since	0.1.0
 * @return  the time in microseconds
 */
function __timer() 
{
	#list($usec, $sec) = explode(" ", microtime());
	#return ((float)$usec + (float)$sec);
    return microtime(TRUE); // only works with PHP5, EXPERT: comment out this line, uncomment the two lines above.
}

/* resets the benchmark request and removes it from the $pb array  
 * @since	0.1.0.0
 * @param	array   &$pb        global pb_array
 * @param 	str     $tName      the name of the timer, if none is specified defaults to ALL
 * @return  TRUE
 */
function pb_benchmarkreset(&$pb, $tName='ALL')
{
	$rTimer = split(',', $tName);
	
	if($rTimer[0] === "ALL") 
	{
		foreach($pb['BENCHMARK'] as $key => $value)
	 	{
	 		unset($pb['BENCHMARK'][$key]);
	 	}
	} else {
		foreach($rTimer as $i) { unset($pb['BENCHMARK'][$i]); }
	}
}

/* System Timer, independent of benchmark library
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 * @param	str     $toggle     Toggles between start(1) and stop(0)
 * @return  the time in seconds
 */
function pb_benchmark(&$pb, $tName='default', $toggle=1) 
{
    $button = __timer();
            
    // 1=on AND 0=off
    switch($toggle)
    {
        case "1":
        $pb['BENCHMARK'][$tName] = $button;
        break;
        
        case "0":
        $start_time = (int) $pb['BENCHMARK'][$tName];
        $pb['BENCHMARK'][$tName] = round(($button-$start_time), 3);
        break;
        
        default:
        //log error
        break;
    }
    
}


/* End of file */
/* Location: ./pb-libraries/pb-benchmark.php */