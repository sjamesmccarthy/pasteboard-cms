<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-templatehooks.php
 * A library file containing functions that make creating a template easier.
 *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */

function is_home() 
{
    
}

function is_admin() 
{

}

function insert_block()
{

}

function logged_in() 
{

}

function get_header($FILE = 'header.php') {
   
    $HEADER_FILE = ABSPATH . PB_ROOT . THEMESPATH . 'includes/' . $FILE;
    if (file_exists($HEADER_FILE)) {
		include_once($HEADER_FILE);
    } else {
		#log to debug();
		error(206, 'File Not Found', 'pb-common.php', $HEADER_FILE);
    }
    
}

function get_footer($FILE = 'footer.php') {   
	
	$FOOTER_FILE = ABSPATH . PB_ROOT . THEMESPATH . 'includes/' . $FILE;
    if (file_exists($FOOTER_FILE)) {
		include_once($FOOTER_FILE);
    } else {
		#log to debug();
		error(218, 'File Not Found', 'pb-common.php', $FOOTER_FILE);
    }
    
}
 
/* End of file */
/* Location: ./pb-content/config/pb-configsite.php */
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */