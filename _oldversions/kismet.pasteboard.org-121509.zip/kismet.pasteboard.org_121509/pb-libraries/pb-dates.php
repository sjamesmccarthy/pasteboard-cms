<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-dates.php
 * Contains functions for formatting dates.
 * Requires the dates-config.php file
 * 
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */

function pb_date($format)
{
    global $pb;

    switch($format)
    {
    
    case "2":
    $pb_date[$format] = TIME_UNIX;
	
    break;
    
    case "8":
    $errname = 'E_NOTICE';
    break;

    case "256":
    $errname = 'E_USER_ERROR';
    break;

    case "512":
    $errname = 'E_USER_WARNING';
    break;
 
    case "1024":
    $errname = 'E_USER_NOTICE';
    break;

    case "4096":
    $errname = 'E_RECOVERABLE_ERROR';
    break;

    case "8191":
    $errname = 'E_ALL';
    break;
    
    default:
    $errname ='UNKNOWN_ERROR_TYPE';
    break;
    
    }
    
    $msg =  "[$errno, $errname] $errstr [$errfile, $errline]";
    log_msg($pb, 'error', $msg);
}

/* End of file */
/* Location: ./pb-libraries/pb-system.php */