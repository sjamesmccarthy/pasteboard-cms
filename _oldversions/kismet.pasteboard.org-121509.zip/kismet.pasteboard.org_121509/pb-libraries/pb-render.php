<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * pb-render.php
 * Contains functions for building the page and displaying it.
 *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */
 
/* whatami? maintenance, page, blog, review, article, forum, etc.
 * first three params are: [c] controller, [m] model/function, [i] id.
 * these can be customized to something else in the configsite.php file.
 *
 * @since	0.1.0
 * @param	array   &$pb        global pb_array
 */
function __routepage(&$pb) 
{
	$pb['ROUTER']['app'] = 'UNDEFINED';
	$pb['ROUTER']['function'] = 'UNDEFINED';
	$pb['ROUTER']['view'] = 'UNDEFINED';
	
	log_msg($pb, 'info', __FUNCTION__ . ' Initialized');
	
		// http://www.domain.com/controller/function/id/foo/bar
		// controller = application
		// function = view
		// id = content
		// foo/bar = variables
		
		// http://www.pageonetwentysix.com/story/view/23/chapter
		// include(PATH . $c)
		// $data = $f($i)
		
		
	pb_benchmark($pb,'lib_routepage',1); // timer-on 
    __maintenance($pb); // load maintenance page if TRUE and returns 
    // if(CACHE_ENGINE == TRUE) { __cached($pb); } // checks to see if the page is cached; if so loads that instead
    // route to correct app view (admin, page, blog, etc) This is where content is fetched
    pb_benchmark($pb,'lib_routepage',0); // timer-off
	
	return(TRUE);
}

/* Can We Build It! Yes We Can!
 * But setup an orange construction zone for non admin users while development
 * is in progress.
 * @since	0.1.0
 */
function __maintenance(&$pb) 
{
	 if(MAINTENANCE === 0) 
    {
        #if $_SESSION == admin; verify user as admin THEN _passthru with notice displayed
        #as a NOTIFICATION BOX only. 
     		
		#return
		#$layout = array(
		#	'view'		=>	'maintenance',
		#	'admin'		=>	'TRUE' (FALSE)
		#	);
		#display($layout);
    }
}

function __get_nice_URL(&$pb) 
{

}

function __parse_template_helpers(&$pb) 
{

}

function __parse_content_helpers(&$pb) 
{

}

function __cache_write(&$pb) 
{

}

function __cache_get(&$pb) 
{

}

function __cache_check(&$pb) 
{

}

/* Too many times have a wished the print_r statement would have a (MAKE_PRETTY) flag.
 * now it does! but needs to  be referenced preint_r.
 *
 * @since	0.1.0
 * @param	array   $value        the array that needs Pretty'ing
 * @return  str     $str          the array print_r'd smashed between <pre></pre>
 */
function _display(&$pb)
{
	
	if(OUTPUT_BUFFER === TRUE) ob_start();
    
	/* 
	1. Validate THEME in configsite.php
	2. Validate VIEW in THEME passed by $layout[view]
	3. Parse the VIEW file for helpers, etc. into $rendered_page
	4. print $rendered_page
	*/
    
	if(OUTPUT_BUFFER === TRUE) ob_end_flush();	
}

  
/* End of file */
/* Location: ./pb-libraries/pb-system.php */