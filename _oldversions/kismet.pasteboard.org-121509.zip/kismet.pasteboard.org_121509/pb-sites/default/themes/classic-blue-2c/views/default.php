<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<!--
Design by James McCarthy
http://www.projectwebstart.com
Copyright 2008
-->

<head>

<!-- required: plops the page title based on the XML file -->
<title><? print $SHOW[TITLE]; ?></title>

<!-- required: base href so you don't have to keep writing this for all relative URLs -->
<base href="<? print $CONFIG[SITE_URL]; ?>/pb-content/" />
	
<!-- optional: favorite icon, okay to remove if you don't want to use -->
<link rel="shortcut icon" href="themes/<? print $CONFIG[THEME]; ?>/images/favicon.ico" type="image/x-icon" />
	
<!-- required: CSS information -->
<style type="text/css" media="all">
@import url(<? print $SHOW[CSSFILE]; ?>);
<? if(isSet($SHOW[PAGE_CSS])) print $SHOW[PAGE_CSS]; ?>
</style>

<!-- required: formats meta tag information -->
<? get_meta(); ?>

</head>

<body>

<div id="content">
<!-- required: will plop in the body content of the webpage from the specified XML file -->
<!-- alteratively, you could create a plugin that would pull the content from a database or other source and then display the results by using something like get_review_content(id); -->
<? print $SHOW[CONTENT]; ?>
</div> <!-- id: content -->

</body>
</html>