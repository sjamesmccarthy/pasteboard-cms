<?php 
if ( ! defined('PB-START')) exit('No direct script access allowed');


/**
 * configsite.php
 * configuration file for the website. This information can be manually changed
 * or through the ADMIN interface. 
 *
 * @package    pasteboard
 * @subpackage site
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 * @link       http://www.pasteboard.org
 */

//set_error_handler("custom_error");

 /* Site Contact information */
define('SITE_COMPANY_NAME', 'pasteboard Group');
define('SITE_COMPANY_CONTACT_NAME', 'James McCarthy');
define('SITE_COMPANY_CONTACT_EMAIL', 'jmccarthy@projectwebstart.com');
define('SITE_COMPANY_CONTACT_PHONE', '(775) 815-9726');
define('SITE_NAME', 'pasteboard.cms LADYBUG build');
define('SITE_SUPPORT_EMAIL', 'webemail@pasteboard.org');
date_default_timezone_set('US/Pacific'); // set this to your server timezone.

/* Site Look and Feel */
define('THEME', 'pasteboard_v2');
define('ADMINTHEME', 'purple_haze');

/* Site Technical Settings */
define('USE404', TRUE);
define('CACHE_ENGINE', TRUE);
define('USEBACKUP', TRUE);
define('MAINTENANCE', FALSE);
define('SITE_LANGUAGE', 'en-us');
define('ROBOTS_FILE', 'allow_robots');
define('HTACCESS', 'public-access');
define('OUTPUT_BUFFER', TRUE);
define('DIAGNOSTICS', TRUE);

/* Site URI configuration */
define('CONTROLLER_TRIG', 'c');
define('FUNCTION_TRIG', 'f');
define('ID_TRIG', 'i');

/* Site Database Information */
define('DB_NAME', 'pbdev');
define('DB_HOST', 'pasteboard.org');
define('DB_USER', 'pasteboard');
define('DB_PSWD', 'kandl3x+en1d');

/* Site Search Information: Google */
define('GOOGLE_ANALYTICS', '');
define('GOOGLE_SITE_VALIDATION', '');
define('GOOGLE_SITEMAP', '');
define('GOOGLE_ADS', '');

/* End of file */
/* Location: ./sites/[site_domain]/configsite.php */