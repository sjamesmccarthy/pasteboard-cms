<?php

if ( ! defined('PB-START')) exit('No direct script access allowed');

/*
// -------------------------------------------------------------------
// SNIP_LOGOUT()
// -------------------------------------------------------------------
// destroys session.
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// <? snip_logout(); ?>
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/
 
 function snip_logout($param = '0') {
 		
 		$snippet = "<p>success : session_destroyed</p>";		 
 		session_destroy();
 		
 	return($snippet);
 	// Returns the output of the snippet to pb-contentsnips_loader.php
 	
 }

/* End of file */
/* Location: ./pb-content/library/snip_logout.php */