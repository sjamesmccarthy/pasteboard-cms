<?php

if ( ! defined('PB-START')) exit('No direct script access allowed');

/*
// -------------------------------------------------------------------
// SNIP_CHECKLOGIN()
// -------------------------------------------------------------------
// This file basically checks to see if a _SESSION username exists 
// and if so it redirects to /pb-admin/ 
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// <? snip_login(); ?>
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/

 function snip_checklogin($param = '0') {
 		
 		if($_SESSION[username]) { 
 		header('location:/pb-admin/');
 		} else {
 		 // log to errors() log
 		} 
 				 		
 	return($snippet);
 	// Returns the output of the snippet to pb-contentsnips_loader.php
 	
 }

/* End of file */
/* Location: ./pb-content/contentsnips/ */