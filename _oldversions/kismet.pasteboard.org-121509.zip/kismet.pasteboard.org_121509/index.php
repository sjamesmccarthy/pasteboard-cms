<? 
/** 
 * pasteboard 
 * a content management framework
 * This is the PHP page the serves all page requests.
 *
 * @package    pasteboard
 * @subpackage core
 * @author     pasteboard team <pb_team@pasteboard.org>
 * @copyright  Copyright (c) 2009, pasteboard group
 * @license    GNU General Public License, http://pasteboard.org/?p=license
 */
 
/**
 * We'll define a CONSTANT variable that will allow access to library files.
 */
define('PB-START', TRUE);

/**
 * Next, we'll also define error_reporting as E_STRICT, including warnings
 * And we'll make sure the server is running PHP 5 or exit the pasteboard framework.
 * And ... set the default timezone for the server.
 */
error_reporting(E_ALL);
version_compare(PHP_VERSION, '5', '<') and exit('PasteBoard requires PHP 5 or newer.');
 
/** 
 * set this to your server timezone. it can be overriden in the siteconfig.php file if the sites are in  
 * different timezones. see http://us2.php.net/manual/en/timezones.php for supported timezones.
 */
date_default_timezone_set('US/Pacific');

/** 
 * Set the $pb array.
 * This little booger is equivalent to what an object would have been if this was written in OOP.
 * Well maybe not TECHNICALLY the same thing, but I hope you get the idea. It will be passed
 * between functions and hold framework dependent variables.
 */
$pb = array();
$pb['LOG']['buffer'][] = 'INITIALIZE|array(pb)';

/**
 * Now, we'll import the config file for the pasteboard framework.
 * This IS_NOT the site config file which will be loaded in a few seconds, literally.
 */
require('./pb-config/pb-config.php'); 
$pb['LOG']['buffer'][] = 'INCLUDE|library: pb-config';

/**
 * Okay, almost there. Loading the bootstrap file. 
 * This file basically starts things up by requiring library files and setting up the
 * theme & template scaffolding for the specific site. Are you excited yet? 
 */
require('./pb-libraries/pb-bootstrap.php');
$pb['LOG']['buffer'][] = 'INCLUDE|library: pb-bootstrap';

/**
 * Buckle-up and enjoy the ride!
 * Oh, BTW, in case you want to peek, the pb_bootstrap function is in /pb-libraries/.
 */
_bootstrap($pb);
log_msg($pb, 'info','Load.Complete(' . $pb['BENCHMARK']['__framework'] . ')');
exit();

/* End of file */
/* Location: index.php */