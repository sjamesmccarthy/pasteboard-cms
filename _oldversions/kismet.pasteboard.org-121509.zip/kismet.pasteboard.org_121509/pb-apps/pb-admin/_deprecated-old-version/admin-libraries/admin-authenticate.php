<?

switch($_REQUEST[action]) {
	
	case "login":
		
		// CHECK THAT FORM VARIABLES ARE NOT BLANK //
		verify_form();
		
		// VALIDATE LICENSE
		validate_license();
		
		// VALIDATE USERNAME, PASSWORD IN DATABASE //
		validate_user($_POST[username],$_POST[pswd]);
		
		// CHECK TO SEE IF THE LOGIN IS GOOD
		if(!$CONFIG[BADLOGIN]) { 
		header('location:/pb-admin/index.php'); 
		}
		
		break;
	
	case "logout":
		
		// DESTROY SESSION; _COOKIE[PHPSESSID] REMAINS UNTIL BROWSER CLOSED
		session_destroy();
		
		// LOGGED OUT FLAG
		$CONFIG[ERR] =1;
		$CONFIG[LOGGEDOUT] =1;
		break;
	
	case "reset":
	
		// RESET PASSWORD
		$CONFIG[ERR] =1;
		$CONFIG[RESET] =1;
		
		// LOADS NEW FORM USING TEMPLATE (LOGIN.PHP)
		break;
	
	case "do_reset":
	
		// RESET PASSWORD
		$CONFIG[ERR] =1;
		$CONFIG[RESETSENT] =1;
		
		// 
		$result = reset_password($_POST[email]);
		print $result;
		break;
		
	default:
		
		// DO NOTHING
		$CONFIG[NEWLOGIN] =1;
		break;

}

function verify_form() {
		
	 	if(!$_POST[username]) { $err++; }
 	 	if(!$_POST[pswd]) { $err++; }
 		
  	if($err > 1) {
  		header('location:/pb-admin/');
  		die;
	}
}
 
function get_user_data() {

// LOOK UP USER IN DATABASE
	$sql = "SELECT *from users where username='$_SESSION[username]' LIMIT 1";
	
	$result = query_exec($sql);
	$count = mysql_num_rows($result);
	
	if($count > 0) { 
		while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    		foreach ($row as $key=>$value) { $USERDATA[$key] = $row[$key]; }
  		}
  	}
  	
  	return($USERDATA);
}

function validate_user($LOGIN,$PASWD) {
	GLOBAL $CONFIG;
	
	// LOOK UP USER IN DATABASE
	$sql = "SELECT * from users where username='$LOGIN' and password=PASSWORD('$PASWD') LIMIT 1";
	
	$result = query_exec($sql);
	$count = mysql_num_rows($result);
	
	if($count > 0) { 
		while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    		foreach ($row as $key=>$value) { $_SESSION[$key] = $row[$key]; }
  		}
  		$valid=1;
  		
  		// UPDATE DATABASE WITH NEW PASSWORD
		$sql = "UPDATE users set lastlogin='" . MYSQLDATETIME . "' where username='$_SESSION[username]'";
		query_exec($sql);

  	} else {
  		$CONFIG[ERR] =1;
  		$CONFIG[BADLOGIN] =1;
  		$valid=0;
  	} 		
  	
  	return($valid);
}

function validate_license() {
	GLOBAL $CONFIG;
	
    # Turn off errors so that it won't show the URL not found error
    error_reporting(0);
	
	# CODE TO GENERATE SERIAL NUMBER; CREATES MD5 HASH of SERIAL_OWNER
	$SN = makeserial();
	$LICENSE_FILE = PB_GETLICENSEURL . $SN . '.xml';
	
	if( false == ($xmlpage=file_get_contents( $LICENSE_FILE ))) {
		$SN = makeserial();
        error(128, 'License File Not Found<br />', 'admin-authenticate.php', 'Please contact your webmaster immediately so this problem can be resolved.<br />Your serial number is: <b>' . $SN . '</b>');
    } else {
    
	$xmlpage = file_get_contents( $LICENSE_FILE );
		
	// FOR PHP5 ONLY; NEED TO UPGRADE FOR PHP4 SUPPORT
	$xml_license = new SimpleXMLElement($xmlpage);
	
	$_SESSION[SERIALLIMIT] = (string) $xml_license->add;
	$_SESSION[SERIALN] = (string) $xml_license->serial;
	$_SESSION[SERIALOWNER] = (string) $xml_license->owner;
	$_SESSION[SERIALPHONE] = (string) $xml_license->phone;
	$_SESSION[SERIALDATE] = (string) $xml_license->setupdate;
	$_SESSION[SERIALTYPE] = (string) $xml_license->type;
	$_SESSION[SERIALEXPIRES] = (string) $xml_license->expires;
	
		if($_SESSION[SERIALN] != $SN) { 
		session_destroy();
		error(147, 'Serial Number Not Valid', 'admin-authenticate.php', 'Please contact your webmaster / ' . $_SESSION[SERIALN] . ' / ' . $SN . ' / serials do not match.');
		}
	
	}
	
}

function reset_password($user) {
	GLOBAL $CONFIG;
	
// CREATE A RANDOM 10-varchar MD5 hash password
$p = substr (MD5(uniqid(rand(),1)), 3, 10);

// UPDATE DATABASE WITH NEW PASSWORD
$sql = "UPDATE users set password=PASSWORD('$p') where email='$_POST[email]'";
query_exec($sql);

$headers = "From: $CONFIG[SITE_NAME] <$_CONFIG[SITE_CONTACT_EMAIL]>"; 
$subject ="Password Reset";
$msg ="Your password has been reset to: $p";

mail($_POST[email],$subject,$msg,$headers);

}

function makeserial() {
	
	GLOBAL $CONFIG;
	$SN = md5($CONFIG[SERIALHASH]);
	$SN = join("-", str_split($SN, 4));
	$SN = strtoupper($SN);
	return($SN);
}

?>