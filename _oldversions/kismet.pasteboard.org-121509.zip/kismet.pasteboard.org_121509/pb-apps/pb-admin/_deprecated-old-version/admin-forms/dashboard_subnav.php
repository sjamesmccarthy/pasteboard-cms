<?

print "
<div id=\"nav_desc\">
<p>
<a href=\"?form=pages&m=add\">New Page</a> | <a href=\"?form=profile\">Change Password</a> | <a href=\"http://groups.google.com/group/pasteboard?hl=en\">Visit Google Group</a>
</p>
</div>";

?>