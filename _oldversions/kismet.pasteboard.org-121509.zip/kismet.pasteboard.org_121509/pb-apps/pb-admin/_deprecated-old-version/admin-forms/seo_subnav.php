<?

GLOBAL $CONFIG;

print "
<div id=\"nav_desc\">
<p>
Do-It-Yourself Links: 
<a target=\"_new\" href=\"http://www.google.com/analytics\">Google Analytics</a> | <a target=\"_new\" href=\"http://validator.w3.org/check?uri=" . $CONFIG[SITE_URL] . "\">Check Markup</a> | <a target=\"_new\" href=\"http://pagerankbot.com/\">Page Rank</a>  | <a target=\"_new\" href=\"http://www.gorank.com/analyze.php\">Keywords</a>
</p>
</div>";

?>