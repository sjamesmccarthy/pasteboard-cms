<?

require_once(ABSPATH . 'pb-admin/admin-forms/profile_form.php');
require_once(ABSPATH . 'pb-admin/admin-library/admin-authenticate.php');
		
switch($_GET[m]) {
	
	case "edit":
		$USERDATA = get_user_data();
		
		$err = check_form();
		if(!$err) { 
			$user = validate_user($_POST[username],$_POST[cpassword]);
			if($user == 1) { 
			process_form(); 
			$USERDATA[RESULTS] =1;
			$USERDATA[MSG] ="PROFILE UPDATED (Click PROFILE tab to see the changes)";
			} else {
			$USERDATA[RESULTS] =1;
			$USERDATA[MSG] ="CURRENT PASSWORD INCORRECT";
			}
		} else {
			$USERDATA[RESULTS] =1;
			$USERDATA[MSG] =$err;
		}
		
		$result = display_form($USERDATA);
		break;
	
	case "delete":
		$result = profile_delete();		
		break;
	
	default:
		$USERDATA = get_user_data();
		$result = display_form($USERDATA);
		print $result;
		break;
	
}

function profile_delete() {
	
	if($_GET[a] == "true") {
	    // DELETE SUCCESS
	    echo "
		<div id=\"content\">
		
		<p>Your profile has been deleted: (DELETE FROM users WHERE id='$_SESSION[id]')</p>
		
		<p>Redirecting to login page.</p>
		</div>
		";
		
		#$sql = "DELETE FROM users WHERE id='$_SESSION[id]'";
		#$result = query_exec($sql);
		
		header('location:auth.php?action=logout');
		exit;
		
	} else {
		// DISPLAY A FORM CONFIRMING THE DELETION OF PROFILE
		echo "
		<form id=\"delete_profile\" action=\"?form=profile&m=delete&a=true\" method=\"post\">
		
		<div id=\"content\">
		<p>
		Delete Profile for, $_SESSION[firstname] $_SESSION[lastname]?
		</p>
		
		<p>
		<input type=\"submit\" value=\"Delete Profile\">
		<input type=\"button\" value=\"Cancel\" onclick=\"location.href='?form=profile';\">
		</p>
		
		</div>
		</form>";
		exit;
		
	}
}

function check_form() {
	
	// CHECK CURRENT PASSWORD FIELDS
	if(!$_POST[cpassword]) { $err = "<p>Enter Current Password</p>"; }
	
	// VALIDATE NEW PASSWORD FIELDS
	if($_POST[password]) {
		if(!$_POST[password]) {$err .= "<p>Password field is blank</p>"; }
		if(!$_POST[repassword]) {$err .= "<p>Verify Password field is blank</p>"; }
		if($_POST[password] != $_POST[repassword]) {
		$err .= "<p>Passwords don't match</p>";
		}
	}
	
	return($err);
	
}

function process_form() {

	if($_POST[password]) {
		$pswdUpd = "password = PASSWORD('$_POST[password]'),";
	}
	
	// UPDATE DATABASE WITH NEW PROFILE INFORMATION
	$sql = "UPDATE users set
				firstname = '$_POST[firstname]',
				lastname = '$_POST[lastname]',
				email = '$_POST[email]',
				$pswdUpd
				hint = '$_POST[hint]'
				WHERE id = '$_POST[uid]'	
	";
	query_exec($sql);
}

?>