<?
$FILENAME = ABSPATH . '/pb-configsite.php';

print "
<div id=\"nav_desc\">
<p>
Your SETTINGS file was last updated on " . date("F d Y H:i:s", filemtime($FILENAME)) . " EST
</p>
</div>
";

?>
