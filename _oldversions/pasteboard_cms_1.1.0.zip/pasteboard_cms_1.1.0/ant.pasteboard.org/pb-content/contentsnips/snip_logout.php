<?php

/**
 * @FILE		/pb-content/phpsnips/snip_logout.php
 * @DESC		logs you out of the admin area; destroys session
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @PARAMS		0
 * @USAGE       <? snip_logout(); ?>
 */
 
 function snip_logout($param = '0') {
 		
 		$snippet = "<p>success : session_destroyed</p>";		 
 		session_destroy();
 		
 	return($snippet);
 	// Returns the output of the snippet to pb-contentsnips_loader.php
 	
 }

?>