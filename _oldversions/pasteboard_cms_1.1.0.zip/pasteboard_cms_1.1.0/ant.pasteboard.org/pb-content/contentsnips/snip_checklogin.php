<?php

/**
 * @FILE		/pb-content/phpsnips/snip_checklogin.php
 * @DESC		logs you out of the admin area; destroys session
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @PARAMS		0
 * @USAGE       <? snip_login(); ?>
 */
 
 function snip_checklogin($param = '0') {
 		
 		if($_SESSION[username]) { 
 		header('location:/pb-admin/');
 		} else {
 		 // log to errors() log
 		} 
 				 		
 	return($snippet);
 	// Returns the output of the snippet to pb-contentsnips_loader.php
 	
 }

?>