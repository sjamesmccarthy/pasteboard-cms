<? 

/*
// -------------------------------------------------------------------
// WRAPPER FILE
// -------------------------------------------------------------------
// This file is used as a wrapper to start the pb-engine. It does 
// nothing but require the controller for the main front-view of the
// website and DEFINEs that pasteboard is running and stars a session.
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// Do not modify.
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/

session_start();
define('PB-START', 'TRUE');
require("./pb-controllers/c_start.php");

/* End of file */
/* Location: index.php */