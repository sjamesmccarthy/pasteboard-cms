<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<!--
Design by James McCarthy
http://www.pasteboard.org
Copyright 2008
-->

<head>

<!-- required: plops the page title based on the XML file -->
<title><? print $CONFIG[SITE_NAME] . "| Admin &raquo; "; print $_GET[form]?></title>

<!-- required: base href so you don't have to keep writing this for all relative URLs -->
<base href="<? print $CONFIG[SITE_URL]; ?>/pb-admin/" />
	
<!-- optional: favorite icon, okay to remove if you don't want to use -->
<link rel="shortcut icon" href="admin-themes/<? print $CONFIG[ADMINTHEME]; ?>/images/favicon.ico" type="image/x-icon" />
	
<!-- required: CSS information -->
<link href="admin-themes/<? print $CONFIG[ADMINTHEME]; ?>/css/default.css" rel="stylesheet" type="text/css" media="screen" />

<body id="<? print $_GET[form]; ?>">

<div id="wrap">
	<div id="header"><h1><? print substr($CONFIG[SITE_NAME],0,25); ?></h1>&nbsp;&raquo; <a target="_new" href="<? print $CONFIG[SITE_URL]; ?>">view site</a></div>
	<div id="welcome"><p><? print $_SESSION[username]; ?><br /><a href="/?p=contact">support</a> . <a href="<? print $CONFIG[SITE_URL]; ?>/pb-admin/auth.php?action=logout">logout</a></p></div>	
	
		<!-- <form id="sysadmin"> -->
		<div id="nav">
		<ul>
			<li id="nav-dashboard"><a href="?form=dashboard">Dashboard</a></li> .
			<li id="nav-pages"><a href="?form=pages">Content</a></li> .			
			<!-- <li id="nav-plugins"><a href="?form=plugins">Plugins</a></li> . -->
			<li id="nav-files"><a href="?form=files">Files</a></li> .
			<li id="nav-profile"><a href="?form=profile">Profile</a></li> .
			<li id="nav-settings"><a href="?form=settings">Settings</a></li>
			
			<? 
			#commenting out for now
			#if($_SESSION[role] == "system") { build_sysadmin(); } 
			?>
			
		</ul>
	</div>
	<!-- </form> -->
	
	<? build_subnav(); ?>
	
	<div id="main">
	<? build_form($_GET[form]); ?>
	</div>
	
</div>
	<div id="footer">
		<p>powered by PASTEBOARD v<? print PB_VERSION; ?> | copyright <? print $CONFIG[FORMAT_YEAR]; ?> The PasteBoard Group | theme: <? print $CONFIG[ADMINTHEME]; ?></p>
	</div>
	
</body>

</html>