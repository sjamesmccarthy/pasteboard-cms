<?

// This should be in a config file.
define('FILES', 'pb-content/files/');
$i=0; //count var for number of files

function display_listings($dirList) {
	
	//<form id="pages_form" action="?form=pages&m=create" method="post">
	// THIS IS WHERE THE PAGE WILL BE GENERATED (should this be in a template)
	$textbox = "
	<div id=\"content\"> <!-- content -->
	<h1>File Explorer</h1>
	<p class=\"title\">Active Directory: /home/nncil/" . FILES . "</p>";
	$textbox .= "<form action=\"?form=files&m=upload\" method=\"post\" enctype=\"multipart/form-data\">Add new file: <input type=\"file\" name=\"form_filename\" size=\"chars\"> <input type=\"submit\" value=\"upload file\" /></form>";
	
	$textbox .= "<table width=\"100%\" border=\"0\" cellpadding=\"5\">";
	$textbox .= "
	<tr bgcolor=\"#000000\" align=\"center\" style=\"background: #000000; color:white;\">
	<th width=\"70%\">File Name</th>
	<th width=\"30%\">Action</th>
	</tr>";
	
	foreach($dirList as $file) {
		$textbox .= "
		<tr bgcolor=\"#CCCCCC\" align=\"left\" class=\"pagelist\">
		<td width=\"70%\">$file</td>
		<td width=\"30%\"><a href=\"?form=files&m=rename&file=$file\">rename</a> | <a href=\"?form=files&m=delete&file=$file\">delete</a> | <a href=\"?form=files&m=copy&file=$file\">copy</a> | <a target=\"_new\" href=\"$CONFIG[SITE_URL]/pb-content/files/$file\">view</a></td>
		</tr>";
		$i++;	
	}
	
	$textbox .= "<tr><td colspan=\"3\">$i files found</td></tr>";
	$textbox .= "</table>";

	$textbox .= "</div> <!-- content -->";
	
	// SIDEBAR AREA
	$textbox .= "
	<div id=\"sidebar\"> <!-- sidebar -->
	<div id=\"sidebar_details\">
	<p class=\"heading\">FILES (Management)</p>
	
	<p style=\"margin-left: 5px;\">
	This area displays all the files in the /files/ directory.</p>
	</div>
	
	<div id=\"sidebar_details\">
	<p class=\"heading\">OPTIONS</p>
	<p style=\"margin-left: 5px;\">
	Please see listing to the left for any available options.	
	</p>
	</div>
	</div> <!-- sidebar -->";

	return($textbox);
}


function getFileListing() {

	$dir = opendir(ABSPATH . FILES);
	$fileList = array();
	while($file = readdir($dir)) 
	{
	
		if(($file != ".") && ($file != "..")) { array_push($fileList, $file); }
	
	}
	
	closedir($dir);
	
	asort($fileList);
	
	return($fileList);
}

function uploadFile($_FILES) {

/*
php_value upload_max_filesize 20M
php_value post_max_size 20M
php_value max_execution_time 200
php_value max_input_time 200
*/
	
	ini_set("upload_max_filesize","8M");
	ini_set("post_max_size","16M");
	ini_set("max_execution_time","200");
	ini_set("max_input_time","200");
	
	echo "<div style=\"padding: 20px 0 0 20px\">";
	
	if ((($_FILES["form_filename"]["type"] == "image/gif")
|| ($_FILES["form_filename"]["type"] == "image/jpeg")
|| ($_FILES["form_filename"]["type"] == "image/jpg")
|| ($_FILES["form_filename"]["type"] == "image/pjpeg")
|| ($_FILES["form_filename"]["type"] == "application/pdf")))
  {
  if ($_FILES["form_filename"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["form_filename"]["error"] . "<br />";
    }
  else
    {
    echo "Upload: " . $_FILES["form_filename"]["name"] . "<br />";
    echo "Type: " . $_FILES["form_filename"]["type"] . "<br />";
    echo "Size: " . ($_FILES["form_filename"]["size"] / 1024) . " Kb<br />";
    echo "Temp file: " . $_FILES["form_filename"]["tmp_name"] . "<br />";

    if (file_exists("upload/" . $_FILES["form_filename"]["name"]))
      {
      echo $_FILES["form_filename"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["form_filename"]["tmp_name"],
      ABSPATH . FILES . $_FILES["form_filename"]["name"]);
      echo "Stored in: " . ABSPATH . FILES . $_FILES["form_filename"]["name"];
      echo "<hr />" . "<a href=\"?form=files\">Return to File Manager</a>";
      }
    }
  }
else
  {
  echo "Invalid file";
  print "<pre>";
  print_r($_FILES);
  print "</pre>";
  }

	echo "</div>";
}

?>