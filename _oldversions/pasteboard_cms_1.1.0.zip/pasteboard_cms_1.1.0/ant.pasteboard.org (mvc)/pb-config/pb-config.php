<?php

if ( ! defined('PB-START')) exit('No direct script access allowed');

/*
// -------------------------------------------------------------------
// CONFIGURATION FILE
// -------------------------------------------------------------------
// This file defines constants that will be used in the pasteboard
// application.
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// Do not modify.
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/

$PHPVERSION= split('\.', PHP_VERSION); // ex. 5.0
define('PB_VERSION', '110');
define('PB_LAST_UPDATED', '09-16-08');
define('PB_GETVERSIONURL', 'http://www.pasteboard.org/_version/updater.xml');
define('PB_GETLICENSEURL', 'http://www.pasteboard.org/_licenses/');
define('PB_LICENSEFILE', $CONFIG[SITE_URL] . '/license.pdf');
define('PB_NAME', 'pasteboard.cms');
define('PB_DEVELOPER', 'James McCarthy');
define('PB_URL', 'http://www.pasteboard.org');
define('PB_SUPPORT_URL', PB_URL . '/support/');
define('TPLEXT', 'php');
define('PB_ROOT', 'pb-content/');
define('ABSPATH', dirname(__FILE__) . '/');
define('URLPATH', $CONFIG[SITE_URL]);
define('PAGESPATH', 'pb-content/pages/');
define('THEMESPATH', 'themes/' . $CONFIG[THEME] . '/');
define('TEMPLATEPATH', 'themes/' . $CONFIG[THEME] . '/templates/');
define('CONTENTSNIPSPATH', 'pb-content/contentsnips/');
define('PLUGINSPATH', 'pb-plugins/');
define('CHARACTER_ENDCODING', 'text/html; charset=UTF-8');
define('LANGUAGE','us-EN');
define('RELPATH', ''); 
define('BASE_HREF', URLPATH);
define('VERSIONOFPHP', $PHPVERSION[0]); 
define('MYSQLDATETIME', date( 'Y-m-d H:i:s'));
define('USELICENSE)', '1');

/* End of file */
/* Location: ./pb-config.php */
