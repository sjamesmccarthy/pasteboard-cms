<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/*
// -------------------------------------------------------------------
// c_start.php()
// -------------------------------------------------------------------
// Controller file for starting the engine. Loads REQUIRED files and 
// then passes to correct view. Views can be: xml, database or admin
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// none
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/

// LOAD PASTEBOARD REQUIRED FILES //
require_once('./pb-configsite.php');
require_once("./pb-config.php");
require_once('./pb-models/pb-common.php');

// LOAD CONTENT FROM REQUESTED XML FILE, DEFAULTS to home.xml //
require_once('./pb-models/pb-content_loader.php');

// LOAD CSS FILE(S) //
require_once('./pb-models/pb-css_loader.php');

// LOAD LICENSE FUNCTION // 
$LICENSE = license();

// DISPLAY THE PAGE //	
ob_start();
include_once('./pb-models/pb-template_loader.php');
ob_end_flush();

#
if($CONFIG[DEBUG] == 1) print "<hr />" . $debug;
# Move this into a function in pb-core.php | usage: debug('run'); //
# Maybe make it a pesky javascript popup menu //

/* End of file */
/* Location: ./pb-controllers/c_start.php */