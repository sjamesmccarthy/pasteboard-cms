<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/*
// -------------------------------------------------------------------
// c_install.php()
// -------------------------------------------------------------------
// Controller file for installing pasteboard.
//
// -------------------------------------------------------------------
// USAGE INSTRUCTIONS
// -------------------------------------------------------------------
// NOT BEING USED AS OF NOW
//
// -------------------------------------------------------------------
// UPDATE HISTORY
// -------------------------------------------------------------------
// SJM - 01/06/09 - Added new header/footer comments
//
*/

/* End of file */
/* Location: ./pb-controllers/c_install.php */