#_blog ( main content )
#_blogcomments ( main content feedback 
#_blogcategories ( describes blog content )
#_blogtags ( describes content sources: blog, reviews, articles, etc. )
#_blogteam ( sets up multiple bloggers for 1 blog)
#_blogregs ( index of blogs )
#_blogtrackbacks ( keeps track of trackback URLs + info )
#_blogtemplate ( keeps track of the blog templates available )
#_admin ( login/pswd for site admin; admin does need profile )
#_adminapps ( blog,profile,links,admin ) 
#_adminpermissions ( which profile users have persmissions for what apps)
#_profile ( user/reader account info )
#_profileoptions ( not core profile data eg., )
#_profilelists ( opt-in emailing lists for user/reader )
#_profiledemographics ( extra info by site )
#_profilefriends ( id_links to friends )<?
#_profilelogin ( login/pswd for profile user/reader )
#_profilezips ( zipcode, latitude, longitude, city, state, abbr : http://www.teamredline.com/zc/ )
#_profilelocalfavs ( favorite local links/bookmarks ; save as for anything on the site )
#_msgsindex ( mail header info )
#_msgscontent ( mail message body )

# #####
# GADGETME.COM gm_
# SQL create tables for CORE v.1
# January 25, 2007, February 8, 2007
# #####

create table gm_blogreg(
	blogreg_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	blogtemplates_id int(10),
	blogreg_name varchar(255),
	blogreg_description TEXT,
	blogreg_linkout enum('true','false') not null default 'false',
	blogreg_linkurl varchar(255),
	blogreg_trackbackson enum('true','false') not null default 'true',
	blogreg_mailtrackbacks enum('true','false') not null default 'true',
	blogreg_mailcomments enum('true','false') not null default 'true',
	blogreg_enabled enum('true','false') not null default 'true',   
	PRIMARY KEY (blogred_id)
) Type=MyISAM comment 'Blog registration for multiple blogs';

create table gm_blogteam(
	blogteam_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	blogreg_id int(10),
	blogteam_enabled enum('true','false') not null default 'true',   
	PRIMARY KEY (blogteam_id)
) Type=MyISAM comment 'Who is a blogger for which blog';

create table gm_blogposts(
	blogposts_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10),
	blogposts_cat_id int(2),
	blogposts_title varchar(255),
	blogposts_content LONGTEXT,
	blogposts_created DATETIME not null default '0000-00-00 00:00:00',
	blogposts_changed DATETIME not null default '0000-00-00 00:00:00',
    blogposts_views int(20),
    blogposts_ping enum('true','false') not null default 'false',
	blogposts_private enum('true','false') not null default 'false',
	blogposts_hidefromhome enum('true','false') not null default 'false',
	blogposts_isdraft enum('true','false') not null default 'false',
	blogposts_comments enum('open','closed','registered_only','moderated') NOT NULL default 'open',
	PRIMARY KEY (blogposts_id)
) Type=MyISAM comment 'Individual blog posts for any blog'; 

create table gm_blogtrackbacks(
	blogtrackbacks_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	blogposts_id int(10) unsigned,
	blogtrackbacks_title varchar(255),
	blogtrackbacks_url varchar(255),
	blogtrackbacks_enabled enum('true','false') not null default 'true',   
	PRIMARY KEY (blogtrackbacks_id)
) Type=MyISAM comment 'Who is linking to specific blog posts';

create table gm_blogcomments(
	blogcm_id int(10) NOT NULL AUTO_INCREMENT,
	blogposts_id int(10) unsigned,
    profile_id int(10) unsigned,
    blogcm_name varchar(255),
    blogcm_email varchar(255),
    blogcm_title varchar(255),
    blogcm_content LONGTEXT,
    blogcm_created DATETIME not null default '0000-00-00 00:00:00',
    blogcm_changed DATETIME not null default '0000-00-00 00:00:00',
    blogcm_ping enum('true','false') default 'false',
    blogcm_private enum('true','false') default 'false',
	PRIMARY KEY (blogcm_id)
) Type=MyISAM comment 'Comments for specific blog posts';

create table gm_blogtags(
	blogtags_id int(10) NOT NULL AUTO_INCREMENT,
	blogcat_id int(10) unsigned,
	blogposts_id int(10) unsigned,
	blogtags_name varchar(255),
	PRIMARY KEY (tag_id)
) Type=MyISAM comment 'Tags for specific blog posts';

create table gm_blogcategories(
	blogcat_id int(10) NOT NULL AUTO_INCREMENT,
	blogcat_name varchar(255),
	blogcat_description TEXT,
	blogcat_enabled enum('true','false') DEFAULT 'true',
	PRIMARY KEY (cat_id)
) Type=MyISAM comment 'Generalized categories for specific blog posts';

create table gm_blogtemplates(
	blogtemplates_id int(10) NOT NULL AUTO_INCREMENT,
	blogtemplates_name varchar(255),
	blogtemplates_description TEXT,
	blogtemplates_path varchar(255)
	blogtemplates_enabled enum('true','false') DEFAULT 'true',
	PRIMARY KEY (blogtemplates_id)
) Type=MyISAM comment 'template index for blog app';

create table gm_admin(
	admin_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	admin_status enum('neo','publisher','editor','writer','guest')
    admin_enabled enum('true','false') default 'false',
	PRIMARY KEY (admin_id)
) Type=MyISAM comment 'Links profiles with administrative functions';

create table gm_adminapp(
	adminapp_id int(10) NOT NULL AUTO_INCREMENT,
	adminapp_name varchar(255),
	adminapp_description varchar(255),
	adminapp_status enum('group','private') default 'private',
	adminapp_enabled enum('true','false') default 'true',
	PRIMARY KEY (app_id)
) Type=MyISAM comment 'Definition of apps available such as blogs-reviews-friends-etc';

create table gm_adminpermissions(
	adminpermissions_id int(10) NOT NULL AUTO_INCREMENT,
	adminapp_id int(10) unsigned,
	profile_id int(10) unsigned,
    adminpermissions_read enum('public','private','super','none') default 'none',
    adminpermissions_write enum('public','private','super','none') default 'none',
    adminpermissions_execute enum('public','private','super','none') default 'none',
	PRIMARY KEY (app_id)
) Type=MyISAM comment 'Sets what profile_id can access what app';

create table gm_profile(
	profile_id int(10) NOT NULL AUTO_INCREMENT,
    profilelogin_id int(10) unsigned,
	profile_firstname varchar(255),
    profile_lastname varchar(255),
    profile_suffix varchar(10),
    profile_prefix varchar(10),
    profile_avatar varchar(255),
    profile_address varchar(255),
    profile_address2 varchar(255),
    profile_city varchar(255),
   	profile_state char(2) unsigned,
	profile_zip int(5) unsigned,
    profile_country char(2) unsigned not null default 'US',
	PRIMARY KEY (profile_id)
) Type=MyISAM comment 'readers and site contributor personal data';

create table gm_profileoptions(
	profileoptions_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	PRIMARY KEY (profileoptions_id)
) Type=MyISAM comment 'extra profile data necessary for website';

create table gm_profilefriends(
	profilefriends_id int(10) unsigned,
	profile_id int(10) unsigned
) Type=MyISAM comment 'tracks ids of of profiles that know each other';

create table gm_profilezips(
	profilezips_id int(10) NOT NULL AUTO_INCREMENT,
	profilezips_zipcode int(5) unsigned,
	profilezips_latitude varchar(15),
	profilezips_longitude varchar(15),
	profilezips_city varchar(100),
	profilezips_state varchar(100),
	profilezips_abrev varchar(2),
	PRIMARY KEY (profilezips_id)
) Type=MyISAM comment 'all zipcodes in the US';

create table gm_profilelists(
	profilelists_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	profilelists_name varchar(255),
	profilelists_description varchar(255),
	profilelists_enabled enum('true','false') not null default 'true',
	profilelists_lastsent DATETIME not null default '0000-00-00 00:00:00',
	profilelists_lastcount int(5) unsigned, 
	PRIMARY KEY (profilelists_id)
) Type=MyISAM comment '';

create table gm_profilelogin(
	profilelogin_id int(10) NOT NULL AUTO_INCREMENT,
	profilelogin_name varchar(255),
	profilelogin_password varchar(50),
    profilelogin_lastvisit DATETIME not null default '0000-00-00 00:00:00',
    profilelogin_created DATETIME not null default '0000-00-00 00:00:00',
    profilelogin_admin enum('true','false') not null default 'false',
    profilelogin_enabled enum('true','false') not null default 'true',
	PRIMARY KEY (profilelogin_id)
) Type=MyISAM comment 'user login and password';

create table gm_profiledemographics(
	profiledemographics_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	PRIMARY KEY (profiledemographics_id)
) Type=MyISAM comment 'extra information';

create table gm_profilelocalfavs(
	profilelinkfavs_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	cat_id(10) unsigned,
	profilelinkfavs_title varchar(255),
	profilelinkfavs_url varchar(255),
	profilelinkfavs_description MEDIUMTEXT,
	profilelinkfavs_created DATETIME not null default '0000-00-00 00:00:00',
	profilelinkfavs_changed DATETIME not null default '0000-00-00 00:00:00',
    profilelinkfavs_views int(20) unsigned,
	profilelinkfavs_private enum('true','false') not null default 'false',
	PRIMARY KEY (profilelinkfavs_id)
) Type=MyISAM comment 'save-as favorites for local links';

create table gm_msgbox(
	msgbox_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	msgbox_sendtoid int(10) unsigned,
	msgbox_ip int(25) unsigned,
	msgbox_flag enum('unread','read','deleted','archived') not null default 'unread',
	msgbox_datesent DATETIME not null default '0000-00-00 00:00:00',
	msgbox_dateread DATETIME not null default '0000-00-00 00:00:00',
	msgbox_encrypted enum('true','false') not null default 'false',
	msgboxemail_id int(10) unsigned,
	PRIMARY KEY (msgbox_id)
) Type=MyISAM comment 'header data for internal mail system';

create table gm_msgboxemail(
	msgboxemail_id int(10) NOT NULL AUTO_INCREMENT,
	msgbox_id int(10) unsigned,
	profile_id int(10) unsigned,
	msgboxemail_content LONGTEXT,
	PRIMARY KEY (msgboxemail_id)
) Type=MyISAM comment 'message data for internal mail system';

create table gm_categories(
	cat_id int(10) NOT NULL AUTO_INCREMENT,
	cat_name varchar(255),
	cat_enabled enum('true','false') DEFAULT 'true',
	PRIMARY KEY (cat_id)
) Type=MyISAM comment '';

#_review (base off of blog)
#_reviewlinks (base off of linkfavs)
#_reviewproscons (pros cons list)
#_reviewcommments (base off of blogcomments)
#_reviewtips (tips for reviewed product)
#_reviewvendors (contact information about vendors to be used as ad leads)
#_reviewassignments (tracks assignments for writers)
#_reviewtrackbacks

create table gm_review(
	review_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	reviewcategory_id int(10) unsigned,
	reviewvendor_id int(10) unsigned,
	reviewassign_id int(10) unsigned,
	review_title varchar(255),
	review_content LONGTEXT,
	review_price DECIMAL(5,2),
	review_rating int(1) not null default 0,
	review_suppliedby TEXT,
	review_website varchar(255),
	review_created DATETIME not null default '0000-00-00 00:00:00',
	review_lastupdted DATETIME not null default '0000-00-00 00:00:00',
	review_views int(10) not null default 0,
	review_comments enum('true','false'),
	PRIMARY KEY (review_id)
) Type=MyISAM comment 'main review data';

create table gm_reviewlinks(
	reviewlinks_id int(10) NOT NULL AUTO_INCREMENT,
	review_id int(10),
	reviewcategories_id int(10),
	reviewlinks_title varchar(255),
	reviewlinks_url varchar(255),
	reviewlinks_description MEDIUMTEXT,
	reviewlinks_created DATETIME not null default '0000-00-00 00:00:00',
	reviewlinks_enabled enum('true','false') not null default 'trues'
	PRIMARY KEY (reviewcategories_id)
) Type=MyISAM comment 'any links associated with review';

create table gm_reviewproscons(
	reviewproscons_id int(10) NOT NULL AUTO_INCREMENT,
	review_id int(10),
	reviewproscons_description MEDIUMTEXT,
	PRIMARY KEY (reviewcategories_id)
) Type=MyISAM comment 'pros and cons list for reviews';

create table gm_reviewtips(
	reviewtips_id int(10) NOT NULL AUTO_INCREMENT,
	review_id int(10),
	profile_id int(10),
	reviewtips_title MEDIUMTEXT,
	reviewtips_description MEDIUMTEXT,
	reviewtips_enabled enum('true','false') not null default 'true'
	PRIMARY KEY (reviewtips_id)
) Type=MyISAM comment 'registered user tips and tricks for reviews';

create table gm_reviewcomments(
	reviewcomments_id int(10) NOT NULL AUTO_INCREMENT,
	review_id int(10) unsigned,
    profile_id int(10) unsigned,
    reviewcomments_name varchar(255),
    reviewcomments_email varchar(255),
    reviewcomments_title varchar(255),
    reviewcomments_content LONGTEXT,
    reviewcomments_created DATETIME not null default '0000-00-00 00:00:00',
    reviewcomments_changed DATETIME not null default '0000-00-00 00:00:00',
    reviewcomments_ping enum('true','false') default 'false',
    reviewcomments_status enum('open','closed','registered_only') NOT NULL default 'open',
	PRIMARY KEY (reviewcomments_id)
) Type=MyISAM comment 'registered user comments for reviews';

create table gm_reviewtrackbacks(
	reviewtrackbacks_id int(10) NOT NULL AUTO_INCREMENT,
	profile_id int(10) unsigned,
	review_id int(10) unsigned,
	reviewtrackbacks_title varchar(255),
	reviewtrackbacks_url varchar(255),
	reviewtrackbacks_enabled enum('true','false') not null default 'true',   
	PRIMARY KEY (reviewtrackbacks_id)
) Type=MyISAM comment 'trackback urls for reviews';

create table gm_reviewvendors(
	reviewvendors_id int(10) NOT NULL AUTO_INCREMENT,
	review_id int(10),
	profile_id int(10),
	admin_id int(10),
	reviewcategory_id int(10),
	reviewvendors_firstname varchar(255),
	reviewvendors_lastname varchar(255),
	reviewvendors_email varchar(255),
	reviewvendors_type enum('corp','pr') not null default 'corp'
	reviewvendors_compname varchar(255),
	reviewvendors_address varchar(255),
	reviewvendors_address2 varchar(255),
	reviewvendors_city varchar(255),
	reviewvendors_state char(2), 
	reviewvendors_province varchar(100),
	reviewvendors_country char(2),
	reviewvendors_phone char(15),
	reviewvendors_fax char(15),
	reviewvendors_methodofcontact enum('phone','email','im','mail'),
	reviewvendors_website varchar(255),
	reviewvendors_lastupdate DATETIME not null default '0000-00-00 00:00:00',
	reviewvendors_contentpublished varcahr(255),
	PRIMARY KEY (reviewtips_id)
) Type=MyISAM comment 'vendor information for reviews and ad leads';

create table gm_reviewassignment(
	reviewassignment_id int(10) NOT NULL AUTO_INCREMENT,
	review_id int(10),
	profile_id int(10),
	admin_id int(10),
	reviewcategory_id int(10),
	reviewassignment_title varchar(255),
	reviewassignment_website varchar(255),
	reviewassignment_status enum('assigned','available','requested','complete'),
	reviewassignment_created DATETIME not null default '0000-00-00 00:00:00',
	reviewassignment_changed DATETIME not null default '0000-00-00 00:00:00',
	reviewassignment_complete DATETIME not null default '0000-00-00 00:00:00',
	PRIMARY KEY (reviewassignment_id)
) Type=MyISAM comment 'list of product to review';