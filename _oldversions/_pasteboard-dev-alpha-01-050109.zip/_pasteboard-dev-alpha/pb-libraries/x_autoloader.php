<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		loader_m.php
 * @DESC		loader model: content, css, template, helpers
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com 
 * @FUNCTIONS	
 */
 
function loadPageContentXML() {
 	
 	print "<pre>";
 	print_r($_GET);
 	
	#if($_GET[p]) { $_GET[page] = $_GET[p]; }
	if(!$_GET[page]) { $_GET[page] = "home"; }
	
	$XML_FILE = PB_ROOT . PB_CONTENT . PB_PAGES . $_GET[page] . ".xml";
	
	if(VERSIONOFPHP == 5) {
		if(file_exists($XML_FILE)) {
		$PAGE_OBJ = xmlp5($XML_FILE);
		} else {
		    if($CONFIG[USE404] == "on") {
		    $PAGE_OBJ = xmlp5(PB_ROOT . PB_CONTENT . PB_PAGES . '404.xml');
		    } else {
    	    error(28, 'XML File Not Found', 'pb-content_loader.php', $XML_FILE); 
		    } 
		}
	} else {
		$PAGE_OBJ = xmlp4($XML_FILE);
	}
	
	
	// LOAD EACH XML ELEMENT INTO VARIABLE
	foreach ($PAGE_OBJ as $key => $value) { 
		${strtoupper($key)} = $value;
		$SHOW[strtoupper($key)] .= $PAGE_OBJ->$key;
	}
	
	// SCRUB DATA
	#$SHOW[TITLE] = preg_replace('/&/i', '&amp;', $SHOW[TITLE]);
	$SHOW[TITLE] = htmlentities($SHOW[TITLE]);
	$SHOW[CONTENT] = html_entity_decode($SHOW[CONTENT]);
	#$SHOW[CONTENT] = preg_replace('/&/i', '&amp;', $SHOW[CONTENT]);
		
    // CHECK PAGE STATUS
    if($SHOW[STATUS] == "archived" || $SHOW[STATUS] == "draft" || $SHOW[STATUS] == "hidden") {
         error(48, 'UNABLE TO DISPLAY CONTENT<br />it may be archived or saved as draft', 'pb-content_loader.php', $XML_FILE); 
    }   
    
// SEARCH FOR TEMPLATESNIPS AND REPLACE WITH RESULTS FROM SNIP
	include( PB_ROOT . PB_LIBRARIES . "pb-helpers_loader.php");
}

function loadCSSfiles() 
{

 	# REMOVE the .ext on the end of the file. 
	$TEMPLATE_SPLIT = split("\.", $TEMPLATE); 
	$TEMPLATE = $TEMPLATE_SPLIT[0];
    
    $CSS_FILE = PB_ROOT . PB_CONTENT . THEMESPATH . "css/" . $TEMPLATE . ".css";
	
	if(file_exists($CSS_FILE)) { 
		$CONFIG[CSSFILE] = THEMESPATH . "css/" . $TEMPLATE . ".css";
	} else {
	    #$CONFIG[CSSFILE] = "themes/default/css/default.css";
	    error(26, 'CSS File Not Found', 'pb-css_loader.php', $CSS_FILE);
	}
	
// LOAD PAGE CSS IF SPECIFIED AND IF EXISTS
    $PAGE_CSS_FILE = PB_ROOT . PB_CONTENT . THEMESPATH . "css/" . $PAGECSS;
    
 	if($PAGECSS && $PAGECSS != "none") {
    	if(file_exists($PAGE_CSS_FILE)) { 
    		$SHOW[PAGE_CSS] = "@import url(" . THEMESPATH . "css/" . $PAGECSS . ");";
    	} else {
    	  error(36, 'PAGE-CSS File Not Found', 'pb-css_loader.php', $PAGE_CSS_FILE);   
    	}
	}

}