<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		system.php
 * @DESC		contains functions for system-level actions such as file locking,
 			    timer (start/stop), preint_r (print_r replacement), log, user_agent (also config - @array),			
				is_{type}, etc.
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	TRUE
 */
 
/******************************************************************
* Function Name: pb_timerOn
* Parameters: $tName
* Description: Starts a timer
* Return type: $timers array
*******************************************************************/ 
function pb_timerOn($tName) 
{

	global $timers;
		
	$mtime = microtime(); 
	$mtime = explode(' ', $mtime); 
	$mtime = $mtime[1] + $mtime[0]; 

	$timers[$tName] = $mtime; 
	
	return($timers);
	
}

/******************************************************************
* Function Name: pb_timerOff
* Parameters: $tName
* Description: Stops a timer
* Return type: $timer array
*******************************************************************/ 
function pb_timerOff($tName) 
{
	
	global $timers;
	
	$mtime = microtime(); 
    $mtime = explode(" ", $mtime); 
    $mtime = $mtime[1] + $mtime[0]; 
    $endTime = $mtime; 
    $timers[$tName] = round(($endTime - $timers[$tName]),3); 

	return($timers);

}

/******************************************************************
* Function Name: pb_timerReset
* Parameters: $tName
* Description: Resets a timer array; if left without args = ALL
* Return type: NULL
*******************************************************************/ 
function pb_timerReset($tName='ALL')
{
	global $timers;
	$rTimer = split(',', $tName);
	
	if($rTimer[0] === "ALL") 
	{
		foreach($timers as $key => $value)
	 	{
	 		unset($timers[$key]);
	 	}
	} else {
		foreach($rTimer as $i) { unset($timers[$i]); }
	}
	
}

/******************************************************************
* Function Name: preint_r
* Parameters: $value
* Description: Formats print_r with <pre> statement to make pretty
* Return type: TRUE
*******************************************************************/ 
function preint_r($value) 
{
	
	print "<pre>";
	print_r($value);
	print "</pre>";
	
	return(TRUE);
}

/* End of file */
/* Location: ./pb-content/config/pb-configsite.php */
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */