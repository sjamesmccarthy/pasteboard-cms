<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		boostrap_c.php
 * @DESC		initializes the pasteboard system
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	pb_boostrap, pb_router
 */

/******************************************************************
* Function Name: pb_bootstrap
* Parameters: $autoload(array)
* Description: Autoloads library files so there isn't a mess of require 
			   statements on the page.
* Return type: TRUE
*******************************************************************/ 
function pb_bootstrap() 
{
	global $timers;
	
	error_reporting(E_STRICT);
	require('./pb-config/pb-config.php');
	pb_autoload($autoload_f,0);	
	
	# START THE OUTPUT BUFFER, SESSION, TIMER
	pb_timerOn('start');
		
	session_start();
	ob_start();
	
	#pb_sanitize_uri();
	pb_router(); # just hand the request to the correct controller; that's all.
	
	pb_timerOff('start');
	$result .= "<p style='text-align:center'>bootstrap(complete).beta | Load.Timer(" . $timers['start'] . ")</span>";
		
	pb_timerReset();
	
	print $result;
	ob_end_flush();
	return(TRUE);
}

/******************************************************************
* Function Name: pb_autoload
* Parameters: $autoload_f(array)
* Description: Autoloads the library files as well as performs single file loading of 
* files if necessary.
* Return type: TRUE
*******************************************************************/ 
function pb_autoload($autoload_f,$mode='0')
{
		
		foreach ($autoload_f as $key=>$value)
		{
			
			foreach($autoload_f[$key] as $filename) 
			{
				
				$required_file = PB_ROOT . $key . DS . $filename . LIBEXT;
				if(file_exists($required_file))
				{
					require($required_file);
				} else {
					#log_error
				}
			}
			
		}
		
	return(TRUE);	
}

/******************************************************************
* Function Name: pb_sanitize_uri
* Parameters: $_REQUEST(array)
* Description: Cleans URI of any strange characters.
* files if necessary.
* Return type: TRUE
*******************************************************************/ 
function pb_sanitize_uri($_REQUEST)
{
	# How do I want to santitize the query str.
	# $1 will always be {str > 10} / $2 will always be {{int > 5}
	$permitted_uri_chars = 'a-z 0-9~%.:_\-';
	
	return(TRUE);	
}
/******************************************************************
* Function Name: pb_router
* Parameters: $type
* Description: Displays the kind of page to be displayed. Two most common types would
* be ADMIN and PAGES, but with the other modules you could have BLOG, REVIEW, ARTICLE.
* It will then be routed to the appropriate CONTROLLER.
* Return type: TRUE
*******************************************************************/ 
function pb_router($type='page') 
{
	
	#load the required controller
	#require(PB_CONTROLLERS . DS . 'pb-pages_m.php');
	#error('Unable to load your default controller.  Please make sure the controller specified in your Routes.php file is valid.');
	
	#switch is no longer needed if routing based on URL or argument (c)ontroller.
	switch($type) 
	{
	
	case "page":
	
		#require(PB_MODELS . DS . 'pb-pages_m.php');
		global $SHOW;
		$SHOW = content_loader();
		css_loader();
		helpers_loader();
		template_loader();
		
		break;
		
	case "admin":
		
		#require(PB_MODELS . DS . 'pb_admin-m.php');
		print "admin.load";
		break;
		
	}

}


/* End of file */
/* Location: ./pb-controllers/bootstrap_c.php */ 
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */