<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		boostrap_c.php
 * @DESC		initializes the pasteboard system
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	pb_boostrap, pb_router
 */

/******************************************************************
* Function Name: pb_bootstrap
* Parameters: $autoload(array)
* Description: Autoloads library files so there isn't a mess of require 
			   statements on the page.
* Return type: TRUE
*******************************************************************/ 
function pb_bootstrap() 
{
	global $timers;
	
	require('./pb-config/pb-config.php');
	pb_autoload($autoload_f,0);	
	
	# START THE OUTPUT BUFFER, SESSION, TIMER
	pb_timerOn('start');
	pb_timerOn('echo');
		
	session_start();
	ob_start();
	print "bootstrap(open).beta";
	
	pb_router();
	
	pb_timerOff('start');
	pb_timerOff('echo');
		
	print "bootstrap(close).beta | ";
	print "Load.Timer(" . $timers['start'] . ")";
	
	pb_timerReset();
	
	ob_end_flush();
	return(TRUE);
}

/******************************************************************
* Function Name: pb_autoload
* Parameters: $autoload_f(array)
* Description: Autoloads the library files as well as performs single file loading of 
* files if necessary.
* Return type: TRUE
*******************************************************************/ 
function pb_autoload($autoload_f,$mode='0')
{
		
		foreach ($autoload_f as $key=>$value)
		{
			
			foreach($autoload_f[$key] as $filename) 
			{
				
				$required_file = PB_ROOT . $key . DS . $filename . LIBEXT;
				if(file_exists($required_file))
				{
					require($required_file);
				} else {
					#log_error
				}
			}
			
		}
		
	return(TRUE);	
}
/******************************************************************
* Function Name: pb_router
* Parameters: $type
* Description: Displays the kind of page to be displayed. Two most common types would
* be ADMIN and PAGES, but with the other modules you could have BLOG, REVIEW, ARTICLE.
* It will then be routed to the appropriate CONTROLLER.
* Return type: TRUE
*******************************************************************/ 
function pb_router($type='page') 
{
	
	#see wordpress -> wp-includes/template-loader.php
	#loads correct page based on URL
	
	switch($type) 
	{
	
	case "page":
	
		#require(PB_MODELS . DS . 'pb-pages_m.php');
		global $SHOW;
		$SHOW = content_loader();
		css_loader();
		helpers_loader();
		template_loader();
		
		break;
		
	case "admin":
		
		#require(PB_MODELS . DS . 'pb_admin-m.php');
		print "admin.load";
		break;
		
	}

}


/* End of file */
/* Location: ./pb-controllers/bootstrap_c.php */ 
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */