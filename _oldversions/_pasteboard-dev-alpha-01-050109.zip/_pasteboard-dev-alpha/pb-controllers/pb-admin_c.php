<?php 

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		start_c.php
 * @DESC		initializes the pasteboard system
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 
 * @FUNCTIONS	none
 */
 
/* End of file */
/* Location: ./pb-content/config/pb-configsite.php */
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */