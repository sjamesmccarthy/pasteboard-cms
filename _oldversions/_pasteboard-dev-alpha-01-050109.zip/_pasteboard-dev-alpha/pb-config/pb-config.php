<?php 
if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		pb-config.php
 * @DESC		This file defines constants that will be used in the pasteboard
 				content management system.
 * @PACKAGE		PASTEBOARD
 * @HISTORY		SJM - 03/30/09 - Reorganized file for version 2.0
 				SJM - 01/06/09 - Added new header/footer comments
 */

$PHPVERSION= split('\.', PHP_VERSION); // ex. 5.0
define('VERSIONOFPHP', $PHPVERSION[0]); 
define('DS', '/');

// pasteboard meta data
define('PB_NAME', 'pasteboard.cms');
define('PB_VERSION', '2.0.0');
define('PB_LAST_UPDATED', '03-30-09');
define('PB_URL', 'http://www.pasteboard.org');
define('PB_GETVERSIONURL', PB_URL . DS . '_version' . DS . 'updater.xml');
define('PB_SUPPORT_URL', PB_URL . DS . 'support' . DS);

// pasteboard system paths
define('PB_ROOT', $_SERVER["DOCUMENT_ROOT"] . DS);
define('PB_CONTENT', 'pb-content' . DS);
define('PB_LIBRARIES', 'pb-libraries' . DS);
define('PB_HELPERS', 'pb-helpers' . DS);
define('PB_PLUGINS', 'pb-plugins' . DS);
define('PB_CONTROLLERS', 'pb-controllers' . DS);
define('PB_MODELS', 'pb-models' . DS);
define('PB_THEMES', 'themes' . DS);
define('PB_TEMPLATES', 'templates' . DS);
define('PB_PAGES', 'pages' . DS);
define('PB_LOG', 'log.txt');

// pasteboard system data: miscellaneous
define('TPLEXT', '.php');
define('LIBEXT', '.php');
define('CHARACTER_ENDCODING', 'text/html; charset=UTF-8');
define('LANGUAGE','us-EN');

// pasteboard system ini_settings
ini_set('max_upload_filesize', 8388608);
ini_set('magic_quotes_gpc', 0);
date_default_timezone_set('America/Los_Angeles');

// pasteboard system autoload libraries
$autoload_f['pb-libraries'] = 
	array(
	'pb-common',
	'pb-content_loader',
	'pb-css_loader', 
	'pb-template_loader', 
	'pb-helpers_loader',
	'pb-system'
	);
	
$autoload_f['pb-config'] = 
	array(
	'pb-configsite'
	);

// MOVE THIS TO DATE HELPER OR STRING LIBRARY
define('MYSQLDATETIME', date( 'Y-m-d H:i:s'));

/* End of file */
/* Location: ./pb-config/pb-config.php */
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */ 