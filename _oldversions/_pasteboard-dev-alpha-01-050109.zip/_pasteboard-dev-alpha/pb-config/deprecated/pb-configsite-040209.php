<?

if ( ! defined('PB-START')) exit('No direct script access allowed');

/**
 * @FILE		pb-configsite.php
 * @DESC		site specific configurations settings.
				This file defines configuration data for the website, NOT for 
				pasteboard and stores the data in a $CONFIG[] array that can be
				easily passed through the framework, applications, plugins, etc.
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.0
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@gmail.com
 * @FUNCTIONS	none
 * @USAGE		Modifications of this file can be done through the /admin area.
				However, the /admin area only supports the variables below. If you
				add any new vairables to the array they will be erased if the /admin
				tool is used to change anything.
 * @HISTORY		SJM - 04/01/09 - Updated header
 				SJM - 01/06/09 - Added new header/footer comments
 */
 
$CONFIG[SITE_COMPANY_NAME] ='pasteboard Group';
$CONFIG[SITE_COMPANY_CONTACT_NAME] ='James McCarthy';
$CONFIG[SITE_COMPANY_CONTACT_EMAIL] ='jmccarthy@projectwebstart.com';
$CONFIG[SITE_COMPANY_CONTACT_PHONE] ='(775) 815-9726';
$CONFIG[SITE_NAME] ='pasteboard.cms LADYBUG build';
$CONFIG[SITE_SUPPORTEMAIL] ='webemail@pasteboard.org';
$CONFIG[SITE_URL] ='http://ladybug.pasteboard.org';
$CONFIG[SITE_DIR] ='sites/_pasteboard-dev-alpha/';
$CONFIG[GOOGLE_ANALYTICS] ='';
$CONFIG[GOOGLE_SITE_VALIDATION] ='';
$CONFIG[GOOGLE_SITEMAP] ='';
$CONFIG[GOOGLE_ADS] ='';
$CONFIG[YAHOO_SITEMAP] ='';
$CONFIG[DB_NAME] ='pasteboardev';
$CONFIG[DB_HOST] ='pasteboard.org';
$CONFIG[DB_USER] ='pasteboard';
$CONFIG[DB_PSWD] ='kandl3x+en1d';
$CONFIG[SERIALHASH] ='09-16-08-16:43';
$CONFIG[HTACCESS] ='public-access';
$CONFIG[DEBUG] ='on';
$CONFIG[THEME] ='pasteboard_v2';
$CONFIG[ADMINTHEME] ='purple_haze';
$CONFIG[USE404] ='on';
$CONFIG[USEBACKUP] ='on';
$CONFIG[SITE_LANGUAGE] ='en-us';
$CONFIG[ROBOTS_FILE] ='allow_robots';

/* End of file */
/* Location: ./pb-content/config/pb-configsite.php */
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */