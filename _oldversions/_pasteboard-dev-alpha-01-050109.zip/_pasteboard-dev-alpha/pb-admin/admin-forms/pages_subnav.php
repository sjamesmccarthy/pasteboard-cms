<?

print "
<div id=\"nav_desc\">
<p>
<span style=\"background: #98A; padding: 5px; color: #FFF;\">Main Pages</span>
</p>
</div>";

?>