<?

function display_form($adminthemeList, $themeList, $USERDATA) {
	GLOBAL $CONFIG;
	
if($USERDATA[RESULTS] == 1) {
	$RESULT_BOX="
	<div id=\"resultbox\" style=\"width:100%; background: #FFB; border: 1px solid #F40; padding:5px; margin-bottom:10px;\">
	$USERDATA[MSG]
	</div>";
}

$textbox .= "
<div id=\"content\">
$RESULT_BOX
<!-- content -->
<h1>Settings</h1>
";
	
if($_SESSION[role] == "system") {

	$textbox .= "
	<p class=\"title\">As a member of the \"system\" group, this area is where you will be able to modify your website options such as name, company contact email, google account data and theme. <b>Modifying these settings will effect how your website performs</b>, please sure you authorized to make changes to this area.
	</p>
	";

	$content_area = "
	<form action=\"?form=settings&m=update\" method=\"post\">
	
	<a name=\"company\"></a> <!-- company -->
	<div id=\"section_shaded\" style=\"width: 100%; margin-top: 10px; margin-bottom: 10px; padding: 5px; background: #CCC;\">
	<a name=\"company\"></a>
	<p>
	<b>Company Name</b><br />
	<input type=\"text\" name=\"SITE_COMPANY_NAME\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[SITE_COMPANY_NAME]\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Company Contact Name</b><br />
	<input type=\"text\" name=\"SITE_COMPANY_CONTACT_NAME\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[SITE_COMPANY_CONTACT_NAME]\">
	</p>

	<p style=\"font-size: 10pt;\">
	<b>Company Contact Email</b><br />
	<input type=\"text\" name=\"SITE_COMPANY_CONTACT_EMAIL\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[SITE_COMPANY_CONTACT_EMAIL]\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Company Contact Phone</b><br />
	<input type=\"text\" name=\"SITE_COMPANY_CONTACT_PHONE\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[SITE_COMPANY_CONTACT_PHONE]\">
	</p>
    </div>
    
    <a name=\"website\"></a><!-- website -->
    <div id=\"section_shaded\" style=\"width: 100%; margin-top: 10px; margin-bottom: 10px; padding: 5px; background: #CCC;\">
    <a name=\"website\"></a>
	<p style=\"font-size: 10pt;\">
	<b>Website Name</b><br />
	<input type=\"text\" name=\"SITE_NAME\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[SITE_NAME]\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Website Support Email</b><br />
	<input type=\"text\" name=\"SITE_SUPPORTEMAIL\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[SITE_SUPPORTEMAIL]\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Website Domain URI</b><br />
	<input type=\"text\" name=\"SITE_URL\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[SITE_URL]\">
	</p>
    </div> 
    
    <a name=\"google\"></a><!-- Google -->
    <div id=\"section_shaded\" style=\"width: 100%; margin-top: 10px; margin-bottom: 10px; padding: 5px; background: #CCC;\">
    <a name=\"google\"></a>
    <p style=\"font-size: 10pt;\">
	<b>Google Analytics</b><br />
	<input type=\"text\" name=\"GOOGLE_ANALYTICS\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[GOOGLE_ANALYTICS]\">
	</p>

<p style=\"font-size: 10pt;\">
	<b>Google Site Verification Id</b><br />
	<input type=\"text\" name=\"GOOGLE_SITE_VALIDATION\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[GOOGLE_SITE_VALIDATION]\">
	</p>
    
    <p style=\"font-size: 10pt;\">
	<b>Google Sitemap Id</b><br />
	<input type=\"text\" name=\"GOOGLE_SITEMAP\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[GOOGLE_SITEMAP]\">
	</p>
    
    <p style=\"font-size: 10pt;\">
	<b>Google Ads Account Id</b><br />
	<input type=\"text\" name=\"GOOGLE_ADS\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[GOOGLE_ADS]\">
	</p>

    <!-- <p style=\"font-size: 10pt;\">
	<b>Yahoo Search Id</b><br />
	<input type=\"text\" name=\"YAHOO_SITEMAP\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[YAHOO_SITEMAP]\">
	</p>-->
	
	</div> 
	<input type=\"hidden\" name=\"YAHOO_SITEMAP\" value=\"\">
	
	<a name=\"database\"></a><!-- Database -->
	<div id=\"section_shaded\" style=\"width: 100%; margin-top: 10px; margin-bottom: 10px; padding: 5px; background: #CCC;\">
    <a name=\"database\"></a>
    <p style=\"font-size: 10pt;\">
	<b>Database Name</b><br />
	<input type=\"text\" name=\"DB_NAME\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[DB_NAME]\">
	</p>

<p style=\"font-size: 10pt;\">
	<b>Database Host</b><br />
	<input class=\"READONLY\" type=\"text\" name=\"DB_HOST\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[DB_HOST]\" READONLY>
	</p>
    
    <p style=\"font-size: 10pt;\">
	<b>Database Username</b><br />
	<input class=\"READONLY\" type=\"text\" name=\"DB_USER\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[DB_USER]\" READONLY>
	</p>
    
    <p style=\"font-size: 10pt;\">
	<b>Database Password</b><br />
	<input class=\"READONLY\" type=\"password\" name=\"DB_PSWD\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[DB_PSWD]\" READONLY>
	</p>
	</div><!-- id: database -->
	
	<a name=\"license\"></a><!-- License -->
	<div id=\"section_shaded\" style=\"width: 100%; margin-top: 10px; margin-bottom: 10px; padding: 5px; background: #CCC;\">	    
    <p style=\"font-size: 10pt;\">
	<b>License Information:</b><br />
	<input class=\"READONLY\" type=\"hidden\" name=\"SERIALHASH\" style=\"width: 95%; height:20px; font-size: 10pt;\" value=\"$CONFIG[SERIALHASH]\" READONLY>
	Serial Number: $_SESSION[SERIALN]<br />Install Date: $CONFIG[SERIALHASH]<br /> License Type: <a target=\"_new\" href=\"" . PB_LICENSEFILE . "\">$_SESSION[SERIALTYPE]</a> / $_SESSION[SERIALLIMIT] pages<br />License Owner: $_SESSION[SERIALOWNER] / $_SESSION[SERIALPHONE]</p>
	
    </div>
    
    <div>
	<p>
	<input type=\"submit\" value=\"Save Settings\" style=\"font-size: 14pt;\">
	<input type=\"button\" value=\"Cancel\" style=\"font-size: 14pt;\" onclick=\"location.href='/pb-admin/';\">
	</p>
	
	</div>
	
    ";
    
	
} else {
	$textbox .= "<p class=\"title\">We're sorry but your group permissions do not allow you to view this area. If you think this is a mistake, please contact the site administrator,  $CONFIG[SITE_COMPANY_CONTACT_NAME]";
	
	if($CONFIG[SITE_COMPANY_CONTACT_PHONE]) { 
		$textbox .= ", $CONFIG[SITE_COMPANY_CONTACT_PHONE]."; 
	} 
}	

// COMPLETE MAIN PAGE
$textbox .= $content_area;
$textbox .= "</div> <!-- content --></div>";

// SIDEBAR AREA

$on_off_list = array('on','off');
$languages = array('en-us');
$robots = array('block_robots','allow_robots');
$htaccess = array('password-required','public-access');

$textbox .= "
<div id=\"sidebar\"> <!-- sidebar -->
<div id=\"sidebar_details\">
<p class=\"heading\">SETTINGS (Website)</p>

<p>
<!-- Manage Users<br /> -->
Backup Site<br />
<a onclick=\"return confirm('Are you sure you want to delete the entire PAGES history? This will permanently remove backups of your webpage history.')\" href=\"http://ant.pasteboard.org/pb-admin/?form=pages&m=history&a=clear-all\">Delete PAGES History (All)</a>
</p>

<p>
<a href=\"?form=settings&m=save\">BackUp</a>/<a href=\"?form=settings&m=restore\">Restore</a> Settings
</p>";

# LOOK FOR RESTORE SNAPSHOT FILE
$FILENAME = ABSPATH . '/pb-configsite.php.backup';

if(file_exists($FILENAME)) {
    $textbox .= "<p style=\"color: green; margin-top: -10px; padding:0; margin-left: 20px; font-size: x-small;\">Settings file BACKED UP on<br />" . date("F d Y H:i:s.", filemtime($FILENAME)) . "</p>";
} else {
    $textbox .= "<p style=\"text-align: center; margin-top: -10px; padding:0; background-color: yellow; font-size: 10px;\">Please Save the Settings file</p>";
}

$textbox .= "</div>";

/* $textbox .= "<!--  onclick=\"document.getElementById('section_shaded_db').style.background = '#98A';\" -->
<div id=\"sidebar_details\">
<p class=\"heading\">SECTIONS</p>
<p>
<a href=\"?form=settings#company\">Company Information</a><br />
<a href=\"?form=settings#website\">Website Information</a><br />
<a href=\"?form=settings#google\">Google/SEO Data</a><br />
<a href=\"?form=settings#database\">Database Maintenance</a><br />
<a href=\"?form=settings#system\">System Information</a>

</p>
</div>";
*/

$textbox .= "
<a name=\"system\"></a> <!-- system -->
<div id=\"sidebar_details\">
<p class=\"heading\">SYSTEM SETTINGS</p>

<p>
<b>.htaccess</b><br />
<select name=\"HTACCESS\">
";

# HTTPACCESS STATUS MENU
foreach ($htaccess as $key=>$value) {
	
	if($CONFIG[HTACCESS] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>

<p>
<b>Debug Mode</b><br />
<select name=\"DEBUG\">
";

# DEBUG STATUS MENU
foreach ($on_off_list as $key=>$value) {
	
	if($CONFIG[DEBUG] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>
<p>
<b>PAGES Theme</b><br />
<select name=\"THEME\">";

# THEME LIST
foreach($themeList as $key=>$value) {
    
    if($CONFIG[THEME] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>

<p>
<b>Admin Theme</b><br />
<select name=\"ADMINTHEME\">";

# ADMINTHEME LIST
foreach($adminthemeList as $key=>$value) {
    
    if($CONFIG[ADMINTHEME] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>

<p>
<b>Use 404 redirect</b><br />
<select name=\"USE404\">
";

# 404 ERROR
foreach ($on_off_list as $key=>$value) {
	
	if($CONFIG[USE404] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>

<p>
<b>PAGES Backup</b><br />
<select name=\"USEBACKUP\">
";

# USE BACKUP

foreach ($on_off_list as $key=>$value) {
	
	if($CONFIG[USEBACKUP] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>

<p>
<b>Language</b><br />
<select name=\"SITE_LANGUAGE\">
";

# LANGUAGE

foreach ($languages as $key=>$value) {
	
	if($CONFIG[SITE_LANGUAGE] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>
<a name=\"robots\"></a>
<p>
<b>ROBOTS.txt</b><br />
<select name=\"ROBOTS_FILE\">
";

# USE ROBOTS FILE

foreach ($robots as $key=>$value) {
	
	if($CONFIG[ROBOTS_FILE] == $value) { $SEL = "SELECTED"; } else { unset($SEL); }
	$textbox .= "<option $SEL value=\"$value\" />" . strtoupper($value) . "</option>";
	
}

$textbox .= "
</select>
</p>


</div>

</div> <!-- sidebar -->
</form>";

print $textbox;

}

?>