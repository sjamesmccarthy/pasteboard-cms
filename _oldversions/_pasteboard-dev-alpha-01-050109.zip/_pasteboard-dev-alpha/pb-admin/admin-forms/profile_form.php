<?

function display_form($USERDATA) {

if($USERDATA[RESULTS] == 1) {
	$RESULT_BOX="
	<div id=\"resultbox\" style=\"width:100%; background: #FFB; border: 1px solid #F40; padding:5px; margin-bottom:10px;\">
	$USERDATA[MSG]
	</div>";
}

$textbox = "
<div id=\"content\"> <!-- content -->
<h1>Profile Management Form</h1>
	<p class=\"title\" style=\"margin-left: 25px;\">for user $USERDATA[firstname] $USERDATA[lastname] (aka $USERDATA[username])</p>
	
	<form action=\"?form=profile&m=edit\" method=\"post\" id=\"profile\">
	<input type=\"hidden\" name=\"uid\" value=\"$USERDATA[id]\">
	
	<p style=\"font-size: 10pt; color:#CCC;\">
	<b>Username</b><br />
	<input class=\"READONLY\" type=\"text\" name=\"username\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$USERDATA[username]\" READONLY>
	</p>
	
	<p style=\"font-size: 10pt; color:#CCC;\">
	<b>Last Login</b><br />
	<input class=\"READONLY\" type=\"text\" name=\"username\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$USERDATA[lastlogin]\" READONLY>
	</p>
	
	$RESULT_BOX
		
	<p style=\"font-size: 10pt;\">
	<b>First Name</b><br />
	<input type=\"text\" name=\"firstname\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$USERDATA[firstname]\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Last name</b><br />
	<input type=\"text\" name=\"lastname\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$USERDATA[lastname]\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>E-mail</b><br />
	<input type=\"text\" name=\"email\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$USERDATA[email]\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>CurrentPassword</b><br />
	<input type=\"password\" name=\"cpassword\" style=\"width: 40%; height:20px; font-size: 10pt;\">	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>New Password</b><br />
	<input type=\"password\" name=\"password\" style=\"width: 40%; height:20px; font-size: 10pt;\"> <b>Re-Type:</b>	<input type=\"text\" name=\"repassword\" style=\"width: 40%; height:20px; font-size: 10pt;\">
	</p>
	
	<p style=\"font-size: 10pt;\">
	<b>Password Hint</b><br />
	<input type=\"text\" name=\"hint\" style=\"width: 100%; height:20px; font-size: 10pt;\" value=\"$USERDATA[hint]\">
	</p>
	
	<p style=\"margin-top: 20px;\">
	<input type=\"submit\" value=\"Update\" style=\"font-size: 14pt;\">
	<input type=\"button\" value=\"Cancel\" style=\"font-size: 14pt;\" onclick=\"location.href='/pb-admin/';\">
	</p>
	";
$textbox .= "</form>
</div> <!-- content -->";

// SIDEBAR AREA
$textbox .= "
<div id=\"sidebar\"> <!-- sidebar -->
<div id=\"sidebar_details\">
<p class=\"heading\">PROFILE (View)</p>

<p style=\"margin-left: 5px;\">
This area displays all details of your profile such as first and last name, e-mail, password, the group you belong to and the option to modify your password hint.</p>
</div>

<div id=\"sidebar_details\">
<p class=\"heading\">OPTIONS</p>
<p style=\"margin-left: 5px;\">
<a onclick=\"return confirm('Are you sure you want to delete? This will prevent you from being able to log back in and edit your webpages.')\" href=\"?form=profile&m=delete\">Delete Profile</a><br />

</p>
</div>
</div> <!-- sidebar -->";


print $textbox;
}

?>