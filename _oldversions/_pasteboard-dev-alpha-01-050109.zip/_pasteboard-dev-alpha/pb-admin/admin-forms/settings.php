<?
		require_once(ABSPATH . 'pb-admin/admin-forms/settings_form.php');
		$adminthemeList = get_pages(ABSPATH . '/pb-admin/admin-themes/');
		$themeList = get_pages(ABSPATH . PB_ROOT . 'themes/');
		
switch($_GET[m]) {
	
	case "save":
        #print "<div id=\"content\">saving restore point";
        $ORIGINAL_FILE = ABSPATH . '/pb-configsite.php';
        $NEW_FILE = ABSPATH . '/pb-configsite.php.backup';
        copy($ORIGINAL_FILE, $NEW_FILE);
        #print "<br />saved<br /><a href=\"?form=settings\">back to settings</a></div>";
        #exit;
        $USERDATA[RESULTS] =1;
		$USERDATA[MSG] ="SETTINGS FILE RESTORE POINT SAVED/BACKED-UP";
		$page = display_form($adminthemeList, $themeList, $USERDATA);
		break;

	case "update":
	    $result = build_file();
	    $result .= build_robots();
	    $result .= build_htaccess();
	    
	    $USERDATA[RESULTS] =1;
		$USERDATA[MSG] ="SETTINGS FILE SAVED";
		$page = display_form($adminthemeList, $themeList, $USERDATA);
    	break;
	
	case "restore":
	    #print "<div id=\"content\">restoring from last save point";
        $ORIGINAL_FILE = ABSPATH . '/pb-configsite.php.backup';
        $NEW_FILE = ABSPATH . '/pb-configsite.php';
        copy($ORIGINAL_FILE, $NEW_FILE);
        #print "<br />restored<br /><a href=\"?form=settings\">back to settings</a></div>";
        #exit;
        $USERDATA[RESULTS] =1;
		$USERDATA[MSG] ="SETTINGS FILE RESTORED FROM SNAPBACK POINT";
		$page = display_form($adminthemeList, $themeList, $USERDATA);
	    break;
	    
	default:
		$page = display_form($adminthemeList, $themeList, $USERDATA);
		print $page;
		break;
	
}

function build_file() {
    
    #print "<div id=\"content\">updating settings";
	
	// BUILD HEADER
	$file = "<?\n\n/**
 * @FILE        pb-siteconfig.php
 * @PACKAGE     PASTEBOARD
 * @LASTUPDATE  " . MYSQLDATETIME . "
 * @LICENSE     Commercial, Copyright 2008
 */\n\n";
 
     // BUILD SETTINGS
	foreach($_POST as $key=>$value) {
	    $file .= "\$CONFIG[$key] ='$value';\n"; 
	}
	
	// BUILD FOOTER
	$file .= "\n/* Last Built on " . MYSQLDATETIME . " */\n\n?>";
	
	// REWRITE THE FILE
	$fh = fopen(ABSPATH .'/pb-configsite.php', "w");
	$result = fwrite($fh, $file);
  	fclose($fh); 
	
    #print "<br />saved<br /><a href=\"?form=settings\">back to settings</a></div>";
	#exit;
	    
}

function build_robots() {
	
	if($_POST[ROBOTS_FILE] == "allow_robots") { $toggle = "allow:"; } else { $toggle = "disallow:"; }
	
$file = "User-agent: *
$toggle /
	
Disallow: /pb-admin/
Disallow: /pb-content/
Disallow: /pb-library/
Disallow: /pb-plugins/
Disallow: /pb-config.php
Disallow: /pb-configsite.php
Disallow: /pb-versioncheck.php";
	
	// REWRITE THE FILE
	$fh = fopen(ABSPATH .'/robots.txt', "w");
	$result = fwrite($fh, $file);
  	fclose($fh); 
	
}

function build_htaccess() {
	
	GLOBAL $CONFIG;
	
	if($_POST[HTACCESS] == "password-required") { 
	$commented = ""; 
	} else { 
	$commented = "#"; 
	}
	
$file = "#htpasswd during dev
$commented" . "AuthUserFile " . ABSPATH . ".htpasswd
$commented" . "AuthName \"Restricted Area for " . $CONFIG[SITE_COMPANY_NAME] . "\"
$commented" . "AuthType Basic
$commented" . "Require valid-user

#custom error docs
ErrorDocument 404 /?page=404
ErrorDocument 403 /?page=404
ErrorDocument 500 /?page=404

# DISABLE DIRECTORY BROWSING
Options All -Indexes

RewriteEngine on 
RewriteCond %{HTTP_HOST} ^" . substr($CONFIG[SITE_URL], 11) ." [NC] 
RewriteRule ^(.*)$ " . $CONFIG[SITE_URL] . "/$1 [L,R=301] 

# FOR CMS (NOT IN USE)
#RewriteRule ^page/([^/\.]+)/?$ index.php?p=$1 [L]
#RewriteRule ^pages/([^/\.]+)/?$ index.php?p=$1 [L]
";
	
	// REWRITE THE FILE
	$fh = fopen(ABSPATH .'/.htaccess', "w");
	$result = fwrite($fh, $file);
  	fclose($fh); 
	
}


?>