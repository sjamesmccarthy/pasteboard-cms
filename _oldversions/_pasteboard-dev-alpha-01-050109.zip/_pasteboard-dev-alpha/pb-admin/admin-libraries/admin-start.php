<?

/**
 * @FILE		admin-start.php
 * @DESC		page that simply loads what is needed for admin area
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.6 
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */

// LOAD PASTEBOARD REQUIRED FILES //
require_once('../pb-configsite.php');
require_once('../pb-config.php');
require_once('../pb-library/pb-common.php');
require_once('../pb-library/pb-db.php');
require_once('admin-library/admin-functions.php');

// CHECK FOR SESSION, IF FOUND LOAD TEMPLATE
if($_SESSION[username] 
	&& $_GET[action] !=  "logout") { 

// CHECK TO SEE IF FIRST TIME LOADING, IF SO ASSIGN ADMIN>LOCATION
if(!$_GET[form]) { $_GET[form] =dashboard; }

// DISPLAY THE ADMIN AREA //	
ob_start();
include_once(ABSPATH . 'pb-admin/admin-themes/' . $CONFIG[ADMINTHEME] . '/index.php');
ob_end_flush();
}

// END

?>