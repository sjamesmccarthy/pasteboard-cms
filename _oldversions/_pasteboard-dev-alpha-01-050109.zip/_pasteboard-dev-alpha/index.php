<? 

/**
 * @FILE		index.php
 * @DESC		short and sweet, loads the front-end-controller 
 * @PACKAGE		PASTEBOARD
 * @COPYRIGHT	See license.pdf
 */

#http://www.addedbytes.com/apache/url-rewriting-for-beginners/
#RewriteRule ^([A-Za-z0-9-]+)/([A-Za-z0-9-]+)/?$ get_product_or_blog_post.php?category_name=$1&item_name=$2 [NC,L]
#http://www.pasteboard.org/blog/23 -> http://www.pasteboard.org?c=blog{$1}&id=24{$2}
#see codeigniter application/config/config.php for permitted URI characters + triggers

define('PB-START', 'TRUE');

# Load the front-end-controller
require('./pb-libraries/pb-bootstrap.php');
pb_bootstrap();

/* End of file */
/* Location: index.php */
/* DO NOT EDIT WITH DREAMWEAVER, IF YOU MUST, THEN INCLUDE THIS LINE ?> */