# CocoaMySQL dump
# Version 0.7b5
# http://cocoamysql.sourceforge.net
#
# Host: pasteboard.org (MySQL 5.0.45-community)
# Database: pasteboard
# Generation Time: 2008-07-24 08:45:59 -0700
# ************************************************************

# Dump of table users
# ------------------------------------------------------------

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) default NULL,
  `firstname` varchar(255) default NULL,
  `lastname` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `role` varchar(255) default NULL,
  `permissions` varchar(3) default NULL,
  `lastlogin` datetime NOT NULL,
  `hint` varchar(255) default NULL,
  `status` int(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`,`username`,`firstname`,`lastname`,`email`,`password`,`role`,`permissions`,`lastlogin`,`hint`,`status`) VALUES ('1','admin','Kimberly','Van Ness','nncil20@sbcglobal.net','*4ACFE3202A5FF5CF467898FC58AAB1D615029441','system','RWX','2008-07-23 16:24:32','administrative account',NULL);


