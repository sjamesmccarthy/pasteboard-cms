<?php

$debug .= "pb-content_loader.loaded()<br />";

/**
 * @FILE		pb-content_loader.php
 * @DESC		Loads the content into variables and $SHOW[C] from XML file
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.6
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */

// Can use ?page or ?p to load the page, so lets check
if($_GET[p]) $_GET[page] = $_GET[p];

// LOAD THE CONTENT PAGE //
// Check to see if the file exists and then parse the XML //
	
	if(!$_GET[page]) { $_GET[page] = "home"; }
	$XML_FILE = ABSPATH . PAGESPATH . $_GET[page] . ".xml";

	if(VERSIONOFPHP == 5) {
		if(file_exists($XML_FILE)) {
		$PAGE_OBJ = xmlp5($XML_FILE);
		} else {
		    if($CONFIG[USE404] == "on") {
		    $PAGE_OBJ = xmlp5(ABSPATH . PAGESPATH . '404.xml');
		    } else {
    	    error(28, 'XML File Not Found', 'pb-content_loader.php', $XML_FILE); 
		    } 
		}
	} else {
		$PAGE_OBJ = xmlp4($XML_FILE);
	}
	
	
	// LOAD EACH XML ELEMENT INTO VARIABLE
	foreach ($PAGE_OBJ as $key => $value) { 
		${strtoupper($key)} = $value;
		$SHOW[strtoupper($key)] .= $PAGE_OBJ->$key;
	}
	
	// SCRUB DATA
	#$SHOW[TITLE] = preg_replace('/&/i', '&amp;', $SHOW[TITLE]);
	$SHOW[TITLE] = htmlentities($SHOW[TITLE]);
	$SHOW[CONTENT] = html_entity_decode($SHOW[CONTENT]);
	#$SHOW[CONTENT] = preg_replace('/&/i', '&amp;', $SHOW[CONTENT]);
		
    // CHECK PAGE STATUS
    if($SHOW[STATUS] == "archived" || $SHOW[STATUS] == "draft" || $SHOW[STATUS] == "hidden") {
         error(48, 'UNABLE TO DISPLAY CONTENT<br />it may be archived or saved as draft', 'pb-content_loader.php', $XML_FILE); 
    }   
    
// SEARCH FOR TEMPLATESNIPS AND REPLACE WITH RESULTS FROM SNIP
	include(ABSPATH . "pb-library/pb-contentsnips_loader.php");


?>