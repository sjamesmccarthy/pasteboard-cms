<?

$debug .= "pb-css_loader.loaded()<br />";

/**
 * @FILE		pb-css_loader.php
 * @DESC		Process CSS file(s)
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */
 
 // REMOVE the .ext on the end of the file. 
	$TEMPLATE_SPLIT = split("\.", $TEMPLATE); 
	$TEMPLATE = $TEMPLATE_SPLIT[0];
	
// LOAD THE DEFAULT CSS FILE //
// Check to see if there is a page css file to use //
// looks relatvie to server_root
    
    $CSS_FILE = ABSPATH . PB_ROOT . THEMESPATH . "css/" . $TEMPLATE . ".css";
	
	if(file_exists($CSS_FILE)) { 
		$CONFIG[CSSFILE] = THEMESPATH . "css/" . $TEMPLATE . ".css";
	} else {
	    #$CONFIG[CSSFILE] = "themes/default/css/default.css";
	    error(26, 'CSS File Not Found', 'pb-css_loader.php', $CSS_FILE);
	}
	
// LOAD PAGE CSS IF SPECIFIED AND IF EXISTS
    $PAGE_CSS_FILE = ABSPATH . PB_ROOT . THEMESPATH . "css/" . $PAGECSS;
    
 	if($PAGECSS && $PAGECSS != "none") {
    	if(file_exists($PAGE_CSS_FILE)) { 
    		$SHOW[PAGE_CSS] = "@import url(" . THEMESPATH . "css/" . $PAGECSS . ");";
    	} else {
    	  error(36, 'PAGE-CSS File Not Found', 'pb-css_loader.php', $PAGE_CSS_FILE);   
    	}
	}
// END //

?>