<?php

$debug .= "pb-template_loader.loaded()<br />";

/**
 * @FILE		pb-template_loader.php
 * @DESC		Checks to see if the template file exits and then process template_snips
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */
 
// LOAD THE TEMPLATE //
// Check to see if there is an alternative template to use //
	
    $TEMPLATE_FILE = ABSPATH . PB_ROOT . TEMPLATEPATH . $TEMPLATE . "." . TPLEXT;
    
	if(file_exists($TEMPLATE_FILE)) {  
	    include($TEMPLATE_FILE);
	    print $LICENSE; 
	} else {
	    error(25, 'File Not Found', 'pb-template_loader.php', $TEMPLATE_FILE);
	}

   
// END // 
  
// SEARCH FOR TEMPLATESNIPS AND REPLACE WITH RESULTS FROM SNIP
// include(ABSPATH . "pb-library/pb-templatesnips_loader.php");
// END //

 ?>