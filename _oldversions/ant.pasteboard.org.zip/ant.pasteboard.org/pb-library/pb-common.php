<?php

$debug .= "pb-core.loaded()<br />";

/**
 * @FILE		pw-core.php
 * @DESC		a library of functions that are used at system level
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.6
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	xmlp5 : parses xml document PHP5 only
  				xmlp4 : parses xml document PHP4 (supports PHP 5)
  				license : prints a license statement at the end of each template generated
  				debug : 
  				get_header : builds the header of the page filtering out blank META tags
  				get_footer :
  				get_content :
  				error : produces nice looking errors for missing files, etc.
 */

/**
 @FUNCTION		xmlp5
 @DESC			PHP5 Required to parse XML file into dynaamic URLS
 @PARAMS		$file; the absolute path to the XML file beign requested
 @UPDATED		01/28/08
 */
 
function xmlp5($file) {

$fp = fopen($file, "r");
$xmlstr = fread($fp, 80000);
fclose($fp);

$xml = new SimpleXMLElement($xmlstr);
$title = $xml->title;

return($xml);
}
/* ** ** ** ** ** ** ** ** ** ** ** ** ** ** */

/**
 @FUNCTION		xmlp4
 @DESC			PHP4/5 Required to parse XML file into dynaamic URLS
 @REQUIREMENTS	function xml2arry(), 
 @PARAMS		$file; the absolute path to the XML file beign requested
 @UPDATED		01/28/08 Initial Install
 				03/03/08 Fixed xmlp4 function
 */

function xmlp4($file) {

$fp = fopen($file, "r");
$xmldata = fread($fp, 80000);
fclose($fp);

 // parse the XML datastring
	 $xml_parser = xml_parser_create ();
	 xml_parse_into_struct ($xml_parser, $xmldata, $vals, $index);
	 xml_parser_free ($xml_parser);
	
	 // convert the parsed data into a PHP datatype
	 $params = array();
	 $ptrs[0] = & $params; 
	
	 foreach ($vals as $xml_elem) {
	   $xml_elem[tag] = 	strtolower($xml_elem[tag]);
	   $level = $xml_elem['level'] - 1;
	   switch ($xml_elem['type']) {
	   case 'open':
		 $tag_or_id = (array_key_exists ('attributes', $xml_elem)) ? $xml_elem['attributes']['ID'] : $xml_elem['tag'];
		 #$ptrs[$level][$tag_or_id] = array ();
		 # $ptrs[$level+1] = & $ptrs[$level][$tag_or_id];
		 $ptrs[$level+1] = & $ptrs[$level];
		 break;
	   case 'complete':
		 $ptrs[$level][$xml_elem['tag']] = (isset ($xml_elem['value'])) ? $xml_elem['value'] : '';
		 break;
	   }
	 }

return($params);

}

function license() {
    GLOBAL $CONFIG, $TEMPLATE;
        
        $CON = "\n\n<!-- powered by " . strtoupper(PB_NAME) . " -->\n";
        $CON .= "<!-- (c)opyright " . date(Y) . ", " . PB_DEVELOPER . " -->\n";
        $CON .= "<!-- " . $CONFIG[THEME] . "/" . $TEMPLATE . ".tpl -->\n";
        $CON .= "<!-- v. " . PB_VERSION . " -->\n";
        
        return($CON);
        
}
    
 function debug($error) {
     
     if($error == "run") {
         print "<pre>";
         print_r($DEBUG_DATA);
         print "</pre>";
         print "<hr />";
         print "debug_mode: done";
     } else {
         # count array; if greater than 1 add otherwise create
         if(count($DEBUG_DATA) > 0) { $DEBUG_DATA .= $error; } 
         else { $DEBUG_DATA = array(); } 
     }

 }

function error($error_line, $error_title, $error_source, $error_detail) {
    GLOBAL $CONFIG;
    
    echo "<style type=\"text/css\">
    <!--
    body {
    	margin-top: 50px;
    	font-family: tahoma, sans-serif;
    	font-size: 12pt;
    }
    #box { 
    	width:500px;
    	height: 120px;
    	padding: 15px;
    	margin: auto;
    	border-top: 1px solid #CC0000;
    	border-right: 1px solid #CC0000;
    	border-bottom: 1px solid #CC0000;
    	border-left: 1px solid #CC0000;
    	background: #FF9999;
    }
    #box p {
    	margin: 5px;
    }
    -->
    </style>
    <html>
    <head>
    <title>Error: Pasteboard</title
    </head>
    <body>
    <div id=\"box\">
    <p style=\"font-weight: bold\">$error_title</p>
    <p>$error_source, $error_line</p>";
    
    if($error_detail) {
        echo "<p style=\"font-size:9pt;\">$error_detail</p>";
        }
        
    echo " <hr />
    <p>Return to <a href=\"" . $CONFIG[SITE_URL] . "\">" . $CONFIG[SITE_URL] . "</a></p>
    </div>
    </body>
    </html>";    
    
    exit;
}

// Note: these tags go anywhere in the template //

function get_meta() {
    GLOBAL $SHOW, $CONFIG;
 	 

# 	'http-equiv="content-type"'=>'text/html; charset=UTF-8',
# 	'viewport'=>'width=808',
	$METATAGS = array (
 	'http-equiv="content-language"'=>'us-EN',
  	'verify-v1'=>$CONFIG[GOOGLE_SITEMAP],
 	'y-key'=>'',
 	'template-engine'=>PB_NAME . ',' . PB_URL,
 	'template-engine-v'=>PB_VERSION,
 	'template-engine-license'=>PB_LICENSE
 	);


	foreach($SHOW as $key => $value) {
		if(preg_match("/META/i", $key)) {
			$keyholder = str_replace("META_", "", $key);
			$METATAGS[strtolower($keyholder)] = strtolower($value);
		}
	}

	ksort($METATAGS);
	
	foreach ($METATAGS as $key => $value) {
		if($value) { 
			if(preg_match("/http-equiv/i", $key)) {
				print "<meta $key content=\"$value\" />\n"; 
			} else {
				print "<meta name=\"$key\" content=\"$value\" />\n"; 
			}
		}
	}

}

function get_header($FILE = 'header.php') {
   
    $HEADER_FILE = ABSPATH . PB_ROOT . THEMESPATH . 'includes/' . $FILE;
    if (file_exists($HEADER_FILE)) {
		include_once($HEADER_FILE);
    } else {
		#log to debug();
		error(206, 'File Not Found', 'pb-common.php', $HEADER_FILE);
    }
    
}

function get_footer($FILE = 'footer.php') {   
	
	$FOOTER_FILE = ABSPATH . PB_ROOT . THEMESPATH . 'includes/' . $FILE;
    if (file_exists($FOOTER_FILE)) {
		include_once($FOOTER_FILE);
    } else {
		#log to debug();
		error(218, 'File Not Found', 'pb-common.php', $FOOTER_FILE);
    }
    
}
    
?>