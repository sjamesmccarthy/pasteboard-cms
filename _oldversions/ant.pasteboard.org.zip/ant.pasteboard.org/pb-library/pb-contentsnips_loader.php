<?php

$debug .= "pb-contentsnips_loader.loaded()<br />";

/**
 * @FILE		pb-contentsnips_loader.php
 * @DESC		Process templatesnips and returns result as formatted HTML
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */

// SEARCH FOR CONTENTSIPS AND REPLACE WITH RESULTS FROM SNIP
		#$do = preg_match_all("/{php}(.*){\/php}/U", $CONTENT, $matches); #old structure prior to v1.0.5
		$do = preg_match_all("/\<\?(.*)\?\>/U", $SHOW[CONTENT], $matches);		
			# ("|<[^>]+>(.*)</[^>]+>|U",
			
		foreach ($matches[1] as $key => $value) {  
		
		if($do == true) {
		$functionCall = split("\(", $value);
		$functionName = trim($functionCall[0]);
		$functionParams = substr_replace($functionCall[1],"",-3);
		
		if($functionParams == 0) { $functionParams == ""; }
		
		$CONTENTSNIP_FILE = ABSPATH . CONTENTSNIPSPATH . $functionName . ".php";
		
		if(file_exists($CONTENTSNIP_FILE)) {
			include_once($CONTENTSNIP_FILE);
			$returned_value = $functionName($functionParams);
		} else {
			// Eventually log to errors()
		}
		
		// REPLACE THE FUNCTION RESULT IN THE CONTENT VARIABLE

		#$str=$CONTENT; # old content; changing variable to avoid confusion in next statement		
		$CONTENT = str_replace("<? $functionName($functionParams); ?>", $returned_value, $SHOW[CONTENT]); # new content
		$SHOW[CONTENT] = $CONTENT;
		}
		
		}
// END //

?>