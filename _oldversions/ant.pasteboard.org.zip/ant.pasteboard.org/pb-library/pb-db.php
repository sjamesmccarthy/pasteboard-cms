<?php

$debug .= "pb-db.loaded()<br />";

/**
 * @FILE		pb-db.php
 * @DESC		opens a persistent connection to database
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */

function start_db() {
    
    GLOBAL $CONFIG;
    
// OPEN CONNECTION OBJECT TO DATABASE
// $dbh = @mysql_pconnect($hostname,$username,$password);
$CON = mysql_pconnect($CONFIG[DB_HOST], $CONFIG[DB_USER], $CONFIG[DB_PSWD]);	
	if(!$CON)  { print "failed: mysql_pconnect()"; }

// SELECT DATABASE TABLE
$DBH = mysql_select_db($CONFIG[DB_NAME], $CON) 
	or die("Couldn't select database");
	
return($CON);
	
}

function query_exec($sql) {

	$CON = start_db();      
	$sql_result = mysql_query($sql,$CON);
	return($sql_result);
	mysql_close($CON);
	
}
	
// END // 

 ?>