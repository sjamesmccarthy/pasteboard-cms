<? 

/**
 * @FILE		pb-start.php
 * @DESC		page that simply loads what is needed
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.6
 * @AUTHOR		James McCarthy
 * @EMAIL		james.mccarthy@mac.com
 * @LICENSE		Commercial, Copyright 2008
 
 * @FUNCTIONS	none
 */

// LOAD PASTEBOARD REQUIRED FILES //
require_once('./pb-configsite.php');
require_once("./pb-config.php");
require_once('./pb-library/pb-common.php');

// LOAD CONTENT FROM REQUESTED XML FILE, DEFAULTS to home.xml //
require_once('./pb-library/pb-content_loader.php');

// LOAD CSS FILE(S) //
require_once('./pb-library/pb-css_loader.php');

// DISPLAY THE PAGE //	
$LICENSE = license();

ob_start();
include_once('./pb-library/pb-template_loader.php');
ob_end_flush();

// END

if($CONFIG[DEBUG] == 1) print "<hr />" . $debug;
// Move this into a function in pb-core.php | usage: debug('run'); //
// Maybe make it a pesky javascript popup menu //

?>