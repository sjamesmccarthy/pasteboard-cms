<? 

session_start();
require("./pb-library/pb-start.php");

// http://www.pasteboard.org
// for support visit our forums online

?>