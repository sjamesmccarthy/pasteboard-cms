<?

switch($_GET[m]) {

	case "add":
		require_once(ABSPATH . 'pb-admin/admin-forms/pages_form.php');
		$result = display_form($_GET[xml],1);
		print $result;
		break;
	
	case "edit":
		require_once(ABSPATH . 'pb-admin/admin-forms/pages_form.php');
		$result = display_form($_GET[xml],2);
		print $result;
		break;
	
	case "delete":
	break;
	
	default:
		require_once(ABSPATH . 'pb-admin/admin-forms/plugins_list.php');
		$dirList = get_pages(ABSPATH . PLUGINSPATH);
		$result = display_listings($dirList);
		print $result;
		break;
	
}

?>