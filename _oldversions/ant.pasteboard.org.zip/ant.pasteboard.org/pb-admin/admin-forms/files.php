<?

switch($_GET[m]) {

	case "upload":
		require_once(ABSPATH . 'pb-admin/admin-forms/files_list.php');
		$result = uploadFile($_FILES);
		print $result;
		break;
	
	case "delete":
		$result = delete_file();
		break;
	
	case "rename":
		$result = rename_file();
		break;
	
	case "copy":
		$result = copy_file();
		break;
	
	default:
		require_once(ABSPATH . 'pb-admin/admin-forms/files_list.php');
		$dirList = getFileListing();
		$result = display_listings($dirList);
		print $result;
		break;
	
}


function rename_file() {
	
	if($_GET[a] == "true") {
		
		// CHECK TO SEE IF FILE EXTENSION EXISTS IF SO REMOVE IT
		#$result = explode('.', $_POST[NFILE]);
		#if($result[1]) { $_POST[NFILE] = $result[0]; }
		
		// CLEAN FILE NAME OF SPACES AND SYMBOLS
		// $_POST[NFILE] = preg_replace("/[^a-zA-Z0-9s]/", "", $result[0]);
		
		$ORIGINAL_FILE = ABSPATH . PB_ROOT . 'files/' . $_POST[OFILE];
		$NEW_FILE = ABSPATH . PB_ROOT . 'files/' . $_POST[NFILE];
		
		// MAKE SURE THAT THERE IS AN ORIGINAL NAME
		if(file_exists($ORIGINAL_FILE)) {
			rename($ORIGINAL_FILE, $NEW_FILE);
			header('location:?form=files');
		} else {
			echo "<div id=\"content\">
			Could not rename the file.
			</div>";
		}
		
	}
	else {	
	
		echo "
		<form id=\"rename_file\" action=\"?form=files&m=rename&a=true\" method=\"post\">
		<input type=\"hidden\" name=\"OFILE\" value=\"$_GET[file]\">
		
		<div id=\"content\">
		<p>
		Renaming file: $_GET[file]
		</p>
		
		<p>
		New name for this file: <input type=\"text\" name=\"NFILE\" size=\"40\"></p>
		
		<p>
		<input type=\"submit\" value=\"Rename File\">
		<input type=\"button\" value=\"Cancel\" onclick=\"location.href='?form=files';\">
		</p>
		
		</div>
		</form>";
		exit;
	}

}

function delete_file() {
	
	$FILE = ABSPATH . PB_ROOT . 'files/' . $_GET[file];

	if(file_exists($FILE)) 
	{
		
		print "deleted($FILE);";
		unlink($FILE);
		
	} else {
		$err= "no file exists";
	}
	
  	header('location:?form=files');	
}

function copy_file() {

	$FILE = ABSPATH . PB_ROOT . 'files/' . $_GET[file];

	// CHECK TO SEE IF FILE EXISTS
	if(file_exists($FILE)) 
	{
	
		// FIRST COPY THE FILE INTO BACKUP_DIR: pages_history
		$BACKUP_DATE = str_replace(' ', '_', MYSQLDATETIME);
		$BACKUP_FILE = ABSPATH . PB_ROOT . 'files/' . $_GET[file] . '_' . $BACKUP_DATE;
		
		#print "<div id=\"content\"><p>$FILE</p><p>$BACKUP_FILE</p></div>";
		$do = copy($FILE, $BACKUP_FILE);
	  	header('location:?form=files');	
	  		
	}

}

?>