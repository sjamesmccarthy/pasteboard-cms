<?

print "
<div id=\"nav_desc\">
<p>
<!-- for user $_SESSION[firstname] $_SESSION[lastname] (aka $_SESSION[username]); last login =$_SESSION[lastlogin] -->
Your password is required to make changes to this page. Do NOT delete your profile.
</p>
</div>
";

?>
