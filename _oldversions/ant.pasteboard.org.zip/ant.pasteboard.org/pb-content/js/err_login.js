function error_chk() 
{

var missing = "";
var ve = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/

if(!document.forms[0].username.value) { missing += " \n- Your Username"; }
if(!document.forms[0].pswd.value) { missing += " \n- Your password"; }

if( missing ){ 
alert ("Missing entries for the following fields:\n" + missing )
return false;
}
	
}	