<?php

/**
 * @FILE		/pb-content/phpsnips/snip_example.php
 * @DESC		example of a phpsnip; phpcod to be included in XML file
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @PARAMS		1 parameter in this example, snips may have multiple parameters like in php
 * @USAGE       <? snip_example(hw); ?>
                snip_example = name of corresponding function and file
                (hw) = parameters passed to function separated by comma
 */
 
 function snip_example($param) {
 	
 		GLOBAL $CONFIG; 
 		switch($param) {
		
		case "hw":
		$snippet = "HelloWorld. Version " . PB_VERSION . "<br />website for " . $CONFIG[SITE_COMPANY_NAME];
		break;
 		
 		default:
 		$snippet = "Error : snip_example ($param)";
 		break;
 	}
 	
 	return($snippet);
 	// Returns the output of the snippet to pb-contentsnips_loader.php
 	
 }

?>