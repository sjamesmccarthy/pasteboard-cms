<?php

/**
 * @FILE		/pb-content/phpsnips/snip_thankyouresponse.php
 * @DESC		returns and appropriate response to forms without having to produce a bazillion XML files.
 * @PACKAGE		PASTEBOARD
 * @VERSION		1.0.5
 * @PARAMS		0
 * @USAGE       <? snip_example(hw); ?>
                snip_thankyouresponse = name of corresponding function and file
 */
 
 function snip_thankyouresponse($param = '0') {
 		
 		# put a file in the plugin folder that stores return information 
 		# to make each for use a single thankyou.xml template and not have
 		# to reproduce extraineous code.
 		
		fopen(pathtofile . '_thankyou.php');
		# redirect /?p=thankyou&form=contact
 		# pathtodir ABSPATH . PBROOT . 'plugins/' . $_REQUEST[form] . '_mgr/' 
 		# file $_REQUEST[form] . '_thankyou.php'
 		
 			
 		# readfile()
 		# return filecontent() through $snippet
 		
 		if($_REQUEST[form]  == "share") {
 		$snippet = "Thanks for sharing karenskommune.org with your friends!";
 		}
 		if($_REQUEST[form]  == "contact") {
 		$snippet = "Someone will return your message via email or phone as quickly as possible.";
 		}
 		 	
 	return($snippet);
 	// Returns the output of the snippet to pb-contentsnips_loader.php
 	
 }

?>