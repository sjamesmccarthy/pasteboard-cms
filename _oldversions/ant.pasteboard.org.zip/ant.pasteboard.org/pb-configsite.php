<?

/**
 * @FILE        pb-siteconfig.php
 * @PACKAGE     PASTEBOARD
 * @LASTUPDATE  2008-09-14 03:11:31
 * @LICENSE     Commercial, Copyright 2008
 */

$CONFIG[SITE_COMPANY_NAME] ='pasteboard Group ANT';
$CONFIG[SITE_COMPANY_CONTACT_NAME] ='James McCarthy';
$CONFIG[SITE_COMPANY_CONTACT_EMAIL] ='jmccarthy@projectwebstart.com';
$CONFIG[SITE_COMPANY_CONTACT_PHONE] ='(775) 815-9726';
$CONFIG[SITE_NAME] ='pasteboard.cms ANT build';
$CONFIG[SITE_SUPPORTEMAIL] ='webemail@pasteboard.org';
$CONFIG[SITE_URL] ='http://ant.pasteboard.org';
$CONFIG[GOOGLE_ANALYTICS] ='';
$CONFIG[GOOGLE_SITE_VALIDATION] ='';
$CONFIG[GOOGLE_SITEMAP] ='';
$CONFIG[GOOGLE_ADS] ='';
$CONFIG[YAHOO_SITEMAP] ='';
$CONFIG[DB_NAME] ='pasteboardev';
$CONFIG[DB_HOST] ='pasteboard.org';
$CONFIG[DB_USER] ='pasteboard';
$CONFIG[DB_PSWD] ='kandl3x+en1d';
$CONFIG[SERIALHASH] ='09-16-08-16:43';
$CONFIG[HTACCESS] ='public-access';
$CONFIG[DEBUG] ='on';
$CONFIG[THEME] ='pasteboard_v1';
$CONFIG[ADMINTHEME] ='purple_haze';
$CONFIG[USE404] ='on';
$CONFIG[USEBACKUP] ='on';
$CONFIG[SITE_LANGUAGE] ='en-us';
$CONFIG[ROBOTS_FILE] ='allow_robots';

/* Last Built on 2008-09-14 03:11:31 */

?>