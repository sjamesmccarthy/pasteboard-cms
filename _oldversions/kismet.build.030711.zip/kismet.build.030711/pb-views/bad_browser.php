<html>

<title>Sad Browser</title>
<div style="width: 400px; background: #FFFF99; border: 1px solid #FFFF00; padding: 10px; margin: 50px auto;">
You are using a sad web browser. There are so many others out there that are waaaay better. Check them out <a href="http://www.whatbrowser.org/en/browser/">here</a> or continue to where you are going <a href="<?= $_SERVER['HTTP_REFERER'] . '?sad_browser=ok' ?>">at your own risk</a>!
</div>
</html>
