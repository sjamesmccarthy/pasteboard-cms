<p style="background-color: #99CC99; padding: 10px;">
<a href="#" class="line">nibh. Donec sem mi, mattis is,<br /></a><a href="#" class="line">tristique at, fringilla id</a>
</p>
