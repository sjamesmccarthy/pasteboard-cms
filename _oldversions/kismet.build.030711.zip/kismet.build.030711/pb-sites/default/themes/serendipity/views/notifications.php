<div id="notifications">
<?= $notifications ?>
</div>