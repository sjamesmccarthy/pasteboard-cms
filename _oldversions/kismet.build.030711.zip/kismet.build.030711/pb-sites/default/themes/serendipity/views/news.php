<p style="background-color: #99CC99; padding: 10px;">
sodales quam vel diam. Aenen diam risus, commodo nec, cuus id, mattis id, sem: <?= $page_title; ?>
</p>
