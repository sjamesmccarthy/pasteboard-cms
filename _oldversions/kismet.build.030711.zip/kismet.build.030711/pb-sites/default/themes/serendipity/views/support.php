<p style="background-color: #99CC99; padding: 10px;">
<strong>sodales quam vel diam.</strong> Aen diam risus, commodo nec, cuus id, mattis id, sem
</p>
