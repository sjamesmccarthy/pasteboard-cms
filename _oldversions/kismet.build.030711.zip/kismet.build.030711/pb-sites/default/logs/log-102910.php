20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|pasteboard.Started
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: useragents-config
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: dates-config
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: fopen-config
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: stopwords-config
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-database
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-useragent
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-hooks
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-sessions
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-cache
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-scaffolding
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-errors
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-uri
20101029092510|127.0.0.1|INCLUDE|2010-10-29 09:25:10|library: pb-logs
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_set_timezone: US/Pacific
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_sitewhoami: default Initialized
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_uri_segment: QUERY_STRING
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_useragent:  
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_useragent: 
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_init_session: Not Implemented
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_dbopen: mysql_pconnect
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029092510|127.0.0.1|SQL|2010-10-29 09:25:10|SQL_logged from show_404, 43
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|_dbclose CLOSED
20101029092510|127.0.0.1|INFO|2010-10-29 09:25:10|pasteboard.Complete (0.996 seconds)
20101029092510|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|pasteboard.Started
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: useragents-config
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: dates-config
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: fopen-config
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: stopwords-config
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-database
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-useragent
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-hooks
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-sessions
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-cache
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-scaffolding
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-errors
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-uri
20101029092536|127.0.0.1|INCLUDE|2010-10-29 09:25:36|library: pb-logs
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_set_timezone: US/Pacific
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_sitewhoami: default Initialized
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_uri_segment: QUERY_STRING
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_useragent:  
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_useragent: 
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_init_session: Not Implemented
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_dbopen: mysql_pconnect
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029092536|127.0.0.1|SQL|2010-10-29 09:25:36|SQL_logged from show_404, 43
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|_dbclose CLOSED
20101029092536|127.0.0.1|INFO|2010-10-29 09:25:36|pasteboard.Complete (1.273 seconds)
20101029092536|127.0.0.1|__ERROR_WARNING|2010-10-29 09:25:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|pasteboard.Started
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: useragents-config
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: dates-config
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: fopen-config
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: stopwords-config
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-database
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-useragent
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-hooks
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-sessions
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-cache
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-scaffolding
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-errors
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-uri
20101029093330|127.0.0.1|INCLUDE|2010-10-29 09:33:30|library: pb-logs
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_set_timezone: US/Pacific
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_sitewhoami: default Initialized
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_uri_segment: QUERY_STRING
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_useragent:  
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_useragent: 
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_init_session: Not Implemented
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_dbopen: mysql_pconnect
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029093330|127.0.0.1|SQL|2010-10-29 09:33:30|SQL_logged from show_404, 43
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|_dbclose CLOSED
20101029093330|127.0.0.1|INFO|2010-10-29 09:33:30|pasteboard.Complete (0.899 seconds)
20101029093330|127.0.0.1|__ERROR_WARNING|2010-10-29 09:33:30|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|pasteboard.Started
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: useragents-config
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: dates-config
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: fopen-config
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: stopwords-config
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-database
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-useragent
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-hooks
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-sessions
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-cache
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-scaffolding
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-errors
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-uri
20101029101156|127.0.0.1|INCLUDE|2010-10-29 10:11:56|library: pb-logs
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_set_timezone: US/Pacific
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_sitewhoami: default Initialized
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_uri_segment: QUERY_STRING
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_useragent:  
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_useragent: 
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_init_session: Not Implemented
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_dbopen: mysql_pconnect
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029101156|127.0.0.1|SQL|2010-10-29 10:11:56|SQL_logged from show_404, 43
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|_dbclose CLOSED
20101029101156|127.0.0.1|INFO|2010-10-29 10:11:56|pasteboard.Complete (1.188 seconds)
20101029101156|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|pasteboard.Started
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: useragents-config
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: dates-config
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: fopen-config
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: stopwords-config
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-database
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-useragent
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-hooks
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-sessions
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-cache
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-scaffolding
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-errors
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-uri
20101029101158|127.0.0.1|INCLUDE|2010-10-29 10:11:58|library: pb-logs
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_set_timezone: US/Pacific
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_sitewhoami: default Initialized
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_uri_segment: QUERY_STRING
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_useragent:  
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_useragent: 
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_init_session: Not Implemented
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_dbopen: mysql_pconnect
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029101158|127.0.0.1|SQL|2010-10-29 10:11:58|SQL_logged from show_404, 43
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|_dbclose CLOSED
20101029101158|127.0.0.1|INFO|2010-10-29 10:11:58|pasteboard.Complete (0.321 seconds)
20101029101158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:11:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|pasteboard.Started
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: useragents-config
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: dates-config
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: fopen-config
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: stopwords-config
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-database
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-useragent
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-hooks
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-sessions
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-cache
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-scaffolding
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-errors
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-uri
20101029102158|127.0.0.1|INCLUDE|2010-10-29 10:21:58|library: pb-logs
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_set_timezone: US/Pacific
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_sitewhoami: default Initialized
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_uri_segment: QUERY_STRING
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_useragent:  
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_useragent: 
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_init_session: Not Implemented
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_dbopen: mysql_pconnect
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029102158|127.0.0.1|SQL|2010-10-29 10:21:58|SQL_logged from show_404, 43
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|_dbclose CLOSED
20101029102158|127.0.0.1|INFO|2010-10-29 10:21:58|pasteboard.Complete (1.571 seconds)
20101029102158|127.0.0.1|__ERROR_WARNING|2010-10-29 10:21:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|pasteboard.Started
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: useragents-config
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: dates-config
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: fopen-config
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: stopwords-config
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-database
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-useragent
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-hooks
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-sessions
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-cache
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-scaffolding
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-errors
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-uri
20101029102344|127.0.0.1|INCLUDE|2010-10-29 10:23:44|library: pb-logs
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_set_timezone: US/Pacific
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_sitewhoami: default Initialized
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_uri_segment: QUERY_STRING
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_useragent:  
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_useragent: 
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_init_session: Not Implemented
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_dbopen: mysql_pconnect
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029102344|127.0.0.1|SQL|2010-10-29 10:23:44|SQL_logged from show_404, 43
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|_dbclose CLOSED
20101029102344|127.0.0.1|INFO|2010-10-29 10:23:44|pasteboard.Complete (0.613 seconds)
20101029102344|127.0.0.1|__ERROR_WARNING|2010-10-29 10:23:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|pasteboard.Started
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: useragents-config
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: dates-config
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: fopen-config
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: stopwords-config
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-database
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-useragent
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-hooks
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-sessions
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-cache
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-scaffolding
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-errors
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-uri
20101029102919|127.0.0.1|INCLUDE|2010-10-29 10:29:19|library: pb-logs
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_set_timezone: US/Pacific
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_sitewhoami: default Initialized
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_uri_segment: QUERY_STRING
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_useragent:  
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_useragent: 
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_init_session: Not Implemented
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_dbopen: mysql_pconnect
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029102919|127.0.0.1|SQL|2010-10-29 10:29:19|SQL_logged from show_404, 43
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|_dbclose CLOSED
20101029102919|127.0.0.1|INFO|2010-10-29 10:29:19|pasteboard.Complete (1.016 seconds)
20101029102919|127.0.0.1|__ERROR_WARNING|2010-10-29 10:29:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|pasteboard.Started
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: useragents-config
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: dates-config
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: fopen-config
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: stopwords-config
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-database
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-useragent
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-hooks
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-sessions
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-cache
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-scaffolding
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-errors
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-uri
20101029103502|127.0.0.1|INCLUDE|2010-10-29 10:35:02|library: pb-logs
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_set_timezone: US/Pacific
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_sitewhoami: default Initialized
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_uri_segment: QUERY_STRING
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_useragent:  
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_useragent: 
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_init_session: Not Implemented
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_dbopen: mysql_pconnect
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029103502|127.0.0.1|SQL|2010-10-29 10:35:02|SQL_logged from show_404, 43
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|_dbclose CLOSED
20101029103502|127.0.0.1|INFO|2010-10-29 10:35:02|pasteboard.Complete (0.926 seconds)
20101029103502|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|pasteboard.Started
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: useragents-config
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: dates-config
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: fopen-config
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: stopwords-config
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-database
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-useragent
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-hooks
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-sessions
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-cache
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-scaffolding
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-errors
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-uri
20101029103506|127.0.0.1|INCLUDE|2010-10-29 10:35:06|library: pb-logs
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_set_timezone: US/Pacific
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_sitewhoami: default Initialized
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_uri_segment: QUERY_STRING
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_useragent:  
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_useragent: 
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_init_session: Not Implemented
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_dbopen: mysql_pconnect
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029103506|127.0.0.1|SQL|2010-10-29 10:35:06|SQL_logged from show_404, 43
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|_dbclose CLOSED
20101029103506|127.0.0.1|INFO|2010-10-29 10:35:06|pasteboard.Complete (0.744 seconds)
20101029103506|127.0.0.1|__ERROR_WARNING|2010-10-29 10:35:06|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|pasteboard.Started
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: useragents-config
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: dates-config
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: fopen-config
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: stopwords-config
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-database
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-useragent
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-hooks
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-sessions
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-cache
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-scaffolding
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-errors
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-uri
20101029105929|127.0.0.1|INCLUDE|2010-10-29 10:59:29|library: pb-logs
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_set_timezone: US/Pacific
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_sitewhoami: default Initialized
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_uri_segment: QUERY_STRING
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_useragent:  
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_useragent: 
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_init_session: Not Implemented
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_dbopen: mysql_pconnect
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029105929|127.0.0.1|SQL|2010-10-29 10:59:29|SQL_logged from show_404, 43
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|_dbclose CLOSED
20101029105929|127.0.0.1|INFO|2010-10-29 10:59:29|pasteboard.Complete (0.648 seconds)
20101029105929|127.0.0.1|__ERROR_WARNING|2010-10-29 10:59:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|pasteboard.Started
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: useragents-config
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: dates-config
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: fopen-config
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: stopwords-config
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-database
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-useragent
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-hooks
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-sessions
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-cache
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-scaffolding
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-errors
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-uri
20101029133558|127.0.0.1|INCLUDE|2010-10-29 13:35:58|library: pb-logs
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_set_timezone: US/Pacific
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_sitewhoami: default Initialized
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_uri_segment: QUERY_STRING
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_useragent:  
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_useragent: 
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_init_session: Not Implemented
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_dbopen: mysql_pconnect
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029133558|127.0.0.1|SQL|2010-10-29 13:35:58|SQL_logged from show_404, 43
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|_dbclose CLOSED
20101029133558|127.0.0.1|INFO|2010-10-29 13:35:58|pasteboard.Complete (1.316 seconds)
20101029133558|127.0.0.1|__ERROR_WARNING|2010-10-29 13:35:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|pasteboard.Started
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: useragents-config
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: dates-config
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: fopen-config
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: stopwords-config
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-database
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-useragent
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-hooks
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-sessions
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-cache
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-scaffolding
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-errors
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-uri
20101029133600|127.0.0.1|INCLUDE|2010-10-29 13:36:00|library: pb-logs
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_set_timezone: US/Pacific
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_sitewhoami: default Initialized
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_uri_segment: QUERY_STRING
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_useragent:  
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_useragent: 
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_init_session: Not Implemented
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_dbopen: mysql_pconnect
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029133600|127.0.0.1|SQL|2010-10-29 13:36:00|SQL_logged from show_404, 43
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|_dbclose CLOSED
20101029133600|127.0.0.1|INFO|2010-10-29 13:36:00|pasteboard.Complete (1.026 seconds)
20101029133600|127.0.0.1|__ERROR_WARNING|2010-10-29 13:36:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|pasteboard.Started
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: useragents-config
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: dates-config
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: fopen-config
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: stopwords-config
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-database
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-useragent
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-hooks
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-sessions
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-cache
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-scaffolding
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-errors
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-uri
20101029133852|127.0.0.1|INCLUDE|2010-10-29 13:38:52|library: pb-logs
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_set_timezone: US/Pacific
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_sitewhoami: default Initialized
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_uri_segment: QUERY_STRING
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_useragent:  
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_useragent: 
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_init_session: Not Implemented
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_dbopen: mysql_pconnect
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101029133852|127.0.0.1|SQL|2010-10-29 13:38:52|SQL_logged from show_404, 43
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|_dbclose CLOSED
20101029133852|127.0.0.1|INFO|2010-10-29 13:38:52|pasteboard.Complete (0.283 seconds)
20101029133852|127.0.0.1|__ERROR_WARNING|2010-10-29 13:38:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
