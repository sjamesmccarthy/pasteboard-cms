20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|pasteboard.Started
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: useragents-config
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: dates-config
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: fopen-config
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: stopwords-config
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-database
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-useragent
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-hooks
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-sessions
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-cache
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-scaffolding
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-errors
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-uri
20100714191937|127.0.0.1|INCLUDE|2010-07-14 19:19:37|library: pb-logs
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_set_timezone: US/Pacific
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_sitewhoami: default Initialized
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_uri_segment: QUERY_STRING
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_useragent:  
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_useragent: 
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_init_session: Not Implemented
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_dbopen: mysql_pconnect
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714191937|127.0.0.1|SQL|2010-07-14 19:19:37|SQL_logged from show_404, 43
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|_dbclose CLOSED
20100714191937|127.0.0.1|INFO|2010-07-14 19:19:37|pasteboard.Complete (30.393 seconds)
20100714191937|127.0.0.1|__ERROR_WARNING|2010-07-14 19:19:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|pasteboard.Started
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: useragents-config
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: dates-config
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: fopen-config
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: stopwords-config
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-database
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-useragent
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-hooks
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-sessions
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-cache
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-scaffolding
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-errors
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-uri
20100714192046|127.0.0.1|INCLUDE|2010-07-14 19:20:46|library: pb-logs
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_set_timezone: US/Pacific
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_sitewhoami: default Initialized
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_uri_segment: QUERY_STRING
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_useragent:  
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_useragent: 
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_init_session: Not Implemented
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_dbopen: mysql_pconnect
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714192046|127.0.0.1|SQL|2010-07-14 19:20:46|SQL_logged from show_404, 43
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|_dbclose CLOSED
20100714192046|127.0.0.1|INFO|2010-07-14 19:20:46|pasteboard.Complete (30.478 seconds)
20100714192046|127.0.0.1|__ERROR_WARNING|2010-07-14 19:20:46|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100714192509|::1|INFO|2010-07-14 19:25:09|pasteboard.Started
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: useragents-config
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: dates-config
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: fopen-config
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: stopwords-config
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-database
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-useragent
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-hooks
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-sessions
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-cache
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-scaffolding
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-errors
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-uri
20100714192509|::1|INCLUDE|2010-07-14 19:25:09|library: pb-logs
20100714192509|::1|INFO|2010-07-14 19:25:09|_set_timezone: US/Pacific
20100714192509|::1|INFO|2010-07-14 19:25:09|_sitewhoami: default Initialized
20100714192509|::1|INFO|2010-07-14 19:25:09|_uri_segment: FRONT PAGE
20100714192509|::1|INFO|2010-07-14 19:25:09|_uri_segment: INDEX_WEBROOT
20100714192509|::1|INFO|2010-07-14 19:25:09|_useragent: Safari 533.16
20100714192509|::1|INFO|2010-07-14 19:25:09|_useragent: Mac OS X
20100714192509|::1|INFO|2010-07-14 19:25:09|_init_session: Not Implemented
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100714192509|::1|INFO|2010-07-14 19:25:09|_dbopen: mysql_pconnect
20100714192509|::1|INFO|2010-07-14 19:25:09|app: page Initialized
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714192509|::1|SQL|2010-07-14 19:25:09|SQL_logged from _get_front_page, 85
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/models/page_model.php
20100714192509|::1|INFO|2010-07-14 19:25:09|model: page_model.php Function: _get_front_page
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/page_controller.php, 64]
20100714192509|::1|INFO|2010-07-14 19:25:09|app: page Function: view
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/views/view_index.php, 32]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714192509|::1|SQL|2010-07-14 19:25:09|SQL_logged from _get_content_index, 22
20100714192509|::1|INFO|2010-07-14 19:25:09|model: page_model.php Function: _get_content_index
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100714192509|::1|INFO|2010-07-14 19:25:09|app: page Terminated
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100714192509|::1|INFO|2010-07-14 19:25:09|_dbclose CLOSED
20100714192509|::1|INFO|2010-07-14 19:25:09|pasteboard.Complete (31.31 seconds)
20100714192509|::1|__ERROR_WARNING|2010-07-14 19:25:09|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100714192601|::1|INFO|2010-07-14 19:26:01|pasteboard.Started
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: useragents-config
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: dates-config
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: fopen-config
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: stopwords-config
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-database
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-useragent
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-hooks
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-sessions
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-cache
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-scaffolding
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-errors
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-uri
20100714192601|::1|INCLUDE|2010-07-14 19:26:01|library: pb-logs
20100714192601|::1|INFO|2010-07-14 19:26:01|_set_timezone: US/Pacific
20100714192601|::1|INFO|2010-07-14 19:26:01|_sitewhoami: default Initialized
20100714192601|::1|INFO|2010-07-14 19:26:01|_uri_segment: FRONT PAGE
20100714192601|::1|INFO|2010-07-14 19:26:01|_uri_segment: INDEX_WEBROOT
20100714192601|::1|INFO|2010-07-14 19:26:01|_useragent: Safari 533.16
20100714192601|::1|INFO|2010-07-14 19:26:01|_useragent: Mac OS X
20100714192601|::1|INFO|2010-07-14 19:26:01|_init_session: Not Implemented
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100714192601|::1|INFO|2010-07-14 19:26:01|_dbopen: mysql_pconnect
20100714192601|::1|INFO|2010-07-14 19:26:01|app: page Initialized
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714192601|::1|SQL|2010-07-14 19:26:01|SQL_logged from _get_front_page, 85
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/models/page_model.php
20100714192601|::1|INFO|2010-07-14 19:26:01|model: page_model.php Function: _get_front_page
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/page_controller.php, 64]
20100714192601|::1|INFO|2010-07-14 19:26:01|app: page Function: view
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/views/view_index.php, 32]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714192601|::1|SQL|2010-07-14 19:26:01|SQL_logged from _get_content_index, 22
20100714192601|::1|INFO|2010-07-14 19:26:01|model: page_model.php Function: _get_content_index
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100714192601|::1|INFO|2010-07-14 19:26:01|app: page Terminated
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100714192601|::1|INFO|2010-07-14 19:26:01|_dbclose CLOSED
20100714192601|::1|INFO|2010-07-14 19:26:01|pasteboard.Complete (30.815 seconds)
20100714192601|::1|__ERROR_WARNING|2010-07-14 19:26:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|pasteboard.Started
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: useragents-config
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: dates-config
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: fopen-config
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: stopwords-config
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-database
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-useragent
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-hooks
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-sessions
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-cache
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-scaffolding
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-errors
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-uri
20100714193007|127.0.0.1|INCLUDE|2010-07-14 19:30:07|library: pb-logs
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_set_timezone: US/Pacific
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_sitewhoami: default Initialized
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_uri_segment: QUERY_STRING
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_useragent:  
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_useragent: 
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_init_session: Not Implemented
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_dbopen: mysql_pconnect
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714193007|127.0.0.1|SQL|2010-07-14 19:30:07|SQL_logged from show_404, 43
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|_dbclose CLOSED
20100714193007|127.0.0.1|INFO|2010-07-14 19:30:07|pasteboard.Complete (31.076 seconds)
20100714193007|127.0.0.1|__ERROR_WARNING|2010-07-14 19:30:07|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|pasteboard.Started
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: useragents-config
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: dates-config
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: fopen-config
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: stopwords-config
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-database
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-useragent
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-hooks
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-sessions
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-cache
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-scaffolding
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-errors
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-uri
20100714194038|127.0.0.1|INCLUDE|2010-07-14 19:40:38|library: pb-logs
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_set_timezone: US/Pacific
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_sitewhoami: default Initialized
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_uri_segment: QUERY_STRING
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_useragent:  
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_useragent: 
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_init_session: Not Implemented
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_dbopen: mysql_pconnect
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714194038|127.0.0.1|SQL|2010-07-14 19:40:38|SQL_logged from show_404, 43
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|_dbclose CLOSED
20100714194038|127.0.0.1|INFO|2010-07-14 19:40:38|pasteboard.Complete (30.753 seconds)
20100714194038|127.0.0.1|__ERROR_WARNING|2010-07-14 19:40:38|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100714214236|::1|INFO|2010-07-14 21:42:36|pasteboard.Started
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: useragents-config
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: dates-config
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: fopen-config
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: stopwords-config
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-database
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-useragent
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-hooks
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-sessions
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-cache
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-scaffolding
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-errors
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-uri
20100714214236|::1|INCLUDE|2010-07-14 21:42:36|library: pb-logs
20100714214236|::1|INFO|2010-07-14 21:42:36|_set_timezone: US/Pacific
20100714214236|::1|INFO|2010-07-14 21:42:36|_sitewhoami: default Initialized
20100714214236|::1|INFO|2010-07-14 21:42:36|_uri_segment: FRONT PAGE
20100714214236|::1|INFO|2010-07-14 21:42:36|_uri_segment: INDEX_WEBROOT
20100714214236|::1|INFO|2010-07-14 21:42:36|_useragent: Safari 533.16
20100714214236|::1|INFO|2010-07-14 21:42:36|_useragent: Mac OS X
20100714214236|::1|INFO|2010-07-14 21:42:36|_init_session: Not Implemented
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100714214236|::1|INFO|2010-07-14 21:42:36|_dbopen: mysql_pconnect
20100714214236|::1|INFO|2010-07-14 21:42:36|app: page Initialized
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714214236|::1|SQL|2010-07-14 21:42:36|SQL_logged from _get_front_page, 85
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/models/page_model.php
20100714214236|::1|INFO|2010-07-14 21:42:36|model: page_model.php Function: _get_front_page
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/page_controller.php, 64]
20100714214236|::1|INFO|2010-07-14 21:42:36|app: page Function: view
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/views/view_index.php, 32]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714214236|::1|SQL|2010-07-14 21:42:36|SQL_logged from _get_content_index, 22
20100714214236|::1|INFO|2010-07-14 21:42:36|model: page_model.php Function: _get_content_index
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100714214236|::1|INFO|2010-07-14 21:42:36|app: page Terminated
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100714214236|::1|INFO|2010-07-14 21:42:36|_dbclose CLOSED
20100714214236|::1|INFO|2010-07-14 21:42:36|pasteboard.Complete (31.559 seconds)
20100714214236|::1|__ERROR_WARNING|2010-07-14 21:42:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100714221559|::1|INFO|2010-07-14 22:15:59|pasteboard.Started
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: useragents-config
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: dates-config
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: fopen-config
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: stopwords-config
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-database
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-useragent
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-hooks
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-sessions
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-cache
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-scaffolding
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-errors
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-uri
20100714221559|::1|INCLUDE|2010-07-14 22:15:59|library: pb-logs
20100714221559|::1|INFO|2010-07-14 22:15:59|_set_timezone: US/Pacific
20100714221559|::1|INFO|2010-07-14 22:15:59|_sitewhoami: default Initialized
20100714221559|::1|INFO|2010-07-14 22:15:59|_uri_segment: FRONT PAGE
20100714221559|::1|INFO|2010-07-14 22:15:59|_uri_segment: INDEX_WEBROOT
20100714221559|::1|INFO|2010-07-14 22:15:59|_useragent: Safari 533.16
20100714221559|::1|INFO|2010-07-14 22:15:59|_useragent: Mac OS X
20100714221559|::1|INFO|2010-07-14 22:15:59|_init_session: Not Implemented
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100714221559|::1|INFO|2010-07-14 22:15:59|_dbopen: mysql_pconnect
20100714221559|::1|INFO|2010-07-14 22:15:59|app: page Initialized
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714221559|::1|SQL|2010-07-14 22:15:59|SQL_logged from _get_front_page, 85
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/models/page_model.php
20100714221559|::1|INFO|2010-07-14 22:15:59|model: page_model.php Function: _get_front_page
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/page_controller.php, 64]
20100714221559|::1|INFO|2010-07-14 22:15:59|app: page Function: view
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/views/view_index.php, 32]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100714221559|::1|SQL|2010-07-14 22:15:59|SQL_logged from _get_content_index, 22
20100714221559|::1|INFO|2010-07-14 22:15:59|model: page_model.php Function: _get_content_index
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100714221559|::1|INFO|2010-07-14 22:15:59|app: page Terminated
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100714221559|::1|INFO|2010-07-14 22:15:59|_dbclose CLOSED
20100714221559|::1|INFO|2010-07-14 22:15:59|pasteboard.Complete (30.931 seconds)
20100714221559|::1|__ERROR_WARNING|2010-07-14 22:15:59|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
