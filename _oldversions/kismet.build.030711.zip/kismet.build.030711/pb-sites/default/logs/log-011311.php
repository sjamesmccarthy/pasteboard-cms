20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|pasteboard.Started
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: useragents-config
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: dates-config
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: fopen-config
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: stopwords-config
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-database
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-useragent
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-hooks
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-sessions
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-cache
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-scaffolding
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-errors
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-uri
20110113213130|127.0.0.1|INCLUDE|2011-01-13 21:31:30|library: pb-logs
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_set_timezone: US/Pacific
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_sitewhoami: default Initialized
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_uri_segment: QUERY_STRING
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_useragent:  
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_useragent: 
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_init_session: Not Implemented
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_dbopen: mysql_pconnect
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113213130|127.0.0.1|SQL|2011-01-13 21:31:30|SQL_logged from show_404, 43
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|_dbclose CLOSED
20110113213130|127.0.0.1|INFO|2011-01-13 21:31:30|pasteboard.Complete (3.274 seconds)
20110113213130|127.0.0.1|__ERROR_WARNING|2011-01-13 21:31:30|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|pasteboard.Started
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: useragents-config
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: dates-config
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: fopen-config
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: stopwords-config
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-database
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-useragent
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-hooks
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-sessions
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-cache
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-scaffolding
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-errors
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-uri
20110113213318|127.0.0.1|INCLUDE|2011-01-13 21:33:18|library: pb-logs
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_set_timezone: US/Pacific
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_sitewhoami: default Initialized
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_uri_segment: QUERY_STRING
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_useragent:  
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_useragent: 
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_init_session: Not Implemented
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_dbopen: mysql_pconnect
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113213318|127.0.0.1|SQL|2011-01-13 21:33:18|SQL_logged from show_404, 43
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|_dbclose CLOSED
20110113213318|127.0.0.1|INFO|2011-01-13 21:33:18|pasteboard.Complete (2.648 seconds)
20110113213318|127.0.0.1|__ERROR_WARNING|2011-01-13 21:33:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|pasteboard.Started
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: useragents-config
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: dates-config
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: fopen-config
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: stopwords-config
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-database
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-useragent
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-hooks
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-sessions
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-cache
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-scaffolding
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-errors
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-uri
20110113213534|127.0.0.1|INCLUDE|2011-01-13 21:35:34|library: pb-logs
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_set_timezone: US/Pacific
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_sitewhoami: default Initialized
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_uri_segment: QUERY_STRING
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_useragent:  
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_useragent: 
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_init_session: Not Implemented
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_dbopen: mysql_pconnect
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113213534|127.0.0.1|SQL|2011-01-13 21:35:34|SQL_logged from show_404, 43
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|_dbclose CLOSED
20110113213534|127.0.0.1|INFO|2011-01-13 21:35:34|pasteboard.Complete (2.199 seconds)
20110113213534|127.0.0.1|__ERROR_WARNING|2011-01-13 21:35:34|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|pasteboard.Started
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: useragents-config
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: dates-config
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: fopen-config
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: stopwords-config
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-database
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-useragent
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-hooks
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-sessions
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-cache
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-scaffolding
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-errors
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-uri
20110113213809|127.0.0.1|INCLUDE|2011-01-13 21:38:09|library: pb-logs
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_set_timezone: US/Pacific
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_sitewhoami: default Initialized
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_uri_segment: QUERY_STRING
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_useragent:  
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_useragent: 
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_init_session: Not Implemented
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_dbopen: mysql_pconnect
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113213809|127.0.0.1|SQL|2011-01-13 21:38:09|SQL_logged from show_404, 43
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|_dbclose CLOSED
20110113213809|127.0.0.1|INFO|2011-01-13 21:38:09|pasteboard.Complete (2.116 seconds)
20110113213809|127.0.0.1|__ERROR_WARNING|2011-01-13 21:38:09|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|pasteboard.Started
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: useragents-config
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: dates-config
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: fopen-config
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: stopwords-config
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-database
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-useragent
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-hooks
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-sessions
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-cache
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-scaffolding
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-errors
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-uri
20110113214133|127.0.0.1|INCLUDE|2011-01-13 21:41:33|library: pb-logs
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_set_timezone: US/Pacific
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_sitewhoami: default Initialized
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_uri_segment: QUERY_STRING
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_useragent:  
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_useragent: 
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_init_session: Not Implemented
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_dbopen: mysql_pconnect
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113214133|127.0.0.1|SQL|2011-01-13 21:41:33|SQL_logged from show_404, 43
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|_dbclose CLOSED
20110113214133|127.0.0.1|INFO|2011-01-13 21:41:33|pasteboard.Complete (2.279 seconds)
20110113214133|127.0.0.1|__ERROR_WARNING|2011-01-13 21:41:33|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|pasteboard.Started
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: useragents-config
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: dates-config
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: fopen-config
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: stopwords-config
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-database
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-useragent
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-hooks
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-sessions
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-cache
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-scaffolding
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-errors
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-uri
20110113214537|127.0.0.1|INCLUDE|2011-01-13 21:45:37|library: pb-logs
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_set_timezone: US/Pacific
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_sitewhoami: default Initialized
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_uri_segment: QUERY_STRING
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_useragent:  
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_useragent: 
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_init_session: Not Implemented
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_dbopen: mysql_pconnect
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113214537|127.0.0.1|SQL|2011-01-13 21:45:37|SQL_logged from show_404, 43
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|_dbclose CLOSED
20110113214537|127.0.0.1|INFO|2011-01-13 21:45:37|pasteboard.Complete (1.933 seconds)
20110113214537|127.0.0.1|__ERROR_WARNING|2011-01-13 21:45:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|pasteboard.Started
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: useragents-config
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: dates-config
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: fopen-config
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: stopwords-config
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-database
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-useragent
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-hooks
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-sessions
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-cache
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-scaffolding
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-errors
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-uri
20110113214956|127.0.0.1|INCLUDE|2011-01-13 21:49:56|library: pb-logs
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_set_timezone: US/Pacific
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_sitewhoami: default Initialized
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_uri_segment: QUERY_STRING
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_useragent:  
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_useragent: 
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_init_session: Not Implemented
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_dbopen: mysql_pconnect
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113214956|127.0.0.1|SQL|2011-01-13 21:49:56|SQL_logged from show_404, 43
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|_dbclose CLOSED
20110113214956|127.0.0.1|INFO|2011-01-13 21:49:56|pasteboard.Complete (2.968 seconds)
20110113214956|127.0.0.1|__ERROR_WARNING|2011-01-13 21:49:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|pasteboard.Started
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: useragents-config
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: dates-config
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: fopen-config
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: stopwords-config
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-database
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-useragent
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-hooks
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-sessions
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-cache
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-scaffolding
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-errors
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-uri
20110113215137|127.0.0.1|INCLUDE|2011-01-13 21:51:37|library: pb-logs
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_set_timezone: US/Pacific
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_sitewhoami: default Initialized
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_uri_segment: QUERY_STRING
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_useragent:  
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_useragent: 
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_init_session: Not Implemented
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_dbopen: mysql_pconnect
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113215137|127.0.0.1|SQL|2011-01-13 21:51:37|SQL_logged from show_404, 43
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|_dbclose CLOSED
20110113215137|127.0.0.1|INFO|2011-01-13 21:51:37|pasteboard.Complete (3.07 seconds)
20110113215137|127.0.0.1|__ERROR_WARNING|2011-01-13 21:51:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|pasteboard.Started
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: useragents-config
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: dates-config
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: fopen-config
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: stopwords-config
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-database
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-useragent
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-hooks
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-sessions
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-cache
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-scaffolding
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-errors
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-uri
20110113215736|127.0.0.1|INCLUDE|2011-01-13 21:57:36|library: pb-logs
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_set_timezone: US/Pacific
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_sitewhoami: default Initialized
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_uri_segment: QUERY_STRING
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_useragent:  
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_useragent: 
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_init_session: Not Implemented
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_dbopen: mysql_pconnect
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110113215736|127.0.0.1|SQL|2011-01-13 21:57:36|SQL_logged from show_404, 43
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|_dbclose CLOSED
20110113215736|127.0.0.1|INFO|2011-01-13 21:57:36|pasteboard.Complete (2.253 seconds)
20110113215736|127.0.0.1|__ERROR_WARNING|2011-01-13 21:57:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
