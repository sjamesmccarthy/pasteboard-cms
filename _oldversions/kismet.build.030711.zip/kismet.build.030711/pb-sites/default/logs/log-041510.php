20100415205711|::1|INFO|2010-04-15 20:57:10|pasteboard.Started
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: useragents-config
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: dates-config
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: fopen-config
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: stopwords-config
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-database
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-useragent
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-hooks
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-sessions
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-cache
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-scaffolding
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-errors
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-uri
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-logs
20100415205711|::1|INFO|2010-04-15 20:57:10|_set_timezone: US/Pacific
20100415205711|::1|INFO|2010-04-15 20:57:10|_sitewhoami: default Initialized
20100415205711|::1|INFO|2010-04-15 20:57:10|_uri_segment: SECONDARY PAGE FOUND w/ID: closelabel.gif
20100415205711|::1|INFO|2010-04-15 20:57:10|_uri_segment: SEGMENT_PATH
20100415205711|::1|INFO|2010-04-15 20:57:10|_useragent: Chrome 5.0.342.9
20100415205711|::1|INFO|2010-04-15 20:57:10|_useragent: Mac OS X
20100415205711|::1|INFO|2010-04-15 20:57:10|_init_session: Not Implemented
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|INFO|2010-04-15 20:57:10|pasteboard.Started
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: useragents-config
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: dates-config
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: fopen-config
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: stopwords-config
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-database
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-useragent
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-hooks
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-sessions
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-cache
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-scaffolding
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-errors
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-uri
20100415205711|::1|INCLUDE|2010-04-15 20:57:10|library: pb-logs
20100415205711|::1|INFO|2010-04-15 20:57:10|_set_timezone: US/Pacific
20100415205711|::1|INFO|2010-04-15 20:57:10|_sitewhoami: default Initialized
20100415205711|::1|INFO|2010-04-15 20:57:10|_uri_segment: SECONDARY PAGE FOUND w/ID: loading.gif
20100415205711|::1|INFO|2010-04-15 20:57:10|_uri_segment: SEGMENT_PATH
20100415205711|::1|INFO|2010-04-15 20:57:10|_useragent: Chrome 5.0.342.9
20100415205711|::1|INFO|2010-04-15 20:57:10|_useragent: Mac OS X
20100415205711|::1|INFO|2010-04-15 20:57:10|_init_session: Not Implemented
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100415205711|::1|INFO|2010-04-15 20:57:10|_dbopen: mysql_pconnect
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|File Not Found: qn_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100415205711|::1|SQL|2010-04-15 20:57:10|SQL_logged from show_404, 43
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100415205711|::1|INFO|2010-04-15 20:57:10|_dbopen: mysql_pconnect
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|File Not Found: qn_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100415205711|::1|SQL|2010-04-15 20:57:10|SQL_logged from show_404, 43
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100415205711|::1|INFO|2010-04-15 20:57:10|_dbclose CLOSED
20100415205711|::1|INFO|2010-04-15 20:57:10|pasteboard.Complete (32.083 seconds)
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100415205711|::1|INFO|2010-04-15 20:57:10|_dbclose CLOSED
20100415205711|::1|INFO|2010-04-15 20:57:10|pasteboard.Complete (32.105 seconds)
20100415205711|::1|__ERROR_WARNING|2010-04-15 20:57:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
