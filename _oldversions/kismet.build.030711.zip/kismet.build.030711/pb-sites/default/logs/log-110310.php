20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|pasteboard.Started
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: useragents-config
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: dates-config
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: fopen-config
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: stopwords-config
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-database
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-useragent
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-hooks
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|pasteboard.Started
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-sessions
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: useragents-config
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: dates-config
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: fopen-config
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: stopwords-config
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-database
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-useragent
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-hooks
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-sessions
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-cache
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-scaffolding
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-errors
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-uri
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-logs
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_set_timezone: US/Pacific
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-cache
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_sitewhoami: default Initialized
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-scaffolding
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-errors
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-uri
20101103214850|127.0.0.1|INCLUDE|2010-11-03 21:48:50|library: pb-logs
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_set_timezone: US/Pacific
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_sitewhoami: default Initialized
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_uri_segment: QUERY_STRING
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_useragent:  
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_useragent: 
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_init_session: Not Implemented
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_uri_segment: QUERY_STRING
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_useragent:  
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_useragent: 
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_init_session: Not Implemented
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_dbopen: mysql_pconnect
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103214850|127.0.0.1|SQL|2010-11-03 21:48:50|SQL_logged from show_404, 43
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_dbopen: mysql_pconnect
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103214850|127.0.0.1|SQL|2010-11-03 21:48:50|SQL_logged from show_404, 43
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_dbclose CLOSED
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|pasteboard.Complete (30.964 seconds)
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|_dbclose CLOSED
20101103214850|127.0.0.1|INFO|2010-11-03 21:48:50|pasteboard.Complete (30.994 seconds)
20101103214850|127.0.0.1|__ERROR_WARNING|2010-11-03 21:48:50|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|pasteboard.Started
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: useragents-config
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: dates-config
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: fopen-config
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: stopwords-config
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-database
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-useragent
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-hooks
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-sessions
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-cache
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-scaffolding
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-errors
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-uri
20101103215336|127.0.0.1|INCLUDE|2010-11-03 21:53:36|library: pb-logs
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_set_timezone: US/Pacific
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_sitewhoami: default Initialized
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_uri_segment: QUERY_STRING
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_useragent:  
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_useragent: 
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_init_session: Not Implemented
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_dbopen: mysql_pconnect
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103215336|127.0.0.1|SQL|2010-11-03 21:53:36|SQL_logged from show_404, 43
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|_dbclose CLOSED
20101103215336|127.0.0.1|INFO|2010-11-03 21:53:36|pasteboard.Complete (30.381 seconds)
20101103215336|127.0.0.1|__ERROR_WARNING|2010-11-03 21:53:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|pasteboard.Started
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: useragents-config
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: dates-config
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: fopen-config
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: stopwords-config
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-database
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-useragent
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-hooks
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-sessions
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-cache
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-scaffolding
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-errors
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-uri
20101103215419|127.0.0.1|INCLUDE|2010-11-03 21:54:19|library: pb-logs
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_set_timezone: US/Pacific
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_sitewhoami: default Initialized
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_uri_segment: QUERY_STRING
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_useragent:  
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_useragent: 
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_init_session: Not Implemented
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_dbopen: mysql_pconnect
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103215419|127.0.0.1|SQL|2010-11-03 21:54:19|SQL_logged from show_404, 43
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|_dbclose CLOSED
20101103215419|127.0.0.1|INFO|2010-11-03 21:54:19|pasteboard.Complete (30.78 seconds)
20101103215419|127.0.0.1|__ERROR_WARNING|2010-11-03 21:54:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|pasteboard.Started
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: useragents-config
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: dates-config
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: fopen-config
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: stopwords-config
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-database
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-useragent
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-hooks
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-sessions
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-cache
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-scaffolding
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-errors
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-uri
20101103220449|127.0.0.1|INCLUDE|2010-11-03 22:04:49|library: pb-logs
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_set_timezone: US/Pacific
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_sitewhoami: default Initialized
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_uri_segment: QUERY_STRING
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_useragent:  
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_useragent: 
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_init_session: Not Implemented
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_dbopen: mysql_pconnect
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103220449|127.0.0.1|SQL|2010-11-03 22:04:49|SQL_logged from show_404, 43
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|_dbclose CLOSED
20101103220449|127.0.0.1|INFO|2010-11-03 22:04:49|pasteboard.Complete (30.968 seconds)
20101103220449|127.0.0.1|__ERROR_WARNING|2010-11-03 22:04:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|pasteboard.Started
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: useragents-config
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: dates-config
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: fopen-config
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: stopwords-config
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-database
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-useragent
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-hooks
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-sessions
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-cache
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-scaffolding
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-errors
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-uri
20101103221520|127.0.0.1|INCLUDE|2010-11-03 22:15:20|library: pb-logs
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_set_timezone: US/Pacific
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_sitewhoami: default Initialized
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_uri_segment: QUERY_STRING
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_useragent:  
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_useragent: 
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_init_session: Not Implemented
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_dbopen: mysql_pconnect
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103221520|127.0.0.1|SQL|2010-11-03 22:15:20|SQL_logged from show_404, 43
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|_dbclose CLOSED
20101103221520|127.0.0.1|INFO|2010-11-03 22:15:20|pasteboard.Complete (30.264 seconds)
20101103221520|127.0.0.1|__ERROR_WARNING|2010-11-03 22:15:20|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|pasteboard.Started
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: useragents-config
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: dates-config
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: fopen-config
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: stopwords-config
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-database
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-useragent
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-hooks
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-sessions
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-cache
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-scaffolding
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-errors
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-uri
20101103222551|127.0.0.1|INCLUDE|2010-11-03 22:25:51|library: pb-logs
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_set_timezone: US/Pacific
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_sitewhoami: default Initialized
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_uri_segment: QUERY_STRING
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_useragent:  
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_useragent: 
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_init_session: Not Implemented
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_dbopen: mysql_pconnect
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103222551|127.0.0.1|SQL|2010-11-03 22:25:51|SQL_logged from show_404, 43
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|_dbclose CLOSED
20101103222551|127.0.0.1|INFO|2010-11-03 22:25:51|pasteboard.Complete (30.513 seconds)
20101103222551|127.0.0.1|__ERROR_WARNING|2010-11-03 22:25:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|pasteboard.Started
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: useragents-config
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: dates-config
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: fopen-config
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: stopwords-config
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-database
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-useragent
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-hooks
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-sessions
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-cache
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-scaffolding
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-errors
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-uri
20101103222649|127.0.0.1|INCLUDE|2010-11-03 22:26:49|library: pb-logs
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_set_timezone: US/Pacific
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_sitewhoami: default Initialized
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_uri_segment: QUERY_STRING
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_useragent:  
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_useragent: 
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_init_session: Not Implemented
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_dbopen: mysql_pconnect
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103222649|127.0.0.1|SQL|2010-11-03 22:26:49|SQL_logged from show_404, 43
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|_dbclose CLOSED
20101103222649|127.0.0.1|INFO|2010-11-03 22:26:49|pasteboard.Complete (30.829 seconds)
20101103222649|127.0.0.1|__ERROR_WARNING|2010-11-03 22:26:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|pasteboard.Started
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: useragents-config
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: dates-config
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: fopen-config
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: stopwords-config
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-database
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-useragent
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-hooks
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-sessions
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-cache
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-scaffolding
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-errors
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-uri
20101103223621|127.0.0.1|INCLUDE|2010-11-03 22:36:21|library: pb-logs
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_set_timezone: US/Pacific
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_sitewhoami: default Initialized
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_uri_segment: QUERY_STRING
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_useragent:  
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_useragent: 
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_init_session: Not Implemented
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_dbopen: mysql_pconnect
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103223621|127.0.0.1|SQL|2010-11-03 22:36:21|SQL_logged from show_404, 43
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|_dbclose CLOSED
20101103223621|127.0.0.1|INFO|2010-11-03 22:36:21|pasteboard.Complete (30.94 seconds)
20101103223621|127.0.0.1|__ERROR_WARNING|2010-11-03 22:36:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|pasteboard.Started
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: useragents-config
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: dates-config
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: fopen-config
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: stopwords-config
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-database
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-useragent
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-hooks
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-sessions
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-cache
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-scaffolding
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-errors
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-uri
20101103224652|127.0.0.1|INCLUDE|2010-11-03 22:46:52|library: pb-logs
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_set_timezone: US/Pacific
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_sitewhoami: default Initialized
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_uri_segment: QUERY_STRING
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_useragent:  
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_useragent: 
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_init_session: Not Implemented
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_dbopen: mysql_pconnect
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103224652|127.0.0.1|SQL|2010-11-03 22:46:52|SQL_logged from show_404, 43
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|_dbclose CLOSED
20101103224652|127.0.0.1|INFO|2010-11-03 22:46:52|pasteboard.Complete (30.276 seconds)
20101103224652|127.0.0.1|__ERROR_WARNING|2010-11-03 22:46:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|pasteboard.Started
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: useragents-config
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: dates-config
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: fopen-config
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: stopwords-config
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-database
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-useragent
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-hooks
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-sessions
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-cache
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-scaffolding
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-errors
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-uri
20101103225723|127.0.0.1|INCLUDE|2010-11-03 22:57:23|library: pb-logs
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_set_timezone: US/Pacific
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_sitewhoami: default Initialized
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_uri_segment: QUERY_STRING
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_useragent:  
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_useragent: 
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_init_session: Not Implemented
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_dbopen: mysql_pconnect
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103225723|127.0.0.1|SQL|2010-11-03 22:57:23|SQL_logged from show_404, 43
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|_dbclose CLOSED
20101103225723|127.0.0.1|INFO|2010-11-03 22:57:23|pasteboard.Complete (30.54 seconds)
20101103225723|127.0.0.1|__ERROR_WARNING|2010-11-03 22:57:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|pasteboard.Started
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: useragents-config
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: dates-config
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: fopen-config
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: stopwords-config
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-database
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-useragent
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-hooks
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-sessions
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-cache
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-scaffolding
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-errors
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-uri
20101103230034|127.0.0.1|INCLUDE|2010-11-03 23:00:34|library: pb-logs
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_set_timezone: US/Pacific
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_sitewhoami: default Initialized
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_uri_segment: QUERY_STRING
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_useragent:  
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_useragent: 
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_init_session: Not Implemented
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_dbopen: mysql_pconnect
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103230034|127.0.0.1|SQL|2010-11-03 23:00:34|SQL_logged from show_404, 43
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|_dbclose CLOSED
20101103230034|127.0.0.1|INFO|2010-11-03 23:00:34|pasteboard.Complete (30.937 seconds)
20101103230034|127.0.0.1|__ERROR_WARNING|2010-11-03 23:00:34|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|pasteboard.Started
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: useragents-config
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: dates-config
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: fopen-config
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: stopwords-config
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-database
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-useragent
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-hooks
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-sessions
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-cache
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-scaffolding
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-errors
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-uri
20101103230753|127.0.0.1|INCLUDE|2010-11-03 23:07:53|library: pb-logs
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_set_timezone: US/Pacific
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_sitewhoami: default Initialized
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_uri_segment: QUERY_STRING
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_useragent:  
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_useragent: 
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_init_session: Not Implemented
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_dbopen: mysql_pconnect
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103230753|127.0.0.1|SQL|2010-11-03 23:07:53|SQL_logged from show_404, 43
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|_dbclose CLOSED
20101103230753|127.0.0.1|INFO|2010-11-03 23:07:53|pasteboard.Complete (31.101 seconds)
20101103230753|127.0.0.1|__ERROR_WARNING|2010-11-03 23:07:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|pasteboard.Started
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: useragents-config
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: dates-config
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: fopen-config
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: stopwords-config
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-database
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-useragent
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-hooks
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-sessions
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-cache
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-scaffolding
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-errors
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-uri
20101103231825|127.0.0.1|INCLUDE|2010-11-03 23:18:25|library: pb-logs
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_set_timezone: US/Pacific
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_sitewhoami: default Initialized
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_uri_segment: QUERY_STRING
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_useragent:  
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_useragent: 
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_init_session: Not Implemented
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_dbopen: mysql_pconnect
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103231825|127.0.0.1|SQL|2010-11-03 23:18:25|SQL_logged from show_404, 43
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|_dbclose CLOSED
20101103231825|127.0.0.1|INFO|2010-11-03 23:18:25|pasteboard.Complete (30.451 seconds)
20101103231825|127.0.0.1|__ERROR_WARNING|2010-11-03 23:18:25|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|pasteboard.Started
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: useragents-config
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: dates-config
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: fopen-config
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: stopwords-config
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-database
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-useragent
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-hooks
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-sessions
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-cache
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-scaffolding
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-errors
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-uri
20101103232855|127.0.0.1|INCLUDE|2010-11-03 23:28:55|library: pb-logs
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_set_timezone: US/Pacific
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_sitewhoami: default Initialized
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_uri_segment: QUERY_STRING
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_useragent:  
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_useragent: 
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_init_session: Not Implemented
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_dbopen: mysql_pconnect
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103232855|127.0.0.1|SQL|2010-11-03 23:28:55|SQL_logged from show_404, 43
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|_dbclose CLOSED
20101103232855|127.0.0.1|INFO|2010-11-03 23:28:55|pasteboard.Complete (30.54 seconds)
20101103232855|127.0.0.1|__ERROR_WARNING|2010-11-03 23:28:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|pasteboard.Started
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: useragents-config
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: dates-config
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: fopen-config
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: stopwords-config
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-database
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-useragent
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-hooks
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-sessions
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-cache
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-scaffolding
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-errors
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-uri
20101103233426|127.0.0.1|INCLUDE|2010-11-03 23:34:26|library: pb-logs
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_set_timezone: US/Pacific
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_sitewhoami: default Initialized
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_uri_segment: QUERY_STRING
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_useragent:  
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_useragent: 
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_init_session: Not Implemented
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_dbopen: mysql_pconnect
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103233426|127.0.0.1|SQL|2010-11-03 23:34:26|SQL_logged from show_404, 43
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|_dbclose CLOSED
20101103233426|127.0.0.1|INFO|2010-11-03 23:34:26|pasteboard.Complete (30.156 seconds)
20101103233426|127.0.0.1|__ERROR_WARNING|2010-11-03 23:34:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|pasteboard.Started
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: useragents-config
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: dates-config
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: fopen-config
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: stopwords-config
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-database
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-useragent
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-hooks
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-sessions
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-cache
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-scaffolding
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-errors
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-uri
20101103233926|127.0.0.1|INCLUDE|2010-11-03 23:39:26|library: pb-logs
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_set_timezone: US/Pacific
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_sitewhoami: default Initialized
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_uri_segment: QUERY_STRING
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_useragent:  
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_useragent: 
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_init_session: Not Implemented
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_dbopen: mysql_pconnect
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103233926|127.0.0.1|SQL|2010-11-03 23:39:26|SQL_logged from show_404, 43
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|_dbclose CLOSED
20101103233926|127.0.0.1|INFO|2010-11-03 23:39:26|pasteboard.Complete (30.239 seconds)
20101103233926|127.0.0.1|__ERROR_WARNING|2010-11-03 23:39:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|pasteboard.Started
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: useragents-config
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: dates-config
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: fopen-config
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: stopwords-config
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-database
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-useragent
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-hooks
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-sessions
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-cache
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-scaffolding
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-errors
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-uri
20101103234956|127.0.0.1|INCLUDE|2010-11-03 23:49:56|library: pb-logs
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_set_timezone: US/Pacific
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_sitewhoami: default Initialized
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_uri_segment: QUERY_STRING
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_useragent:  
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_useragent: 
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_init_session: Not Implemented
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_dbopen: mysql_pconnect
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101103234956|127.0.0.1|SQL|2010-11-03 23:49:56|SQL_logged from show_404, 43
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|_dbclose CLOSED
20101103234956|127.0.0.1|INFO|2010-11-03 23:49:56|pasteboard.Complete (30.479 seconds)
20101103234956|127.0.0.1|__ERROR_WARNING|2010-11-03 23:49:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
