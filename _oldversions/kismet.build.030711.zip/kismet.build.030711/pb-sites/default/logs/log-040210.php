20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|pasteboard.Started
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: useragents-config
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: dates-config
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: fopen-config
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: stopwords-config
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-database
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-useragent
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-hooks
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-sessions
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-cache
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-scaffolding
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-errors
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-uri
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|library: pb-logs
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_set_timezone: US/Pacific
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_sitewhoami: default Initialized
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_uri_segment: SEGMENT_PATH
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_useragent: Chrome 5.0.342.7
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_useragent: Mac OS X
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_init_session: Not Implemented
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_dbopen: mysql_pconnect
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|app: admin Initialized
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|app: admin Function: login
20100402132151|127.0.0.1|__ERROR_WARNING|2010-04-02 13:21:51|No favicon FILE FOUND-> Line 354-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|get_css / file: $file
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|get_css / file: $file
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|get_css / file: $file
20100402132151|127.0.0.1|INCLUDE|2010-04-02 13:21:51|get_js / file: $file
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|app: admin Terminated
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|_dbclose CLOSED
20100402132151|127.0.0.1|INFO|2010-04-02 13:21:51|pasteboard.Complete (1.149 seconds)
20100402132151|127.0.0.1|__ERROR_WARNING|2010-04-02 13:21:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|pasteboard.Started
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: useragents-config
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: dates-config
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: fopen-config
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: stopwords-config
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-database
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-useragent
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-hooks
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-sessions
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-cache
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-scaffolding
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-errors
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-uri
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|library: pb-logs
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_set_timezone: US/Pacific
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_sitewhoami: default Initialized
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_uri_segment: SEGMENT_PATH
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_useragent: Chrome 5.0.342.7
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_useragent: Mac OS X
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_init_session: Not Implemented
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_dbopen: mysql_pconnect
20100402132153|127.0.0.1|__ERROR_WARNING|2010-04-02 13:21:53|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100402132153|127.0.0.1|SQL|2010-04-02 13:21:53|SQL_logged from show_404, 43
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|get_css / file: $file
20100402132153|127.0.0.1|INCLUDE|2010-04-02 13:21:53|get_css / file: $file
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|_dbclose CLOSED
20100402132153|127.0.0.1|INFO|2010-04-02 13:21:53|pasteboard.Complete (0.982 seconds)
20100402132153|127.0.0.1|__ERROR_WARNING|2010-04-02 13:21:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|pasteboard.Started
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: useragents-config
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: dates-config
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: fopen-config
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: stopwords-config
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-database
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-useragent
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-hooks
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-sessions
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-cache
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-scaffolding
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-errors
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-uri
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-logs
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_set_timezone: US/Pacific
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_sitewhoami: default Initialized
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_uri_segment: SEGMENT_PATH
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_useragent: Chrome 5.0.342.7
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_useragent: Mac OS X
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_init_session: Not Implemented
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_dbopen: mysql_pconnect
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|app: admin Initialized
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|app: admin Function: login
20100402195522|127.0.0.1|__ERROR_WARNING|2010-04-02 19:55:22|No favicon FILE FOUND-> Line 354-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|get_css / file: $file
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|get_css / file: $file
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|get_css / file: $file
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|get_js / file: $file
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|app: admin Terminated
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_dbclose CLOSED
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|pasteboard.Complete (0.408 seconds)
20100402195522|127.0.0.1|__ERROR_WARNING|2010-04-02 19:55:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|pasteboard.Started
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: useragents-config
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: dates-config
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: fopen-config
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: stopwords-config
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-database
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-useragent
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-hooks
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-sessions
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-cache
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-scaffolding
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-errors
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-uri
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|library: pb-logs
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_set_timezone: US/Pacific
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_sitewhoami: default Initialized
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_uri_segment: SEGMENT_PATH
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_useragent: Chrome 5.0.342.7
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_useragent: Mac OS X
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_init_session: Not Implemented
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_dbopen: mysql_pconnect
20100402195522|127.0.0.1|__ERROR_WARNING|2010-04-02 19:55:22|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100402195522|127.0.0.1|SQL|2010-04-02 19:55:22|SQL_logged from show_404, 43
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|get_css / file: $file
20100402195522|127.0.0.1|INCLUDE|2010-04-02 19:55:22|get_css / file: $file
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|_dbclose CLOSED
20100402195522|127.0.0.1|INFO|2010-04-02 19:55:22|pasteboard.Complete (0.844 seconds)
20100402195522|127.0.0.1|__ERROR_WARNING|2010-04-02 19:55:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100402222824|::1|INFO|2010-04-02 22:28:23|pasteboard.Started
20100402222824|::1|INFO|2010-04-02 22:28:23|pasteboard.Started
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: useragents-config
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: dates-config
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: fopen-config
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: stopwords-config
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-database
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-useragent
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-hooks
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-sessions
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-cache
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-scaffolding
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-errors
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-uri
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-logs
20100402222824|::1|INFO|2010-04-02 22:28:23|_set_timezone: US/Pacific
20100402222824|::1|INFO|2010-04-02 22:28:23|_sitewhoami: default Initialized
20100402222824|::1|INFO|2010-04-02 22:28:23|_uri_segment: SECONDARY PAGE FOUND w/ID: closelabel.gif
20100402222824|::1|INFO|2010-04-02 22:28:23|_uri_segment: SEGMENT_PATH
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: useragents-config
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: dates-config
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: fopen-config
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: stopwords-config
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-database
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-useragent
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-hooks
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-sessions
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-cache
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-scaffolding
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-errors
20100402222824|::1|INFO|2010-04-02 22:28:23|_useragent: Chrome 5.0.342.7
20100402222824|::1|INFO|2010-04-02 22:28:23|_useragent: Mac OS X
20100402222824|::1|INFO|2010-04-02 22:28:23|_init_session: Not Implemented
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-uri
20100402222824|::1|INCLUDE|2010-04-02 22:28:23|library: pb-logs
20100402222824|::1|INFO|2010-04-02 22:28:23|_set_timezone: US/Pacific
20100402222824|::1|INFO|2010-04-02 22:28:23|_sitewhoami: default Initialized
20100402222824|::1|INFO|2010-04-02 22:28:23|_uri_segment: SECONDARY PAGE FOUND w/ID: loading.gif
20100402222824|::1|INFO|2010-04-02 22:28:23|_uri_segment: SEGMENT_PATH
20100402222824|::1|INFO|2010-04-02 22:28:23|_useragent: Chrome 5.0.342.7
20100402222824|::1|INFO|2010-04-02 22:28:23|_useragent: Mac OS X
20100402222824|::1|INFO|2010-04-02 22:28:23|_init_session: Not Implemented
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100402222824|::1|INFO|2010-04-02 22:28:23|_dbopen: mysql_pconnect
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|File Not Found: qn_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100402222824|::1|INFO|2010-04-02 22:28:23|_dbopen: mysql_pconnect
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|File Not Found: qn_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100402222824|::1|SQL|2010-04-02 22:28:23|SQL_logged from show_404, 43
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100402222824|::1|SQL|2010-04-02 22:28:23|SQL_logged from show_404, 43
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100402222824|::1|INFO|2010-04-02 22:28:23|_dbclose CLOSED
20100402222824|::1|INFO|2010-04-02 22:28:23|pasteboard.Complete (33.922 seconds)
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100402222824|::1|INFO|2010-04-02 22:28:23|_dbclose CLOSED
20100402222824|::1|INFO|2010-04-02 22:28:23|pasteboard.Complete (33.957 seconds)
20100402222824|::1|__ERROR_WARNING|2010-04-02 22:28:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
