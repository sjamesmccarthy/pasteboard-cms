20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|pasteboard.Started
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: useragents-config
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: dates-config
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: fopen-config
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: stopwords-config
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-database
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-useragent
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-hooks
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-sessions
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-cache
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-scaffolding
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-errors
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-uri
20101218092213|127.0.0.1|INCLUDE|2010-12-18 09:22:13|library: pb-logs
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_set_timezone: US/Pacific
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_sitewhoami: default Initialized
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_uri_segment: QUERY_STRING
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_useragent:  
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_useragent: 
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_init_session: Not Implemented
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_dbopen: mysql_pconnect
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218092213|127.0.0.1|SQL|2010-12-18 09:22:13|SQL_logged from show_404, 43
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|_dbclose CLOSED
20101218092213|127.0.0.1|INFO|2010-12-18 09:22:13|pasteboard.Complete (3.442 seconds)
20101218092213|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|pasteboard.Started
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: useragents-config
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: dates-config
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: fopen-config
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: stopwords-config
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-database
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-useragent
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-hooks
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-sessions
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-cache
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-scaffolding
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-errors
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-uri
20101218092254|127.0.0.1|INCLUDE|2010-12-18 09:22:54|library: pb-logs
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_set_timezone: US/Pacific
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_sitewhoami: default Initialized
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_uri_segment: QUERY_STRING
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_useragent:  
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_useragent: 
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_init_session: Not Implemented
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_dbopen: mysql_pconnect
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218092254|127.0.0.1|SQL|2010-12-18 09:22:54|SQL_logged from show_404, 43
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|_dbclose CLOSED
20101218092254|127.0.0.1|INFO|2010-12-18 09:22:54|pasteboard.Complete (1.292 seconds)
20101218092254|127.0.0.1|__ERROR_WARNING|2010-12-18 09:22:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|pasteboard.Started
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: useragents-config
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: dates-config
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: fopen-config
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: stopwords-config
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-database
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-useragent
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-hooks
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-sessions
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-cache
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-scaffolding
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-errors
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-uri
20101218092622|127.0.0.1|INCLUDE|2010-12-18 09:26:22|library: pb-logs
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_set_timezone: US/Pacific
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_sitewhoami: default Initialized
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_uri_segment: QUERY_STRING
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_useragent:  
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_useragent: 
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_init_session: Not Implemented
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_dbopen: mysql_pconnect
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218092622|127.0.0.1|SQL|2010-12-18 09:26:22|SQL_logged from show_404, 43
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|_dbclose CLOSED
20101218092622|127.0.0.1|INFO|2010-12-18 09:26:22|pasteboard.Complete (1.75 seconds)
20101218092622|127.0.0.1|__ERROR_WARNING|2010-12-18 09:26:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|pasteboard.Started
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: useragents-config
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: dates-config
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: fopen-config
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: stopwords-config
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-database
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-useragent
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-hooks
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-sessions
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-cache
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-scaffolding
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-errors
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-uri
20101218093217|127.0.0.1|INCLUDE|2010-12-18 09:32:17|library: pb-logs
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_set_timezone: US/Pacific
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_sitewhoami: default Initialized
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_uri_segment: QUERY_STRING
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_useragent:  
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_useragent: 
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_init_session: Not Implemented
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_dbopen: mysql_pconnect
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218093217|127.0.0.1|SQL|2010-12-18 09:32:17|SQL_logged from show_404, 43
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|_dbclose CLOSED
20101218093217|127.0.0.1|INFO|2010-12-18 09:32:17|pasteboard.Complete (3.122 seconds)
20101218093217|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|pasteboard.Started
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: useragents-config
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: dates-config
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: fopen-config
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: stopwords-config
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-database
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-useragent
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-hooks
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-sessions
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-cache
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-scaffolding
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-errors
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-uri
20101218093236|127.0.0.1|INCLUDE|2010-12-18 09:32:36|library: pb-logs
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_set_timezone: US/Pacific
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_sitewhoami: default Initialized
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_uri_segment: QUERY_STRING
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_useragent:  
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_useragent: 
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_init_session: Not Implemented
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_dbopen: mysql_pconnect
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218093236|127.0.0.1|SQL|2010-12-18 09:32:36|SQL_logged from show_404, 43
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|_dbclose CLOSED
20101218093236|127.0.0.1|INFO|2010-12-18 09:32:36|pasteboard.Complete (0.302 seconds)
20101218093236|127.0.0.1|__ERROR_WARNING|2010-12-18 09:32:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|pasteboard.Started
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: useragents-config
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: dates-config
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: fopen-config
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: stopwords-config
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-database
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-useragent
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-hooks
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-sessions
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-cache
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-scaffolding
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-errors
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-uri
20101218093913|127.0.0.1|INCLUDE|2010-12-18 09:39:13|library: pb-logs
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_set_timezone: US/Pacific
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_sitewhoami: default Initialized
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_uri_segment: QUERY_STRING
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_useragent:  
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_useragent: 
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_init_session: Not Implemented
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_dbopen: mysql_pconnect
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218093913|127.0.0.1|SQL|2010-12-18 09:39:13|SQL_logged from show_404, 43
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|_dbclose CLOSED
20101218093913|127.0.0.1|INFO|2010-12-18 09:39:13|pasteboard.Complete (2.256 seconds)
20101218093913|127.0.0.1|__ERROR_WARNING|2010-12-18 09:39:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|pasteboard.Started
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: useragents-config
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: dates-config
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: fopen-config
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: stopwords-config
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-database
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-useragent
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-hooks
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-sessions
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-cache
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-scaffolding
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-errors
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-uri
20101218094020|127.0.0.1|INCLUDE|2010-12-18 09:40:20|library: pb-logs
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_set_timezone: US/Pacific
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_sitewhoami: default Initialized
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_uri_segment: QUERY_STRING
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_useragent:  
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_useragent: 
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_init_session: Not Implemented
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_dbopen: mysql_pconnect
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218094020|127.0.0.1|SQL|2010-12-18 09:40:20|SQL_logged from show_404, 43
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|_dbclose CLOSED
20101218094020|127.0.0.1|INFO|2010-12-18 09:40:20|pasteboard.Complete (1.543 seconds)
20101218094020|127.0.0.1|__ERROR_WARNING|2010-12-18 09:40:20|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|pasteboard.Started
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: useragents-config
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: dates-config
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: fopen-config
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: stopwords-config
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-database
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-useragent
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-hooks
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-sessions
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-cache
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-scaffolding
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-errors
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-uri
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-logs
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_set_timezone: US/Pacific
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_sitewhoami: default Initialized
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_uri_segment: QUERY_STRING
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_useragent:  
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_useragent: 
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_init_session: Not Implemented
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|pasteboard.Started
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: useragents-config
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: dates-config
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: fopen-config
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: stopwords-config
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-database
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-useragent
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-hooks
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-sessions
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-cache
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-scaffolding
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-errors
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-uri
20101218094212|127.0.0.1|INCLUDE|2010-12-18 09:42:12|library: pb-logs
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_set_timezone: US/Pacific
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_sitewhoami: default Initialized
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_uri_segment: QUERY_STRING
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_useragent:  
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_useragent: 
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_init_session: Not Implemented
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_dbopen: mysql_pconnect
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218094212|127.0.0.1|SQL|2010-12-18 09:42:12|SQL_logged from show_404, 43
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_dbclose CLOSED
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|pasteboard.Complete (1.521 seconds)
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_dbopen: mysql_pconnect
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101218094212|127.0.0.1|SQL|2010-12-18 09:42:12|SQL_logged from show_404, 43
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|_dbclose CLOSED
20101218094212|127.0.0.1|INFO|2010-12-18 09:42:12|pasteboard.Complete (1.53 seconds)
20101218094212|127.0.0.1|__ERROR_WARNING|2010-12-18 09:42:12|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
