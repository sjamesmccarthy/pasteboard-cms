20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|pasteboard.Started
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: useragents-config
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: dates-config
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|pasteboard.Started
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: fopen-config
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: useragents-config
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: stopwords-config
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: dates-config
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-database
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: fopen-config
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-useragent
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: stopwords-config
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-hooks
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-database
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-sessions
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-useragent
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-cache
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-hooks
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-scaffolding
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-sessions
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-errors
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-uri
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-logs
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_set_timezone: US/Pacific
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-cache
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-scaffolding
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-errors
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_sitewhoami: default Initialized
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-uri
20100526193000|127.0.0.1|INCLUDE|2010-05-26 19:29:59|library: pb-logs
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_set_timezone: US/Pacific
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_sitewhoami: default Initialized
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_uri_segment: QUERY_STRING
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_uri_segment: QUERY_STRING
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_useragent:  
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_useragent: 
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_init_session: Not Implemented
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_useragent:  
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_useragent: 
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_init_session: Not Implemented
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|pasteboard.Started
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: useragents-config
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: dates-config
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: fopen-config
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: stopwords-config
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-database
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-useragent
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-hooks
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-sessions
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-cache
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-scaffolding
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-errors
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-uri
20100526193020|127.0.0.1|INCLUDE|2010-05-26 19:30:20|library: pb-logs
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_set_timezone: US/Pacific
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_sitewhoami: default Initialized
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_uri_segment: QUERY_STRING
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_useragent:  
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_useragent: 
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_init_session: Not Implemented
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_dbopen: mysql_pconnect
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193000|127.0.0.1|SQL|2010-05-26 19:29:59|SQL_logged from show_404, 43
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_dbopen: mysql_pconnect
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193000|127.0.0.1|SQL|2010-05-26 19:29:59|SQL_logged from show_404, 43
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_dbclose CLOSED
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|_dbclose CLOSED
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|pasteboard.Complete (32.383 seconds)
20100526193000|127.0.0.1|INFO|2010-05-26 19:29:59|pasteboard.Complete (32.383 seconds)
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526193000|127.0.0.1|__ERROR_WARNING|2010-05-26 19:29:59|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|pasteboard.Started
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: useragents-config
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: dates-config
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: fopen-config
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: stopwords-config
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-database
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-useragent
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-hooks
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-sessions
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-cache
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-scaffolding
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-errors
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-uri
20100526193032|127.0.0.1|INCLUDE|2010-05-26 19:30:32|library: pb-logs
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_set_timezone: US/Pacific
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_sitewhoami: default Initialized
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_uri_segment: QUERY_STRING
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_useragent:  
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_useragent: 
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_init_session: Not Implemented
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|pasteboard.Started
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: useragents-config
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: dates-config
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: fopen-config
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: stopwords-config
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-database
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-useragent
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-hooks
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-sessions
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-cache
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-scaffolding
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-errors
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-uri
20100526193033|127.0.0.1|INCLUDE|2010-05-26 19:30:33|library: pb-logs
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_set_timezone: US/Pacific
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_sitewhoami: default Initialized
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_uri_segment: QUERY_STRING
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_useragent:  
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_useragent: 
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_init_session: Not Implemented
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_dbopen: mysql_pconnect
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193020|127.0.0.1|SQL|2010-05-26 19:30:20|SQL_logged from show_404, 43
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|_dbclose CLOSED
20100526193020|127.0.0.1|INFO|2010-05-26 19:30:20|pasteboard.Complete (30.147 seconds)
20100526193020|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:20|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|pasteboard.Started
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: useragents-config
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: dates-config
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: fopen-config
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: stopwords-config
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-database
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-useragent
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-hooks
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-sessions
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-cache
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-scaffolding
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-errors
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-uri
20100526193054|127.0.0.1|INCLUDE|2010-05-26 19:30:54|library: pb-logs
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_set_timezone: US/Pacific
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_sitewhoami: default Initialized
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_uri_segment: QUERY_STRING
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_useragent:  
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_useragent: 
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_init_session: Not Implemented
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_dbopen: mysql_pconnect
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193032|127.0.0.1|SQL|2010-05-26 19:30:32|SQL_logged from show_404, 43
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|_dbclose CLOSED
20100526193032|127.0.0.1|INFO|2010-05-26 19:30:32|pasteboard.Complete (30.44 seconds)
20100526193032|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:32|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_dbopen: mysql_pconnect
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193033|127.0.0.1|SQL|2010-05-26 19:30:33|SQL_logged from show_404, 43
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|_dbclose CLOSED
20100526193033|127.0.0.1|INFO|2010-05-26 19:30:33|pasteboard.Complete (31.141 seconds)
20100526193033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:33|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_dbopen: mysql_pconnect
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193054|127.0.0.1|SQL|2010-05-26 19:30:54|SQL_logged from show_404, 43
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|_dbclose CLOSED
20100526193054|127.0.0.1|INFO|2010-05-26 19:30:54|pasteboard.Complete (30.283 seconds)
20100526193054|127.0.0.1|__ERROR_WARNING|2010-05-26 19:30:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|pasteboard.Started
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: useragents-config
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: dates-config
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: fopen-config
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: stopwords-config
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-database
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-useragent
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-hooks
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-sessions
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-cache
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-scaffolding
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-errors
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-uri
20100526193236|127.0.0.1|INCLUDE|2010-05-26 19:32:36|library: pb-logs
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_set_timezone: US/Pacific
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_sitewhoami: default Initialized
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_uri_segment: QUERY_STRING
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_useragent:  
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_useragent: 
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_init_session: Not Implemented
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_dbopen: mysql_pconnect
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193236|127.0.0.1|SQL|2010-05-26 19:32:36|SQL_logged from show_404, 43
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|_dbclose CLOSED
20100526193236|127.0.0.1|INFO|2010-05-26 19:32:36|pasteboard.Complete (30.999 seconds)
20100526193236|127.0.0.1|__ERROR_WARNING|2010-05-26 19:32:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|pasteboard.Started
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: useragents-config
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: dates-config
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: fopen-config
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: stopwords-config
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-database
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-useragent
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-hooks
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-sessions
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-cache
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-scaffolding
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-errors
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-uri
20100526193310|127.0.0.1|INCLUDE|2010-05-26 19:33:10|library: pb-logs
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_set_timezone: US/Pacific
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_sitewhoami: default Initialized
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_uri_segment: QUERY_STRING
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_useragent:  
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_useragent: 
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_init_session: Not Implemented
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|pasteboard.Started
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: useragents-config
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: dates-config
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: fopen-config
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: stopwords-config
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-database
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-useragent
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-hooks
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-sessions
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-cache
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-scaffolding
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-errors
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-uri
20100526193331|127.0.0.1|INCLUDE|2010-05-26 19:33:31|library: pb-logs
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_set_timezone: US/Pacific
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_sitewhoami: default Initialized
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_uri_segment: QUERY_STRING
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_useragent:  
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_useragent: 
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_init_session: Not Implemented
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_dbopen: mysql_pconnect
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193310|127.0.0.1|SQL|2010-05-26 19:33:10|SQL_logged from show_404, 43
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|_dbclose CLOSED
20100526193310|127.0.0.1|INFO|2010-05-26 19:33:10|pasteboard.Complete (30.787 seconds)
20100526193310|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_dbopen: mysql_pconnect
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526193331|127.0.0.1|SQL|2010-05-26 19:33:31|SQL_logged from show_404, 43
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|_dbclose CLOSED
20100526193331|127.0.0.1|INFO|2010-05-26 19:33:31|pasteboard.Complete (30.574 seconds)
20100526193331|127.0.0.1|__ERROR_WARNING|2010-05-26 19:33:31|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|pasteboard.Started
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: useragents-config
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: dates-config
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: fopen-config
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: stopwords-config
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-database
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-useragent
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-hooks
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-sessions
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-cache
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-scaffolding
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-errors
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-uri
20100526194033|127.0.0.1|INCLUDE|2010-05-26 19:40:33|library: pb-logs
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_set_timezone: US/Pacific
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_sitewhoami: default Initialized
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_uri_segment: QUERY_STRING
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_useragent:  
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_useragent: 
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_init_session: Not Implemented
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_dbopen: mysql_pconnect
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526194033|127.0.0.1|SQL|2010-05-26 19:40:33|SQL_logged from show_404, 43
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|_dbclose CLOSED
20100526194033|127.0.0.1|INFO|2010-05-26 19:40:33|pasteboard.Complete (30.399 seconds)
20100526194033|127.0.0.1|__ERROR_WARNING|2010-05-26 19:40:33|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|pasteboard.Started
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: useragents-config
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: dates-config
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: fopen-config
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: stopwords-config
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-database
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-useragent
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-hooks
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-sessions
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-cache
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-scaffolding
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-errors
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-uri
20100526195104|127.0.0.1|INCLUDE|2010-05-26 19:51:04|library: pb-logs
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_set_timezone: US/Pacific
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_sitewhoami: default Initialized
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_uri_segment: QUERY_STRING
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_useragent:  
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_useragent: 
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_init_session: Not Implemented
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_dbopen: mysql_pconnect
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526195104|127.0.0.1|SQL|2010-05-26 19:51:04|SQL_logged from show_404, 43
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|_dbclose CLOSED
20100526195104|127.0.0.1|INFO|2010-05-26 19:51:04|pasteboard.Complete (30.552 seconds)
20100526195104|127.0.0.1|__ERROR_WARNING|2010-05-26 19:51:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|pasteboard.Started
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: useragents-config
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: dates-config
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: fopen-config
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: stopwords-config
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-database
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-useragent
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-hooks
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-sessions
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-cache
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-scaffolding
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-errors
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-uri
20100526200051|127.0.0.1|INCLUDE|2010-05-26 20:00:51|library: pb-logs
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_set_timezone: US/Pacific
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_sitewhoami: default Initialized
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_uri_segment: QUERY_STRING
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_useragent:  
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_useragent: 
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_init_session: Not Implemented
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_dbopen: mysql_pconnect
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526200051|127.0.0.1|SQL|2010-05-26 20:00:51|SQL_logged from show_404, 43
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|_dbclose CLOSED
20100526200051|127.0.0.1|INFO|2010-05-26 20:00:51|pasteboard.Complete (31.025 seconds)
20100526200051|127.0.0.1|__ERROR_WARNING|2010-05-26 20:00:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|pasteboard.Started
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: useragents-config
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: dates-config
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: fopen-config
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: stopwords-config
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-database
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-useragent
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-hooks
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-sessions
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-cache
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-scaffolding
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-errors
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-uri
20100526200125|127.0.0.1|INCLUDE|2010-05-26 20:01:25|library: pb-logs
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_set_timezone: US/Pacific
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_sitewhoami: default Initialized
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_uri_segment: QUERY_STRING
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_useragent:  
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_useragent: 
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_init_session: Not Implemented
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|pasteboard.Started
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: useragents-config
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: dates-config
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: fopen-config
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: stopwords-config
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-database
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-useragent
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-hooks
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-sessions
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-cache
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-scaffolding
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-errors
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-uri
20100526200135|127.0.0.1|INCLUDE|2010-05-26 20:01:35|library: pb-logs
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_set_timezone: US/Pacific
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_sitewhoami: default Initialized
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_uri_segment: QUERY_STRING
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_useragent:  
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_useragent: 
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_init_session: Not Implemented
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_dbopen: mysql_pconnect
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526200125|127.0.0.1|SQL|2010-05-26 20:01:25|SQL_logged from show_404, 43
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|_dbclose CLOSED
20100526200125|127.0.0.1|INFO|2010-05-26 20:01:25|pasteboard.Complete (30.572 seconds)
20100526200125|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:25|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_dbopen: mysql_pconnect
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526200135|127.0.0.1|SQL|2010-05-26 20:01:35|SQL_logged from show_404, 43
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|_dbclose CLOSED
20100526200135|127.0.0.1|INFO|2010-05-26 20:01:35|pasteboard.Complete (30.605 seconds)
20100526200135|127.0.0.1|__ERROR_WARNING|2010-05-26 20:01:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|pasteboard.Started
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: useragents-config
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: dates-config
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: fopen-config
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: stopwords-config
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-database
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-useragent
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-hooks
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-sessions
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-cache
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-scaffolding
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-errors
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-uri
20100526200341|127.0.0.1|INCLUDE|2010-05-26 20:03:41|library: pb-logs
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_set_timezone: US/Pacific
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_sitewhoami: default Initialized
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_uri_segment: QUERY_STRING
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_useragent:  
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_useragent: 
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_init_session: Not Implemented
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|pasteboard.Started
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: useragents-config
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: dates-config
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: fopen-config
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: stopwords-config
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-database
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-useragent
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-hooks
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-sessions
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-cache
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-scaffolding
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-errors
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-uri
20100526200402|127.0.0.1|INCLUDE|2010-05-26 20:04:02|library: pb-logs
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_set_timezone: US/Pacific
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_sitewhoami: default Initialized
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_uri_segment: QUERY_STRING
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_useragent:  
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_useragent: 
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_init_session: Not Implemented
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_dbopen: mysql_pconnect
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526200341|127.0.0.1|SQL|2010-05-26 20:03:41|SQL_logged from show_404, 43
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|_dbclose CLOSED
20100526200341|127.0.0.1|INFO|2010-05-26 20:03:41|pasteboard.Complete (30.734 seconds)
20100526200341|127.0.0.1|__ERROR_WARNING|2010-05-26 20:03:41|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_dbopen: mysql_pconnect
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526200402|127.0.0.1|SQL|2010-05-26 20:04:02|SQL_logged from show_404, 43
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|_dbclose CLOSED
20100526200402|127.0.0.1|INFO|2010-05-26 20:04:02|pasteboard.Complete (30.823 seconds)
20100526200402|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|pasteboard.Started
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: useragents-config
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: dates-config
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: fopen-config
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: stopwords-config
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-database
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-useragent
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-hooks
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-sessions
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-cache
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-scaffolding
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-errors
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-uri
20100526200447|127.0.0.1|INCLUDE|2010-05-26 20:04:47|library: pb-logs
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_set_timezone: US/Pacific
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_sitewhoami: default Initialized
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_uri_segment: QUERY_STRING
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_useragent:  
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_useragent: 
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_init_session: Not Implemented
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_dbopen: mysql_pconnect
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526200447|127.0.0.1|SQL|2010-05-26 20:04:47|SQL_logged from show_404, 43
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|_dbclose CLOSED
20100526200447|127.0.0.1|INFO|2010-05-26 20:04:47|pasteboard.Complete (30.937 seconds)
20100526200447|127.0.0.1|__ERROR_WARNING|2010-05-26 20:04:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|pasteboard.Started
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: useragents-config
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: dates-config
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: fopen-config
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: stopwords-config
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-database
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-useragent
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-hooks
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-sessions
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-cache
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-scaffolding
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-errors
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-uri
20100526200542|127.0.0.1|INCLUDE|2010-05-26 20:05:42|library: pb-logs
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_set_timezone: US/Pacific
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_sitewhoami: default Initialized
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_uri_segment: QUERY_STRING
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_useragent:  
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_useragent: 
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_init_session: Not Implemented
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_dbopen: mysql_pconnect
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526200542|127.0.0.1|SQL|2010-05-26 20:05:42|SQL_logged from show_404, 43
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|_dbclose CLOSED
20100526200542|127.0.0.1|INFO|2010-05-26 20:05:42|pasteboard.Complete (30.87 seconds)
20100526200542|127.0.0.1|__ERROR_WARNING|2010-05-26 20:05:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|pasteboard.Started
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: useragents-config
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: dates-config
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: fopen-config
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: stopwords-config
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-database
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-useragent
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-hooks
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-sessions
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-cache
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-scaffolding
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-errors
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-uri
20100526201205|127.0.0.1|INCLUDE|2010-05-26 20:12:05|library: pb-logs
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_set_timezone: US/Pacific
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_sitewhoami: default Initialized
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_uri_segment: QUERY_STRING
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_useragent:  
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_useragent: 
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_init_session: Not Implemented
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_dbopen: mysql_pconnect
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526201205|127.0.0.1|SQL|2010-05-26 20:12:05|SQL_logged from show_404, 43
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|_dbclose CLOSED
20100526201205|127.0.0.1|INFO|2010-05-26 20:12:05|pasteboard.Complete (30.948 seconds)
20100526201205|127.0.0.1|__ERROR_WARNING|2010-05-26 20:12:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|pasteboard.Started
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: useragents-config
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: dates-config
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: fopen-config
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: stopwords-config
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-database
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-useragent
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-hooks
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-sessions
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-cache
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-scaffolding
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-errors
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-uri
20100526202236|127.0.0.1|INCLUDE|2010-05-26 20:22:36|library: pb-logs
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_set_timezone: US/Pacific
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_sitewhoami: default Initialized
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_uri_segment: QUERY_STRING
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_useragent:  
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_useragent: 
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_init_session: Not Implemented
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_dbopen: mysql_pconnect
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526202236|127.0.0.1|SQL|2010-05-26 20:22:36|SQL_logged from show_404, 43
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|_dbclose CLOSED
20100526202236|127.0.0.1|INFO|2010-05-26 20:22:36|pasteboard.Complete (30.104 seconds)
20100526202236|127.0.0.1|__ERROR_WARNING|2010-05-26 20:22:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|pasteboard.Started
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: useragents-config
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: dates-config
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: fopen-config
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: stopwords-config
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-database
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-useragent
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-hooks
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-sessions
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-cache
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-scaffolding
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-errors
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-uri
20100526203156|127.0.0.1|INCLUDE|2010-05-26 20:31:56|library: pb-logs
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_set_timezone: US/Pacific
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_sitewhoami: default Initialized
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_uri_segment: QUERY_STRING
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_useragent:  
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_useragent: 
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_init_session: Not Implemented
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_dbopen: mysql_pconnect
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526203156|127.0.0.1|SQL|2010-05-26 20:31:56|SQL_logged from show_404, 43
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|_dbclose CLOSED
20100526203156|127.0.0.1|INFO|2010-05-26 20:31:56|pasteboard.Complete (31.03 seconds)
20100526203156|127.0.0.1|__ERROR_WARNING|2010-05-26 20:31:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|pasteboard.Started
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: useragents-config
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: dates-config
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: fopen-config
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: stopwords-config
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-database
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-useragent
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-hooks
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-sessions
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-cache
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-scaffolding
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-errors
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-uri
20100526203306|127.0.0.1|INCLUDE|2010-05-26 20:33:06|library: pb-logs
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_set_timezone: US/Pacific
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_sitewhoami: default Initialized
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_uri_segment: QUERY_STRING
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_useragent:  
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_useragent: 
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_init_session: Not Implemented
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_dbopen: mysql_pconnect
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526203306|127.0.0.1|SQL|2010-05-26 20:33:06|SQL_logged from show_404, 43
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|_dbclose CLOSED
20100526203306|127.0.0.1|INFO|2010-05-26 20:33:06|pasteboard.Complete (30.532 seconds)
20100526203306|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:06|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|pasteboard.Started
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: useragents-config
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: dates-config
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: fopen-config
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: stopwords-config
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-database
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-useragent
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-hooks
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-sessions
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-cache
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-scaffolding
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-errors
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-uri
20100526203358|127.0.0.1|INCLUDE|2010-05-26 20:33:58|library: pb-logs
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_set_timezone: US/Pacific
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_sitewhoami: default Initialized
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_uri_segment: QUERY_STRING
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_useragent:  
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_useragent: 
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_init_session: Not Implemented
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_dbopen: mysql_pconnect
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526203358|127.0.0.1|SQL|2010-05-26 20:33:58|SQL_logged from show_404, 43
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|_dbclose CLOSED
20100526203358|127.0.0.1|INFO|2010-05-26 20:33:58|pasteboard.Complete (30.643 seconds)
20100526203358|127.0.0.1|__ERROR_WARNING|2010-05-26 20:33:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|pasteboard.Started
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: useragents-config
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: dates-config
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: fopen-config
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: stopwords-config
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-database
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-useragent
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-hooks
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-sessions
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-cache
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-scaffolding
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-errors
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-uri
20100526203648|127.0.0.1|INCLUDE|2010-05-26 20:36:48|library: pb-logs
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_set_timezone: US/Pacific
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_sitewhoami: default Initialized
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_uri_segment: QUERY_STRING
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_useragent:  
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_useragent: 
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_init_session: Not Implemented
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_dbopen: mysql_pconnect
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526203648|127.0.0.1|SQL|2010-05-26 20:36:48|SQL_logged from show_404, 43
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|_dbclose CLOSED
20100526203648|127.0.0.1|INFO|2010-05-26 20:36:48|pasteboard.Complete (31.02 seconds)
20100526203648|127.0.0.1|__ERROR_WARNING|2010-05-26 20:36:48|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|pasteboard.Started
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: useragents-config
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: dates-config
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: fopen-config
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: stopwords-config
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-database
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-useragent
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-hooks
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-sessions
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-cache
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-scaffolding
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-errors
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-uri
20100526203755|127.0.0.1|INCLUDE|2010-05-26 20:37:55|library: pb-logs
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_set_timezone: US/Pacific
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_sitewhoami: default Initialized
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_uri_segment: QUERY_STRING
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_useragent:  
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_useragent: 
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_init_session: Not Implemented
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|pasteboard.Started
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: useragents-config
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: dates-config
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: fopen-config
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: stopwords-config
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-database
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-useragent
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-hooks
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-sessions
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-cache
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-scaffolding
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-errors
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-uri
20100526203756|127.0.0.1|INCLUDE|2010-05-26 20:37:56|library: pb-logs
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_set_timezone: US/Pacific
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_sitewhoami: default Initialized
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_uri_segment: QUERY_STRING
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_useragent:  
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_useragent: 
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_init_session: Not Implemented
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_dbopen: mysql_pconnect
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526203755|127.0.0.1|SQL|2010-05-26 20:37:55|SQL_logged from show_404, 43
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|_dbclose CLOSED
20100526203755|127.0.0.1|INFO|2010-05-26 20:37:55|pasteboard.Complete (30.111 seconds)
20100526203755|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_dbopen: mysql_pconnect
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526203756|127.0.0.1|SQL|2010-05-26 20:37:56|SQL_logged from show_404, 43
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|_dbclose CLOSED
20100526203756|127.0.0.1|INFO|2010-05-26 20:37:56|pasteboard.Complete (30.088 seconds)
20100526203756|127.0.0.1|__ERROR_WARNING|2010-05-26 20:37:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|pasteboard.Started
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: useragents-config
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: dates-config
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: fopen-config
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: stopwords-config
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-database
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-useragent
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-hooks
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-sessions
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-cache
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-scaffolding
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-errors
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-uri
20100526203917|127.0.0.1|INCLUDE|2010-05-26 20:39:17|library: pb-logs
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_set_timezone: US/Pacific
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_sitewhoami: default Initialized
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_uri_segment: QUERY_STRING
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_useragent:  
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_useragent: 
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_init_session: Not Implemented
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_dbopen: mysql_pconnect
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526203917|127.0.0.1|SQL|2010-05-26 20:39:17|SQL_logged from show_404, 43
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|_dbclose CLOSED
20100526203917|127.0.0.1|INFO|2010-05-26 20:39:17|pasteboard.Complete (30.127 seconds)
20100526203917|127.0.0.1|__ERROR_WARNING|2010-05-26 20:39:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|pasteboard.Started
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: useragents-config
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: dates-config
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: fopen-config
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: stopwords-config
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-database
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-useragent
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-hooks
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-sessions
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-cache
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-scaffolding
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-errors
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-uri
20100526204337|127.0.0.1|INCLUDE|2010-05-26 20:43:37|library: pb-logs
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_set_timezone: US/Pacific
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_sitewhoami: default Initialized
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_uri_segment: QUERY_STRING
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_useragent:  
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_useragent: 
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_init_session: Not Implemented
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_dbopen: mysql_pconnect
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526204337|127.0.0.1|SQL|2010-05-26 20:43:37|SQL_logged from show_404, 43
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|_dbclose CLOSED
20100526204337|127.0.0.1|INFO|2010-05-26 20:43:37|pasteboard.Complete (30.16 seconds)
20100526204337|127.0.0.1|__ERROR_WARNING|2010-05-26 20:43:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|pasteboard.Started
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: useragents-config
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: dates-config
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: fopen-config
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: stopwords-config
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-database
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-useragent
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-hooks
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-sessions
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-cache
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-scaffolding
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-errors
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-uri
20100526205408|127.0.0.1|INCLUDE|2010-05-26 20:54:08|library: pb-logs
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_set_timezone: US/Pacific
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_sitewhoami: default Initialized
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_uri_segment: QUERY_STRING
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_useragent:  
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_useragent: 
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_init_session: Not Implemented
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_dbopen: mysql_pconnect
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526205408|127.0.0.1|SQL|2010-05-26 20:54:08|SQL_logged from show_404, 43
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|_dbclose CLOSED
20100526205408|127.0.0.1|INFO|2010-05-26 20:54:08|pasteboard.Complete (30.753 seconds)
20100526205408|127.0.0.1|__ERROR_WARNING|2010-05-26 20:54:08|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|pasteboard.Started
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: useragents-config
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: dates-config
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: fopen-config
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: stopwords-config
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-database
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-useragent
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-hooks
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-sessions
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-cache
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-scaffolding
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-errors
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-uri
20100526210227|127.0.0.1|INCLUDE|2010-05-26 21:02:27|library: pb-logs
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_set_timezone: US/Pacific
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_sitewhoami: default Initialized
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_uri_segment: QUERY_STRING
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_useragent:  
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_useragent: 
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_init_session: Not Implemented
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_dbopen: mysql_pconnect
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526210227|127.0.0.1|SQL|2010-05-26 21:02:27|SQL_logged from show_404, 43
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|_dbclose CLOSED
20100526210227|127.0.0.1|INFO|2010-05-26 21:02:27|pasteboard.Complete (31.045 seconds)
20100526210227|127.0.0.1|__ERROR_WARNING|2010-05-26 21:02:27|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|pasteboard.Started
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: useragents-config
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: dates-config
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: fopen-config
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: stopwords-config
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-database
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-useragent
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-hooks
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-sessions
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-cache
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-scaffolding
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-errors
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-uri
20100526210438|127.0.0.1|INCLUDE|2010-05-26 21:04:38|library: pb-logs
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_set_timezone: US/Pacific
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_sitewhoami: default Initialized
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_uri_segment: QUERY_STRING
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_useragent:  
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_useragent: 
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_init_session: Not Implemented
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_dbopen: mysql_pconnect
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526210438|127.0.0.1|SQL|2010-05-26 21:04:38|SQL_logged from show_404, 43
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|_dbclose CLOSED
20100526210438|127.0.0.1|INFO|2010-05-26 21:04:38|pasteboard.Complete (30.631 seconds)
20100526210438|127.0.0.1|__ERROR_WARNING|2010-05-26 21:04:38|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|pasteboard.Started
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: useragents-config
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: dates-config
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: fopen-config
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: stopwords-config
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-database
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-useragent
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-hooks
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-sessions
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-cache
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-scaffolding
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-errors
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-uri
20100526210738|127.0.0.1|INCLUDE|2010-05-26 21:07:38|library: pb-logs
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_set_timezone: US/Pacific
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_sitewhoami: default Initialized
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_uri_segment: QUERY_STRING
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_useragent:  
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_useragent: 
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_init_session: Not Implemented
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_dbopen: mysql_pconnect
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526210738|127.0.0.1|SQL|2010-05-26 21:07:38|SQL_logged from show_404, 43
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|_dbclose CLOSED
20100526210738|127.0.0.1|INFO|2010-05-26 21:07:38|pasteboard.Complete (30.76 seconds)
20100526210738|127.0.0.1|__ERROR_WARNING|2010-05-26 21:07:38|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|pasteboard.Started
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: useragents-config
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: dates-config
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: fopen-config
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: stopwords-config
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-database
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-useragent
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-hooks
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-sessions
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-cache
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-scaffolding
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-errors
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-uri
20100526211030|127.0.0.1|INCLUDE|2010-05-26 21:10:30|library: pb-logs
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_set_timezone: US/Pacific
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_sitewhoami: default Initialized
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_uri_segment: QUERY_STRING
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_useragent:  
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_useragent: 
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_init_session: Not Implemented
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_dbopen: mysql_pconnect
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526211030|127.0.0.1|SQL|2010-05-26 21:10:30|SQL_logged from show_404, 43
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|_dbclose CLOSED
20100526211030|127.0.0.1|INFO|2010-05-26 21:10:30|pasteboard.Complete (31.202 seconds)
20100526211030|127.0.0.1|__ERROR_WARNING|2010-05-26 21:10:30|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|pasteboard.Started
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: useragents-config
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: dates-config
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: fopen-config
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: stopwords-config
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-database
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-useragent
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-hooks
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-sessions
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-cache
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-scaffolding
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-errors
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-uri
20100526211142|127.0.0.1|INCLUDE|2010-05-26 21:11:42|library: pb-logs
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_set_timezone: US/Pacific
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_sitewhoami: default Initialized
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_uri_segment: QUERY_STRING
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_useragent:  
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_useragent: 
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_init_session: Not Implemented
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|pasteboard.Started
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: useragents-config
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: dates-config
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: fopen-config
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: stopwords-config
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-database
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-useragent
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-hooks
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-sessions
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-cache
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-scaffolding
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-errors
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-uri
20100526211154|127.0.0.1|INCLUDE|2010-05-26 21:11:53|library: pb-logs
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_set_timezone: US/Pacific
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_sitewhoami: default Initialized
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_uri_segment: QUERY_STRING
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_useragent:  
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_useragent: 
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_init_session: Not Implemented
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_dbopen: mysql_pconnect
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526211142|127.0.0.1|SQL|2010-05-26 21:11:42|SQL_logged from show_404, 43
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|_dbclose CLOSED
20100526211142|127.0.0.1|INFO|2010-05-26 21:11:42|pasteboard.Complete (31.111 seconds)
20100526211142|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_dbopen: mysql_pconnect
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526211154|127.0.0.1|SQL|2010-05-26 21:11:53|SQL_logged from show_404, 43
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|_dbclose CLOSED
20100526211154|127.0.0.1|INFO|2010-05-26 21:11:53|pasteboard.Complete (31.05 seconds)
20100526211154|127.0.0.1|__ERROR_WARNING|2010-05-26 21:11:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|pasteboard.Started
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: useragents-config
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: dates-config
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: fopen-config
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: stopwords-config
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-database
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-useragent
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-hooks
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-sessions
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-cache
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-scaffolding
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-errors
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-uri
20100526211245|127.0.0.1|INCLUDE|2010-05-26 21:12:45|library: pb-logs
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_set_timezone: US/Pacific
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_sitewhoami: default Initialized
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_uri_segment: QUERY_STRING
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_useragent:  
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_useragent: 
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_init_session: Not Implemented
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_dbopen: mysql_pconnect
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526211245|127.0.0.1|SQL|2010-05-26 21:12:45|SQL_logged from show_404, 43
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|_dbclose CLOSED
20100526211245|127.0.0.1|INFO|2010-05-26 21:12:45|pasteboard.Complete (30.159 seconds)
20100526211245|127.0.0.1|__ERROR_WARNING|2010-05-26 21:12:45|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|pasteboard.Started
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: useragents-config
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: dates-config
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: fopen-config
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: stopwords-config
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-database
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-useragent
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-hooks
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-sessions
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-cache
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-scaffolding
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-errors
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-uri
20100526211509|127.0.0.1|INCLUDE|2010-05-26 21:15:09|library: pb-logs
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_set_timezone: US/Pacific
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_sitewhoami: default Initialized
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_uri_segment: QUERY_STRING
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_useragent:  
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_useragent: 
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_init_session: Not Implemented
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_dbopen: mysql_pconnect
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526211509|127.0.0.1|SQL|2010-05-26 21:15:09|SQL_logged from show_404, 43
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|_dbclose CLOSED
20100526211509|127.0.0.1|INFO|2010-05-26 21:15:09|pasteboard.Complete (30.266 seconds)
20100526211509|127.0.0.1|__ERROR_WARNING|2010-05-26 21:15:09|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|pasteboard.Started
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: useragents-config
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: dates-config
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: fopen-config
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: stopwords-config
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-database
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-useragent
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-hooks
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-sessions
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-cache
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-scaffolding
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-errors
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-uri
20100526212539|127.0.0.1|INCLUDE|2010-05-26 21:25:39|library: pb-logs
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_set_timezone: US/Pacific
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_sitewhoami: default Initialized
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_uri_segment: QUERY_STRING
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_useragent:  
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_useragent: 
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_init_session: Not Implemented
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_dbopen: mysql_pconnect
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526212539|127.0.0.1|SQL|2010-05-26 21:25:39|SQL_logged from show_404, 43
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|_dbclose CLOSED
20100526212539|127.0.0.1|INFO|2010-05-26 21:25:39|pasteboard.Complete (30.87 seconds)
20100526212539|127.0.0.1|__ERROR_WARNING|2010-05-26 21:25:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|pasteboard.Started
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: useragents-config
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: dates-config
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: fopen-config
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: stopwords-config
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-database
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-useragent
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-hooks
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-sessions
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-cache
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-scaffolding
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-errors
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-uri
20100526213259|127.0.0.1|INCLUDE|2010-05-26 21:32:59|library: pb-logs
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_set_timezone: US/Pacific
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_sitewhoami: default Initialized
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_uri_segment: QUERY_STRING
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_useragent:  
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_useragent: 
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_init_session: Not Implemented
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_dbopen: mysql_pconnect
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526213259|127.0.0.1|SQL|2010-05-26 21:32:59|SQL_logged from show_404, 43
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|_dbclose CLOSED
20100526213259|127.0.0.1|INFO|2010-05-26 21:32:59|pasteboard.Complete (30.473 seconds)
20100526213259|127.0.0.1|__ERROR_WARNING|2010-05-26 21:32:59|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|pasteboard.Started
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: useragents-config
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: dates-config
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: fopen-config
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: stopwords-config
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-database
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-useragent
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-hooks
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-sessions
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-cache
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-scaffolding
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-errors
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-uri
20100526213610|127.0.0.1|INCLUDE|2010-05-26 21:36:10|library: pb-logs
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_set_timezone: US/Pacific
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_sitewhoami: default Initialized
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_uri_segment: QUERY_STRING
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_useragent:  
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_useragent: 
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_init_session: Not Implemented
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_dbopen: mysql_pconnect
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100526213610|127.0.0.1|SQL|2010-05-26 21:36:10|SQL_logged from show_404, 43
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|_dbclose CLOSED
20100526213610|127.0.0.1|INFO|2010-05-26 21:36:10|pasteboard.Complete (30.669 seconds)
20100526213610|127.0.0.1|__ERROR_WARNING|2010-05-26 21:36:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
