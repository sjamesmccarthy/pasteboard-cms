20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|pasteboard.Started
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: useragents-config
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: dates-config
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: fopen-config
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: stopwords-config
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-database
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-useragent
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-hooks
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-sessions
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-cache
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-scaffolding
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-errors
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-uri
20101027125715|127.0.0.1|INCLUDE|2010-10-27 12:57:14|library: pb-logs
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_set_timezone: US/Pacific
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_sitewhoami: default Initialized
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_uri_segment: QUERY_STRING
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_useragent:  
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_useragent: 
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_init_session: Not Implemented
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_dbopen: mysql_pconnect
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101027125715|127.0.0.1|SQL|2010-10-27 12:57:14|SQL_logged from show_404, 43
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|_dbclose CLOSED
20101027125715|127.0.0.1|INFO|2010-10-27 12:57:14|pasteboard.Complete (1.613 seconds)
20101027125715|127.0.0.1|__ERROR_WARNING|2010-10-27 12:57:14|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|pasteboard.Started
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: useragents-config
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: dates-config
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: fopen-config
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: stopwords-config
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-database
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-useragent
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-hooks
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-sessions
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-cache
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-scaffolding
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-errors
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-uri
20101027125800|127.0.0.1|INCLUDE|2010-10-27 12:58:00|library: pb-logs
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_set_timezone: US/Pacific
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_sitewhoami: default Initialized
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_uri_segment: QUERY_STRING
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_useragent:  
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_useragent: 
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_init_session: Not Implemented
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_dbopen: mysql_pconnect
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101027125800|127.0.0.1|SQL|2010-10-27 12:58:00|SQL_logged from show_404, 43
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|_dbclose CLOSED
20101027125800|127.0.0.1|INFO|2010-10-27 12:58:00|pasteboard.Complete (0.3 seconds)
20101027125800|127.0.0.1|__ERROR_WARNING|2010-10-27 12:58:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|pasteboard.Started
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: useragents-config
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: dates-config
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: fopen-config
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: stopwords-config
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-database
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-useragent
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-hooks
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-sessions
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-cache
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-scaffolding
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-errors
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-uri
20101027130715|127.0.0.1|INCLUDE|2010-10-27 13:07:15|library: pb-logs
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_set_timezone: US/Pacific
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_sitewhoami: default Initialized
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_uri_segment: QUERY_STRING
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_useragent:  
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_useragent: 
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_init_session: Not Implemented
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_dbopen: mysql_pconnect
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101027130715|127.0.0.1|SQL|2010-10-27 13:07:15|SQL_logged from show_404, 43
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|_dbclose CLOSED
20101027130715|127.0.0.1|INFO|2010-10-27 13:07:15|pasteboard.Complete (0.854 seconds)
20101027130715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:07:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|pasteboard.Started
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: useragents-config
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: dates-config
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: fopen-config
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: stopwords-config
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-database
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-useragent
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-hooks
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-sessions
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-cache
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-scaffolding
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-errors
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-uri
20101027131715|127.0.0.1|INCLUDE|2010-10-27 13:17:15|library: pb-logs
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_set_timezone: US/Pacific
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_sitewhoami: default Initialized
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_uri_segment: QUERY_STRING
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_useragent:  
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_useragent: 
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_init_session: Not Implemented
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_dbopen: mysql_pconnect
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101027131715|127.0.0.1|SQL|2010-10-27 13:17:15|SQL_logged from show_404, 43
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|_dbclose CLOSED
20101027131715|127.0.0.1|INFO|2010-10-27 13:17:15|pasteboard.Complete (1.226 seconds)
20101027131715|127.0.0.1|__ERROR_WARNING|2010-10-27 13:17:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|pasteboard.Started
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: useragents-config
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: dates-config
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: fopen-config
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: stopwords-config
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-database
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-useragent
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-hooks
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-sessions
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-cache
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-scaffolding
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-errors
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-uri
20101027132721|127.0.0.1|INCLUDE|2010-10-27 13:27:21|library: pb-logs
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_set_timezone: US/Pacific
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_sitewhoami: default Initialized
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_uri_segment: QUERY_STRING
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_useragent:  
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_useragent: 
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_init_session: Not Implemented
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_dbopen: mysql_pconnect
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101027132721|127.0.0.1|SQL|2010-10-27 13:27:21|SQL_logged from show_404, 43
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|_dbclose CLOSED
20101027132721|127.0.0.1|INFO|2010-10-27 13:27:21|pasteboard.Complete (0.64 seconds)
20101027132721|127.0.0.1|__ERROR_WARNING|2010-10-27 13:27:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|pasteboard.Started
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: useragents-config
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: dates-config
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: fopen-config
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: stopwords-config
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-database
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-useragent
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-hooks
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-sessions
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-cache
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-scaffolding
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-errors
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-uri
20101027132801|127.0.0.1|INCLUDE|2010-10-27 13:28:01|library: pb-logs
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_set_timezone: US/Pacific
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_sitewhoami: default Initialized
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_uri_segment: QUERY_STRING
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_useragent:  
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_useragent: 
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_init_session: Not Implemented
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_dbopen: mysql_pconnect
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101027132801|127.0.0.1|SQL|2010-10-27 13:28:01|SQL_logged from show_404, 43
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|_dbclose CLOSED
20101027132801|127.0.0.1|INFO|2010-10-27 13:28:01|pasteboard.Complete (0.447 seconds)
20101027132801|127.0.0.1|__ERROR_WARNING|2010-10-27 13:28:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|pasteboard.Started
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: useragents-config
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: dates-config
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: fopen-config
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: stopwords-config
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-database
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-useragent
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-hooks
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-sessions
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-cache
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-scaffolding
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-errors
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-uri
20101027133605|127.0.0.1|INCLUDE|2010-10-27 13:36:05|library: pb-logs
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_set_timezone: US/Pacific
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_sitewhoami: default Initialized
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_uri_segment: QUERY_STRING
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_useragent:  
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_useragent: 
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_init_session: Not Implemented
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_dbopen: mysql_pconnect
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101027133605|127.0.0.1|SQL|2010-10-27 13:36:05|SQL_logged from show_404, 43
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|_dbclose CLOSED
20101027133605|127.0.0.1|INFO|2010-10-27 13:36:05|pasteboard.Complete (1.495 seconds)
20101027133605|127.0.0.1|__ERROR_WARNING|2010-10-27 13:36:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
