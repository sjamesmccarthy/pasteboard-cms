20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|pasteboard.Started
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: useragents-config
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: dates-config
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: fopen-config
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: stopwords-config
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-database
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-useragent
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-hooks
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-sessions
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-cache
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-scaffolding
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-errors
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-uri
20100919000635|127.0.0.1|INCLUDE|2010-09-19 00:06:35|library: pb-logs
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_set_timezone: US/Pacific
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_sitewhoami: default Initialized
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_uri_segment: QUERY_STRING
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_useragent:  
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_useragent: 
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_init_session: Not Implemented
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_dbopen: mysql_pconnect
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919000635|127.0.0.1|SQL|2010-09-19 00:06:35|SQL_logged from show_404, 43
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|_dbclose CLOSED
20100919000635|127.0.0.1|INFO|2010-09-19 00:06:35|pasteboard.Complete (30.379 seconds)
20100919000635|127.0.0.1|__ERROR_WARNING|2010-09-19 00:06:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|pasteboard.Started
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: useragents-config
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: dates-config
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: fopen-config
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: stopwords-config
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-database
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-useragent
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-hooks
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-sessions
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-cache
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-scaffolding
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-errors
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-uri
20100919001629|127.0.0.1|INCLUDE|2010-09-19 00:16:29|library: pb-logs
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_set_timezone: US/Pacific
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_sitewhoami: default Initialized
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_uri_segment: QUERY_STRING
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_useragent:  
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_useragent: 
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_init_session: Not Implemented
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_dbopen: mysql_pconnect
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919001629|127.0.0.1|SQL|2010-09-19 00:16:29|SQL_logged from show_404, 43
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|_dbclose CLOSED
20100919001629|127.0.0.1|INFO|2010-09-19 00:16:29|pasteboard.Complete (31.79 seconds)
20100919001629|127.0.0.1|__ERROR_WARNING|2010-09-19 00:16:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|pasteboard.Started
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: useragents-config
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: dates-config
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: fopen-config
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: stopwords-config
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-database
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-useragent
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-hooks
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-sessions
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-cache
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-scaffolding
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-errors
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-uri
20100919001705|127.0.0.1|INCLUDE|2010-09-19 00:17:05|library: pb-logs
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_set_timezone: US/Pacific
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_sitewhoami: default Initialized
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_uri_segment: QUERY_STRING
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_useragent:  
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_useragent: 
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_init_session: Not Implemented
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_dbopen: mysql_pconnect
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919001705|127.0.0.1|SQL|2010-09-19 00:17:05|SQL_logged from show_404, 43
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|_dbclose CLOSED
20100919001705|127.0.0.1|INFO|2010-09-19 00:17:05|pasteboard.Complete (30.702 seconds)
20100919001705|127.0.0.1|__ERROR_WARNING|2010-09-19 00:17:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|pasteboard.Started
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: useragents-config
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: dates-config
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: fopen-config
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: stopwords-config
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-database
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-useragent
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-hooks
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-sessions
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-cache
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-scaffolding
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-errors
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-uri
20100919002735|127.0.0.1|INCLUDE|2010-09-19 00:27:35|library: pb-logs
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_set_timezone: US/Pacific
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_sitewhoami: default Initialized
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_uri_segment: QUERY_STRING
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_useragent:  
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_useragent: 
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_init_session: Not Implemented
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_dbopen: mysql_pconnect
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919002735|127.0.0.1|SQL|2010-09-19 00:27:35|SQL_logged from show_404, 43
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|_dbclose CLOSED
20100919002735|127.0.0.1|INFO|2010-09-19 00:27:35|pasteboard.Complete (31.002 seconds)
20100919002735|127.0.0.1|__ERROR_WARNING|2010-09-19 00:27:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|pasteboard.Started
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: useragents-config
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: dates-config
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: fopen-config
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: stopwords-config
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-database
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-useragent
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-hooks
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-sessions
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-cache
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-scaffolding
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-errors
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-uri
20100919003807|127.0.0.1|INCLUDE|2010-09-19 00:38:07|library: pb-logs
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_set_timezone: US/Pacific
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_sitewhoami: default Initialized
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_uri_segment: QUERY_STRING
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_useragent:  
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_useragent: 
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_init_session: Not Implemented
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_dbopen: mysql_pconnect
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919003807|127.0.0.1|SQL|2010-09-19 00:38:07|SQL_logged from show_404, 43
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|_dbclose CLOSED
20100919003807|127.0.0.1|INFO|2010-09-19 00:38:07|pasteboard.Complete (33.162 seconds)
20100919003807|127.0.0.1|__ERROR_WARNING|2010-09-19 00:38:07|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|pasteboard.Started
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: useragents-config
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: dates-config
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: fopen-config
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: stopwords-config
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-database
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-useragent
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-hooks
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-sessions
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-cache
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-scaffolding
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-errors
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-uri
20100919004840|127.0.0.1|INCLUDE|2010-09-19 00:48:40|library: pb-logs
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_set_timezone: US/Pacific
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_sitewhoami: default Initialized
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_uri_segment: QUERY_STRING
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_useragent:  
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_useragent: 
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_init_session: Not Implemented
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_dbopen: mysql_pconnect
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919004840|127.0.0.1|SQL|2010-09-19 00:48:40|SQL_logged from show_404, 43
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|_dbclose CLOSED
20100919004840|127.0.0.1|INFO|2010-09-19 00:48:40|pasteboard.Complete (30.686 seconds)
20100919004840|127.0.0.1|__ERROR_WARNING|2010-09-19 00:48:40|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|pasteboard.Started
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: useragents-config
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: dates-config
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: fopen-config
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: stopwords-config
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-database
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-useragent
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-hooks
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-sessions
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-cache
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-scaffolding
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-errors
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-uri
20100919005028|127.0.0.1|INCLUDE|2010-09-19 00:50:28|library: pb-logs
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_set_timezone: US/Pacific
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_sitewhoami: default Initialized
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_uri_segment: QUERY_STRING
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_useragent:  
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_useragent: 
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_init_session: Not Implemented
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_dbopen: mysql_pconnect
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919005028|127.0.0.1|SQL|2010-09-19 00:50:28|SQL_logged from show_404, 43
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|_dbclose CLOSED
20100919005028|127.0.0.1|INFO|2010-09-19 00:50:28|pasteboard.Complete (30.971 seconds)
20100919005028|127.0.0.1|__ERROR_WARNING|2010-09-19 00:50:28|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|pasteboard.Started
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: useragents-config
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: dates-config
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: fopen-config
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: stopwords-config
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-database
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-useragent
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-hooks
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-sessions
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-cache
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-scaffolding
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-errors
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-uri
20100919005910|127.0.0.1|INCLUDE|2010-09-19 00:59:10|library: pb-logs
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_set_timezone: US/Pacific
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_sitewhoami: default Initialized
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_uri_segment: QUERY_STRING
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_useragent:  
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_useragent: 
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_init_session: Not Implemented
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_dbopen: mysql_pconnect
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919005910|127.0.0.1|SQL|2010-09-19 00:59:10|SQL_logged from show_404, 43
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|_dbclose CLOSED
20100919005910|127.0.0.1|INFO|2010-09-19 00:59:10|pasteboard.Complete (31.049 seconds)
20100919005910|127.0.0.1|__ERROR_WARNING|2010-09-19 00:59:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|pasteboard.Started
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: useragents-config
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: dates-config
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: fopen-config
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: stopwords-config
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-database
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-useragent
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-hooks
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-sessions
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-cache
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-scaffolding
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-errors
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-uri
20100919010944|127.0.0.1|INCLUDE|2010-09-19 01:09:44|library: pb-logs
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_set_timezone: US/Pacific
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_sitewhoami: default Initialized
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_uri_segment: QUERY_STRING
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_useragent:  
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_useragent: 
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_init_session: Not Implemented
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_dbopen: mysql_pconnect
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919010944|127.0.0.1|SQL|2010-09-19 01:09:44|SQL_logged from show_404, 43
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|_dbclose CLOSED
20100919010944|127.0.0.1|INFO|2010-09-19 01:09:44|pasteboard.Complete (32.914 seconds)
20100919010944|127.0.0.1|__ERROR_WARNING|2010-09-19 01:09:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|pasteboard.Started
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: useragents-config
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: dates-config
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: fopen-config
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: stopwords-config
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-database
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-useragent
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-hooks
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-sessions
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-cache
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-scaffolding
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-errors
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-uri
20100919012016|127.0.0.1|INCLUDE|2010-09-19 01:20:16|library: pb-logs
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_set_timezone: US/Pacific
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_sitewhoami: default Initialized
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_uri_segment: QUERY_STRING
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_useragent:  
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_useragent: 
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_init_session: Not Implemented
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_dbopen: mysql_pconnect
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919012016|127.0.0.1|SQL|2010-09-19 01:20:16|SQL_logged from show_404, 43
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|_dbclose CLOSED
20100919012016|127.0.0.1|INFO|2010-09-19 01:20:16|pasteboard.Complete (30.789 seconds)
20100919012016|127.0.0.1|__ERROR_WARNING|2010-09-19 01:20:16|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|pasteboard.Started
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: useragents-config
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: dates-config
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: fopen-config
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: stopwords-config
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-database
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-useragent
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-hooks
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-sessions
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-cache
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-scaffolding
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-errors
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-uri
20100919012440|127.0.0.1|INCLUDE|2010-09-19 01:24:40|library: pb-logs
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_set_timezone: US/Pacific
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_sitewhoami: default Initialized
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_uri_segment: QUERY_STRING
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_useragent:  
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_useragent: 
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_init_session: Not Implemented
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_dbopen: mysql_pconnect
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919012440|127.0.0.1|SQL|2010-09-19 01:24:40|SQL_logged from show_404, 43
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|_dbclose CLOSED
20100919012440|127.0.0.1|INFO|2010-09-19 01:24:40|pasteboard.Complete (30.939 seconds)
20100919012440|127.0.0.1|__ERROR_WARNING|2010-09-19 01:24:40|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|pasteboard.Started
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: useragents-config
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: dates-config
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: fopen-config
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: stopwords-config
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-database
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-useragent
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-hooks
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-sessions
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-cache
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-scaffolding
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-errors
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-uri
20100919013046|127.0.0.1|INCLUDE|2010-09-19 01:30:46|library: pb-logs
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_set_timezone: US/Pacific
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_sitewhoami: default Initialized
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_uri_segment: QUERY_STRING
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_useragent:  
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_useragent: 
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_init_session: Not Implemented
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_dbopen: mysql_pconnect
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919013046|127.0.0.1|SQL|2010-09-19 01:30:46|SQL_logged from show_404, 43
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|_dbclose CLOSED
20100919013046|127.0.0.1|INFO|2010-09-19 01:30:46|pasteboard.Complete (31.1 seconds)
20100919013046|127.0.0.1|__ERROR_WARNING|2010-09-19 01:30:46|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|pasteboard.Started
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: useragents-config
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: dates-config
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: fopen-config
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: stopwords-config
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-database
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-useragent
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-hooks
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-sessions
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-cache
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-scaffolding
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-errors
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-uri
20100919014118|127.0.0.1|INCLUDE|2010-09-19 01:41:18|library: pb-logs
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_set_timezone: US/Pacific
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_sitewhoami: default Initialized
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_uri_segment: QUERY_STRING
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_useragent:  
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_useragent: 
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_init_session: Not Implemented
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_dbopen: mysql_pconnect
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919014118|127.0.0.1|SQL|2010-09-19 01:41:18|SQL_logged from show_404, 43
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|_dbclose CLOSED
20100919014118|127.0.0.1|INFO|2010-09-19 01:41:18|pasteboard.Complete (33.634 seconds)
20100919014118|127.0.0.1|__ERROR_WARNING|2010-09-19 01:41:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|pasteboard.Started
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: useragents-config
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: dates-config
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: fopen-config
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: stopwords-config
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-database
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-useragent
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-hooks
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-sessions
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-cache
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-scaffolding
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-errors
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-uri
20100919015151|127.0.0.1|INCLUDE|2010-09-19 01:51:51|library: pb-logs
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_set_timezone: US/Pacific
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_sitewhoami: default Initialized
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_uri_segment: QUERY_STRING
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_useragent:  
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_useragent: 
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_init_session: Not Implemented
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_dbopen: mysql_pconnect
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919015151|127.0.0.1|SQL|2010-09-19 01:51:51|SQL_logged from show_404, 43
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|_dbclose CLOSED
20100919015151|127.0.0.1|INFO|2010-09-19 01:51:51|pasteboard.Complete (31.07 seconds)
20100919015151|127.0.0.1|__ERROR_WARNING|2010-09-19 01:51:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|pasteboard.Started
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: useragents-config
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: dates-config
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: fopen-config
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: stopwords-config
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-database
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-useragent
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-hooks
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-sessions
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-cache
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-scaffolding
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-errors
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-uri
20100919015817|127.0.0.1|INCLUDE|2010-09-19 01:58:17|library: pb-logs
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_set_timezone: US/Pacific
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_sitewhoami: default Initialized
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_uri_segment: QUERY_STRING
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_useragent:  
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_useragent: 
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_init_session: Not Implemented
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_dbopen: mysql_pconnect
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919015817|127.0.0.1|SQL|2010-09-19 01:58:17|SQL_logged from show_404, 43
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|_dbclose CLOSED
20100919015817|127.0.0.1|INFO|2010-09-19 01:58:17|pasteboard.Complete (30.53 seconds)
20100919015817|127.0.0.1|__ERROR_WARNING|2010-09-19 01:58:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|pasteboard.Started
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: useragents-config
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: dates-config
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: fopen-config
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: stopwords-config
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-database
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-useragent
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-hooks
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-sessions
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-cache
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-scaffolding
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-errors
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-uri
20100919020222|127.0.0.1|INCLUDE|2010-09-19 02:02:22|library: pb-logs
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_set_timezone: US/Pacific
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_sitewhoami: default Initialized
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_uri_segment: QUERY_STRING
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_useragent:  
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_useragent: 
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_init_session: Not Implemented
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_dbopen: mysql_pconnect
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919020222|127.0.0.1|SQL|2010-09-19 02:02:22|SQL_logged from show_404, 43
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|_dbclose CLOSED
20100919020222|127.0.0.1|INFO|2010-09-19 02:02:22|pasteboard.Complete (30.545 seconds)
20100919020222|127.0.0.1|__ERROR_WARNING|2010-09-19 02:02:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|pasteboard.Started
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: useragents-config
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: dates-config
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: fopen-config
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: stopwords-config
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-database
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-useragent
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-hooks
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-sessions
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-cache
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-scaffolding
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-errors
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-uri
20100919021253|127.0.0.1|INCLUDE|2010-09-19 02:12:53|library: pb-logs
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_set_timezone: US/Pacific
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_sitewhoami: default Initialized
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_uri_segment: QUERY_STRING
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_useragent:  
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_useragent: 
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_init_session: Not Implemented
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_dbopen: mysql_pconnect
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919021253|127.0.0.1|SQL|2010-09-19 02:12:53|SQL_logged from show_404, 43
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|_dbclose CLOSED
20100919021253|127.0.0.1|INFO|2010-09-19 02:12:53|pasteboard.Complete (33.048 seconds)
20100919021253|127.0.0.1|__ERROR_WARNING|2010-09-19 02:12:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|pasteboard.Started
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: useragents-config
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: dates-config
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: fopen-config
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: stopwords-config
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-database
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-useragent
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-hooks
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-sessions
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-cache
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-scaffolding
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-errors
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-uri
20100919022326|127.0.0.1|INCLUDE|2010-09-19 02:23:26|library: pb-logs
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_set_timezone: US/Pacific
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_sitewhoami: default Initialized
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_uri_segment: QUERY_STRING
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_useragent:  
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_useragent: 
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_init_session: Not Implemented
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_dbopen: mysql_pconnect
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919022326|127.0.0.1|SQL|2010-09-19 02:23:26|SQL_logged from show_404, 43
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|_dbclose CLOSED
20100919022326|127.0.0.1|INFO|2010-09-19 02:23:26|pasteboard.Complete (31.069 seconds)
20100919022326|127.0.0.1|__ERROR_WARNING|2010-09-19 02:23:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|pasteboard.Started
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: useragents-config
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: dates-config
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: fopen-config
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: stopwords-config
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-database
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-useragent
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-hooks
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-sessions
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-cache
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-scaffolding
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-errors
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-uri
20100919023246|127.0.0.1|INCLUDE|2010-09-19 02:32:46|library: pb-logs
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_set_timezone: US/Pacific
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_sitewhoami: default Initialized
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_uri_segment: QUERY_STRING
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_useragent:  
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_useragent: 
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_init_session: Not Implemented
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_dbopen: mysql_pconnect
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919023246|127.0.0.1|SQL|2010-09-19 02:32:46|SQL_logged from show_404, 43
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|_dbclose CLOSED
20100919023246|127.0.0.1|INFO|2010-09-19 02:32:46|pasteboard.Complete (30.227 seconds)
20100919023246|127.0.0.1|__ERROR_WARNING|2010-09-19 02:32:46|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|pasteboard.Started
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: useragents-config
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: dates-config
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: fopen-config
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: stopwords-config
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-database
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-useragent
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-hooks
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-sessions
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-cache
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-scaffolding
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-errors
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-uri
20100919023358|127.0.0.1|INCLUDE|2010-09-19 02:33:58|library: pb-logs
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_set_timezone: US/Pacific
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_sitewhoami: default Initialized
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_uri_segment: QUERY_STRING
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_useragent:  
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_useragent: 
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_init_session: Not Implemented
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_dbopen: mysql_pconnect
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919023358|127.0.0.1|SQL|2010-09-19 02:33:58|SQL_logged from show_404, 43
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|_dbclose CLOSED
20100919023358|127.0.0.1|INFO|2010-09-19 02:33:58|pasteboard.Complete (30.156 seconds)
20100919023358|127.0.0.1|__ERROR_WARNING|2010-09-19 02:33:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|pasteboard.Started
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: useragents-config
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: dates-config
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: fopen-config
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: stopwords-config
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-database
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-useragent
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-hooks
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-sessions
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-cache
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-scaffolding
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-errors
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-uri
20100919024429|127.0.0.1|INCLUDE|2010-09-19 02:44:29|library: pb-logs
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_set_timezone: US/Pacific
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_sitewhoami: default Initialized
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_uri_segment: QUERY_STRING
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_useragent:  
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_useragent: 
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_init_session: Not Implemented
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_dbopen: mysql_pconnect
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919024429|127.0.0.1|SQL|2010-09-19 02:44:29|SQL_logged from show_404, 43
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|_dbclose CLOSED
20100919024429|127.0.0.1|INFO|2010-09-19 02:44:29|pasteboard.Complete (30.618 seconds)
20100919024429|127.0.0.1|__ERROR_WARNING|2010-09-19 02:44:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|pasteboard.Started
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: useragents-config
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: dates-config
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: fopen-config
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: stopwords-config
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-database
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-useragent
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-hooks
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-sessions
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-cache
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-scaffolding
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-errors
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-uri
20100919025459|127.0.0.1|INCLUDE|2010-09-19 02:54:59|library: pb-logs
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_set_timezone: US/Pacific
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_sitewhoami: default Initialized
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_uri_segment: QUERY_STRING
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_useragent:  
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_useragent: 
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_init_session: Not Implemented
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_dbopen: mysql_pconnect
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919025459|127.0.0.1|SQL|2010-09-19 02:54:59|SQL_logged from show_404, 43
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|_dbclose CLOSED
20100919025459|127.0.0.1|INFO|2010-09-19 02:54:59|pasteboard.Complete (30.925 seconds)
20100919025459|127.0.0.1|__ERROR_WARNING|2010-09-19 02:54:59|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|pasteboard.Started
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: useragents-config
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: dates-config
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: fopen-config
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: stopwords-config
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-database
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-useragent
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-hooks
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-sessions
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-cache
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-scaffolding
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-errors
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-uri
20100919030530|127.0.0.1|INCLUDE|2010-09-19 03:05:30|library: pb-logs
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_set_timezone: US/Pacific
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_sitewhoami: default Initialized
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_uri_segment: QUERY_STRING
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_useragent:  
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_useragent: 
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_init_session: Not Implemented
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_dbopen: mysql_pconnect
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919030530|127.0.0.1|SQL|2010-09-19 03:05:30|SQL_logged from show_404, 43
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|_dbclose CLOSED
20100919030530|127.0.0.1|INFO|2010-09-19 03:05:30|pasteboard.Complete (30.367 seconds)
20100919030530|127.0.0.1|__ERROR_WARNING|2010-09-19 03:05:30|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|pasteboard.Started
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: useragents-config
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: dates-config
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: fopen-config
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: stopwords-config
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-database
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-useragent
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-hooks
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-sessions
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-cache
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-scaffolding
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-errors
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-uri
20100919030649|127.0.0.1|INCLUDE|2010-09-19 03:06:49|library: pb-logs
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_set_timezone: US/Pacific
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_sitewhoami: default Initialized
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_uri_segment: QUERY_STRING
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_useragent:  
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_useragent: 
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_init_session: Not Implemented
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_dbopen: mysql_pconnect
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919030649|127.0.0.1|SQL|2010-09-19 03:06:49|SQL_logged from show_404, 43
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|_dbclose CLOSED
20100919030649|127.0.0.1|INFO|2010-09-19 03:06:49|pasteboard.Complete (31.123 seconds)
20100919030649|127.0.0.1|__ERROR_WARNING|2010-09-19 03:06:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|pasteboard.Started
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: useragents-config
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: dates-config
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: fopen-config
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: stopwords-config
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-database
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-useragent
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-hooks
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-sessions
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-cache
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-scaffolding
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-errors
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-uri
20100919031601|127.0.0.1|INCLUDE|2010-09-19 03:16:01|library: pb-logs
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_set_timezone: US/Pacific
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_sitewhoami: default Initialized
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_uri_segment: QUERY_STRING
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_useragent:  
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_useragent: 
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_init_session: Not Implemented
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_dbopen: mysql_pconnect
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919031601|127.0.0.1|SQL|2010-09-19 03:16:01|SQL_logged from show_404, 43
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|_dbclose CLOSED
20100919031601|127.0.0.1|INFO|2010-09-19 03:16:01|pasteboard.Complete (33.727 seconds)
20100919031601|127.0.0.1|__ERROR_WARNING|2010-09-19 03:16:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|pasteboard.Started
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: useragents-config
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: dates-config
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: fopen-config
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: stopwords-config
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-database
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-useragent
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-hooks
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-sessions
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-cache
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-scaffolding
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-errors
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-uri
20100919032635|127.0.0.1|INCLUDE|2010-09-19 03:26:35|library: pb-logs
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_set_timezone: US/Pacific
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_sitewhoami: default Initialized
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_uri_segment: QUERY_STRING
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_useragent:  
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_useragent: 
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_init_session: Not Implemented
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_dbopen: mysql_pconnect
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919032635|127.0.0.1|SQL|2010-09-19 03:26:35|SQL_logged from show_404, 43
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|_dbclose CLOSED
20100919032635|127.0.0.1|INFO|2010-09-19 03:26:35|pasteboard.Complete (30.875 seconds)
20100919032635|127.0.0.1|__ERROR_WARNING|2010-09-19 03:26:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|pasteboard.Started
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: useragents-config
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: dates-config
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: fopen-config
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: stopwords-config
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-database
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-useragent
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-hooks
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-sessions
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-cache
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-scaffolding
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-errors
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-uri
20100919033706|127.0.0.1|INCLUDE|2010-09-19 03:37:06|library: pb-logs
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_set_timezone: US/Pacific
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_sitewhoami: default Initialized
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_uri_segment: QUERY_STRING
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_useragent:  
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_useragent: 
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_init_session: Not Implemented
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_dbopen: mysql_pconnect
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919033706|127.0.0.1|SQL|2010-09-19 03:37:06|SQL_logged from show_404, 43
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|_dbclose CLOSED
20100919033706|127.0.0.1|INFO|2010-09-19 03:37:06|pasteboard.Complete (30.424 seconds)
20100919033706|127.0.0.1|__ERROR_WARNING|2010-09-19 03:37:06|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|pasteboard.Started
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: useragents-config
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: dates-config
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: fopen-config
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: stopwords-config
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-database
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-useragent
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-hooks
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-sessions
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-cache
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-scaffolding
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-errors
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-uri
20100919034004|127.0.0.1|INCLUDE|2010-09-19 03:40:04|library: pb-logs
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_set_timezone: US/Pacific
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_sitewhoami: default Initialized
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_uri_segment: QUERY_STRING
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_useragent:  
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_useragent: 
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_init_session: Not Implemented
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_dbopen: mysql_pconnect
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919034004|127.0.0.1|SQL|2010-09-19 03:40:04|SQL_logged from show_404, 43
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|_dbclose CLOSED
20100919034004|127.0.0.1|INFO|2010-09-19 03:40:04|pasteboard.Complete (30.73 seconds)
20100919034004|127.0.0.1|__ERROR_WARNING|2010-09-19 03:40:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|pasteboard.Started
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: useragents-config
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: dates-config
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: fopen-config
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: stopwords-config
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-database
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-useragent
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-hooks
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-sessions
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-cache
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-scaffolding
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-errors
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-uri
20100919034737|127.0.0.1|INCLUDE|2010-09-19 03:47:37|library: pb-logs
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_set_timezone: US/Pacific
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_sitewhoami: default Initialized
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_uri_segment: QUERY_STRING
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_useragent:  
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_useragent: 
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_init_session: Not Implemented
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_dbopen: mysql_pconnect
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919034737|127.0.0.1|SQL|2010-09-19 03:47:37|SQL_logged from show_404, 43
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|_dbclose CLOSED
20100919034737|127.0.0.1|INFO|2010-09-19 03:47:37|pasteboard.Complete (30.889 seconds)
20100919034737|127.0.0.1|__ERROR_WARNING|2010-09-19 03:47:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|pasteboard.Started
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: useragents-config
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: dates-config
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: fopen-config
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: stopwords-config
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-database
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-useragent
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-hooks
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-sessions
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-cache
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-scaffolding
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-errors
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-uri
20100919035808|127.0.0.1|INCLUDE|2010-09-19 03:58:08|library: pb-logs
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_set_timezone: US/Pacific
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_sitewhoami: default Initialized
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_uri_segment: QUERY_STRING
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_useragent:  
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_useragent: 
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_init_session: Not Implemented
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_dbopen: mysql_pconnect
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919035808|127.0.0.1|SQL|2010-09-19 03:58:08|SQL_logged from show_404, 43
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|_dbclose CLOSED
20100919035808|127.0.0.1|INFO|2010-09-19 03:58:08|pasteboard.Complete (30.514 seconds)
20100919035808|127.0.0.1|__ERROR_WARNING|2010-09-19 03:58:08|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|pasteboard.Started
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: useragents-config
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: dates-config
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: fopen-config
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: stopwords-config
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-database
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-useragent
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-hooks
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-sessions
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-cache
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-scaffolding
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-errors
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-uri
20100919040839|127.0.0.1|INCLUDE|2010-09-19 04:08:39|library: pb-logs
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_set_timezone: US/Pacific
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_sitewhoami: default Initialized
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_uri_segment: QUERY_STRING
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_useragent:  
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_useragent: 
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_init_session: Not Implemented
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_dbopen: mysql_pconnect
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919040839|127.0.0.1|SQL|2010-09-19 04:08:39|SQL_logged from show_404, 43
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|_dbclose CLOSED
20100919040839|127.0.0.1|INFO|2010-09-19 04:08:39|pasteboard.Complete (30.912 seconds)
20100919040839|127.0.0.1|__ERROR_WARNING|2010-09-19 04:08:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|pasteboard.Started
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: useragents-config
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: dates-config
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: fopen-config
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: stopwords-config
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-database
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-useragent
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-hooks
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-sessions
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-cache
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-scaffolding
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-errors
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-uri
20100919041354|127.0.0.1|INCLUDE|2010-09-19 04:13:54|library: pb-logs
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_set_timezone: US/Pacific
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_sitewhoami: default Initialized
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_uri_segment: QUERY_STRING
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_useragent:  
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_useragent: 
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_init_session: Not Implemented
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_dbopen: mysql_pconnect
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919041354|127.0.0.1|SQL|2010-09-19 04:13:54|SQL_logged from show_404, 43
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|_dbclose CLOSED
20100919041354|127.0.0.1|INFO|2010-09-19 04:13:54|pasteboard.Complete (30.941 seconds)
20100919041354|127.0.0.1|__ERROR_WARNING|2010-09-19 04:13:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|pasteboard.Started
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: useragents-config
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: dates-config
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: fopen-config
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: stopwords-config
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-database
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-useragent
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-hooks
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-sessions
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-cache
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-scaffolding
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-errors
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-uri
20100919041910|127.0.0.1|INCLUDE|2010-09-19 04:19:10|library: pb-logs
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_set_timezone: US/Pacific
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_sitewhoami: default Initialized
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_uri_segment: QUERY_STRING
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_useragent:  
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_useragent: 
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_init_session: Not Implemented
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_dbopen: mysql_pconnect
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919041910|127.0.0.1|SQL|2010-09-19 04:19:10|SQL_logged from show_404, 43
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|_dbclose CLOSED
20100919041910|127.0.0.1|INFO|2010-09-19 04:19:10|pasteboard.Complete (38.251 seconds)
20100919041910|127.0.0.1|__ERROR_WARNING|2010-09-19 04:19:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|pasteboard.Started
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: useragents-config
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: dates-config
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: fopen-config
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: stopwords-config
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-database
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-useragent
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-hooks
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-sessions
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-cache
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-scaffolding
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-errors
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-uri
20100919042949|127.0.0.1|INCLUDE|2010-09-19 04:29:49|library: pb-logs
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_set_timezone: US/Pacific
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_sitewhoami: default Initialized
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_uri_segment: QUERY_STRING
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_useragent:  
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_useragent: 
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_init_session: Not Implemented
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_dbopen: mysql_pconnect
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919042949|127.0.0.1|SQL|2010-09-19 04:29:49|SQL_logged from show_404, 43
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|_dbclose CLOSED
20100919042949|127.0.0.1|INFO|2010-09-19 04:29:49|pasteboard.Complete (30.74 seconds)
20100919042949|127.0.0.1|__ERROR_WARNING|2010-09-19 04:29:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|pasteboard.Started
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: useragents-config
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: dates-config
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: fopen-config
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: stopwords-config
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-database
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-useragent
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-hooks
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-sessions
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-cache
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-scaffolding
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-errors
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-uri
20100919044020|127.0.0.1|INCLUDE|2010-09-19 04:40:20|library: pb-logs
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_set_timezone: US/Pacific
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_sitewhoami: default Initialized
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_uri_segment: QUERY_STRING
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_useragent:  
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_useragent: 
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_init_session: Not Implemented
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_dbopen: mysql_pconnect
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919044020|127.0.0.1|SQL|2010-09-19 04:40:20|SQL_logged from show_404, 43
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|_dbclose CLOSED
20100919044020|127.0.0.1|INFO|2010-09-19 04:40:20|pasteboard.Complete (30.313 seconds)
20100919044020|127.0.0.1|__ERROR_WARNING|2010-09-19 04:40:20|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|pasteboard.Started
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: useragents-config
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: dates-config
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: fopen-config
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: stopwords-config
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-database
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-useragent
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-hooks
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-sessions
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-cache
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-scaffolding
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-errors
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-uri
20100919044424|127.0.0.1|INCLUDE|2010-09-19 04:44:24|library: pb-logs
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_set_timezone: US/Pacific
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_sitewhoami: default Initialized
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_uri_segment: QUERY_STRING
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_useragent:  
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_useragent: 
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_init_session: Not Implemented
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_dbopen: mysql_pconnect
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919044424|127.0.0.1|SQL|2010-09-19 04:44:24|SQL_logged from show_404, 43
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|_dbclose CLOSED
20100919044424|127.0.0.1|INFO|2010-09-19 04:44:24|pasteboard.Complete (30.681 seconds)
20100919044424|127.0.0.1|__ERROR_WARNING|2010-09-19 04:44:24|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|pasteboard.Started
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: useragents-config
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: dates-config
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: fopen-config
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: stopwords-config
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-database
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-useragent
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-hooks
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-sessions
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-cache
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-scaffolding
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-errors
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-uri
20100919045050|127.0.0.1|INCLUDE|2010-09-19 04:50:50|library: pb-logs
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_set_timezone: US/Pacific
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_sitewhoami: default Initialized
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_uri_segment: QUERY_STRING
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_useragent:  
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_useragent: 
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_init_session: Not Implemented
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_dbopen: mysql_pconnect
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919045050|127.0.0.1|SQL|2010-09-19 04:50:50|SQL_logged from show_404, 43
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|_dbclose CLOSED
20100919045050|127.0.0.1|INFO|2010-09-19 04:50:50|pasteboard.Complete (30.919 seconds)
20100919045050|127.0.0.1|__ERROR_WARNING|2010-09-19 04:50:50|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|pasteboard.Started
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: useragents-config
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: dates-config
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: fopen-config
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: stopwords-config
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-database
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-useragent
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-hooks
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-sessions
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-cache
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-scaffolding
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-errors
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-uri
20100919050125|127.0.0.1|INCLUDE|2010-09-19 05:01:25|library: pb-logs
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_set_timezone: US/Pacific
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_sitewhoami: default Initialized
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_uri_segment: QUERY_STRING
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_useragent:  
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_useragent: 
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_init_session: Not Implemented
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_dbopen: mysql_pconnect
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919050125|127.0.0.1|SQL|2010-09-19 05:01:25|SQL_logged from show_404, 43
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|_dbclose CLOSED
20100919050125|127.0.0.1|INFO|2010-09-19 05:01:25|pasteboard.Complete (30.686 seconds)
20100919050125|127.0.0.1|__ERROR_WARNING|2010-09-19 05:01:25|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|pasteboard.Started
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: useragents-config
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: dates-config
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: fopen-config
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: stopwords-config
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-database
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-useragent
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-hooks
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-sessions
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-cache
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-scaffolding
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-errors
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-uri
20100919051155|127.0.0.1|INCLUDE|2010-09-19 05:11:55|library: pb-logs
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_set_timezone: US/Pacific
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_sitewhoami: default Initialized
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_uri_segment: QUERY_STRING
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_useragent:  
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_useragent: 
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_init_session: Not Implemented
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_dbopen: mysql_pconnect
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919051155|127.0.0.1|SQL|2010-09-19 05:11:55|SQL_logged from show_404, 43
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|_dbclose CLOSED
20100919051155|127.0.0.1|INFO|2010-09-19 05:11:55|pasteboard.Complete (31.122 seconds)
20100919051155|127.0.0.1|__ERROR_WARNING|2010-09-19 05:11:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|pasteboard.Started
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: useragents-config
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: dates-config
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: fopen-config
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: stopwords-config
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-database
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-useragent
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-hooks
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-sessions
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-cache
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-scaffolding
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-errors
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-uri
20100919051801|127.0.0.1|INCLUDE|2010-09-19 05:18:01|library: pb-logs
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_set_timezone: US/Pacific
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_sitewhoami: default Initialized
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_uri_segment: QUERY_STRING
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_useragent:  
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_useragent: 
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_init_session: Not Implemented
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_dbopen: mysql_pconnect
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919051801|127.0.0.1|SQL|2010-09-19 05:18:01|SQL_logged from show_404, 43
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|_dbclose CLOSED
20100919051801|127.0.0.1|INFO|2010-09-19 05:18:01|pasteboard.Complete (30.464 seconds)
20100919051801|127.0.0.1|__ERROR_WARNING|2010-09-19 05:18:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|pasteboard.Started
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: useragents-config
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: dates-config
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: fopen-config
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: stopwords-config
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-database
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-useragent
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-hooks
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-sessions
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-cache
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-scaffolding
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-errors
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-uri
20100919052227|127.0.0.1|INCLUDE|2010-09-19 05:22:27|library: pb-logs
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_set_timezone: US/Pacific
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_sitewhoami: default Initialized
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_uri_segment: QUERY_STRING
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_useragent:  
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_useragent: 
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_init_session: Not Implemented
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_dbopen: mysql_pconnect
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919052227|127.0.0.1|SQL|2010-09-19 05:22:27|SQL_logged from show_404, 43
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|_dbclose CLOSED
20100919052227|127.0.0.1|INFO|2010-09-19 05:22:27|pasteboard.Complete (30.545 seconds)
20100919052227|127.0.0.1|__ERROR_WARNING|2010-09-19 05:22:27|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|pasteboard.Started
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: useragents-config
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: dates-config
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: fopen-config
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: stopwords-config
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-database
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-useragent
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-hooks
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-sessions
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-cache
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-scaffolding
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-errors
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-uri
20100919053257|127.0.0.1|INCLUDE|2010-09-19 05:32:57|library: pb-logs
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_set_timezone: US/Pacific
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_sitewhoami: default Initialized
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_uri_segment: QUERY_STRING
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_useragent:  
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_useragent: 
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_init_session: Not Implemented
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_dbopen: mysql_pconnect
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919053257|127.0.0.1|SQL|2010-09-19 05:32:57|SQL_logged from show_404, 43
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|_dbclose CLOSED
20100919053257|127.0.0.1|INFO|2010-09-19 05:32:57|pasteboard.Complete (30.982 seconds)
20100919053257|127.0.0.1|__ERROR_WARNING|2010-09-19 05:32:57|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|pasteboard.Started
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: useragents-config
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: dates-config
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: fopen-config
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: stopwords-config
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-database
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-useragent
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-hooks
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-sessions
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-cache
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-scaffolding
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-errors
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-uri
20100919054328|127.0.0.1|INCLUDE|2010-09-19 05:43:28|library: pb-logs
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_set_timezone: US/Pacific
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_sitewhoami: default Initialized
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_uri_segment: QUERY_STRING
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_useragent:  
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_useragent: 
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_init_session: Not Implemented
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_dbopen: mysql_pconnect
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919054328|127.0.0.1|SQL|2010-09-19 05:43:28|SQL_logged from show_404, 43
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|_dbclose CLOSED
20100919054328|127.0.0.1|INFO|2010-09-19 05:43:28|pasteboard.Complete (37.409 seconds)
20100919054328|127.0.0.1|__ERROR_WARNING|2010-09-19 05:43:28|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|pasteboard.Started
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: useragents-config
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: dates-config
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: fopen-config
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: stopwords-config
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-database
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-useragent
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-hooks
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-sessions
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-cache
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-scaffolding
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-errors
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-uri
20100919055228|127.0.0.1|INCLUDE|2010-09-19 05:52:28|library: pb-logs
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_set_timezone: US/Pacific
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_sitewhoami: default Initialized
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_uri_segment: QUERY_STRING
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_useragent:  
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_useragent: 
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_init_session: Not Implemented
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_dbopen: mysql_pconnect
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919055228|127.0.0.1|SQL|2010-09-19 05:52:28|SQL_logged from show_404, 43
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|_dbclose CLOSED
20100919055228|127.0.0.1|INFO|2010-09-19 05:52:28|pasteboard.Complete (30.665 seconds)
20100919055228|127.0.0.1|__ERROR_WARNING|2010-09-19 05:52:28|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|pasteboard.Started
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: useragents-config
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: dates-config
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: fopen-config
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: stopwords-config
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-database
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-useragent
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-hooks
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-sessions
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-cache
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-scaffolding
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-errors
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-uri
20100919055406|127.0.0.1|INCLUDE|2010-09-19 05:54:06|library: pb-logs
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_set_timezone: US/Pacific
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_sitewhoami: default Initialized
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_uri_segment: QUERY_STRING
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_useragent:  
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_useragent: 
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_init_session: Not Implemented
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_dbopen: mysql_pconnect
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919055406|127.0.0.1|SQL|2010-09-19 05:54:06|SQL_logged from show_404, 43
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|_dbclose CLOSED
20100919055406|127.0.0.1|INFO|2010-09-19 05:54:06|pasteboard.Complete (30.593 seconds)
20100919055406|127.0.0.1|__ERROR_WARNING|2010-09-19 05:54:06|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|pasteboard.Started
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: useragents-config
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: dates-config
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: fopen-config
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: stopwords-config
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-database
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-useragent
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-hooks
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-sessions
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-cache
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-scaffolding
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-errors
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-uri
20100919060437|127.0.0.1|INCLUDE|2010-09-19 06:04:37|library: pb-logs
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_set_timezone: US/Pacific
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_sitewhoami: default Initialized
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_uri_segment: QUERY_STRING
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_useragent:  
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_useragent: 
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_init_session: Not Implemented
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_dbopen: mysql_pconnect
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919060437|127.0.0.1|SQL|2010-09-19 06:04:37|SQL_logged from show_404, 43
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|_dbclose CLOSED
20100919060437|127.0.0.1|INFO|2010-09-19 06:04:37|pasteboard.Complete (31.06 seconds)
20100919060437|127.0.0.1|__ERROR_WARNING|2010-09-19 06:04:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|pasteboard.Started
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: useragents-config
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: dates-config
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: fopen-config
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: stopwords-config
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-database
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-useragent
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-hooks
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-sessions
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-cache
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-scaffolding
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-errors
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-uri
20100919061512|127.0.0.1|INCLUDE|2010-09-19 06:15:12|library: pb-logs
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_set_timezone: US/Pacific
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_sitewhoami: default Initialized
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_uri_segment: QUERY_STRING
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_useragent:  
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_useragent: 
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_init_session: Not Implemented
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_dbopen: mysql_pconnect
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919061512|127.0.0.1|SQL|2010-09-19 06:15:12|SQL_logged from show_404, 43
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|_dbclose CLOSED
20100919061512|127.0.0.1|INFO|2010-09-19 06:15:12|pasteboard.Complete (30.892 seconds)
20100919061512|127.0.0.1|__ERROR_WARNING|2010-09-19 06:15:12|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|pasteboard.Started
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: useragents-config
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: dates-config
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: fopen-config
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: stopwords-config
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-database
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-useragent
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-hooks
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-sessions
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-cache
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-scaffolding
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-errors
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-uri
20100919062542|127.0.0.1|INCLUDE|2010-09-19 06:25:42|library: pb-logs
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_set_timezone: US/Pacific
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_sitewhoami: default Initialized
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_uri_segment: QUERY_STRING
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_useragent:  
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_useragent: 
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_init_session: Not Implemented
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|pasteboard.Started
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: useragents-config
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: dates-config
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: fopen-config
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: stopwords-config
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-database
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-useragent
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-hooks
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-sessions
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-cache
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-scaffolding
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-errors
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-uri
20100919062543|127.0.0.1|INCLUDE|2010-09-19 06:25:43|library: pb-logs
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_set_timezone: US/Pacific
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_sitewhoami: default Initialized
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_uri_segment: QUERY_STRING
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_useragent:  
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_useragent: 
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_init_session: Not Implemented
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_dbopen: mysql_pconnect
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919062542|127.0.0.1|SQL|2010-09-19 06:25:42|SQL_logged from show_404, 43
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|_dbclose CLOSED
20100919062542|127.0.0.1|INFO|2010-09-19 06:25:42|pasteboard.Complete (31.044 seconds)
20100919062542|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_dbopen: mysql_pconnect
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919062543|127.0.0.1|SQL|2010-09-19 06:25:43|SQL_logged from show_404, 43
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|_dbclose CLOSED
20100919062543|127.0.0.1|INFO|2010-09-19 06:25:43|pasteboard.Complete (30.967 seconds)
20100919062543|127.0.0.1|__ERROR_WARNING|2010-09-19 06:25:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|pasteboard.Started
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: useragents-config
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: dates-config
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: fopen-config
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: stopwords-config
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-database
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-useragent
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-hooks
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-sessions
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-cache
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-scaffolding
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-errors
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-uri
20100919063614|127.0.0.1|INCLUDE|2010-09-19 06:36:14|library: pb-logs
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_set_timezone: US/Pacific
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_sitewhoami: default Initialized
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_uri_segment: QUERY_STRING
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_useragent:  
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_useragent: 
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_init_session: Not Implemented
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_dbopen: mysql_pconnect
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919063614|127.0.0.1|SQL|2010-09-19 06:36:14|SQL_logged from show_404, 43
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|_dbclose CLOSED
20100919063614|127.0.0.1|INFO|2010-09-19 06:36:14|pasteboard.Complete (30.503 seconds)
20100919063614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:36:14|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|pasteboard.Started
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: useragents-config
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: dates-config
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: fopen-config
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: stopwords-config
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-database
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-useragent
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-hooks
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-sessions
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-cache
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-scaffolding
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-errors
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-uri
20100919064644|127.0.0.1|INCLUDE|2010-09-19 06:46:44|library: pb-logs
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_set_timezone: US/Pacific
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_sitewhoami: default Initialized
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_uri_segment: QUERY_STRING
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_useragent:  
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_useragent: 
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_init_session: Not Implemented
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_dbopen: mysql_pconnect
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919064644|127.0.0.1|SQL|2010-09-19 06:46:44|SQL_logged from show_404, 43
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|_dbclose CLOSED
20100919064644|127.0.0.1|INFO|2010-09-19 06:46:44|pasteboard.Complete (39.559 seconds)
20100919064644|127.0.0.1|__ERROR_WARNING|2010-09-19 06:46:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|pasteboard.Started
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: useragents-config
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: dates-config
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: fopen-config
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: stopwords-config
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-database
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-useragent
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-hooks
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-sessions
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-cache
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-scaffolding
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-errors
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-uri
20100919065614|127.0.0.1|INCLUDE|2010-09-19 06:56:14|library: pb-logs
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_set_timezone: US/Pacific
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_sitewhoami: default Initialized
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_uri_segment: QUERY_STRING
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_useragent:  
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_useragent: 
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_init_session: Not Implemented
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_dbopen: mysql_pconnect
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919065614|127.0.0.1|SQL|2010-09-19 06:56:14|SQL_logged from show_404, 43
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|_dbclose CLOSED
20100919065614|127.0.0.1|INFO|2010-09-19 06:56:14|pasteboard.Complete (31.033 seconds)
20100919065614|127.0.0.1|__ERROR_WARNING|2010-09-19 06:56:14|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|pasteboard.Started
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: useragents-config
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: dates-config
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: fopen-config
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: stopwords-config
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-database
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-useragent
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-hooks
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-sessions
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-cache
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-scaffolding
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-errors
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-uri
20100919065724|127.0.0.1|INCLUDE|2010-09-19 06:57:24|library: pb-logs
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_set_timezone: US/Pacific
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_sitewhoami: default Initialized
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_uri_segment: QUERY_STRING
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_useragent:  
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_useragent: 
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_init_session: Not Implemented
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_dbopen: mysql_pconnect
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919065724|127.0.0.1|SQL|2010-09-19 06:57:24|SQL_logged from show_404, 43
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|_dbclose CLOSED
20100919065724|127.0.0.1|INFO|2010-09-19 06:57:24|pasteboard.Complete (31.066 seconds)
20100919065724|127.0.0.1|__ERROR_WARNING|2010-09-19 06:57:24|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|pasteboard.Started
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: useragents-config
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: dates-config
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: fopen-config
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: stopwords-config
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-database
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-useragent
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-hooks
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-sessions
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-cache
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-scaffolding
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-errors
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-uri
20100919070758|127.0.0.1|INCLUDE|2010-09-19 07:07:58|library: pb-logs
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_set_timezone: US/Pacific
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_sitewhoami: default Initialized
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_uri_segment: QUERY_STRING
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_useragent:  
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_useragent: 
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_init_session: Not Implemented
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_dbopen: mysql_pconnect
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919070758|127.0.0.1|SQL|2010-09-19 07:07:58|SQL_logged from show_404, 43
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|_dbclose CLOSED
20100919070758|127.0.0.1|INFO|2010-09-19 07:07:58|pasteboard.Complete (30.841 seconds)
20100919070758|127.0.0.1|__ERROR_WARNING|2010-09-19 07:07:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|pasteboard.Started
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: useragents-config
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: dates-config
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: fopen-config
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: stopwords-config
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-database
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-useragent
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-hooks
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-sessions
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-cache
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-scaffolding
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-errors
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-uri
20100919071829|127.0.0.1|INCLUDE|2010-09-19 07:18:29|library: pb-logs
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_set_timezone: US/Pacific
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_sitewhoami: default Initialized
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_uri_segment: QUERY_STRING
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_useragent:  
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_useragent: 
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_init_session: Not Implemented
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_dbopen: mysql_pconnect
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919071829|127.0.0.1|SQL|2010-09-19 07:18:29|SQL_logged from show_404, 43
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|_dbclose CLOSED
20100919071829|127.0.0.1|INFO|2010-09-19 07:18:29|pasteboard.Complete (30.296 seconds)
20100919071829|127.0.0.1|__ERROR_WARNING|2010-09-19 07:18:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|pasteboard.Started
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: useragents-config
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: dates-config
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: fopen-config
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: stopwords-config
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-database
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-useragent
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-hooks
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-sessions
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-cache
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-scaffolding
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-errors
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-uri
20100919072900|127.0.0.1|INCLUDE|2010-09-19 07:29:00|library: pb-logs
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_set_timezone: US/Pacific
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_sitewhoami: default Initialized
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_uri_segment: QUERY_STRING
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_useragent:  
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_useragent: 
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_init_session: Not Implemented
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_dbopen: mysql_pconnect
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919072900|127.0.0.1|SQL|2010-09-19 07:29:00|SQL_logged from show_404, 43
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|_dbclose CLOSED
20100919072900|127.0.0.1|INFO|2010-09-19 07:29:00|pasteboard.Complete (30.592 seconds)
20100919072900|127.0.0.1|__ERROR_WARNING|2010-09-19 07:29:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|pasteboard.Started
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: useragents-config
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: dates-config
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: fopen-config
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: stopwords-config
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-database
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-useragent
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-hooks
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-sessions
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-cache
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-scaffolding
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-errors
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-uri
20100919073014|127.0.0.1|INCLUDE|2010-09-19 07:30:14|library: pb-logs
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_set_timezone: US/Pacific
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_sitewhoami: default Initialized
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_uri_segment: QUERY_STRING
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_useragent:  
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_useragent: 
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_init_session: Not Implemented
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_dbopen: mysql_pconnect
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919073014|127.0.0.1|SQL|2010-09-19 07:30:14|SQL_logged from show_404, 43
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|_dbclose CLOSED
20100919073014|127.0.0.1|INFO|2010-09-19 07:30:14|pasteboard.Complete (30.787 seconds)
20100919073014|127.0.0.1|__ERROR_WARNING|2010-09-19 07:30:14|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|pasteboard.Started
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: useragents-config
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: dates-config
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: fopen-config
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: stopwords-config
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-database
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-useragent
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-hooks
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-sessions
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-cache
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-scaffolding
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-errors
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-uri
20100919073930|127.0.0.1|INCLUDE|2010-09-19 07:39:30|library: pb-logs
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_set_timezone: US/Pacific
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_sitewhoami: default Initialized
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_uri_segment: QUERY_STRING
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_useragent:  
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_useragent: 
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_init_session: Not Implemented
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_dbopen: mysql_pconnect
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919073930|127.0.0.1|SQL|2010-09-19 07:39:30|SQL_logged from show_404, 43
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|_dbclose CLOSED
20100919073930|127.0.0.1|INFO|2010-09-19 07:39:30|pasteboard.Complete (31.056 seconds)
20100919073930|127.0.0.1|__ERROR_WARNING|2010-09-19 07:39:30|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|pasteboard.Started
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: useragents-config
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: dates-config
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: fopen-config
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: stopwords-config
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-database
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-useragent
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-hooks
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-sessions
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-cache
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-scaffolding
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-errors
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-uri
20100919075001|127.0.0.1|INCLUDE|2010-09-19 07:50:01|library: pb-logs
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_set_timezone: US/Pacific
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_sitewhoami: default Initialized
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_uri_segment: QUERY_STRING
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_useragent:  
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_useragent: 
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_init_session: Not Implemented
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_dbopen: mysql_pconnect
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919075001|127.0.0.1|SQL|2010-09-19 07:50:01|SQL_logged from show_404, 43
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|_dbclose CLOSED
20100919075001|127.0.0.1|INFO|2010-09-19 07:50:01|pasteboard.Complete (30.547 seconds)
20100919075001|127.0.0.1|__ERROR_WARNING|2010-09-19 07:50:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|pasteboard.Started
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: useragents-config
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: dates-config
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: fopen-config
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: stopwords-config
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-database
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-useragent
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-hooks
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-sessions
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-cache
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-scaffolding
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-errors
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-uri
20100919080032|127.0.0.1|INCLUDE|2010-09-19 08:00:32|library: pb-logs
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_set_timezone: US/Pacific
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_sitewhoami: default Initialized
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_uri_segment: QUERY_STRING
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_useragent:  
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_useragent: 
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_init_session: Not Implemented
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_dbopen: mysql_pconnect
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919080032|127.0.0.1|SQL|2010-09-19 08:00:32|SQL_logged from show_404, 43
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|_dbclose CLOSED
20100919080032|127.0.0.1|INFO|2010-09-19 08:00:32|pasteboard.Complete (30.416 seconds)
20100919080032|127.0.0.1|__ERROR_WARNING|2010-09-19 08:00:32|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|pasteboard.Started
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: useragents-config
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: dates-config
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: fopen-config
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: stopwords-config
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-database
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-useragent
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-hooks
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-sessions
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-cache
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-scaffolding
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-errors
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-uri
20100919080346|127.0.0.1|INCLUDE|2010-09-19 08:03:46|library: pb-logs
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_set_timezone: US/Pacific
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_sitewhoami: default Initialized
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_uri_segment: QUERY_STRING
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_useragent:  
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_useragent: 
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_init_session: Not Implemented
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_dbopen: mysql_pconnect
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919080346|127.0.0.1|SQL|2010-09-19 08:03:46|SQL_logged from show_404, 43
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|_dbclose CLOSED
20100919080346|127.0.0.1|INFO|2010-09-19 08:03:46|pasteboard.Complete (35.33 seconds)
20100919080346|127.0.0.1|__ERROR_WARNING|2010-09-19 08:03:46|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|pasteboard.Started
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: useragents-config
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: dates-config
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: fopen-config
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: stopwords-config
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-database
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-useragent
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-hooks
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-sessions
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-cache
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-scaffolding
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-errors
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-uri
20100919081103|127.0.0.1|INCLUDE|2010-09-19 08:11:03|library: pb-logs
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_set_timezone: US/Pacific
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_sitewhoami: default Initialized
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_uri_segment: QUERY_STRING
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_useragent:  
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_useragent: 
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_init_session: Not Implemented
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_dbopen: mysql_pconnect
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919081103|127.0.0.1|SQL|2010-09-19 08:11:03|SQL_logged from show_404, 43
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|_dbclose CLOSED
20100919081103|127.0.0.1|INFO|2010-09-19 08:11:03|pasteboard.Complete (30.954 seconds)
20100919081103|127.0.0.1|__ERROR_WARNING|2010-09-19 08:11:03|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|pasteboard.Started
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: useragents-config
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: dates-config
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: fopen-config
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: stopwords-config
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-database
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-useragent
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-hooks
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-sessions
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-cache
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-scaffolding
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-errors
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-uri
20100919082134|127.0.0.1|INCLUDE|2010-09-19 08:21:34|library: pb-logs
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_set_timezone: US/Pacific
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_sitewhoami: default Initialized
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_uri_segment: QUERY_STRING
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_useragent:  
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_useragent: 
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_init_session: Not Implemented
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_dbopen: mysql_pconnect
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919082134|127.0.0.1|SQL|2010-09-19 08:21:34|SQL_logged from show_404, 43
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|_dbclose CLOSED
20100919082134|127.0.0.1|INFO|2010-09-19 08:21:34|pasteboard.Complete (31.581 seconds)
20100919082134|127.0.0.1|__ERROR_WARNING|2010-09-19 08:21:34|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|pasteboard.Started
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: useragents-config
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: dates-config
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: fopen-config
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: stopwords-config
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-database
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-useragent
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-hooks
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-sessions
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-cache
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-scaffolding
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-errors
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-uri
20100919083205|127.0.0.1|INCLUDE|2010-09-19 08:32:05|library: pb-logs
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_set_timezone: US/Pacific
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_sitewhoami: default Initialized
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_uri_segment: QUERY_STRING
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_useragent:  
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_useragent: 
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_init_session: Not Implemented
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_dbopen: mysql_pconnect
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919083205|127.0.0.1|SQL|2010-09-19 08:32:05|SQL_logged from show_404, 43
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|_dbclose CLOSED
20100919083205|127.0.0.1|INFO|2010-09-19 08:32:05|pasteboard.Complete (31.862 seconds)
20100919083205|127.0.0.1|__ERROR_WARNING|2010-09-19 08:32:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|pasteboard.Started
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: useragents-config
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: dates-config
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: fopen-config
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: stopwords-config
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-database
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-useragent
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-hooks
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-sessions
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-cache
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-scaffolding
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-errors
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-uri
20100919083734|127.0.0.1|INCLUDE|2010-09-19 08:37:34|library: pb-logs
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_set_timezone: US/Pacific
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_sitewhoami: default Initialized
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_uri_segment: QUERY_STRING
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_useragent:  
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_useragent: 
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_init_session: Not Implemented
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_dbopen: mysql_pconnect
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919083734|127.0.0.1|SQL|2010-09-19 08:37:34|SQL_logged from show_404, 43
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|_dbclose CLOSED
20100919083734|127.0.0.1|INFO|2010-09-19 08:37:34|pasteboard.Complete (30.395 seconds)
20100919083734|127.0.0.1|__ERROR_WARNING|2010-09-19 08:37:34|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|pasteboard.Started
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: useragents-config
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: dates-config
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: fopen-config
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: stopwords-config
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-database
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-useragent
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-hooks
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-sessions
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-cache
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-scaffolding
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-errors
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-uri
20100919084237|127.0.0.1|INCLUDE|2010-09-19 08:42:37|library: pb-logs
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_set_timezone: US/Pacific
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_sitewhoami: default Initialized
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_uri_segment: QUERY_STRING
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_useragent:  
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_useragent: 
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_init_session: Not Implemented
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_dbopen: mysql_pconnect
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919084237|127.0.0.1|SQL|2010-09-19 08:42:37|SQL_logged from show_404, 43
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|_dbclose CLOSED
20100919084237|127.0.0.1|INFO|2010-09-19 08:42:37|pasteboard.Complete (30.432 seconds)
20100919084237|127.0.0.1|__ERROR_WARNING|2010-09-19 08:42:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|pasteboard.Started
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: useragents-config
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: dates-config
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: fopen-config
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: stopwords-config
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-database
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-useragent
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-hooks
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-sessions
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-cache
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-scaffolding
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-errors
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-uri
20100919085307|127.0.0.1|INCLUDE|2010-09-19 08:53:07|library: pb-logs
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_set_timezone: US/Pacific
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_sitewhoami: default Initialized
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_uri_segment: QUERY_STRING
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_useragent:  
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_useragent: 
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_init_session: Not Implemented
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_dbopen: mysql_pconnect
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919085307|127.0.0.1|SQL|2010-09-19 08:53:07|SQL_logged from show_404, 43
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|_dbclose CLOSED
20100919085307|127.0.0.1|INFO|2010-09-19 08:53:07|pasteboard.Complete (30.861 seconds)
20100919085307|127.0.0.1|__ERROR_WARNING|2010-09-19 08:53:07|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|pasteboard.Started
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: useragents-config
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: dates-config
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: fopen-config
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: stopwords-config
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-database
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-useragent
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-hooks
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-sessions
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-cache
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-scaffolding
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-errors
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-uri
20100919090338|127.0.0.1|INCLUDE|2010-09-19 09:03:38|library: pb-logs
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_set_timezone: US/Pacific
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_sitewhoami: default Initialized
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_uri_segment: QUERY_STRING
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_useragent:  
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_useragent: 
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_init_session: Not Implemented
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_dbopen: mysql_pconnect
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919090338|127.0.0.1|SQL|2010-09-19 09:03:38|SQL_logged from show_404, 43
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|_dbclose CLOSED
20100919090338|127.0.0.1|INFO|2010-09-19 09:03:38|pasteboard.Complete (36.186 seconds)
20100919090338|127.0.0.1|__ERROR_WARNING|2010-09-19 09:03:38|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|pasteboard.Started
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: useragents-config
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: dates-config
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: fopen-config
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: stopwords-config
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-database
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-useragent
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-hooks
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-sessions
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-cache
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-scaffolding
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-errors
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-uri
20100919091043|127.0.0.1|INCLUDE|2010-09-19 09:10:43|library: pb-logs
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_set_timezone: US/Pacific
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_sitewhoami: default Initialized
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_uri_segment: QUERY_STRING
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_useragent:  
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_useragent: 
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_init_session: Not Implemented
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_dbopen: mysql_pconnect
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919091043|127.0.0.1|SQL|2010-09-19 09:10:43|SQL_logged from show_404, 43
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|_dbclose CLOSED
20100919091043|127.0.0.1|INFO|2010-09-19 09:10:43|pasteboard.Complete (30.986 seconds)
20100919091043|127.0.0.1|__ERROR_WARNING|2010-09-19 09:10:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|pasteboard.Started
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: useragents-config
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: dates-config
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: fopen-config
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: stopwords-config
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-database
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-useragent
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-hooks
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-sessions
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-cache
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-scaffolding
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-errors
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-uri
20100919091415|127.0.0.1|INCLUDE|2010-09-19 09:14:15|library: pb-logs
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_set_timezone: US/Pacific
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_sitewhoami: default Initialized
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_uri_segment: QUERY_STRING
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_useragent:  
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_useragent: 
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_init_session: Not Implemented
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_dbopen: mysql_pconnect
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919091415|127.0.0.1|SQL|2010-09-19 09:14:15|SQL_logged from show_404, 43
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|_dbclose CLOSED
20100919091415|127.0.0.1|INFO|2010-09-19 09:14:15|pasteboard.Complete (31.082 seconds)
20100919091415|127.0.0.1|__ERROR_WARNING|2010-09-19 09:14:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|pasteboard.Started
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: useragents-config
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: dates-config
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: fopen-config
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: stopwords-config
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-database
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-useragent
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-hooks
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-sessions
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-cache
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-scaffolding
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-errors
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-uri
20100919092447|127.0.0.1|INCLUDE|2010-09-19 09:24:47|library: pb-logs
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_set_timezone: US/Pacific
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_sitewhoami: default Initialized
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_uri_segment: QUERY_STRING
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_useragent:  
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_useragent: 
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_init_session: Not Implemented
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_dbopen: mysql_pconnect
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919092447|127.0.0.1|SQL|2010-09-19 09:24:47|SQL_logged from show_404, 43
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|_dbclose CLOSED
20100919092447|127.0.0.1|INFO|2010-09-19 09:24:47|pasteboard.Complete (34.973 seconds)
20100919092447|127.0.0.1|__ERROR_WARNING|2010-09-19 09:24:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|pasteboard.Started
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: useragents-config
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: dates-config
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: fopen-config
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: stopwords-config
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-database
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-useragent
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-hooks
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-sessions
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-cache
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-scaffolding
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-errors
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-uri
20100919093522|127.0.0.1|INCLUDE|2010-09-19 09:35:22|library: pb-logs
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_set_timezone: US/Pacific
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_sitewhoami: default Initialized
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_uri_segment: QUERY_STRING
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_useragent:  
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_useragent: 
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_init_session: Not Implemented
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_dbopen: mysql_pconnect
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919093522|127.0.0.1|SQL|2010-09-19 09:35:22|SQL_logged from show_404, 43
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|_dbclose CLOSED
20100919093522|127.0.0.1|INFO|2010-09-19 09:35:22|pasteboard.Complete (30.372 seconds)
20100919093522|127.0.0.1|__ERROR_WARNING|2010-09-19 09:35:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|pasteboard.Started
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: useragents-config
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: dates-config
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: fopen-config
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: stopwords-config
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-database
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-useragent
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-hooks
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-sessions
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-cache
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-scaffolding
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-errors
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-uri
20100919094502|127.0.0.1|INCLUDE|2010-09-19 09:45:02|library: pb-logs
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_set_timezone: US/Pacific
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_sitewhoami: default Initialized
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_uri_segment: QUERY_STRING
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_useragent:  
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_useragent: 
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_init_session: Not Implemented
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_dbopen: mysql_pconnect
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919094502|127.0.0.1|SQL|2010-09-19 09:45:02|SQL_logged from show_404, 43
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|_dbclose CLOSED
20100919094502|127.0.0.1|INFO|2010-09-19 09:45:02|pasteboard.Complete (30.196 seconds)
20100919094502|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|pasteboard.Started
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: useragents-config
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: dates-config
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: fopen-config
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: stopwords-config
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-database
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-useragent
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-hooks
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-sessions
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-cache
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-scaffolding
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-errors
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-uri
20100919094553|127.0.0.1|INCLUDE|2010-09-19 09:45:53|library: pb-logs
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_set_timezone: US/Pacific
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_sitewhoami: default Initialized
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_uri_segment: QUERY_STRING
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_useragent:  
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_useragent: 
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_init_session: Not Implemented
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_dbopen: mysql_pconnect
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919094553|127.0.0.1|SQL|2010-09-19 09:45:53|SQL_logged from show_404, 43
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|_dbclose CLOSED
20100919094553|127.0.0.1|INFO|2010-09-19 09:45:53|pasteboard.Complete (30.102 seconds)
20100919094553|127.0.0.1|__ERROR_WARNING|2010-09-19 09:45:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|pasteboard.Started
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: useragents-config
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: dates-config
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: fopen-config
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: stopwords-config
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-database
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-useragent
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-hooks
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-sessions
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-cache
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-scaffolding
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-errors
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-uri
20100919095624|127.0.0.1|INCLUDE|2010-09-19 09:56:24|library: pb-logs
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_set_timezone: US/Pacific
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_sitewhoami: default Initialized
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_uri_segment: QUERY_STRING
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_useragent:  
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_useragent: 
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_init_session: Not Implemented
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_dbopen: mysql_pconnect
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919095624|127.0.0.1|SQL|2010-09-19 09:56:24|SQL_logged from show_404, 43
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|_dbclose CLOSED
20100919095624|127.0.0.1|INFO|2010-09-19 09:56:24|pasteboard.Complete (31.064 seconds)
20100919095624|127.0.0.1|__ERROR_WARNING|2010-09-19 09:56:24|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|pasteboard.Started
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: useragents-config
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: dates-config
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: fopen-config
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: stopwords-config
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-database
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-useragent
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-hooks
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-sessions
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-cache
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-scaffolding
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-errors
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-uri
20100919100657|127.0.0.1|INCLUDE|2010-09-19 10:06:57|library: pb-logs
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_set_timezone: US/Pacific
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_sitewhoami: default Initialized
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_uri_segment: QUERY_STRING
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_useragent:  
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_useragent: 
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_init_session: Not Implemented
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_dbopen: mysql_pconnect
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919100657|127.0.0.1|SQL|2010-09-19 10:06:57|SQL_logged from show_404, 43
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|_dbclose CLOSED
20100919100657|127.0.0.1|INFO|2010-09-19 10:06:57|pasteboard.Complete (30.259 seconds)
20100919100657|127.0.0.1|__ERROR_WARNING|2010-09-19 10:06:57|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|pasteboard.Started
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: useragents-config
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: dates-config
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: fopen-config
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: stopwords-config
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-database
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-useragent
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-hooks
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-sessions
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-cache
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-scaffolding
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-errors
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-uri
20100919101728|127.0.0.1|INCLUDE|2010-09-19 10:17:28|library: pb-logs
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_set_timezone: US/Pacific
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_sitewhoami: default Initialized
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_uri_segment: QUERY_STRING
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_useragent:  
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_useragent: 
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_init_session: Not Implemented
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_dbopen: mysql_pconnect
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919101728|127.0.0.1|SQL|2010-09-19 10:17:28|SQL_logged from show_404, 43
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|_dbclose CLOSED
20100919101728|127.0.0.1|INFO|2010-09-19 10:17:28|pasteboard.Complete (36.911 seconds)
20100919101728|127.0.0.1|__ERROR_WARNING|2010-09-19 10:17:28|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|pasteboard.Started
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: useragents-config
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: dates-config
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: fopen-config
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: stopwords-config
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-database
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-useragent
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-hooks
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-sessions
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-cache
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-scaffolding
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-errors
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-uri
20100919101819|127.0.0.1|INCLUDE|2010-09-19 10:18:19|library: pb-logs
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_set_timezone: US/Pacific
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_sitewhoami: default Initialized
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_uri_segment: QUERY_STRING
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_useragent:  
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_useragent: 
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_init_session: Not Implemented
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_dbopen: mysql_pconnect
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919101819|127.0.0.1|SQL|2010-09-19 10:18:19|SQL_logged from show_404, 43
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|_dbclose CLOSED
20100919101819|127.0.0.1|INFO|2010-09-19 10:18:19|pasteboard.Complete (31.095 seconds)
20100919101819|127.0.0.1|__ERROR_WARNING|2010-09-19 10:18:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|pasteboard.Started
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: useragents-config
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: dates-config
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: fopen-config
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: stopwords-config
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-database
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-useragent
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-hooks
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-sessions
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-cache
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-scaffolding
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-errors
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-uri
20100919102805|127.0.0.1|INCLUDE|2010-09-19 10:28:05|library: pb-logs
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_set_timezone: US/Pacific
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_sitewhoami: default Initialized
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_uri_segment: QUERY_STRING
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_useragent:  
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_useragent: 
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_init_session: Not Implemented
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_dbopen: mysql_pconnect
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919102805|127.0.0.1|SQL|2010-09-19 10:28:05|SQL_logged from show_404, 43
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|_dbclose CLOSED
20100919102805|127.0.0.1|INFO|2010-09-19 10:28:05|pasteboard.Complete (30.912 seconds)
20100919102805|127.0.0.1|__ERROR_WARNING|2010-09-19 10:28:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|pasteboard.Started
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: useragents-config
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: dates-config
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: fopen-config
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: stopwords-config
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-database
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-useragent
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-hooks
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-sessions
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-cache
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-scaffolding
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-errors
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-uri
20100919103836|127.0.0.1|INCLUDE|2010-09-19 10:38:36|library: pb-logs
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_set_timezone: US/Pacific
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_sitewhoami: default Initialized
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_uri_segment: QUERY_STRING
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_useragent:  
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_useragent: 
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_init_session: Not Implemented
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_dbopen: mysql_pconnect
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919103836|127.0.0.1|SQL|2010-09-19 10:38:36|SQL_logged from show_404, 43
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|_dbclose CLOSED
20100919103836|127.0.0.1|INFO|2010-09-19 10:38:36|pasteboard.Complete (30.222 seconds)
20100919103836|127.0.0.1|__ERROR_WARNING|2010-09-19 10:38:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|pasteboard.Started
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: useragents-config
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: dates-config
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: fopen-config
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: stopwords-config
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-database
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-useragent
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-hooks
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-sessions
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-cache
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-scaffolding
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-errors
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-uri
20100919104907|127.0.0.1|INCLUDE|2010-09-19 10:49:07|library: pb-logs
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_set_timezone: US/Pacific
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_sitewhoami: default Initialized
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_uri_segment: QUERY_STRING
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_useragent:  
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_useragent: 
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_init_session: Not Implemented
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_dbopen: mysql_pconnect
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919104907|127.0.0.1|SQL|2010-09-19 10:49:07|SQL_logged from show_404, 43
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|_dbclose CLOSED
20100919104907|127.0.0.1|INFO|2010-09-19 10:49:07|pasteboard.Complete (35.99 seconds)
20100919104907|127.0.0.1|__ERROR_WARNING|2010-09-19 10:49:07|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|pasteboard.Started
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: useragents-config
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: dates-config
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: fopen-config
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: stopwords-config
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-database
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-useragent
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-hooks
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-sessions
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-cache
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-scaffolding
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-errors
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-uri
20100919105106|127.0.0.1|INCLUDE|2010-09-19 10:51:06|library: pb-logs
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_set_timezone: US/Pacific
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_sitewhoami: default Initialized
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_uri_segment: QUERY_STRING
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_useragent:  
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_useragent: 
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_init_session: Not Implemented
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_dbopen: mysql_pconnect
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919105106|127.0.0.1|SQL|2010-09-19 10:51:06|SQL_logged from show_404, 43
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|_dbclose CLOSED
20100919105106|127.0.0.1|INFO|2010-09-19 10:51:06|pasteboard.Complete (30.302 seconds)
20100919105106|127.0.0.1|__ERROR_WARNING|2010-09-19 10:51:06|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|pasteboard.Started
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: useragents-config
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: dates-config
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: fopen-config
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: stopwords-config
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-database
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-useragent
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-hooks
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-sessions
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-cache
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-scaffolding
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-errors
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-uri
20100919105944|127.0.0.1|INCLUDE|2010-09-19 10:59:44|library: pb-logs
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_set_timezone: US/Pacific
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_sitewhoami: default Initialized
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_uri_segment: QUERY_STRING
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_useragent:  
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_useragent: 
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_init_session: Not Implemented
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_dbopen: mysql_pconnect
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919105944|127.0.0.1|SQL|2010-09-19 10:59:44|SQL_logged from show_404, 43
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|_dbclose CLOSED
20100919105944|127.0.0.1|INFO|2010-09-19 10:59:44|pasteboard.Complete (30.74 seconds)
20100919105944|127.0.0.1|__ERROR_WARNING|2010-09-19 10:59:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|pasteboard.Started
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: useragents-config
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: dates-config
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: fopen-config
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: stopwords-config
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-database
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-useragent
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-hooks
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-sessions
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-cache
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-scaffolding
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-errors
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-uri
20100919111015|127.0.0.1|INCLUDE|2010-09-19 11:10:15|library: pb-logs
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_set_timezone: US/Pacific
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_sitewhoami: default Initialized
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_uri_segment: QUERY_STRING
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_useragent:  
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_useragent: 
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_init_session: Not Implemented
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_dbopen: mysql_pconnect
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919111015|127.0.0.1|SQL|2010-09-19 11:10:15|SQL_logged from show_404, 43
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|_dbclose CLOSED
20100919111015|127.0.0.1|INFO|2010-09-19 11:10:15|pasteboard.Complete (30.574 seconds)
20100919111015|127.0.0.1|__ERROR_WARNING|2010-09-19 11:10:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|pasteboard.Started
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: useragents-config
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: dates-config
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: fopen-config
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: stopwords-config
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-database
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-useragent
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-hooks
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-sessions
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-cache
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-scaffolding
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-errors
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-uri
20100919112045|127.0.0.1|INCLUDE|2010-09-19 11:20:45|library: pb-logs
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_set_timezone: US/Pacific
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_sitewhoami: default Initialized
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_uri_segment: QUERY_STRING
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_useragent:  
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_useragent: 
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_init_session: Not Implemented
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_dbopen: mysql_pconnect
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919112045|127.0.0.1|SQL|2010-09-19 11:20:45|SQL_logged from show_404, 43
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|_dbclose CLOSED
20100919112045|127.0.0.1|INFO|2010-09-19 11:20:45|pasteboard.Complete (33.403 seconds)
20100919112045|127.0.0.1|__ERROR_WARNING|2010-09-19 11:20:45|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|pasteboard.Started
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: useragents-config
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: dates-config
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: fopen-config
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: stopwords-config
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-database
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-useragent
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-hooks
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-sessions
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-cache
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-scaffolding
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-errors
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-uri
20100919112535|127.0.0.1|INCLUDE|2010-09-19 11:25:35|library: pb-logs
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_set_timezone: US/Pacific
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_sitewhoami: default Initialized
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_uri_segment: QUERY_STRING
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_useragent:  
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_useragent: 
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_init_session: Not Implemented
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_dbopen: mysql_pconnect
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919112535|127.0.0.1|SQL|2010-09-19 11:25:35|SQL_logged from show_404, 43
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|_dbclose CLOSED
20100919112535|127.0.0.1|INFO|2010-09-19 11:25:35|pasteboard.Complete (30.677 seconds)
20100919112535|127.0.0.1|__ERROR_WARNING|2010-09-19 11:25:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|pasteboard.Started
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: useragents-config
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: dates-config
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: fopen-config
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: stopwords-config
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-database
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-useragent
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-hooks
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-sessions
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-cache
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-scaffolding
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-errors
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-uri
20100919113119|127.0.0.1|INCLUDE|2010-09-19 11:31:19|library: pb-logs
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_set_timezone: US/Pacific
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_sitewhoami: default Initialized
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_uri_segment: QUERY_STRING
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_useragent:  
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_useragent: 
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_init_session: Not Implemented
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_dbopen: mysql_pconnect
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919113119|127.0.0.1|SQL|2010-09-19 11:31:19|SQL_logged from show_404, 43
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|_dbclose CLOSED
20100919113119|127.0.0.1|INFO|2010-09-19 11:31:19|pasteboard.Complete (30.965 seconds)
20100919113119|127.0.0.1|__ERROR_WARNING|2010-09-19 11:31:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|pasteboard.Started
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: useragents-config
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: dates-config
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: fopen-config
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: stopwords-config
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-database
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-useragent
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-hooks
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-sessions
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-cache
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-scaffolding
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-errors
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-uri
20100919114150|127.0.0.1|INCLUDE|2010-09-19 11:41:50|library: pb-logs
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_set_timezone: US/Pacific
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_sitewhoami: default Initialized
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_uri_segment: QUERY_STRING
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_useragent:  
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_useragent: 
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_init_session: Not Implemented
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_dbopen: mysql_pconnect
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919114150|127.0.0.1|SQL|2010-09-19 11:41:50|SQL_logged from show_404, 43
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|_dbclose CLOSED
20100919114150|127.0.0.1|INFO|2010-09-19 11:41:50|pasteboard.Complete (31.063 seconds)
20100919114150|127.0.0.1|__ERROR_WARNING|2010-09-19 11:41:50|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|pasteboard.Started
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: useragents-config
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: dates-config
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: fopen-config
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: stopwords-config
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-database
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-useragent
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-hooks
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-sessions
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-cache
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-scaffolding
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-errors
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-uri
20100919115139|127.0.0.1|INCLUDE|2010-09-19 11:51:39|library: pb-logs
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_set_timezone: US/Pacific
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_sitewhoami: default Initialized
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_uri_segment: QUERY_STRING
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_useragent:  
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_useragent: 
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_init_session: Not Implemented
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_dbopen: mysql_pconnect
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919115139|127.0.0.1|SQL|2010-09-19 11:51:39|SQL_logged from show_404, 43
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|_dbclose CLOSED
20100919115139|127.0.0.1|INFO|2010-09-19 11:51:39|pasteboard.Complete (35.762 seconds)
20100919115139|127.0.0.1|__ERROR_WARNING|2010-09-19 11:51:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|pasteboard.Started
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: useragents-config
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: dates-config
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: fopen-config
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: stopwords-config
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-database
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-useragent
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-hooks
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-sessions
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-cache
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-scaffolding
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-errors
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-uri
20100919115939|127.0.0.1|INCLUDE|2010-09-19 11:59:39|library: pb-logs
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_set_timezone: US/Pacific
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_sitewhoami: default Initialized
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_uri_segment: QUERY_STRING
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_useragent:  
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_useragent: 
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_init_session: Not Implemented
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_dbopen: mysql_pconnect
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919115939|127.0.0.1|SQL|2010-09-19 11:59:39|SQL_logged from show_404, 43
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|_dbclose CLOSED
20100919115939|127.0.0.1|INFO|2010-09-19 11:59:39|pasteboard.Complete (31.251 seconds)
20100919115939|127.0.0.1|__ERROR_WARNING|2010-09-19 11:59:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|pasteboard.Started
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: useragents-config
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: dates-config
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: fopen-config
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: stopwords-config
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-database
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-useragent
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-hooks
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-sessions
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-cache
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-scaffolding
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-errors
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-uri
20100919120215|127.0.0.1|INCLUDE|2010-09-19 12:02:15|library: pb-logs
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_set_timezone: US/Pacific
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_sitewhoami: default Initialized
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_uri_segment: QUERY_STRING
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_useragent:  
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_useragent: 
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_init_session: Not Implemented
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_dbopen: mysql_pconnect
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100919120215|127.0.0.1|SQL|2010-09-19 12:02:15|SQL_logged from show_404, 43
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|_dbclose CLOSED
20100919120215|127.0.0.1|INFO|2010-09-19 12:02:15|pasteboard.Complete (30.865 seconds)
20100919120215|127.0.0.1|__ERROR_WARNING|2010-09-19 12:02:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
