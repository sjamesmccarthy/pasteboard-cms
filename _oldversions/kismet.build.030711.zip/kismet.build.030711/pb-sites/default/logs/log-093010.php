20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|pasteboard.Started
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: useragents-config
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: dates-config
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: fopen-config
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: stopwords-config
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-database
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-useragent
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-hooks
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-sessions
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-cache
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-scaffolding
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-errors
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-uri
20100930171912|127.0.0.1|INCLUDE|2010-09-30 17:19:12|library: pb-logs
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_set_timezone: US/Pacific
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_sitewhoami: default Initialized
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_uri_segment: QUERY_STRING
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_useragent:  
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_useragent: 
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_init_session: Not Implemented
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_dbopen: mysql_pconnect
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100930171912|127.0.0.1|SQL|2010-09-30 17:19:12|SQL_logged from show_404, 43
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|_dbclose CLOSED
20100930171912|127.0.0.1|INFO|2010-09-30 17:19:12|pasteboard.Complete (32.152 seconds)
20100930171912|127.0.0.1|__ERROR_WARNING|2010-09-30 17:19:12|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|pasteboard.Started
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: useragents-config
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: dates-config
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: fopen-config
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: stopwords-config
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-database
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-useragent
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-hooks
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-sessions
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-cache
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-scaffolding
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-errors
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-uri
20100930173023|127.0.0.1|INCLUDE|2010-09-30 17:30:23|library: pb-logs
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_set_timezone: US/Pacific
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_sitewhoami: default Initialized
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_uri_segment: QUERY_STRING
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_useragent:  
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_useragent: 
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_init_session: Not Implemented
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_dbopen: mysql_pconnect
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100930173023|127.0.0.1|SQL|2010-09-30 17:30:23|SQL_logged from show_404, 43
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|_dbclose CLOSED
20100930173023|127.0.0.1|INFO|2010-09-30 17:30:23|pasteboard.Complete (30.796 seconds)
20100930173023|127.0.0.1|__ERROR_WARNING|2010-09-30 17:30:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
