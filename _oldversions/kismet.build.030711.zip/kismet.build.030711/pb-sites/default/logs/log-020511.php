20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|pasteboard.Started
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: useragents-config
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: dates-config
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: fopen-config
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: stopwords-config
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-database
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-useragent
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-hooks
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-sessions
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-cache
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-scaffolding
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-errors
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-uri
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-logs
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_set_timezone: US/Pacific
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_sitewhoami: default Initialized
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_uri_segment: QUERY_STRING
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_useragent:  
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_useragent: 
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_init_session: Not Implemented
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|pasteboard.Started
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: useragents-config
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: dates-config
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: fopen-config
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: stopwords-config
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-database
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-useragent
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-hooks
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-sessions
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-cache
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-scaffolding
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-errors
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-uri
20110205113213|127.0.0.1|INCLUDE|2011-02-05 11:32:13|library: pb-logs
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_set_timezone: US/Pacific
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_sitewhoami: default Initialized
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_uri_segment: QUERY_STRING
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_useragent:  
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_useragent: 
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_init_session: Not Implemented
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_dbopen: mysql_pconnect
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_dbopen: mysql_pconnect
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205113213|127.0.0.1|SQL|2011-02-05 11:32:13|SQL_logged from show_404, 43
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205113213|127.0.0.1|SQL|2011-02-05 11:32:13|SQL_logged from show_404, 43
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_dbclose CLOSED
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|pasteboard.Complete (2.715 seconds)
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|_dbclose CLOSED
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110205113213|127.0.0.1|INFO|2011-02-05 11:32:13|pasteboard.Complete (3.719 seconds)
20110205113213|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|pasteboard.Started
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: useragents-config
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: dates-config
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: fopen-config
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: stopwords-config
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-database
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-useragent
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-hooks
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-sessions
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-cache
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-scaffolding
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-errors
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-uri
20110205113239|127.0.0.1|INCLUDE|2011-02-05 11:32:39|library: pb-logs
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_set_timezone: US/Pacific
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_sitewhoami: default Initialized
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_uri_segment: QUERY_STRING
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_useragent:  
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_useragent: 
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_init_session: Not Implemented
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_dbopen: mysql_pconnect
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205113239|127.0.0.1|SQL|2011-02-05 11:32:39|SQL_logged from show_404, 43
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|_dbclose CLOSED
20110205113239|127.0.0.1|INFO|2011-02-05 11:32:39|pasteboard.Complete (1.02 seconds)
20110205113239|127.0.0.1|__ERROR_WARNING|2011-02-05 11:32:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|pasteboard.Started
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: useragents-config
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: dates-config
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: fopen-config
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: stopwords-config
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-database
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-useragent
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-hooks
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-sessions
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-cache
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-scaffolding
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-errors
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-uri
20110205113304|127.0.0.1|INCLUDE|2011-02-05 11:33:04|library: pb-logs
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_set_timezone: US/Pacific
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_sitewhoami: default Initialized
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_uri_segment: QUERY_STRING
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_useragent:  
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_useragent: 
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_init_session: Not Implemented
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_dbopen: mysql_pconnect
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205113304|127.0.0.1|SQL|2011-02-05 11:33:04|SQL_logged from show_404, 43
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|_dbclose CLOSED
20110205113304|127.0.0.1|INFO|2011-02-05 11:33:04|pasteboard.Complete (1.011 seconds)
20110205113304|127.0.0.1|__ERROR_WARNING|2011-02-05 11:33:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|pasteboard.Started
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: useragents-config
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: dates-config
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: fopen-config
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: stopwords-config
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-database
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-useragent
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-hooks
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-sessions
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-cache
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-scaffolding
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-errors
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-uri
20110205113541|127.0.0.1|INCLUDE|2011-02-05 11:35:41|library: pb-logs
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_set_timezone: US/Pacific
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_sitewhoami: default Initialized
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_uri_segment: QUERY_STRING
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_useragent:  
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_useragent: 
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_init_session: Not Implemented
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_dbopen: mysql_pconnect
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205113541|127.0.0.1|SQL|2011-02-05 11:35:41|SQL_logged from show_404, 43
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|_dbclose CLOSED
20110205113541|127.0.0.1|INFO|2011-02-05 11:35:41|pasteboard.Complete (2.743 seconds)
20110205113541|127.0.0.1|__ERROR_WARNING|2011-02-05 11:35:41|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|pasteboard.Started
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: useragents-config
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: dates-config
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: fopen-config
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: stopwords-config
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-database
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-useragent
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-hooks
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-sessions
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-cache
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-scaffolding
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-errors
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-uri
20110205113739|127.0.0.1|INCLUDE|2011-02-05 11:37:39|library: pb-logs
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_set_timezone: US/Pacific
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_sitewhoami: default Initialized
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_uri_segment: QUERY_STRING
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_useragent:  
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_useragent: 
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_init_session: Not Implemented
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_dbopen: mysql_pconnect
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205113739|127.0.0.1|SQL|2011-02-05 11:37:39|SQL_logged from show_404, 43
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|_dbclose CLOSED
20110205113739|127.0.0.1|INFO|2011-02-05 11:37:39|pasteboard.Complete (2.185 seconds)
20110205113739|127.0.0.1|__ERROR_WARNING|2011-02-05 11:37:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|pasteboard.Started
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: useragents-config
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: dates-config
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: fopen-config
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: stopwords-config
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-database
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-useragent
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-hooks
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-sessions
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-cache
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-scaffolding
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-errors
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-uri
20110205114742|127.0.0.1|INCLUDE|2011-02-05 11:47:42|library: pb-logs
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_set_timezone: US/Pacific
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_sitewhoami: default Initialized
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_uri_segment: QUERY_STRING
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_useragent:  
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_useragent: 
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_init_session: Not Implemented
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_dbopen: mysql_pconnect
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205114742|127.0.0.1|SQL|2011-02-05 11:47:42|SQL_logged from show_404, 43
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|_dbclose CLOSED
20110205114742|127.0.0.1|INFO|2011-02-05 11:47:42|pasteboard.Complete (1.272 seconds)
20110205114742|127.0.0.1|__ERROR_WARNING|2011-02-05 11:47:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|pasteboard.Started
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: useragents-config
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: dates-config
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: fopen-config
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: stopwords-config
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-database
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-useragent
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-hooks
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-sessions
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-cache
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-scaffolding
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-errors
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-uri
20110205115229|127.0.0.1|INCLUDE|2011-02-05 11:52:29|library: pb-logs
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_set_timezone: US/Pacific
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_sitewhoami: default Initialized
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_uri_segment: QUERY_STRING
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_useragent:  
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_useragent: 
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_init_session: Not Implemented
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_dbopen: mysql_pconnect
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205115229|127.0.0.1|SQL|2011-02-05 11:52:29|SQL_logged from show_404, 43
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|_dbclose CLOSED
20110205115229|127.0.0.1|INFO|2011-02-05 11:52:29|pasteboard.Complete (1.604 seconds)
20110205115229|127.0.0.1|__ERROR_WARNING|2011-02-05 11:52:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|pasteboard.Started
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: useragents-config
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: dates-config
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: fopen-config
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: stopwords-config
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-database
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-useragent
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-hooks
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-sessions
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-cache
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-scaffolding
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-errors
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-uri
20110205115620|127.0.0.1|INCLUDE|2011-02-05 11:56:20|library: pb-logs
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_set_timezone: US/Pacific
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_sitewhoami: default Initialized
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_uri_segment: QUERY_STRING
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_useragent:  
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_useragent: 
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_init_session: Not Implemented
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_dbopen: mysql_pconnect
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110205115620|127.0.0.1|SQL|2011-02-05 11:56:20|SQL_logged from show_404, 43
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|_dbclose CLOSED
20110205115620|127.0.0.1|INFO|2011-02-05 11:56:20|pasteboard.Complete (1.724 seconds)
20110205115620|127.0.0.1|__ERROR_WARNING|2011-02-05 11:56:20|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
