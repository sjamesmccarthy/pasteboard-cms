20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|pasteboard.Started
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: useragents-config
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: dates-config
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: fopen-config
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: stopwords-config
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-database
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-useragent
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-hooks
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-sessions
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-cache
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-scaffolding
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-errors
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-uri
20110104212348|127.0.0.1|INCLUDE|2011-01-04 21:23:48|library: pb-logs
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_set_timezone: US/Pacific
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_sitewhoami: default Initialized
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_uri_segment: QUERY_STRING
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_useragent:  
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_useragent: 
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_init_session: Not Implemented
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_dbopen: mysql_pconnect
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110104212348|127.0.0.1|SQL|2011-01-04 21:23:48|SQL_logged from show_404, 43
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|_dbclose CLOSED
20110104212348|127.0.0.1|INFO|2011-01-04 21:23:48|pasteboard.Complete (1.738 seconds)
20110104212348|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:48|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|pasteboard.Started
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: useragents-config
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: dates-config
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: fopen-config
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: stopwords-config
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-database
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-useragent
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-hooks
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-sessions
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-cache
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-scaffolding
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-errors
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-uri
20110104212359|127.0.0.1|INCLUDE|2011-01-04 21:23:59|library: pb-logs
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_set_timezone: US/Pacific
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_sitewhoami: default Initialized
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_uri_segment: QUERY_STRING
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_useragent:  
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_useragent: 
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_init_session: Not Implemented
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_dbopen: mysql_pconnect
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110104212359|127.0.0.1|SQL|2011-01-04 21:23:59|SQL_logged from show_404, 43
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|_dbclose CLOSED
20110104212359|127.0.0.1|INFO|2011-01-04 21:23:59|pasteboard.Complete (1.034 seconds)
20110104212359|127.0.0.1|__ERROR_WARNING|2011-01-04 21:23:59|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|pasteboard.Started
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: useragents-config
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: dates-config
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: fopen-config
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: stopwords-config
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-database
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-useragent
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-hooks
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-sessions
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-cache
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-scaffolding
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-errors
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-uri
20110104212427|127.0.0.1|INCLUDE|2011-01-04 21:24:27|library: pb-logs
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_set_timezone: US/Pacific
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_sitewhoami: default Initialized
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_uri_segment: QUERY_STRING
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_useragent:  
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_useragent: 
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_init_session: Not Implemented
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_dbopen: mysql_pconnect
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110104212427|127.0.0.1|SQL|2011-01-04 21:24:27|SQL_logged from show_404, 43
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|_dbclose CLOSED
20110104212427|127.0.0.1|INFO|2011-01-04 21:24:27|pasteboard.Complete (0.981 seconds)
20110104212427|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:27|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|pasteboard.Started
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: useragents-config
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: dates-config
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: fopen-config
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: stopwords-config
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-database
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-useragent
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-hooks
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-sessions
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-cache
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-scaffolding
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-errors
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-uri
20110104212454|127.0.0.1|INCLUDE|2011-01-04 21:24:54|library: pb-logs
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_set_timezone: US/Pacific
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_sitewhoami: default Initialized
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_uri_segment: QUERY_STRING
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_useragent:  
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_useragent: 
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_init_session: Not Implemented
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_dbopen: mysql_pconnect
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110104212454|127.0.0.1|SQL|2011-01-04 21:24:54|SQL_logged from show_404, 43
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|_dbclose CLOSED
20110104212454|127.0.0.1|INFO|2011-01-04 21:24:54|pasteboard.Complete (1.407 seconds)
20110104212454|127.0.0.1|__ERROR_WARNING|2011-01-04 21:24:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|pasteboard.Started
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: useragents-config
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: dates-config
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: fopen-config
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: stopwords-config
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-database
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-useragent
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-hooks
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-sessions
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-cache
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-scaffolding
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-errors
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-uri
20110104212532|127.0.0.1|INCLUDE|2011-01-04 21:25:32|library: pb-logs
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_set_timezone: US/Pacific
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_sitewhoami: default Initialized
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_uri_segment: QUERY_STRING
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_useragent:  
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_useragent: 
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_init_session: Not Implemented
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_dbopen: mysql_pconnect
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110104212532|127.0.0.1|SQL|2011-01-04 21:25:32|SQL_logged from show_404, 43
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|_dbclose CLOSED
20110104212532|127.0.0.1|INFO|2011-01-04 21:25:32|pasteboard.Complete (0.404 seconds)
20110104212532|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:32|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|pasteboard.Started
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: useragents-config
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: dates-config
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: fopen-config
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: stopwords-config
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-database
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-useragent
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-hooks
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-sessions
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-cache
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-scaffolding
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-errors
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-uri
20110104212551|127.0.0.1|INCLUDE|2011-01-04 21:25:51|library: pb-logs
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_set_timezone: US/Pacific
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_sitewhoami: default Initialized
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_uri_segment: QUERY_STRING
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_useragent:  
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_useragent: 
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_init_session: Not Implemented
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_dbopen: mysql_pconnect
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110104212551|127.0.0.1|SQL|2011-01-04 21:25:51|SQL_logged from show_404, 43
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|_dbclose CLOSED
20110104212551|127.0.0.1|INFO|2011-01-04 21:25:51|pasteboard.Complete (0.641 seconds)
20110104212551|127.0.0.1|__ERROR_WARNING|2011-01-04 21:25:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|pasteboard.Started
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: useragents-config
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: dates-config
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: fopen-config
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: stopwords-config
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-database
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-useragent
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-hooks
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-sessions
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-cache
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-scaffolding
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-errors
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-uri
20110104212743|127.0.0.1|INCLUDE|2011-01-04 21:27:43|library: pb-logs
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_set_timezone: US/Pacific
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_sitewhoami: default Initialized
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_uri_segment: QUERY_STRING
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_useragent:  
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_useragent: 
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_init_session: Not Implemented
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_dbopen: mysql_pconnect
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110104212743|127.0.0.1|SQL|2011-01-04 21:27:43|SQL_logged from show_404, 43
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|_dbclose CLOSED
20110104212743|127.0.0.1|INFO|2011-01-04 21:27:43|pasteboard.Complete (1.883 seconds)
20110104212743|127.0.0.1|__ERROR_WARNING|2011-01-04 21:27:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|pasteboard.Started
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: useragents-config
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: dates-config
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: fopen-config
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: stopwords-config
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-database
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-useragent
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-hooks
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-sessions
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-cache
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-scaffolding
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-errors
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-uri
20110104212836|127.0.0.1|INCLUDE|2011-01-04 21:28:36|library: pb-logs
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_set_timezone: US/Pacific
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_sitewhoami: default Initialized
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_uri_segment: QUERY_STRING
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_useragent:  
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_useragent: 
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_init_session: Not Implemented
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_dbopen: mysql_pconnect
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110104212836|127.0.0.1|SQL|2011-01-04 21:28:36|SQL_logged from show_404, 43
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|_dbclose CLOSED
20110104212836|127.0.0.1|INFO|2011-01-04 21:28:36|pasteboard.Complete (0.27 seconds)
20110104212836|127.0.0.1|__ERROR_WARNING|2011-01-04 21:28:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
