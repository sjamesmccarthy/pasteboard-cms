20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|pasteboard.Started
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: useragents-config
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|pasteboard.Started
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: dates-config
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: useragents-config
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: fopen-config
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: dates-config
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: stopwords-config
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: fopen-config
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-database
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: stopwords-config
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-useragent
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-database
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-hooks
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-useragent
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-sessions
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-hooks
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-cache
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-sessions
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-scaffolding
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-cache
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-errors
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-scaffolding
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-uri
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-errors
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-logs
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-uri
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_set_timezone: US/Pacific
20110223132318|127.0.0.1|INCLUDE|2011-02-23 13:23:17|library: pb-logs
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_sitewhoami: default Initialized
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_set_timezone: US/Pacific
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_sitewhoami: default Initialized
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_uri_segment: QUERY_STRING
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_uri_segment: QUERY_STRING
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_useragent:  
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_useragent: 
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_init_session: Not Implemented
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_useragent:  
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_useragent: 
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_init_session: Not Implemented
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_dbopen: mysql_pconnect
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_dbopen: mysql_pconnect
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110223132318|127.0.0.1|SQL|2011-02-23 13:23:17|SQL_logged from show_404, 43
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110223132318|127.0.0.1|SQL|2011-02-23 13:23:17|SQL_logged from show_404, 43
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_dbclose CLOSED
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|pasteboard.Complete (3.656 seconds)
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|_dbclose CLOSED
20110223132318|127.0.0.1|INFO|2011-02-23 13:23:17|pasteboard.Complete (3.657 seconds)
20110223132318|127.0.0.1|__ERROR_WARNING|2011-02-23 13:23:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|pasteboard.Started
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: useragents-config
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: dates-config
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: fopen-config
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: stopwords-config
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-database
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-useragent
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-hooks
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-sessions
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-cache
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-scaffolding
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-errors
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-uri
20110223132543|127.0.0.1|INCLUDE|2011-02-23 13:25:43|library: pb-logs
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_set_timezone: US/Pacific
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_sitewhoami: default Initialized
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_uri_segment: QUERY_STRING
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_useragent:  
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_useragent: 
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_init_session: Not Implemented
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_dbopen: mysql_pconnect
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110223132543|127.0.0.1|SQL|2011-02-23 13:25:43|SQL_logged from show_404, 43
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|_dbclose CLOSED
20110223132543|127.0.0.1|INFO|2011-02-23 13:25:43|pasteboard.Complete (1.556 seconds)
20110223132543|127.0.0.1|__ERROR_WARNING|2011-02-23 13:25:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|pasteboard.Started
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: useragents-config
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: dates-config
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: fopen-config
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: stopwords-config
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-database
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-useragent
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-hooks
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-sessions
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-cache
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-scaffolding
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-errors
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-uri
20110223132655|127.0.0.1|INCLUDE|2011-02-23 13:26:55|library: pb-logs
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_set_timezone: US/Pacific
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_sitewhoami: default Initialized
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_uri_segment: QUERY_STRING
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_useragent:  
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_useragent: 
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_init_session: Not Implemented
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_dbopen: mysql_pconnect
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110223132655|127.0.0.1|SQL|2011-02-23 13:26:55|SQL_logged from show_404, 43
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|_dbclose CLOSED
20110223132655|127.0.0.1|INFO|2011-02-23 13:26:55|pasteboard.Complete (0.959 seconds)
20110223132655|127.0.0.1|__ERROR_WARNING|2011-02-23 13:26:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|pasteboard.Started
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: useragents-config
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: dates-config
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: fopen-config
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: stopwords-config
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-database
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-useragent
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-hooks
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-sessions
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-cache
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-scaffolding
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-errors
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-uri
20110223132735|127.0.0.1|INCLUDE|2011-02-23 13:27:35|library: pb-logs
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_set_timezone: US/Pacific
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_sitewhoami: default Initialized
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_uri_segment: QUERY_STRING
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_useragent:  
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_useragent: 
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_init_session: Not Implemented
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_dbopen: mysql_pconnect
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110223132735|127.0.0.1|SQL|2011-02-23 13:27:35|SQL_logged from show_404, 43
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|_dbclose CLOSED
20110223132735|127.0.0.1|INFO|2011-02-23 13:27:35|pasteboard.Complete (0.476 seconds)
20110223132735|127.0.0.1|__ERROR_WARNING|2011-02-23 13:27:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|pasteboard.Started
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: useragents-config
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: dates-config
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: fopen-config
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: stopwords-config
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-database
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-useragent
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-hooks
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-sessions
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-cache
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-scaffolding
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-errors
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-uri
20110223133320|127.0.0.1|INCLUDE|2011-02-23 13:33:20|library: pb-logs
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_set_timezone: US/Pacific
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_sitewhoami: default Initialized
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_uri_segment: QUERY_STRING
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_useragent:  
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_useragent: 
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_init_session: Not Implemented
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_dbopen: mysql_pconnect
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110223133320|127.0.0.1|SQL|2011-02-23 13:33:20|SQL_logged from show_404, 43
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|_dbclose CLOSED
20110223133320|127.0.0.1|INFO|2011-02-23 13:33:20|pasteboard.Complete (1.206 seconds)
20110223133320|127.0.0.1|__ERROR_WARNING|2011-02-23 13:33:20|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
