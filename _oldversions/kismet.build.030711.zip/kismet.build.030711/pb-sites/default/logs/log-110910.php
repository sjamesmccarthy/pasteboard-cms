20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|pasteboard.Started
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: useragents-config
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: dates-config
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: fopen-config
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: stopwords-config
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-database
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-useragent
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-hooks
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-sessions
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-cache
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-scaffolding
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-errors
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-uri
20101109201640|127.0.0.1|INCLUDE|2010-11-09 20:16:39|library: pb-logs
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_set_timezone: US/Pacific
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_sitewhoami: default Initialized
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_uri_segment: FRONT PAGE
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_uri_segment: INDEX_WEBROOT
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_useragent: Chrome 8.0.552.28
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_useragent: Mac OS X
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_init_session: Not Implemented
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_dbopen: mysql_pconnect
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|app: page Initialized
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201640|127.0.0.1|SQL|2010-11-09 20:16:39|SQL_logged from _get_front_page, 85
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|model: page_model.php Function: _get_front_page
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|app: page Function: view
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201640|127.0.0.1|SQL|2010-11-09 20:16:39|SQL_logged from _get_content_index, 22
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|model: page_model.php Function: _get_content_index
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|app: page Terminated
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|_dbclose CLOSED
20101109201640|127.0.0.1|INFO|2010-11-09 20:16:39|pasteboard.Complete (38.061 seconds)
20101109201640|127.0.0.1|__ERROR_WARNING|2010-11-09 20:16:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101109201718|127.0.0.1|INFO|2010-11-09 20:17:18|pasteboard.Started
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: useragents-config
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: dates-config
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: fopen-config
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: stopwords-config
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-database
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-useragent
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-hooks
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-sessions
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-cache
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-scaffolding
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-errors
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-uri
20101109201718|127.0.0.1|INCLUDE|2010-11-09 20:17:18|library: pb-logs
20101109201718|127.0.0.1|INFO|2010-11-09 20:17:18|_set_timezone: US/Pacific
20101109201718|127.0.0.1|INFO|2010-11-09 20:17:18|_sitewhoami: default Initialized
20101109201718|127.0.0.1|INFO|2010-11-09 20:17:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101109201718|127.0.0.1|INFO|2010-11-09 20:17:18|_uri_segment: SEGMENT_PATH
20101109201718|127.0.0.1|INFO|2010-11-09 20:17:18|_useragent: Chrome 8.0.552.28
20101109201718|127.0.0.1|INFO|2010-11-09 20:17:18|_useragent: Mac OS X
20101109201718|127.0.0.1|INFO|2010-11-09 20:17:18|_init_session: Not Implemented
20101109201718|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201718|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201718|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|pasteboard.Started
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: useragents-config
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: dates-config
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: fopen-config
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: stopwords-config
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-database
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-useragent
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-hooks
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-sessions
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-cache
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-scaffolding
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-errors
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-uri
20101109201732|127.0.0.1|INCLUDE|2010-11-09 20:17:32|library: pb-logs
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_set_timezone: US/Pacific
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_sitewhoami: default Initialized
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_uri_segment: FRONT PAGE
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_uri_segment: INDEX_WEBROOT
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_useragent: Chrome 8.0.552.28
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_useragent: Mac OS X
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_init_session: Not Implemented
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_dbopen: mysql_pconnect
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|app: page Initialized
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201732|127.0.0.1|SQL|2010-11-09 20:17:32|SQL_logged from _get_front_page, 85
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|model: page_model.php Function: _get_front_page
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|app: page Function: view
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201732|127.0.0.1|SQL|2010-11-09 20:17:32|SQL_logged from _get_content_index, 22
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|model: page_model.php Function: _get_content_index
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|app: page Terminated
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|_dbclose CLOSED
20101109201732|127.0.0.1|INFO|2010-11-09 20:17:32|pasteboard.Complete (31.893 seconds)
20101109201732|127.0.0.1|__ERROR_WARNING|2010-11-09 20:17:32|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|pasteboard.Started
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: useragents-config
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: dates-config
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: fopen-config
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: stopwords-config
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-database
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-useragent
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-hooks
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-sessions
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-cache
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-scaffolding
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-errors
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-uri
20101109201804|127.0.0.1|INCLUDE|2010-11-09 20:18:04|library: pb-logs
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_set_timezone: US/Pacific
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_sitewhoami: default Initialized
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_uri_segment: SEGMENT_PATH
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_useragent: Chrome 8.0.552.28
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_useragent: Mac OS X
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_init_session: Not Implemented
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_dbopen: mysql_pconnect
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201804|127.0.0.1|SQL|2010-11-09 20:18:04|SQL_logged from show_404, 43
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|_dbclose CLOSED
20101109201804|127.0.0.1|INFO|2010-11-09 20:18:04|pasteboard.Complete (30.756 seconds)
20101109201804|127.0.0.1|__ERROR_WARNING|2010-11-09 20:18:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|pasteboard.Started
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: useragents-config
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: dates-config
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: fopen-config
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: stopwords-config
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-database
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-useragent
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-hooks
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-sessions
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-cache
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-scaffolding
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-errors
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-uri
20101109201910|127.0.0.1|INCLUDE|2010-11-09 20:19:10|library: pb-logs
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_set_timezone: US/Pacific
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_sitewhoami: default Initialized
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_uri_segment: FRONT PAGE
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_uri_segment: INDEX_WEBROOT
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_useragent: Chrome 8.0.552.28
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_useragent: Mac OS X
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_init_session: Not Implemented
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_dbopen: mysql_pconnect
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|app: page Initialized
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201910|127.0.0.1|SQL|2010-11-09 20:19:10|SQL_logged from _get_front_page, 85
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|model: page_model.php Function: _get_front_page
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|app: page Function: view
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201910|127.0.0.1|SQL|2010-11-09 20:19:10|SQL_logged from _get_content_index, 22
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|model: page_model.php Function: _get_content_index
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|app: page Terminated
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|_dbclose CLOSED
20101109201910|127.0.0.1|INFO|2010-11-09 20:19:10|pasteboard.Complete (30.717 seconds)
20101109201910|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|pasteboard.Started
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: useragents-config
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: dates-config
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: fopen-config
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: stopwords-config
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-database
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-useragent
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-hooks
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-sessions
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-cache
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-scaffolding
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-errors
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-uri
20101109201940|127.0.0.1|INCLUDE|2010-11-09 20:19:40|library: pb-logs
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_set_timezone: US/Pacific
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_sitewhoami: default Initialized
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_uri_segment: FRONT PAGE
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_uri_segment: INDEX_WEBROOT
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_useragent: Chrome 8.0.552.28
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_useragent: Mac OS X
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_init_session: Not Implemented
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_dbopen: mysql_pconnect
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|app: page Initialized
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201940|127.0.0.1|SQL|2010-11-09 20:19:40|SQL_logged from _get_front_page, 85
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|model: page_model.php Function: _get_front_page
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|app: page Function: view
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101109201940|127.0.0.1|SQL|2010-11-09 20:19:40|SQL_logged from _get_content_index, 22
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|model: page_model.php Function: _get_content_index
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|app: page Terminated
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|_dbclose CLOSED
20101109201940|127.0.0.1|INFO|2010-11-09 20:19:40|pasteboard.Complete (31.499 seconds)
20101109201940|127.0.0.1|__ERROR_WARNING|2010-11-09 20:19:40|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
