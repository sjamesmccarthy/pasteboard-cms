20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|pasteboard.Started
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: useragents-config
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: dates-config
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: fopen-config
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: stopwords-config
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-database
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-useragent
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-hooks
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-sessions
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-cache
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-scaffolding
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-errors
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-uri
20100711204604|127.0.0.1|INCLUDE|2010-07-11 20:46:04|library: pb-logs
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_set_timezone: US/Pacific
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_sitewhoami: default Initialized
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_uri_segment: QUERY_STRING
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_useragent:  
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_useragent: 
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_init_session: Not Implemented
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|pasteboard.Started
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: useragents-config
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: dates-config
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: fopen-config
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: stopwords-config
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-database
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-useragent
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-hooks
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-sessions
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-cache
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-scaffolding
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-errors
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-uri
20100711204615|127.0.0.1|INCLUDE|2010-07-11 20:46:15|library: pb-logs
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_set_timezone: US/Pacific
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_sitewhoami: default Initialized
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_uri_segment: QUERY_STRING
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_useragent:  
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_useragent: 
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_init_session: Not Implemented
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_dbopen: mysql_pconnect
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100711204604|127.0.0.1|SQL|2010-07-11 20:46:04|SQL_logged from show_404, 43
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|_dbclose CLOSED
20100711204604|127.0.0.1|INFO|2010-07-11 20:46:04|pasteboard.Complete (31.812 seconds)
20100711204604|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_dbopen: mysql_pconnect
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100711204615|127.0.0.1|SQL|2010-07-11 20:46:15|SQL_logged from show_404, 43
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|_dbclose CLOSED
20100711204615|127.0.0.1|INFO|2010-07-11 20:46:15|pasteboard.Complete (30.377 seconds)
20100711204615|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|pasteboard.Started
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: useragents-config
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: dates-config
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: fopen-config
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: stopwords-config
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-database
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-useragent
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-hooks
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-sessions
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-cache
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-scaffolding
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-errors
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-uri
20100711204646|127.0.0.1|INCLUDE|2010-07-11 20:46:46|library: pb-logs
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_set_timezone: US/Pacific
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_sitewhoami: default Initialized
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_uri_segment: QUERY_STRING
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_useragent:  
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_useragent: 
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_init_session: Not Implemented
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_dbopen: mysql_pconnect
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100711204646|127.0.0.1|SQL|2010-07-11 20:46:46|SQL_logged from show_404, 43
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|_dbclose CLOSED
20100711204646|127.0.0.1|INFO|2010-07-11 20:46:46|pasteboard.Complete (30.498 seconds)
20100711204646|127.0.0.1|__ERROR_WARNING|2010-07-11 20:46:46|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|pasteboard.Started
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: useragents-config
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: dates-config
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: fopen-config
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: stopwords-config
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-database
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-useragent
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-hooks
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-sessions
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-cache
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-scaffolding
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-errors
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-uri
20100711211218|127.0.0.1|INCLUDE|2010-07-11 21:12:18|library: pb-logs
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_set_timezone: US/Pacific
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_sitewhoami: default Initialized
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_uri_segment: QUERY_STRING
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_useragent:  
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_useragent: 
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_init_session: Not Implemented
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_dbopen: mysql_pconnect
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100711211218|127.0.0.1|SQL|2010-07-11 21:12:18|SQL_logged from show_404, 43
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|_dbclose CLOSED
20100711211218|127.0.0.1|INFO|2010-07-11 21:12:18|pasteboard.Complete (31.194 seconds)
20100711211218|127.0.0.1|__ERROR_WARNING|2010-07-11 21:12:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
