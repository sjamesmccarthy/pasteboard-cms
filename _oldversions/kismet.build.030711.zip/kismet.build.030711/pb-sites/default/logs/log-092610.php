20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|pasteboard.Started
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: useragents-config
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: dates-config
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: fopen-config
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: stopwords-config
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-database
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-useragent
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-hooks
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-sessions
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-cache
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-scaffolding
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-errors
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-uri
20100926113355|127.0.0.1|INCLUDE|2010-09-26 11:33:54|library: pb-logs
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_set_timezone: US/Pacific
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_sitewhoami: default Initialized
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_uri_segment: QUERY_STRING
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_useragent:  
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_useragent: 
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_init_session: Not Implemented
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_dbopen: mysql_pconnect
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100926113355|127.0.0.1|SQL|2010-09-26 11:33:54|SQL_logged from show_404, 43
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|_dbclose CLOSED
20100926113355|127.0.0.1|INFO|2010-09-26 11:33:54|pasteboard.Complete (32.456 seconds)
20100926113355|127.0.0.1|__ERROR_WARNING|2010-09-26 11:33:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|pasteboard.Started
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: useragents-config
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: dates-config
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: fopen-config
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: stopwords-config
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-database
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-useragent
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-hooks
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-sessions
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-cache
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-scaffolding
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-errors
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-uri
20100926113738|127.0.0.1|INCLUDE|2010-09-26 11:37:38|library: pb-logs
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_set_timezone: US/Pacific
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_sitewhoami: default Initialized
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_uri_segment: QUERY_STRING
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_useragent:  
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_useragent: 
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_init_session: Not Implemented
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_dbopen: mysql_pconnect
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100926113738|127.0.0.1|SQL|2010-09-26 11:37:38|SQL_logged from show_404, 43
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|_dbclose CLOSED
20100926113738|127.0.0.1|INFO|2010-09-26 11:37:38|pasteboard.Complete (30.741 seconds)
20100926113738|127.0.0.1|__ERROR_WARNING|2010-09-26 11:37:38|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
