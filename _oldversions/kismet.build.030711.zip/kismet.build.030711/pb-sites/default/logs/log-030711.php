20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|pasteboard.Started
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: useragents-config
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: dates-config
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: fopen-config
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: stopwords-config
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-database
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-useragent
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-hooks
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-sessions
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-cache
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-scaffolding
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-errors
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-uri
20110307182243|127.0.0.1|INCLUDE|2011-03-07 18:22:43|library: pb-logs
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_set_timezone: US/Pacific
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_sitewhoami: default Initialized
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_uri_segment: FRONT PAGE
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_uri_segment: INDEX_WEBROOT
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_useragent: Chrome 10.0.648.127
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_useragent: Mac OS X
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_init_session: Not Implemented
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_dbopen: mysql_pconnect
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|app: page Initialized
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110307182243|127.0.0.1|SQL|2011-03-07 18:22:43|SQL_logged from _get_front_page, 85
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|model: page_model.php Function: _get_front_page
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|app: page Function: view
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110307182243|127.0.0.1|SQL|2011-03-07 18:22:43|SQL_logged from _get_content_index, 22
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|model: page_model.php Function: _get_content_index
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|app: page Terminated
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|_dbclose CLOSED
20110307182243|127.0.0.1|INFO|2011-03-07 18:22:43|pasteboard.Complete (4.486 seconds)
20110307182243|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|pasteboard.Started
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: useragents-config
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: dates-config
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: fopen-config
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: stopwords-config
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-database
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-useragent
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-hooks
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-sessions
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-cache
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-scaffolding
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-errors
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-uri
20110307182248|127.0.0.1|INCLUDE|2011-03-07 18:22:48|library: pb-logs
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_set_timezone: US/Pacific
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_sitewhoami: default Initialized
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_uri_segment: SEGMENT_PATH
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_useragent: Chrome 10.0.648.127
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_useragent: Mac OS X
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_init_session: Not Implemented
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_dbopen: mysql_pconnect
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110307182248|127.0.0.1|SQL|2011-03-07 18:22:48|SQL_logged from show_404, 43
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|_dbclose CLOSED
20110307182248|127.0.0.1|INFO|2011-03-07 18:22:48|pasteboard.Complete (2.027 seconds)
20110307182248|127.0.0.1|__ERROR_WARNING|2011-03-07 18:22:48|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|pasteboard.Started
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: useragents-config
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: dates-config
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: fopen-config
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: stopwords-config
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-database
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-useragent
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-hooks
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-sessions
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-cache
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-scaffolding
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-errors
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-uri
20110307183622|127.0.0.1|INCLUDE|2011-03-07 18:36:22|library: pb-logs
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_set_timezone: US/Pacific
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_sitewhoami: default Initialized
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_uri_segment: FRONT PAGE
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_uri_segment: INDEX_WEBROOT
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_useragent: Chrome 10.0.648.127
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_useragent: Mac OS X
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_init_session: Not Implemented
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 308]
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_dbopen: mysql_pconnect
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|app: page Initialized
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 331]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 332]
20110307183622|127.0.0.1|SQL|2011-03-07 18:36:22|SQL_logged from _get_front_page, 85
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|model: page_model.php Function: _get_front_page
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|app: page Function: view
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 331]
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 332]
20110307183622|127.0.0.1|SQL|2011-03-07 18:36:22|SQL_logged from _get_content_index, 22
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|model: page_model.php Function: _get_content_index
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|Template Not Found: /Users/james/Dropbox/kismet.pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-system.php
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|app: page Terminated
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 318]
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|_dbclose CLOSED
20110307183622|127.0.0.1|INFO|2011-03-07 18:36:22|pasteboard.Complete (2.457 seconds)
20110307183622|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|pasteboard.Started
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: useragents-config
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: dates-config
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: fopen-config
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: stopwords-config
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-database
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-useragent
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-hooks
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-sessions
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-cache
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-scaffolding
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-errors
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-uri
20110307183625|127.0.0.1|INCLUDE|2011-03-07 18:36:25|library: pb-logs
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_set_timezone: US/Pacific
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_sitewhoami: default Initialized
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_uri_segment: SEGMENT_PATH
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_useragent: Chrome 10.0.648.127
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_useragent: Mac OS X
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_init_session: Not Implemented
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 308]
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_dbopen: mysql_pconnect
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-bootstrap.php
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 331]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 332]
20110307183625|127.0.0.1|SQL|2011-03-07 18:36:25|SQL_logged from show_404, 43
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 67]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 68]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 69]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 71]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 72]
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|Template Not Found: /Users/james/Dropbox/kismet.pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-system.php
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 318]
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|_dbclose CLOSED
20110307183625|127.0.0.1|INFO|2011-03-07 18:36:25|pasteboard.Complete (1.405 seconds)
20110307183625|127.0.0.1|__ERROR_WARNING|2011-03-07 18:36:25|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|pasteboard.Started
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: useragents-config
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: dates-config
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: fopen-config
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: stopwords-config
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-database
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-useragent
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-hooks
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-sessions
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-cache
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-scaffolding
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-errors
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-uri
20110307183810|127.0.0.1|INCLUDE|2011-03-07 18:38:10|library: pb-logs
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_set_timezone: US/Pacific
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_sitewhoami: default Initialized
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_uri_segment: FRONT PAGE
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_uri_segment: INDEX_WEBROOT
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_useragent: Chrome 10.0.648.127
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_useragent: Mac OS X
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_init_session: Not Implemented
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 308]
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_dbopen: mysql_pconnect
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|app: page Initialized
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 331]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 332]
20110307183810|127.0.0.1|SQL|2011-03-07 18:38:10|SQL_logged from _get_front_page, 85
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|model: page_model.php Function: _get_front_page
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|app: page Function: view
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 331]
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 332]
20110307183810|127.0.0.1|SQL|2011-03-07 18:38:10|SQL_logged from _get_content_index, 22
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|model: page_model.php Function: _get_content_index
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|Template Not Found: /Users/james/Dropbox/kismet.pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-system.php
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|app: page Terminated
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 318]
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|_dbclose CLOSED
20110307183810|127.0.0.1|INFO|2011-03-07 18:38:10|pasteboard.Complete (1.567 seconds)
20110307183810|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|pasteboard.Started
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: useragents-config
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: dates-config
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: fopen-config
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: stopwords-config
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-database
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-useragent
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-hooks
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-sessions
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-cache
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-scaffolding
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-errors
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-uri
20110307183812|127.0.0.1|INCLUDE|2011-03-07 18:38:12|library: pb-logs
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_set_timezone: US/Pacific
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_sitewhoami: default Initialized
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_uri_segment: SEGMENT_PATH
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_useragent: Chrome 10.0.648.127
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_useragent: Mac OS X
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_init_session: Not Implemented
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 308]
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_dbopen: mysql_pconnect
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-bootstrap.php
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 331]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 332]
20110307183812|127.0.0.1|SQL|2011-03-07 18:38:12|SQL_logged from show_404, 43
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 67]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 68]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 69]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 71]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-errors.php, 72]
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|Template Not Found: /Users/james/Dropbox/kismet.pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-system.php
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 318]
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|_dbclose CLOSED
20110307183812|127.0.0.1|INFO|2011-03-07 18:38:12|pasteboard.Complete (0.374 seconds)
20110307183812|127.0.0.1|__ERROR_WARNING|2011-03-07 18:38:12|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|pasteboard.Started
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: useragents-config
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: dates-config
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: fopen-config
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: stopwords-config
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-database
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-useragent
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-hooks
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-sessions
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-cache
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-scaffolding
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-errors
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-uri
20110307184227|127.0.0.1|INCLUDE|2011-03-07 18:42:27|library: pb-logs
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_set_timezone: US/Pacific
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_sitewhoami: default Initialized
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_uri_segment: FRONT PAGE
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_uri_segment: INDEX_WEBROOT
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_useragent: Chrome 10.0.648.127
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_useragent: Mac OS X
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_init_session: Not Implemented
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 300]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 306]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 308]
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_dbopen: mysql_pconnect
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|app: page Initialized
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 331]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 332]
20110307184227|127.0.0.1|SQL|2011-03-07 18:42:27|SQL_logged from _get_front_page, 85
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|model: page_model.php Function: _get_front_page
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|app: page Function: view
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/kismet.pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 331]
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 332]
20110307184227|127.0.0.1|SQL|2011-03-07 18:42:27|SQL_logged from _get_content_index, 22
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|model: page_model.php Function: _get_content_index
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|Template Not Found: /Users/james/Dropbox/kismet.pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-system.php
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|app: page Terminated
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-database.php, 318]
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|_dbclose CLOSED
20110307184227|127.0.0.1|INFO|2011-03-07 18:42:27|pasteboard.Complete (1.639 seconds)
20110307184227|127.0.0.1|__ERROR_WARNING|2011-03-07 18:42:27|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/kismet.pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
