20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|pasteboard.Started
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: useragents-config
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: dates-config
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: fopen-config
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: stopwords-config
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-database
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-useragent
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-hooks
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-sessions
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-cache
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-scaffolding
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-errors
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-uri
20110109143513|127.0.0.1|INCLUDE|2011-01-09 14:35:13|library: pb-logs
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_set_timezone: US/Pacific
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_sitewhoami: default Initialized
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_uri_segment: QUERY_STRING
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_useragent:  
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_useragent: 
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_init_session: Not Implemented
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_dbopen: mysql_pconnect
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109143513|127.0.0.1|SQL|2011-01-09 14:35:13|SQL_logged from show_404, 43
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|_dbclose CLOSED
20110109143513|127.0.0.1|INFO|2011-01-09 14:35:13|pasteboard.Complete (1.932 seconds)
20110109143513|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|pasteboard.Started
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: useragents-config
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: dates-config
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: fopen-config
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: stopwords-config
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-database
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-useragent
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-hooks
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-sessions
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-cache
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-scaffolding
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-errors
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-uri
20110109143515|127.0.0.1|INCLUDE|2011-01-09 14:35:15|library: pb-logs
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_set_timezone: US/Pacific
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_sitewhoami: default Initialized
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_uri_segment: QUERY_STRING
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_useragent:  
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_useragent: 
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_init_session: Not Implemented
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_dbopen: mysql_pconnect
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109143515|127.0.0.1|SQL|2011-01-09 14:35:15|SQL_logged from show_404, 43
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|_dbclose CLOSED
20110109143515|127.0.0.1|INFO|2011-01-09 14:35:15|pasteboard.Complete (0.948 seconds)
20110109143515|127.0.0.1|__ERROR_WARNING|2011-01-09 14:35:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|pasteboard.Started
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: useragents-config
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: dates-config
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: fopen-config
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: stopwords-config
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-database
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-useragent
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-hooks
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-sessions
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-cache
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-scaffolding
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-errors
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-uri
20110109143600|127.0.0.1|INCLUDE|2011-01-09 14:36:00|library: pb-logs
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_set_timezone: US/Pacific
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_sitewhoami: default Initialized
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_uri_segment: QUERY_STRING
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_useragent:  
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_useragent: 
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_init_session: Not Implemented
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_dbopen: mysql_pconnect
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109143600|127.0.0.1|SQL|2011-01-09 14:36:00|SQL_logged from show_404, 43
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|_dbclose CLOSED
20110109143600|127.0.0.1|INFO|2011-01-09 14:36:00|pasteboard.Complete (0.987 seconds)
20110109143600|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|pasteboard.Started
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: useragents-config
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: dates-config
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: fopen-config
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: stopwords-config
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-database
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-useragent
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-hooks
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-sessions
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-cache
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-scaffolding
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-errors
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-uri
20110109143603|127.0.0.1|INCLUDE|2011-01-09 14:36:03|library: pb-logs
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_set_timezone: US/Pacific
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_sitewhoami: default Initialized
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_uri_segment: QUERY_STRING
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_useragent:  
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_useragent: 
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_init_session: Not Implemented
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_dbopen: mysql_pconnect
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109143603|127.0.0.1|SQL|2011-01-09 14:36:03|SQL_logged from show_404, 43
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|_dbclose CLOSED
20110109143603|127.0.0.1|INFO|2011-01-09 14:36:03|pasteboard.Complete (0.463 seconds)
20110109143603|127.0.0.1|__ERROR_WARNING|2011-01-09 14:36:03|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|pasteboard.Started
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: useragents-config
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: dates-config
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: fopen-config
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: stopwords-config
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-database
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-useragent
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-hooks
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-sessions
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-cache
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-scaffolding
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-errors
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-uri
20110109143722|127.0.0.1|INCLUDE|2011-01-09 14:37:22|library: pb-logs
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_set_timezone: US/Pacific
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_sitewhoami: default Initialized
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_uri_segment: QUERY_STRING
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_useragent:  
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_useragent: 
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_init_session: Not Implemented
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_dbopen: mysql_pconnect
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109143722|127.0.0.1|SQL|2011-01-09 14:37:22|SQL_logged from show_404, 43
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|_dbclose CLOSED
20110109143722|127.0.0.1|INFO|2011-01-09 14:37:22|pasteboard.Complete (2.568 seconds)
20110109143722|127.0.0.1|__ERROR_WARNING|2011-01-09 14:37:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|pasteboard.Started
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: useragents-config
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: dates-config
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: fopen-config
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: stopwords-config
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-database
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-useragent
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-hooks
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-sessions
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-cache
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-scaffolding
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-errors
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-uri
20110109143809|127.0.0.1|INCLUDE|2011-01-09 14:38:09|library: pb-logs
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_set_timezone: US/Pacific
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_sitewhoami: default Initialized
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_uri_segment: QUERY_STRING
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_useragent:  
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_useragent: 
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_init_session: Not Implemented
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_dbopen: mysql_pconnect
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109143809|127.0.0.1|SQL|2011-01-09 14:38:09|SQL_logged from show_404, 43
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|_dbclose CLOSED
20110109143809|127.0.0.1|INFO|2011-01-09 14:38:09|pasteboard.Complete (0.565 seconds)
20110109143809|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:09|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|pasteboard.Started
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: useragents-config
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: dates-config
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: fopen-config
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: stopwords-config
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-database
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-useragent
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-hooks
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-sessions
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-cache
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-scaffolding
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-errors
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-uri
20110109143823|127.0.0.1|INCLUDE|2011-01-09 14:38:23|library: pb-logs
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_set_timezone: US/Pacific
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_sitewhoami: default Initialized
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_uri_segment: QUERY_STRING
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_useragent:  
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_useragent: 
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_init_session: Not Implemented
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_dbopen: mysql_pconnect
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109143823|127.0.0.1|SQL|2011-01-09 14:38:23|SQL_logged from show_404, 43
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|_dbclose CLOSED
20110109143823|127.0.0.1|INFO|2011-01-09 14:38:23|pasteboard.Complete (0.519 seconds)
20110109143823|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|pasteboard.Started
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: useragents-config
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: dates-config
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: fopen-config
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: stopwords-config
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-database
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-useragent
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-hooks
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-sessions
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-cache
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-scaffolding
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-errors
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-uri
20110109143826|127.0.0.1|INCLUDE|2011-01-09 14:38:26|library: pb-logs
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_set_timezone: US/Pacific
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_sitewhoami: default Initialized
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_uri_segment: QUERY_STRING
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_useragent:  
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_useragent: 
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_init_session: Not Implemented
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_dbopen: mysql_pconnect
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109143826|127.0.0.1|SQL|2011-01-09 14:38:26|SQL_logged from show_404, 43
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|_dbclose CLOSED
20110109143826|127.0.0.1|INFO|2011-01-09 14:38:26|pasteboard.Complete (5.37 seconds)
20110109143826|127.0.0.1|__ERROR_WARNING|2011-01-09 14:38:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|pasteboard.Started
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: useragents-config
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: dates-config
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: fopen-config
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: stopwords-config
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-database
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-useragent
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-hooks
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-sessions
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-cache
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-scaffolding
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-errors
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-uri
20110109144151|127.0.0.1|INCLUDE|2011-01-09 14:41:51|library: pb-logs
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_set_timezone: US/Pacific
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_sitewhoami: default Initialized
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_uri_segment: QUERY_STRING
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_useragent:  
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_useragent: 
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_init_session: Not Implemented
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_dbopen: mysql_pconnect
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109144151|127.0.0.1|SQL|2011-01-09 14:41:51|SQL_logged from show_404, 43
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|_dbclose CLOSED
20110109144151|127.0.0.1|INFO|2011-01-09 14:41:51|pasteboard.Complete (1.128 seconds)
20110109144151|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|pasteboard.Started
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: useragents-config
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: dates-config
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: fopen-config
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: stopwords-config
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-database
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-useragent
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-hooks
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-sessions
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-cache
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-scaffolding
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-errors
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-uri
20110109144158|127.0.0.1|INCLUDE|2011-01-09 14:41:58|library: pb-logs
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_set_timezone: US/Pacific
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_sitewhoami: default Initialized
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_uri_segment: QUERY_STRING
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_useragent:  
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_useragent: 
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_init_session: Not Implemented
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_dbopen: mysql_pconnect
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110109144158|127.0.0.1|SQL|2011-01-09 14:41:58|SQL_logged from show_404, 43
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|_dbclose CLOSED
20110109144158|127.0.0.1|INFO|2011-01-09 14:41:58|pasteboard.Complete (0.195 seconds)
20110109144158|127.0.0.1|__ERROR_WARNING|2011-01-09 14:41:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
