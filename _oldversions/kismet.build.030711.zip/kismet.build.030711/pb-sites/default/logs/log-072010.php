20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|pasteboard.Started
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: useragents-config
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: dates-config
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: fopen-config
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: stopwords-config
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-database
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-useragent
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-hooks
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-sessions
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-cache
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-scaffolding
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-errors
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-uri
20100720132549|127.0.0.1|INCLUDE|2010-07-20 13:25:49|library: pb-logs
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_set_timezone: US/Pacific
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_sitewhoami: default Initialized
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_uri_segment: QUERY_STRING
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_useragent:  
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_useragent: 
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_init_session: Not Implemented
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_dbopen: mysql_pconnect
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720132549|127.0.0.1|SQL|2010-07-20 13:25:49|SQL_logged from show_404, 43
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|_dbclose CLOSED
20100720132549|127.0.0.1|INFO|2010-07-20 13:25:49|pasteboard.Complete (2.716 seconds)
20100720132549|127.0.0.1|__ERROR_WARNING|2010-07-20 13:25:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|pasteboard.Started
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: useragents-config
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: dates-config
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: fopen-config
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: stopwords-config
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-database
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-useragent
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-hooks
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-sessions
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-cache
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-scaffolding
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-errors
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-uri
20100720132721|127.0.0.1|INCLUDE|2010-07-20 13:27:21|library: pb-logs
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_set_timezone: US/Pacific
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_sitewhoami: default Initialized
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_uri_segment: QUERY_STRING
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_useragent:  
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_useragent: 
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_init_session: Not Implemented
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_dbopen: mysql_pconnect
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720132721|127.0.0.1|SQL|2010-07-20 13:27:21|SQL_logged from show_404, 43
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|_dbclose CLOSED
20100720132721|127.0.0.1|INFO|2010-07-20 13:27:21|pasteboard.Complete (0.972 seconds)
20100720132721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:27:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|pasteboard.Started
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: useragents-config
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: dates-config
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: fopen-config
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: stopwords-config
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-database
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-useragent
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-hooks
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-sessions
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-cache
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-scaffolding
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-errors
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-uri
20100720133552|127.0.0.1|INCLUDE|2010-07-20 13:35:52|library: pb-logs
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_set_timezone: US/Pacific
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_sitewhoami: default Initialized
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_uri_segment: QUERY_STRING
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_useragent:  
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_useragent: 
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_init_session: Not Implemented
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_dbopen: mysql_pconnect
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720133552|127.0.0.1|SQL|2010-07-20 13:35:52|SQL_logged from show_404, 43
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|_dbclose CLOSED
20100720133552|127.0.0.1|INFO|2010-07-20 13:35:52|pasteboard.Complete (0.154 seconds)
20100720133552|127.0.0.1|__ERROR_WARNING|2010-07-20 13:35:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|pasteboard.Started
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: useragents-config
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: dates-config
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: fopen-config
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: stopwords-config
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-database
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-useragent
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-hooks
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-sessions
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-cache
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-scaffolding
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-errors
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-uri
20100720134553|127.0.0.1|INCLUDE|2010-07-20 13:45:53|library: pb-logs
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_set_timezone: US/Pacific
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_sitewhoami: default Initialized
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_uri_segment: QUERY_STRING
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_useragent:  
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_useragent: 
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_init_session: Not Implemented
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_dbopen: mysql_pconnect
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720134553|127.0.0.1|SQL|2010-07-20 13:45:53|SQL_logged from show_404, 43
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|_dbclose CLOSED
20100720134553|127.0.0.1|INFO|2010-07-20 13:45:53|pasteboard.Complete (1.441 seconds)
20100720134553|127.0.0.1|__ERROR_WARNING|2010-07-20 13:45:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|pasteboard.Started
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: useragents-config
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: dates-config
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: fopen-config
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: stopwords-config
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-database
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-useragent
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-hooks
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-sessions
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-cache
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-scaffolding
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-errors
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-uri
20100720135556|127.0.0.1|INCLUDE|2010-07-20 13:55:56|library: pb-logs
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_set_timezone: US/Pacific
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_sitewhoami: default Initialized
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_uri_segment: QUERY_STRING
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_useragent:  
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_useragent: 
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_init_session: Not Implemented
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_dbopen: mysql_pconnect
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720135556|127.0.0.1|SQL|2010-07-20 13:55:56|SQL_logged from show_404, 43
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|_dbclose CLOSED
20100720135556|127.0.0.1|INFO|2010-07-20 13:55:56|pasteboard.Complete (0.296 seconds)
20100720135556|127.0.0.1|__ERROR_WARNING|2010-07-20 13:55:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|pasteboard.Started
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: useragents-config
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: dates-config
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: fopen-config
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: stopwords-config
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-database
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-useragent
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-hooks
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-sessions
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-cache
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-scaffolding
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-errors
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-uri
20100720135721|127.0.0.1|INCLUDE|2010-07-20 13:57:21|library: pb-logs
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_set_timezone: US/Pacific
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_sitewhoami: default Initialized
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_uri_segment: QUERY_STRING
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_useragent:  
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_useragent: 
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_init_session: Not Implemented
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_dbopen: mysql_pconnect
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720135721|127.0.0.1|SQL|2010-07-20 13:57:21|SQL_logged from show_404, 43
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|_dbclose CLOSED
20100720135721|127.0.0.1|INFO|2010-07-20 13:57:21|pasteboard.Complete (0.625 seconds)
20100720135721|127.0.0.1|__ERROR_WARNING|2010-07-20 13:57:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|pasteboard.Started
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: useragents-config
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: dates-config
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: fopen-config
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: stopwords-config
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-database
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-useragent
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-hooks
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-sessions
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-cache
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-scaffolding
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-errors
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-uri
20100720140556|127.0.0.1|INCLUDE|2010-07-20 14:05:56|library: pb-logs
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_set_timezone: US/Pacific
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_sitewhoami: default Initialized
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_uri_segment: QUERY_STRING
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_useragent:  
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_useragent: 
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_init_session: Not Implemented
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_dbopen: mysql_pconnect
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720140556|127.0.0.1|SQL|2010-07-20 14:05:56|SQL_logged from show_404, 43
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|_dbclose CLOSED
20100720140556|127.0.0.1|INFO|2010-07-20 14:05:56|pasteboard.Complete (2.113 seconds)
20100720140556|127.0.0.1|__ERROR_WARNING|2010-07-20 14:05:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|pasteboard.Started
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: useragents-config
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: dates-config
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: fopen-config
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: stopwords-config
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-database
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-useragent
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-hooks
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-sessions
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-cache
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-scaffolding
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-errors
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-uri
20100720140816|127.0.0.1|INCLUDE|2010-07-20 14:08:16|library: pb-logs
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_set_timezone: US/Pacific
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_sitewhoami: default Initialized
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_uri_segment: QUERY_STRING
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_useragent:  
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_useragent: 
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_init_session: Not Implemented
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_dbopen: mysql_pconnect
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720140816|127.0.0.1|SQL|2010-07-20 14:08:16|SQL_logged from show_404, 43
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|_dbclose CLOSED
20100720140816|127.0.0.1|INFO|2010-07-20 14:08:16|pasteboard.Complete (1.002 seconds)
20100720140816|127.0.0.1|__ERROR_WARNING|2010-07-20 14:08:16|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|pasteboard.Started
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: useragents-config
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: dates-config
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: fopen-config
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: stopwords-config
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-database
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-useragent
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-hooks
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-sessions
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-cache
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-scaffolding
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-errors
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-uri
20100720142721|127.0.0.1|INCLUDE|2010-07-20 14:27:21|library: pb-logs
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_set_timezone: US/Pacific
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_sitewhoami: default Initialized
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_uri_segment: QUERY_STRING
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_useragent:  
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_useragent: 
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_init_session: Not Implemented
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_dbopen: mysql_pconnect
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720142721|127.0.0.1|SQL|2010-07-20 14:27:21|SQL_logged from show_404, 43
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|_dbclose CLOSED
20100720142721|127.0.0.1|INFO|2010-07-20 14:27:21|pasteboard.Complete (2.461 seconds)
20100720142721|127.0.0.1|__ERROR_WARNING|2010-07-20 14:27:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|pasteboard.Started
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: useragents-config
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: dates-config
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: fopen-config
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: stopwords-config
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-database
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-useragent
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-hooks
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-sessions
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-cache
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-scaffolding
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-errors
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-uri
20100720145454|127.0.0.1|INCLUDE|2010-07-20 14:54:54|library: pb-logs
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_set_timezone: US/Pacific
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_sitewhoami: default Initialized
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_uri_segment: QUERY_STRING
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_useragent:  
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_useragent: 
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_init_session: Not Implemented
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_dbopen: mysql_pconnect
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720145454|127.0.0.1|SQL|2010-07-20 14:54:54|SQL_logged from show_404, 43
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|_dbclose CLOSED
20100720145454|127.0.0.1|INFO|2010-07-20 14:54:54|pasteboard.Complete (0.804 seconds)
20100720145454|127.0.0.1|__ERROR_WARNING|2010-07-20 14:54:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|pasteboard.Started
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: useragents-config
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: dates-config
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: fopen-config
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: stopwords-config
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-database
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-useragent
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-hooks
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-sessions
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-cache
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-scaffolding
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-errors
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-uri
20100720145723|127.0.0.1|INCLUDE|2010-07-20 14:57:23|library: pb-logs
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_set_timezone: US/Pacific
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_sitewhoami: default Initialized
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_uri_segment: QUERY_STRING
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_useragent:  
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_useragent: 
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_init_session: Not Implemented
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_dbopen: mysql_pconnect
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720145723|127.0.0.1|SQL|2010-07-20 14:57:23|SQL_logged from show_404, 43
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|_dbclose CLOSED
20100720145723|127.0.0.1|INFO|2010-07-20 14:57:23|pasteboard.Complete (1.572 seconds)
20100720145723|127.0.0.1|__ERROR_WARNING|2010-07-20 14:57:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|pasteboard.Started
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: useragents-config
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: dates-config
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: fopen-config
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: stopwords-config
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-database
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-useragent
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-hooks
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-sessions
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-cache
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-scaffolding
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-errors
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-uri
20100720150454|127.0.0.1|INCLUDE|2010-07-20 15:04:54|library: pb-logs
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_set_timezone: US/Pacific
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_sitewhoami: default Initialized
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_uri_segment: QUERY_STRING
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_useragent:  
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_useragent: 
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_init_session: Not Implemented
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_dbopen: mysql_pconnect
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720150454|127.0.0.1|SQL|2010-07-20 15:04:54|SQL_logged from show_404, 43
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|_dbclose CLOSED
20100720150454|127.0.0.1|INFO|2010-07-20 15:04:54|pasteboard.Complete (0.87 seconds)
20100720150454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:04:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|pasteboard.Started
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: useragents-config
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: dates-config
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: fopen-config
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: stopwords-config
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-database
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-useragent
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-hooks
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-sessions
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-cache
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-scaffolding
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-errors
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-uri
20100720151454|127.0.0.1|INCLUDE|2010-07-20 15:14:54|library: pb-logs
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_set_timezone: US/Pacific
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_sitewhoami: default Initialized
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_uri_segment: QUERY_STRING
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_useragent:  
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_useragent: 
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_init_session: Not Implemented
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_dbopen: mysql_pconnect
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720151454|127.0.0.1|SQL|2010-07-20 15:14:54|SQL_logged from show_404, 43
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|_dbclose CLOSED
20100720151454|127.0.0.1|INFO|2010-07-20 15:14:54|pasteboard.Complete (0.158 seconds)
20100720151454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:14:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|pasteboard.Started
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: useragents-config
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: dates-config
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: fopen-config
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: stopwords-config
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-database
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-useragent
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-hooks
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-sessions
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-cache
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-scaffolding
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-errors
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-uri
20100720152454|127.0.0.1|INCLUDE|2010-07-20 15:24:54|library: pb-logs
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_set_timezone: US/Pacific
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_sitewhoami: default Initialized
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_uri_segment: QUERY_STRING
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_useragent:  
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_useragent: 
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_init_session: Not Implemented
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_dbopen: mysql_pconnect
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720152454|127.0.0.1|SQL|2010-07-20 15:24:54|SQL_logged from show_404, 43
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|_dbclose CLOSED
20100720152454|127.0.0.1|INFO|2010-07-20 15:24:54|pasteboard.Complete (0.725 seconds)
20100720152454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:24:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|pasteboard.Started
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: useragents-config
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: dates-config
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: fopen-config
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: stopwords-config
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-database
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-useragent
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-hooks
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-sessions
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-cache
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-scaffolding
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-errors
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-uri
20100720152725|127.0.0.1|INCLUDE|2010-07-20 15:27:25|library: pb-logs
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_set_timezone: US/Pacific
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_sitewhoami: default Initialized
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_uri_segment: QUERY_STRING
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_useragent:  
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_useragent: 
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_init_session: Not Implemented
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_dbopen: mysql_pconnect
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720152725|127.0.0.1|SQL|2010-07-20 15:27:25|SQL_logged from show_404, 43
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|_dbclose CLOSED
20100720152725|127.0.0.1|INFO|2010-07-20 15:27:25|pasteboard.Complete (0.141 seconds)
20100720152725|127.0.0.1|__ERROR_WARNING|2010-07-20 15:27:25|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|pasteboard.Started
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: useragents-config
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: dates-config
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: fopen-config
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: stopwords-config
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-database
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-useragent
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-hooks
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-sessions
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-cache
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-scaffolding
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-errors
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-uri
20100720153454|127.0.0.1|INCLUDE|2010-07-20 15:34:54|library: pb-logs
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_set_timezone: US/Pacific
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_sitewhoami: default Initialized
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_uri_segment: QUERY_STRING
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_useragent:  
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_useragent: 
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_init_session: Not Implemented
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_dbopen: mysql_pconnect
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720153454|127.0.0.1|SQL|2010-07-20 15:34:54|SQL_logged from show_404, 43
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|_dbclose CLOSED
20100720153454|127.0.0.1|INFO|2010-07-20 15:34:54|pasteboard.Complete (0.449 seconds)
20100720153454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:34:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|pasteboard.Started
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: useragents-config
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: dates-config
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: fopen-config
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: stopwords-config
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-database
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-useragent
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-hooks
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-sessions
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-cache
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-scaffolding
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-errors
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-uri
20100720154454|127.0.0.1|INCLUDE|2010-07-20 15:44:54|library: pb-logs
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_set_timezone: US/Pacific
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_sitewhoami: default Initialized
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_uri_segment: QUERY_STRING
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_useragent:  
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_useragent: 
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_init_session: Not Implemented
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_dbopen: mysql_pconnect
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720154454|127.0.0.1|SQL|2010-07-20 15:44:54|SQL_logged from show_404, 43
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|_dbclose CLOSED
20100720154454|127.0.0.1|INFO|2010-07-20 15:44:54|pasteboard.Complete (1.021 seconds)
20100720154454|127.0.0.1|__ERROR_WARNING|2010-07-20 15:44:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|pasteboard.Started
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: useragents-config
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: dates-config
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: fopen-config
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: stopwords-config
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-database
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-useragent
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-hooks
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-sessions
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-cache
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-scaffolding
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-errors
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-uri
20100720155456|127.0.0.1|INCLUDE|2010-07-20 15:54:56|library: pb-logs
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_set_timezone: US/Pacific
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_sitewhoami: default Initialized
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_uri_segment: QUERY_STRING
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_useragent:  
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_useragent: 
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_init_session: Not Implemented
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_dbopen: mysql_pconnect
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720155456|127.0.0.1|SQL|2010-07-20 15:54:56|SQL_logged from show_404, 43
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|_dbclose CLOSED
20100720155456|127.0.0.1|INFO|2010-07-20 15:54:56|pasteboard.Complete (0.238 seconds)
20100720155456|127.0.0.1|__ERROR_WARNING|2010-07-20 15:54:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|pasteboard.Started
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: useragents-config
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: dates-config
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: fopen-config
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: stopwords-config
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-database
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-useragent
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-hooks
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-sessions
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-cache
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-scaffolding
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-errors
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-uri
20100720155726|127.0.0.1|INCLUDE|2010-07-20 15:57:26|library: pb-logs
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_set_timezone: US/Pacific
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_sitewhoami: default Initialized
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_uri_segment: QUERY_STRING
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_useragent:  
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_useragent: 
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_init_session: Not Implemented
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_dbopen: mysql_pconnect
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720155726|127.0.0.1|SQL|2010-07-20 15:57:26|SQL_logged from show_404, 43
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|_dbclose CLOSED
20100720155726|127.0.0.1|INFO|2010-07-20 15:57:26|pasteboard.Complete (0.162 seconds)
20100720155726|127.0.0.1|__ERROR_WARNING|2010-07-20 15:57:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|pasteboard.Started
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: useragents-config
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: dates-config
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: fopen-config
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: stopwords-config
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-database
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-useragent
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-hooks
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-sessions
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-cache
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-scaffolding
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-errors
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-uri
20100720160457|127.0.0.1|INCLUDE|2010-07-20 16:04:57|library: pb-logs
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_set_timezone: US/Pacific
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_sitewhoami: default Initialized
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_uri_segment: QUERY_STRING
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_useragent:  
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_useragent: 
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_init_session: Not Implemented
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_dbopen: mysql_pconnect
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720160457|127.0.0.1|SQL|2010-07-20 16:04:57|SQL_logged from show_404, 43
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|_dbclose CLOSED
20100720160457|127.0.0.1|INFO|2010-07-20 16:04:57|pasteboard.Complete (0.35 seconds)
20100720160457|127.0.0.1|__ERROR_WARNING|2010-07-20 16:04:57|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|pasteboard.Started
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: useragents-config
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: dates-config
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: fopen-config
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: stopwords-config
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-database
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-useragent
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-hooks
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-sessions
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-cache
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-scaffolding
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-errors
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-uri
20100720161458|127.0.0.1|INCLUDE|2010-07-20 16:14:58|library: pb-logs
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_set_timezone: US/Pacific
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_sitewhoami: default Initialized
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_uri_segment: QUERY_STRING
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_useragent:  
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_useragent: 
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_init_session: Not Implemented
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_dbopen: mysql_pconnect
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720161458|127.0.0.1|SQL|2010-07-20 16:14:58|SQL_logged from show_404, 43
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|_dbclose CLOSED
20100720161458|127.0.0.1|INFO|2010-07-20 16:14:58|pasteboard.Complete (0.624 seconds)
20100720161458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:14:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|pasteboard.Started
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: useragents-config
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: dates-config
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: fopen-config
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: stopwords-config
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-database
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-useragent
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-hooks
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-sessions
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-cache
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-scaffolding
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-errors
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-uri
20100720162458|127.0.0.1|INCLUDE|2010-07-20 16:24:58|library: pb-logs
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_set_timezone: US/Pacific
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_sitewhoami: default Initialized
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_uri_segment: QUERY_STRING
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_useragent:  
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_useragent: 
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_init_session: Not Implemented
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_dbopen: mysql_pconnect
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720162458|127.0.0.1|SQL|2010-07-20 16:24:58|SQL_logged from show_404, 43
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|_dbclose CLOSED
20100720162458|127.0.0.1|INFO|2010-07-20 16:24:58|pasteboard.Complete (0.562 seconds)
20100720162458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:24:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|pasteboard.Started
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: useragents-config
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: dates-config
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: fopen-config
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: stopwords-config
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-database
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-useragent
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-hooks
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-sessions
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-cache
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-scaffolding
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-errors
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-uri
20100720162726|127.0.0.1|INCLUDE|2010-07-20 16:27:26|library: pb-logs
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_set_timezone: US/Pacific
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_sitewhoami: default Initialized
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_uri_segment: QUERY_STRING
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_useragent:  
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_useragent: 
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_init_session: Not Implemented
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_dbopen: mysql_pconnect
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720162726|127.0.0.1|SQL|2010-07-20 16:27:26|SQL_logged from show_404, 43
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|_dbclose CLOSED
20100720162726|127.0.0.1|INFO|2010-07-20 16:27:26|pasteboard.Complete (0.302 seconds)
20100720162726|127.0.0.1|__ERROR_WARNING|2010-07-20 16:27:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|pasteboard.Started
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: useragents-config
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: dates-config
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: fopen-config
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: stopwords-config
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-database
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-useragent
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-hooks
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-sessions
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-cache
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-scaffolding
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-errors
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-uri
20100720163458|127.0.0.1|INCLUDE|2010-07-20 16:34:58|library: pb-logs
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_set_timezone: US/Pacific
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_sitewhoami: default Initialized
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_uri_segment: QUERY_STRING
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_useragent:  
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_useragent: 
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_init_session: Not Implemented
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_dbopen: mysql_pconnect
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720163458|127.0.0.1|SQL|2010-07-20 16:34:58|SQL_logged from show_404, 43
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|_dbclose CLOSED
20100720163458|127.0.0.1|INFO|2010-07-20 16:34:58|pasteboard.Complete (0.519 seconds)
20100720163458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:34:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|pasteboard.Started
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: useragents-config
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: dates-config
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: fopen-config
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: stopwords-config
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-database
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-useragent
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-hooks
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-sessions
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-cache
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-scaffolding
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-errors
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-uri
20100720164458|127.0.0.1|INCLUDE|2010-07-20 16:44:58|library: pb-logs
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_set_timezone: US/Pacific
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_sitewhoami: default Initialized
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_uri_segment: QUERY_STRING
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_useragent:  
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_useragent: 
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_init_session: Not Implemented
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_dbopen: mysql_pconnect
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720164458|127.0.0.1|SQL|2010-07-20 16:44:58|SQL_logged from show_404, 43
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|_dbclose CLOSED
20100720164458|127.0.0.1|INFO|2010-07-20 16:44:58|pasteboard.Complete (0.788 seconds)
20100720164458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:44:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|pasteboard.Started
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: useragents-config
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: dates-config
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: fopen-config
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: stopwords-config
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-database
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-useragent
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-hooks
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-sessions
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-cache
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-scaffolding
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-errors
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-uri
20100720165458|127.0.0.1|INCLUDE|2010-07-20 16:54:58|library: pb-logs
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_set_timezone: US/Pacific
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_sitewhoami: default Initialized
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_uri_segment: QUERY_STRING
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_useragent:  
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_useragent: 
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_init_session: Not Implemented
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_dbopen: mysql_pconnect
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720165458|127.0.0.1|SQL|2010-07-20 16:54:58|SQL_logged from show_404, 43
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|_dbclose CLOSED
20100720165458|127.0.0.1|INFO|2010-07-20 16:54:58|pasteboard.Complete (1.089 seconds)
20100720165458|127.0.0.1|__ERROR_WARNING|2010-07-20 16:54:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|pasteboard.Started
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: useragents-config
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: dates-config
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: fopen-config
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: stopwords-config
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-database
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-useragent
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-hooks
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-sessions
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-cache
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-scaffolding
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-errors
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-uri
20100720165727|127.0.0.1|INCLUDE|2010-07-20 16:57:27|library: pb-logs
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_set_timezone: US/Pacific
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_sitewhoami: default Initialized
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_uri_segment: QUERY_STRING
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_useragent:  
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_useragent: 
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_init_session: Not Implemented
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_dbopen: mysql_pconnect
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720165727|127.0.0.1|SQL|2010-07-20 16:57:27|SQL_logged from show_404, 43
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|_dbclose CLOSED
20100720165727|127.0.0.1|INFO|2010-07-20 16:57:27|pasteboard.Complete (0.523 seconds)
20100720165727|127.0.0.1|__ERROR_WARNING|2010-07-20 16:57:27|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|pasteboard.Started
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: useragents-config
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: dates-config
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: fopen-config
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: stopwords-config
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-database
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-useragent
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-hooks
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-sessions
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-cache
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-scaffolding
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-errors
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-uri
20100720170143|127.0.0.1|INCLUDE|2010-07-20 17:01:43|library: pb-logs
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_set_timezone: US/Pacific
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_sitewhoami: default Initialized
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_uri_segment: QUERY_STRING
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_useragent:  
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_useragent: 
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_init_session: Not Implemented
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_dbopen: mysql_pconnect
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720170143|127.0.0.1|SQL|2010-07-20 17:01:43|SQL_logged from show_404, 43
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|_dbclose CLOSED
20100720170143|127.0.0.1|INFO|2010-07-20 17:01:43|pasteboard.Complete (0.273 seconds)
20100720170143|127.0.0.1|__ERROR_WARNING|2010-07-20 17:01:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|pasteboard.Started
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: useragents-config
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: dates-config
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: fopen-config
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: stopwords-config
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-database
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-useragent
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-hooks
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-sessions
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-cache
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-scaffolding
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-errors
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-uri
20100720172728|127.0.0.1|INCLUDE|2010-07-20 17:27:28|library: pb-logs
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_set_timezone: US/Pacific
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_sitewhoami: default Initialized
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_uri_segment: QUERY_STRING
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_useragent:  
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_useragent: 
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_init_session: Not Implemented
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_dbopen: mysql_pconnect
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720172728|127.0.0.1|SQL|2010-07-20 17:27:28|SQL_logged from show_404, 43
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|_dbclose CLOSED
20100720172728|127.0.0.1|INFO|2010-07-20 17:27:28|pasteboard.Complete (0.353 seconds)
20100720172728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:27:28|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|pasteboard.Started
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: useragents-config
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: dates-config
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: fopen-config
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: stopwords-config
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-database
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-useragent
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-hooks
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-sessions
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-cache
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-scaffolding
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-errors
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-uri
20100720175216|127.0.0.1|INCLUDE|2010-07-20 17:52:16|library: pb-logs
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_set_timezone: US/Pacific
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_sitewhoami: default Initialized
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_uri_segment: QUERY_STRING
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_useragent:  
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_useragent: 
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_init_session: Not Implemented
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_dbopen: mysql_pconnect
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720175216|127.0.0.1|SQL|2010-07-20 17:52:16|SQL_logged from show_404, 43
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|_dbclose CLOSED
20100720175216|127.0.0.1|INFO|2010-07-20 17:52:16|pasteboard.Complete (0.421 seconds)
20100720175216|127.0.0.1|__ERROR_WARNING|2010-07-20 17:52:16|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|pasteboard.Started
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: useragents-config
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: dates-config
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: fopen-config
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: stopwords-config
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-database
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-useragent
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-hooks
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-sessions
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-cache
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-scaffolding
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-errors
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-uri
20100720175728|127.0.0.1|INCLUDE|2010-07-20 17:57:28|library: pb-logs
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_set_timezone: US/Pacific
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_sitewhoami: default Initialized
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_uri_segment: QUERY_STRING
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_useragent:  
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_useragent: 
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_init_session: Not Implemented
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_dbopen: mysql_pconnect
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720175728|127.0.0.1|SQL|2010-07-20 17:57:28|SQL_logged from show_404, 43
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|_dbclose CLOSED
20100720175728|127.0.0.1|INFO|2010-07-20 17:57:28|pasteboard.Complete (0.857 seconds)
20100720175728|127.0.0.1|__ERROR_WARNING|2010-07-20 17:57:28|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|pasteboard.Started
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: useragents-config
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: dates-config
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: fopen-config
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: stopwords-config
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-database
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-useragent
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-hooks
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-sessions
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-cache
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-scaffolding
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-errors
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-uri
20100720180216|127.0.0.1|INCLUDE|2010-07-20 18:02:16|library: pb-logs
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_set_timezone: US/Pacific
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_sitewhoami: default Initialized
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_uri_segment: QUERY_STRING
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_useragent:  
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_useragent: 
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_init_session: Not Implemented
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_dbopen: mysql_pconnect
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720180216|127.0.0.1|SQL|2010-07-20 18:02:16|SQL_logged from show_404, 43
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|_dbclose CLOSED
20100720180216|127.0.0.1|INFO|2010-07-20 18:02:16|pasteboard.Complete (1.034 seconds)
20100720180216|127.0.0.1|__ERROR_WARNING|2010-07-20 18:02:16|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|pasteboard.Started
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: useragents-config
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: dates-config
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: fopen-config
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: stopwords-config
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-database
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-useragent
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-hooks
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-sessions
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-cache
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-scaffolding
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-errors
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-uri
20100720181218|127.0.0.1|INCLUDE|2010-07-20 18:12:18|library: pb-logs
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_set_timezone: US/Pacific
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_sitewhoami: default Initialized
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_uri_segment: QUERY_STRING
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_useragent:  
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_useragent: 
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_init_session: Not Implemented
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_dbopen: mysql_pconnect
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720181218|127.0.0.1|SQL|2010-07-20 18:12:18|SQL_logged from show_404, 43
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|_dbclose CLOSED
20100720181218|127.0.0.1|INFO|2010-07-20 18:12:18|pasteboard.Complete (0.642 seconds)
20100720181218|127.0.0.1|__ERROR_WARNING|2010-07-20 18:12:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|pasteboard.Started
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: useragents-config
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: dates-config
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: fopen-config
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: stopwords-config
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-database
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-useragent
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-hooks
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-sessions
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-cache
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-scaffolding
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-errors
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-uri
20100720182219|127.0.0.1|INCLUDE|2010-07-20 18:22:19|library: pb-logs
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_set_timezone: US/Pacific
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_sitewhoami: default Initialized
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_uri_segment: QUERY_STRING
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_useragent:  
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_useragent: 
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_init_session: Not Implemented
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_dbopen: mysql_pconnect
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720182219|127.0.0.1|SQL|2010-07-20 18:22:19|SQL_logged from show_404, 43
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|_dbclose CLOSED
20100720182219|127.0.0.1|INFO|2010-07-20 18:22:19|pasteboard.Complete (0.94 seconds)
20100720182219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:22:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|pasteboard.Started
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: useragents-config
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: dates-config
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: fopen-config
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: stopwords-config
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-database
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-useragent
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-hooks
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-sessions
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-cache
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-scaffolding
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-errors
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-uri
20100720182729|127.0.0.1|INCLUDE|2010-07-20 18:27:29|library: pb-logs
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_set_timezone: US/Pacific
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_sitewhoami: default Initialized
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_uri_segment: QUERY_STRING
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_useragent:  
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_useragent: 
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_init_session: Not Implemented
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_dbopen: mysql_pconnect
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720182729|127.0.0.1|SQL|2010-07-20 18:27:29|SQL_logged from show_404, 43
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|_dbclose CLOSED
20100720182729|127.0.0.1|INFO|2010-07-20 18:27:29|pasteboard.Complete (0.152 seconds)
20100720182729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:27:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|pasteboard.Started
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: useragents-config
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: dates-config
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: fopen-config
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: stopwords-config
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-database
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-useragent
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-hooks
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-sessions
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-cache
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-scaffolding
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-errors
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-uri
20100720183219|127.0.0.1|INCLUDE|2010-07-20 18:32:19|library: pb-logs
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_set_timezone: US/Pacific
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_sitewhoami: default Initialized
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_uri_segment: QUERY_STRING
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_useragent:  
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_useragent: 
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_init_session: Not Implemented
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_dbopen: mysql_pconnect
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720183219|127.0.0.1|SQL|2010-07-20 18:32:19|SQL_logged from show_404, 43
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|_dbclose CLOSED
20100720183219|127.0.0.1|INFO|2010-07-20 18:32:19|pasteboard.Complete (1.14 seconds)
20100720183219|127.0.0.1|__ERROR_WARNING|2010-07-20 18:32:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|pasteboard.Started
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: useragents-config
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: dates-config
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: fopen-config
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: stopwords-config
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-database
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-useragent
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-hooks
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-sessions
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-cache
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-scaffolding
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-errors
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-uri
20100720184221|127.0.0.1|INCLUDE|2010-07-20 18:42:21|library: pb-logs
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_set_timezone: US/Pacific
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_sitewhoami: default Initialized
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_uri_segment: QUERY_STRING
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_useragent:  
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_useragent: 
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_init_session: Not Implemented
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_dbopen: mysql_pconnect
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720184221|127.0.0.1|SQL|2010-07-20 18:42:21|SQL_logged from show_404, 43
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|_dbclose CLOSED
20100720184221|127.0.0.1|INFO|2010-07-20 18:42:21|pasteboard.Complete (0.909 seconds)
20100720184221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:42:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|pasteboard.Started
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: useragents-config
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: dates-config
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: fopen-config
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: stopwords-config
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-database
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-useragent
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-hooks
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-sessions
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-cache
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-scaffolding
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-errors
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-uri
20100720185221|127.0.0.1|INCLUDE|2010-07-20 18:52:21|library: pb-logs
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_set_timezone: US/Pacific
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_sitewhoami: default Initialized
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_uri_segment: QUERY_STRING
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_useragent:  
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_useragent: 
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_init_session: Not Implemented
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_dbopen: mysql_pconnect
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720185221|127.0.0.1|SQL|2010-07-20 18:52:21|SQL_logged from show_404, 43
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|_dbclose CLOSED
20100720185221|127.0.0.1|INFO|2010-07-20 18:52:21|pasteboard.Complete (0.436 seconds)
20100720185221|127.0.0.1|__ERROR_WARNING|2010-07-20 18:52:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|pasteboard.Started
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: useragents-config
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: dates-config
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: fopen-config
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: stopwords-config
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-database
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-useragent
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-hooks
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-sessions
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-cache
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-scaffolding
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-errors
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-uri
20100720185729|127.0.0.1|INCLUDE|2010-07-20 18:57:29|library: pb-logs
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_set_timezone: US/Pacific
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_sitewhoami: default Initialized
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_uri_segment: QUERY_STRING
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_useragent:  
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_useragent: 
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_init_session: Not Implemented
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_dbopen: mysql_pconnect
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720185729|127.0.0.1|SQL|2010-07-20 18:57:29|SQL_logged from show_404, 43
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|_dbclose CLOSED
20100720185729|127.0.0.1|INFO|2010-07-20 18:57:29|pasteboard.Complete (0.744 seconds)
20100720185729|127.0.0.1|__ERROR_WARNING|2010-07-20 18:57:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|pasteboard.Started
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: useragents-config
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: dates-config
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: fopen-config
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: stopwords-config
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-database
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-useragent
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-hooks
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-sessions
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-cache
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-scaffolding
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-errors
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-uri
20100720185949|127.0.0.1|INCLUDE|2010-07-20 18:59:49|library: pb-logs
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_set_timezone: US/Pacific
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_sitewhoami: default Initialized
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_uri_segment: QUERY_STRING
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_useragent:  
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_useragent: 
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_init_session: Not Implemented
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_dbopen: mysql_pconnect
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720185949|127.0.0.1|SQL|2010-07-20 18:59:49|SQL_logged from show_404, 43
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|_dbclose CLOSED
20100720185949|127.0.0.1|INFO|2010-07-20 18:59:49|pasteboard.Complete (0.457 seconds)
20100720185949|127.0.0.1|__ERROR_WARNING|2010-07-20 18:59:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|pasteboard.Started
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: useragents-config
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: dates-config
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: fopen-config
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: stopwords-config
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-database
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-useragent
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-hooks
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-sessions
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-cache
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-scaffolding
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-errors
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-uri
20100720213325|127.0.0.1|INCLUDE|2010-07-20 21:33:25|library: pb-logs
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_set_timezone: US/Pacific
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_sitewhoami: default Initialized
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_uri_segment: QUERY_STRING
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_useragent:  
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_useragent: 
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_init_session: Not Implemented
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_dbopen: mysql_pconnect
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720213325|127.0.0.1|SQL|2010-07-20 21:33:25|SQL_logged from show_404, 43
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|_dbclose CLOSED
20100720213325|127.0.0.1|INFO|2010-07-20 21:33:25|pasteboard.Complete (0.845 seconds)
20100720213325|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:25|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|pasteboard.Started
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: useragents-config
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: dates-config
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: fopen-config
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: stopwords-config
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-database
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-useragent
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-hooks
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-sessions
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-cache
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-scaffolding
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-errors
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-uri
20100720213326|127.0.0.1|INCLUDE|2010-07-20 21:33:26|library: pb-logs
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_set_timezone: US/Pacific
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_sitewhoami: default Initialized
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_uri_segment: QUERY_STRING
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_useragent:  
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_useragent: 
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_init_session: Not Implemented
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_dbopen: mysql_pconnect
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720213326|127.0.0.1|SQL|2010-07-20 21:33:26|SQL_logged from show_404, 43
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|_dbclose CLOSED
20100720213326|127.0.0.1|INFO|2010-07-20 21:33:26|pasteboard.Complete (0.993 seconds)
20100720213326|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|pasteboard.Started
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: useragents-config
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: dates-config
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: fopen-config
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: stopwords-config
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-database
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-useragent
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-hooks
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-sessions
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-cache
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-scaffolding
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-errors
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-uri
20100720213329|127.0.0.1|INCLUDE|2010-07-20 21:33:29|library: pb-logs
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_set_timezone: US/Pacific
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_sitewhoami: default Initialized
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_uri_segment: QUERY_STRING
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_useragent:  
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_useragent: 
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_init_session: Not Implemented
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_dbopen: mysql_pconnect
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720213329|127.0.0.1|SQL|2010-07-20 21:33:29|SQL_logged from show_404, 43
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|_dbclose CLOSED
20100720213329|127.0.0.1|INFO|2010-07-20 21:33:29|pasteboard.Complete (0.437 seconds)
20100720213329|127.0.0.1|__ERROR_WARNING|2010-07-20 21:33:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|pasteboard.Started
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: useragents-config
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: dates-config
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: fopen-config
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: stopwords-config
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-database
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-useragent
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-hooks
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-sessions
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-cache
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-scaffolding
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-errors
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-uri
20100720213526|127.0.0.1|INCLUDE|2010-07-20 21:35:26|library: pb-logs
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_set_timezone: US/Pacific
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_sitewhoami: default Initialized
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_uri_segment: QUERY_STRING
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_useragent:  
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_useragent: 
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_init_session: Not Implemented
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_dbopen: mysql_pconnect
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100720213526|127.0.0.1|SQL|2010-07-20 21:35:26|SQL_logged from show_404, 43
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|_dbclose CLOSED
20100720213526|127.0.0.1|INFO|2010-07-20 21:35:26|pasteboard.Complete (31.051 seconds)
20100720213526|127.0.0.1|__ERROR_WARNING|2010-07-20 21:35:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
