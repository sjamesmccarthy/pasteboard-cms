20100608174635|::1|INFO|2010-06-08 17:46:35|pasteboard.Started
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: useragents-config
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: dates-config
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: fopen-config
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: stopwords-config
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-database
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-useragent
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-hooks
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-sessions
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-cache
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-scaffolding
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-errors
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-uri
20100608174635|::1|INCLUDE|2010-06-08 17:46:35|library: pb-logs
20100608174635|::1|INFO|2010-06-08 17:46:35|_set_timezone: US/Pacific
20100608174635|::1|INFO|2010-06-08 17:46:35|_sitewhoami: default Initialized
20100608174635|::1|INFO|2010-06-08 17:46:35|_uri_segment: FRONT PAGE
20100608174635|::1|INFO|2010-06-08 17:46:35|_uri_segment: INDEX_WEBROOT
20100608174635|::1|INFO|2010-06-08 17:46:35|_useragent: Safari 533.16
20100608174635|::1|INFO|2010-06-08 17:46:35|_useragent: Mac OS X
20100608174635|::1|INFO|2010-06-08 17:46:35|_init_session: Not Implemented
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100608174635|::1|INFO|2010-06-08 17:46:35|_dbopen: mysql_pconnect
20100608174635|::1|INFO|2010-06-08 17:46:35|app: page Initialized
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100608174635|::1|SQL|2010-06-08 17:46:35|SQL_logged from _get_front_page, 85
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/models/page_model.php
20100608174635|::1|INFO|2010-06-08 17:46:35|model: page_model.php Function: _get_front_page
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/page_controller.php, 64]
20100608174635|::1|INFO|2010-06-08 17:46:35|app: page Function: view
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/page/views/view_index.php, 32]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100608174635|::1|SQL|2010-06-08 17:46:35|SQL_logged from _get_content_index, 22
20100608174635|::1|INFO|2010-06-08 17:46:35|model: page_model.php Function: _get_content_index
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100608174635|::1|INFO|2010-06-08 17:46:35|app: page Terminated
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100608174635|::1|INFO|2010-06-08 17:46:35|_dbclose CLOSED
20100608174635|::1|INFO|2010-06-08 17:46:35|pasteboard.Complete (30.705 seconds)
20100608174635|::1|__ERROR_WARNING|2010-06-08 17:46:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
