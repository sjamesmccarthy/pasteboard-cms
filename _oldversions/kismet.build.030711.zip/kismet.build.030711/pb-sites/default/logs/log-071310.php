20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|pasteboard.Started
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: useragents-config
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: dates-config
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: fopen-config
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: stopwords-config
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-database
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-useragent
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-hooks
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-sessions
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-cache
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-scaffolding
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-errors
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-uri
20100713201256|127.0.0.1|INCLUDE|2010-07-13 20:12:56|library: pb-logs
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_set_timezone: US/Pacific
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_sitewhoami: default Initialized
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_uri_segment: QUERY_STRING
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_useragent:  
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_useragent: 
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_init_session: Not Implemented
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_dbopen: mysql_pconnect
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713201256|127.0.0.1|SQL|2010-07-13 20:12:56|SQL_logged from show_404, 43
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|_dbclose CLOSED
20100713201256|127.0.0.1|INFO|2010-07-13 20:12:56|pasteboard.Complete (30.837 seconds)
20100713201256|127.0.0.1|__ERROR_WARNING|2010-07-13 20:12:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|pasteboard.Started
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: useragents-config
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: dates-config
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: fopen-config
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: stopwords-config
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-database
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-useragent
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-hooks
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-sessions
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-cache
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-scaffolding
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-errors
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-uri
20100713212131|127.0.0.1|INCLUDE|2010-07-13 21:21:31|library: pb-logs
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_set_timezone: US/Pacific
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_sitewhoami: default Initialized
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_uri_segment: QUERY_STRING
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_useragent:  
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_useragent: 
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_init_session: Not Implemented
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_dbopen: mysql_pconnect
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713212131|127.0.0.1|SQL|2010-07-13 21:21:31|SQL_logged from show_404, 43
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|_dbclose CLOSED
20100713212131|127.0.0.1|INFO|2010-07-13 21:21:31|pasteboard.Complete (30.879 seconds)
20100713212131|127.0.0.1|__ERROR_WARNING|2010-07-13 21:21:31|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|pasteboard.Started
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: useragents-config
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: dates-config
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: fopen-config
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: stopwords-config
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-database
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-useragent
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-hooks
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-sessions
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-cache
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-scaffolding
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-errors
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-uri
20100713212257|127.0.0.1|INCLUDE|2010-07-13 21:22:57|library: pb-logs
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_set_timezone: US/Pacific
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_sitewhoami: default Initialized
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_uri_segment: QUERY_STRING
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_useragent:  
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_useragent: 
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_init_session: Not Implemented
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_dbopen: mysql_pconnect
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713212257|127.0.0.1|SQL|2010-07-13 21:22:57|SQL_logged from show_404, 43
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|_dbclose CLOSED
20100713212257|127.0.0.1|INFO|2010-07-13 21:22:57|pasteboard.Complete (31.266 seconds)
20100713212257|127.0.0.1|__ERROR_WARNING|2010-07-13 21:22:57|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|pasteboard.Started
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: useragents-config
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: dates-config
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: fopen-config
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: stopwords-config
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-database
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-useragent
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-hooks
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-sessions
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-cache
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-scaffolding
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-errors
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-uri
20100713213201|127.0.0.1|INCLUDE|2010-07-13 21:32:01|library: pb-logs
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_set_timezone: US/Pacific
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_sitewhoami: default Initialized
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_uri_segment: QUERY_STRING
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_useragent:  
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_useragent: 
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_init_session: Not Implemented
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_dbopen: mysql_pconnect
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713213201|127.0.0.1|SQL|2010-07-13 21:32:01|SQL_logged from show_404, 43
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|_dbclose CLOSED
20100713213201|127.0.0.1|INFO|2010-07-13 21:32:01|pasteboard.Complete (30.893 seconds)
20100713213201|127.0.0.1|__ERROR_WARNING|2010-07-13 21:32:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|pasteboard.Started
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: useragents-config
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: dates-config
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: fopen-config
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: stopwords-config
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-database
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-useragent
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-hooks
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-sessions
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-cache
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-scaffolding
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-errors
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-uri
20100713214232|127.0.0.1|INCLUDE|2010-07-13 21:42:32|library: pb-logs
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_set_timezone: US/Pacific
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_sitewhoami: default Initialized
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_uri_segment: QUERY_STRING
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_useragent:  
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_useragent: 
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_init_session: Not Implemented
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_dbopen: mysql_pconnect
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713214232|127.0.0.1|SQL|2010-07-13 21:42:32|SQL_logged from show_404, 43
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|_dbclose CLOSED
20100713214232|127.0.0.1|INFO|2010-07-13 21:42:32|pasteboard.Complete (30.901 seconds)
20100713214232|127.0.0.1|__ERROR_WARNING|2010-07-13 21:42:32|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|pasteboard.Started
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: useragents-config
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: dates-config
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: fopen-config
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: stopwords-config
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-database
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-useragent
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-hooks
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-sessions
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-cache
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-scaffolding
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-errors
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-uri
20100713215302|127.0.0.1|INCLUDE|2010-07-13 21:53:02|library: pb-logs
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_set_timezone: US/Pacific
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_sitewhoami: default Initialized
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_uri_segment: QUERY_STRING
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_useragent:  
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_useragent: 
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_init_session: Not Implemented
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_dbopen: mysql_pconnect
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713215302|127.0.0.1|SQL|2010-07-13 21:53:02|SQL_logged from show_404, 43
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|_dbclose CLOSED
20100713215302|127.0.0.1|INFO|2010-07-13 21:53:02|pasteboard.Complete (31.647 seconds)
20100713215302|127.0.0.1|__ERROR_WARNING|2010-07-13 21:53:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|pasteboard.Started
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: useragents-config
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: dates-config
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: fopen-config
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: stopwords-config
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-database
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-useragent
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-hooks
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-sessions
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-cache
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-scaffolding
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-errors
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-uri
20100713215655|127.0.0.1|INCLUDE|2010-07-13 21:56:55|library: pb-logs
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_set_timezone: US/Pacific
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_sitewhoami: default Initialized
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_uri_segment: QUERY_STRING
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_useragent:  
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_useragent: 
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_init_session: Not Implemented
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_dbopen: mysql_pconnect
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713215655|127.0.0.1|SQL|2010-07-13 21:56:55|SQL_logged from show_404, 43
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|_dbclose CLOSED
20100713215655|127.0.0.1|INFO|2010-07-13 21:56:55|pasteboard.Complete (30.43 seconds)
20100713215655|127.0.0.1|__ERROR_WARNING|2010-07-13 21:56:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|pasteboard.Started
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: useragents-config
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: dates-config
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: fopen-config
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: stopwords-config
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-database
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-useragent
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-hooks
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-sessions
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-cache
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-scaffolding
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-errors
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-uri
20100713220334|127.0.0.1|INCLUDE|2010-07-13 22:03:34|library: pb-logs
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_set_timezone: US/Pacific
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_sitewhoami: default Initialized
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_uri_segment: QUERY_STRING
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_useragent:  
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_useragent: 
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_init_session: Not Implemented
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_dbopen: mysql_pconnect
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713220334|127.0.0.1|SQL|2010-07-13 22:03:34|SQL_logged from show_404, 43
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|_dbclose CLOSED
20100713220334|127.0.0.1|INFO|2010-07-13 22:03:34|pasteboard.Complete (30.832 seconds)
20100713220334|127.0.0.1|__ERROR_WARNING|2010-07-13 22:03:34|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|pasteboard.Started
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: useragents-config
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: dates-config
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: fopen-config
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: stopwords-config
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-database
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-useragent
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-hooks
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-sessions
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-cache
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-scaffolding
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-errors
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-uri
20100713221405|127.0.0.1|INCLUDE|2010-07-13 22:14:05|library: pb-logs
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_set_timezone: US/Pacific
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_sitewhoami: default Initialized
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_uri_segment: QUERY_STRING
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_useragent:  
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_useragent: 
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_init_session: Not Implemented
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_dbopen: mysql_pconnect
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713221405|127.0.0.1|SQL|2010-07-13 22:14:05|SQL_logged from show_404, 43
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|_dbclose CLOSED
20100713221405|127.0.0.1|INFO|2010-07-13 22:14:05|pasteboard.Complete (31.103 seconds)
20100713221405|127.0.0.1|__ERROR_WARNING|2010-07-13 22:14:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|pasteboard.Started
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: useragents-config
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: dates-config
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: fopen-config
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: stopwords-config
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-database
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-useragent
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-hooks
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-sessions
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-cache
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-scaffolding
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-errors
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-uri
20100713222437|127.0.0.1|INCLUDE|2010-07-13 22:24:37|library: pb-logs
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_set_timezone: US/Pacific
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_sitewhoami: default Initialized
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_uri_segment: QUERY_STRING
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_useragent:  
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_useragent: 
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_init_session: Not Implemented
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_dbopen: mysql_pconnect
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713222437|127.0.0.1|SQL|2010-07-13 22:24:37|SQL_logged from show_404, 43
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|_dbclose CLOSED
20100713222437|127.0.0.1|INFO|2010-07-13 22:24:37|pasteboard.Complete (31.114 seconds)
20100713222437|127.0.0.1|__ERROR_WARNING|2010-07-13 22:24:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|pasteboard.Started
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: useragents-config
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: dates-config
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: fopen-config
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: stopwords-config
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-database
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-useragent
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-hooks
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-sessions
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-cache
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-scaffolding
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-errors
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-uri
20100713223012|127.0.0.1|INCLUDE|2010-07-13 22:30:12|library: pb-logs
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_set_timezone: US/Pacific
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_sitewhoami: default Initialized
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_uri_segment: QUERY_STRING
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_useragent:  
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_useragent: 
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_init_session: Not Implemented
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_dbopen: mysql_pconnect
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713223012|127.0.0.1|SQL|2010-07-13 22:30:12|SQL_logged from show_404, 43
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|_dbclose CLOSED
20100713223012|127.0.0.1|INFO|2010-07-13 22:30:12|pasteboard.Complete (31.268 seconds)
20100713223012|127.0.0.1|__ERROR_WARNING|2010-07-13 22:30:12|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|pasteboard.Started
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: useragents-config
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: dates-config
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: fopen-config
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: stopwords-config
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-database
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-useragent
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-hooks
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-sessions
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-cache
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-scaffolding
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-errors
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-uri
20100713223508|127.0.0.1|INCLUDE|2010-07-13 22:35:08|library: pb-logs
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_set_timezone: US/Pacific
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_sitewhoami: default Initialized
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_uri_segment: QUERY_STRING
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_useragent:  
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_useragent: 
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_init_session: Not Implemented
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_dbopen: mysql_pconnect
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713223508|127.0.0.1|SQL|2010-07-13 22:35:08|SQL_logged from show_404, 43
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|_dbclose CLOSED
20100713223508|127.0.0.1|INFO|2010-07-13 22:35:08|pasteboard.Complete (30.813 seconds)
20100713223508|127.0.0.1|__ERROR_WARNING|2010-07-13 22:35:08|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|pasteboard.Started
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: useragents-config
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: dates-config
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: fopen-config
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: stopwords-config
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-database
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-useragent
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-hooks
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-sessions
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-cache
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-scaffolding
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-errors
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-uri
20100713224539|127.0.0.1|INCLUDE|2010-07-13 22:45:39|library: pb-logs
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_set_timezone: US/Pacific
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_sitewhoami: default Initialized
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_uri_segment: QUERY_STRING
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_useragent:  
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_useragent: 
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_init_session: Not Implemented
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_dbopen: mysql_pconnect
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713224539|127.0.0.1|SQL|2010-07-13 22:45:39|SQL_logged from show_404, 43
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|_dbclose CLOSED
20100713224539|127.0.0.1|INFO|2010-07-13 22:45:39|pasteboard.Complete (30.71 seconds)
20100713224539|127.0.0.1|__ERROR_WARNING|2010-07-13 22:45:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|pasteboard.Started
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: useragents-config
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: dates-config
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: fopen-config
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: stopwords-config
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-database
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-useragent
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-hooks
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-sessions
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-cache
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-scaffolding
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-errors
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-uri
20100713225610|127.0.0.1|INCLUDE|2010-07-13 22:56:10|library: pb-logs
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_set_timezone: US/Pacific
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_sitewhoami: default Initialized
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_uri_segment: QUERY_STRING
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_useragent:  
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_useragent: 
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_init_session: Not Implemented
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_dbopen: mysql_pconnect
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713225610|127.0.0.1|SQL|2010-07-13 22:56:10|SQL_logged from show_404, 43
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|_dbclose CLOSED
20100713225610|127.0.0.1|INFO|2010-07-13 22:56:10|pasteboard.Complete (30.74 seconds)
20100713225610|127.0.0.1|__ERROR_WARNING|2010-07-13 22:56:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|pasteboard.Started
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: useragents-config
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: dates-config
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: fopen-config
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: stopwords-config
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-database
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-useragent
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-hooks
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-sessions
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-cache
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-scaffolding
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-errors
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-uri
20100713230044|127.0.0.1|INCLUDE|2010-07-13 23:00:44|library: pb-logs
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_set_timezone: US/Pacific
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_sitewhoami: default Initialized
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_uri_segment: QUERY_STRING
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_useragent:  
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_useragent: 
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_init_session: Not Implemented
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_dbopen: mysql_pconnect
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713230044|127.0.0.1|SQL|2010-07-13 23:00:44|SQL_logged from show_404, 43
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|_dbclose CLOSED
20100713230044|127.0.0.1|INFO|2010-07-13 23:00:44|pasteboard.Complete (31.014 seconds)
20100713230044|127.0.0.1|__ERROR_WARNING|2010-07-13 23:00:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|pasteboard.Started
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: useragents-config
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: dates-config
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: fopen-config
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: stopwords-config
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-database
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-useragent
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-hooks
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-sessions
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-cache
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-scaffolding
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-errors
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-uri
20100713230640|127.0.0.1|INCLUDE|2010-07-13 23:06:40|library: pb-logs
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_set_timezone: US/Pacific
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_sitewhoami: default Initialized
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_uri_segment: QUERY_STRING
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_useragent:  
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_useragent: 
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_init_session: Not Implemented
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_dbopen: mysql_pconnect
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100713230640|127.0.0.1|SQL|2010-07-13 23:06:40|SQL_logged from show_404, 43
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|_dbclose CLOSED
20100713230640|127.0.0.1|INFO|2010-07-13 23:06:40|pasteboard.Complete (30.965 seconds)
20100713230640|127.0.0.1|__ERROR_WARNING|2010-07-13 23:06:40|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
