20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|pasteboard.Started
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: useragents-config
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: dates-config
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: fopen-config
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: stopwords-config
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-database
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-useragent
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-hooks
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-sessions
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-cache
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-scaffolding
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-errors
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-uri
20110111174847|127.0.0.1|INCLUDE|2011-01-11 17:48:47|library: pb-logs
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_set_timezone: US/Pacific
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_sitewhoami: default Initialized
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_uri_segment: QUERY_STRING
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_useragent:  
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_useragent: 
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_init_session: Not Implemented
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_dbopen: mysql_pconnect
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110111174847|127.0.0.1|SQL|2011-01-11 17:48:47|SQL_logged from show_404, 43
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|_dbclose CLOSED
20110111174847|127.0.0.1|INFO|2011-01-11 17:48:47|pasteboard.Complete (3.249 seconds)
20110111174847|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|pasteboard.Started
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: useragents-config
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: dates-config
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: fopen-config
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: stopwords-config
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-database
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-useragent
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-hooks
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-sessions
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-cache
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-scaffolding
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-errors
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-uri
20110111174855|127.0.0.1|INCLUDE|2011-01-11 17:48:55|library: pb-logs
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_set_timezone: US/Pacific
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_sitewhoami: default Initialized
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_uri_segment: QUERY_STRING
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_useragent:  
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_useragent: 
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_init_session: Not Implemented
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_dbopen: mysql_pconnect
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110111174855|127.0.0.1|SQL|2011-01-11 17:48:55|SQL_logged from show_404, 43
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|_dbclose CLOSED
20110111174855|127.0.0.1|INFO|2011-01-11 17:48:55|pasteboard.Complete (0.661 seconds)
20110111174855|127.0.0.1|__ERROR_WARNING|2011-01-11 17:48:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|pasteboard.Started
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: useragents-config
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: dates-config
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: fopen-config
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: stopwords-config
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-database
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-useragent
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-hooks
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-sessions
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-cache
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-scaffolding
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-errors
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-uri
20110111175157|127.0.0.1|INCLUDE|2011-01-11 17:51:57|library: pb-logs
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_set_timezone: US/Pacific
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_sitewhoami: default Initialized
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_uri_segment: QUERY_STRING
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_useragent:  
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_useragent: 
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_init_session: Not Implemented
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_dbopen: mysql_pconnect
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110111175157|127.0.0.1|SQL|2011-01-11 17:51:57|SQL_logged from show_404, 43
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|_dbclose CLOSED
20110111175157|127.0.0.1|INFO|2011-01-11 17:51:57|pasteboard.Complete (2.489 seconds)
20110111175157|127.0.0.1|__ERROR_WARNING|2011-01-11 17:51:57|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|pasteboard.Started
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: useragents-config
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: dates-config
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: fopen-config
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: stopwords-config
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-database
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-useragent
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-hooks
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-sessions
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-cache
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-scaffolding
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-errors
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-uri
20110111175305|127.0.0.1|INCLUDE|2011-01-11 17:53:05|library: pb-logs
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_set_timezone: US/Pacific
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_sitewhoami: default Initialized
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_uri_segment: QUERY_STRING
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_useragent:  
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_useragent: 
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_init_session: Not Implemented
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_dbopen: mysql_pconnect
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110111175305|127.0.0.1|SQL|2011-01-11 17:53:05|SQL_logged from show_404, 43
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|_dbclose CLOSED
20110111175305|127.0.0.1|INFO|2011-01-11 17:53:05|pasteboard.Complete (2.719 seconds)
20110111175305|127.0.0.1|__ERROR_WARNING|2011-01-11 17:53:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
