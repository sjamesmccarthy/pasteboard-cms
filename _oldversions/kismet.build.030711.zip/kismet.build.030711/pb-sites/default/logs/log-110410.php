20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|pasteboard.Started
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: useragents-config
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: dates-config
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: fopen-config
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: stopwords-config
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-database
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-useragent
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-hooks
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-sessions
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-cache
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-scaffolding
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-errors
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-uri
20101104000027|127.0.0.1|INCLUDE|2010-11-04 00:00:27|library: pb-logs
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_set_timezone: US/Pacific
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_sitewhoami: default Initialized
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_uri_segment: QUERY_STRING
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_useragent:  
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_useragent: 
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_init_session: Not Implemented
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_dbopen: mysql_pconnect
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101104000027|127.0.0.1|SQL|2010-11-04 00:00:27|SQL_logged from show_404, 43
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|_dbclose CLOSED
20101104000027|127.0.0.1|INFO|2010-11-04 00:00:27|pasteboard.Complete (30.131 seconds)
20101104000027|127.0.0.1|__ERROR_WARNING|2010-11-04 00:00:27|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|pasteboard.Started
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: useragents-config
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: dates-config
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: fopen-config
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: stopwords-config
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-database
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-useragent
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-hooks
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-sessions
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-cache
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-scaffolding
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-errors
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-uri
20101104000741|127.0.0.1|INCLUDE|2010-11-04 00:07:41|library: pb-logs
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_set_timezone: US/Pacific
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_sitewhoami: default Initialized
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_uri_segment: QUERY_STRING
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_useragent:  
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_useragent: 
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_init_session: Not Implemented
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_dbopen: mysql_pconnect
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101104000741|127.0.0.1|SQL|2010-11-04 00:07:41|SQL_logged from show_404, 43
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|_dbclose CLOSED
20101104000741|127.0.0.1|INFO|2010-11-04 00:07:41|pasteboard.Complete (30.419 seconds)
20101104000741|127.0.0.1|__ERROR_WARNING|2010-11-04 00:07:41|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|pasteboard.Started
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: useragents-config
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: dates-config
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: fopen-config
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: stopwords-config
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-database
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-useragent
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-hooks
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-sessions
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-cache
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-scaffolding
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-errors
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-uri
20101104001058|127.0.0.1|INCLUDE|2010-11-04 00:10:58|library: pb-logs
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_set_timezone: US/Pacific
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_sitewhoami: default Initialized
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_uri_segment: QUERY_STRING
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_useragent:  
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_useragent: 
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_init_session: Not Implemented
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_dbopen: mysql_pconnect
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101104001058|127.0.0.1|SQL|2010-11-04 00:10:58|SQL_logged from show_404, 43
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|_dbclose CLOSED
20101104001058|127.0.0.1|INFO|2010-11-04 00:10:58|pasteboard.Complete (30.492 seconds)
20101104001058|127.0.0.1|__ERROR_WARNING|2010-11-04 00:10:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|pasteboard.Started
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: useragents-config
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: dates-config
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: fopen-config
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: stopwords-config
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-database
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-useragent
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-hooks
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-sessions
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-cache
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-scaffolding
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-errors
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-uri
20101104002051|127.0.0.1|INCLUDE|2010-11-04 00:20:51|library: pb-logs
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_set_timezone: US/Pacific
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_sitewhoami: default Initialized
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_uri_segment: QUERY_STRING
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_useragent:  
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_useragent: 
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_init_session: Not Implemented
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_dbopen: mysql_pconnect
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101104002051|127.0.0.1|SQL|2010-11-04 00:20:51|SQL_logged from show_404, 43
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|_dbclose CLOSED
20101104002051|127.0.0.1|INFO|2010-11-04 00:20:51|pasteboard.Complete (25543.602 seconds)
20101104002051|127.0.0.1|__ERROR_WARNING|2010-11-04 00:20:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
