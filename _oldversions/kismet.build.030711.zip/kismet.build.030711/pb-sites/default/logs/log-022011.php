20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|pasteboard.Started
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|pasteboard.Started
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: useragents-config
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: useragents-config
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: dates-config
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: dates-config
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: fopen-config
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: fopen-config
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: stopwords-config
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: stopwords-config
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-database
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-database
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-useragent
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-useragent
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-hooks
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-hooks
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-sessions
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-sessions
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-cache
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-cache
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-scaffolding
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-scaffolding
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-errors
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-uri
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-errors
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-logs
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-uri
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_set_timezone: US/Pacific
20110220155513|127.0.0.1|INCLUDE|2011-02-20 15:55:13|library: pb-logs
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_sitewhoami: default Initialized
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_set_timezone: US/Pacific
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_sitewhoami: default Initialized
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_uri_segment: QUERY_STRING
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_uri_segment: QUERY_STRING
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_useragent:  
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_useragent:  
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_useragent: 
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_init_session: Not Implemented
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_useragent: 
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_init_session: Not Implemented
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_dbopen: mysql_pconnect
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155513|127.0.0.1|SQL|2011-02-20 15:55:13|SQL_logged from show_404, 43
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_dbopen: mysql_pconnect
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220155513|127.0.0.1|SQL|2011-02-20 15:55:13|SQL_logged from show_404, 43
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_dbclose CLOSED
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|pasteboard.Complete (4.913 seconds)
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|_dbclose CLOSED
20110220155513|127.0.0.1|INFO|2011-02-20 15:55:13|pasteboard.Complete (4.914 seconds)
20110220155513|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|pasteboard.Started
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: useragents-config
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: dates-config
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: fopen-config
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: stopwords-config
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-database
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-useragent
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-hooks
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-sessions
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-cache
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-scaffolding
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-errors
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-uri
20110220155535|127.0.0.1|INCLUDE|2011-02-20 15:55:35|library: pb-logs
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_set_timezone: US/Pacific
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_sitewhoami: default Initialized
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_uri_segment: QUERY_STRING
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_useragent:  
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_useragent: 
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_init_session: Not Implemented
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_dbopen: mysql_pconnect
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220155535|127.0.0.1|SQL|2011-02-20 15:55:35|SQL_logged from show_404, 43
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|_dbclose CLOSED
20110220155535|127.0.0.1|INFO|2011-02-20 15:55:35|pasteboard.Complete (0.853 seconds)
20110220155535|127.0.0.1|__ERROR_WARNING|2011-02-20 15:55:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|pasteboard.Started
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: useragents-config
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: dates-config
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: fopen-config
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: stopwords-config
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-database
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-useragent
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-hooks
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-sessions
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-cache
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-scaffolding
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-errors
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-uri
20110220155819|127.0.0.1|INCLUDE|2011-02-20 15:58:18|library: pb-logs
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_set_timezone: US/Pacific
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_sitewhoami: default Initialized
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_uri_segment: QUERY_STRING
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_useragent:  
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_useragent: 
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_init_session: Not Implemented
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_dbopen: mysql_pconnect
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220155819|127.0.0.1|SQL|2011-02-20 15:58:18|SQL_logged from show_404, 43
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|_dbclose CLOSED
20110220155819|127.0.0.1|INFO|2011-02-20 15:58:18|pasteboard.Complete (2.21 seconds)
20110220155819|127.0.0.1|__ERROR_WARNING|2011-02-20 15:58:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|pasteboard.Started
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: useragents-config
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: dates-config
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: fopen-config
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: stopwords-config
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-database
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-useragent
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-hooks
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-sessions
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-cache
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-scaffolding
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-errors
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-uri
20110220155917|127.0.0.1|INCLUDE|2011-02-20 15:59:17|library: pb-logs
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_set_timezone: US/Pacific
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_sitewhoami: default Initialized
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_uri_segment: QUERY_STRING
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_useragent:  
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_useragent: 
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_init_session: Not Implemented
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_dbopen: mysql_pconnect
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220155917|127.0.0.1|SQL|2011-02-20 15:59:17|SQL_logged from show_404, 43
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|_dbclose CLOSED
20110220155917|127.0.0.1|INFO|2011-02-20 15:59:17|pasteboard.Complete (0.52 seconds)
20110220155917|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|pasteboard.Started
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: useragents-config
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: dates-config
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: fopen-config
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: stopwords-config
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-database
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-useragent
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-hooks
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-sessions
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-cache
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-scaffolding
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-errors
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-uri
20110220155936|127.0.0.1|INCLUDE|2011-02-20 15:59:36|library: pb-logs
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_set_timezone: US/Pacific
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_sitewhoami: default Initialized
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_uri_segment: QUERY_STRING
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_useragent:  
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_useragent: 
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_init_session: Not Implemented
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_dbopen: mysql_pconnect
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220155936|127.0.0.1|SQL|2011-02-20 15:59:36|SQL_logged from show_404, 43
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|_dbclose CLOSED
20110220155936|127.0.0.1|INFO|2011-02-20 15:59:36|pasteboard.Complete (1.892 seconds)
20110220155936|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|pasteboard.Started
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: useragents-config
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: dates-config
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: fopen-config
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: stopwords-config
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-database
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-useragent
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-hooks
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-sessions
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-cache
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-scaffolding
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-errors
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-uri
20110220155947|127.0.0.1|INCLUDE|2011-02-20 15:59:47|library: pb-logs
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_set_timezone: US/Pacific
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_sitewhoami: default Initialized
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_uri_segment: QUERY_STRING
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_useragent:  
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_useragent: 
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_init_session: Not Implemented
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_dbopen: mysql_pconnect
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220155947|127.0.0.1|SQL|2011-02-20 15:59:47|SQL_logged from show_404, 43
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|_dbclose CLOSED
20110220155947|127.0.0.1|INFO|2011-02-20 15:59:47|pasteboard.Complete (0.642 seconds)
20110220155947|127.0.0.1|__ERROR_WARNING|2011-02-20 15:59:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|pasteboard.Started
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: useragents-config
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: dates-config
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: fopen-config
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: stopwords-config
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-database
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-useragent
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-hooks
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-sessions
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-cache
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-scaffolding
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-errors
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-uri
20110220160517|127.0.0.1|INCLUDE|2011-02-20 16:05:17|library: pb-logs
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_set_timezone: US/Pacific
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_sitewhoami: default Initialized
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_uri_segment: QUERY_STRING
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_useragent:  
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_useragent: 
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_init_session: Not Implemented
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_dbopen: mysql_pconnect
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220160517|127.0.0.1|SQL|2011-02-20 16:05:17|SQL_logged from show_404, 43
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|_dbclose CLOSED
20110220160517|127.0.0.1|INFO|2011-02-20 16:05:17|pasteboard.Complete (1.897 seconds)
20110220160517|127.0.0.1|__ERROR_WARNING|2011-02-20 16:05:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|pasteboard.Started
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: useragents-config
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: dates-config
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: fopen-config
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: stopwords-config
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-database
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-useragent
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-hooks
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-sessions
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-cache
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-scaffolding
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-errors
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-uri
20110220163622|127.0.0.1|INCLUDE|2011-02-20 16:36:22|library: pb-logs
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_set_timezone: US/Pacific
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_sitewhoami: default Initialized
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_uri_segment: QUERY_STRING
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_useragent:  
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_useragent: 
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_init_session: Not Implemented
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_dbopen: mysql_pconnect
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220163622|127.0.0.1|SQL|2011-02-20 16:36:22|SQL_logged from show_404, 43
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|_dbclose CLOSED
20110220163622|127.0.0.1|INFO|2011-02-20 16:36:22|pasteboard.Complete (2.269 seconds)
20110220163622|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|pasteboard.Started
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: useragents-config
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: dates-config
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: fopen-config
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: stopwords-config
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-database
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-useragent
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-hooks
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-sessions
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-cache
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-scaffolding
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-errors
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-uri
20110220163629|127.0.0.1|INCLUDE|2011-02-20 16:36:29|library: pb-logs
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_set_timezone: US/Pacific
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_sitewhoami: default Initialized
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_uri_segment: QUERY_STRING
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_useragent:  
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_useragent: 
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_init_session: Not Implemented
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_dbopen: mysql_pconnect
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220163629|127.0.0.1|SQL|2011-02-20 16:36:29|SQL_logged from show_404, 43
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|_dbclose CLOSED
20110220163629|127.0.0.1|INFO|2011-02-20 16:36:29|pasteboard.Complete (0.813 seconds)
20110220163629|127.0.0.1|__ERROR_WARNING|2011-02-20 16:36:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|pasteboard.Started
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: useragents-config
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: dates-config
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: fopen-config
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: stopwords-config
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-database
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-useragent
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-hooks
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-sessions
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-cache
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-scaffolding
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-errors
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-uri
20110220163751|127.0.0.1|INCLUDE|2011-02-20 16:37:51|library: pb-logs
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_set_timezone: US/Pacific
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_sitewhoami: default Initialized
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_uri_segment: QUERY_STRING
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_useragent:  
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_useragent: 
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_init_session: Not Implemented
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_dbopen: mysql_pconnect
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220163751|127.0.0.1|SQL|2011-02-20 16:37:51|SQL_logged from show_404, 43
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|_dbclose CLOSED
20110220163751|127.0.0.1|INFO|2011-02-20 16:37:51|pasteboard.Complete (1.186 seconds)
20110220163751|127.0.0.1|__ERROR_WARNING|2011-02-20 16:37:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|pasteboard.Started
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: useragents-config
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: dates-config
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: fopen-config
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: stopwords-config
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-database
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-useragent
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-hooks
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-sessions
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-cache
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-scaffolding
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-errors
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-uri
20110220163816|127.0.0.1|INCLUDE|2011-02-20 16:38:16|library: pb-logs
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_set_timezone: US/Pacific
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_sitewhoami: default Initialized
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_uri_segment: QUERY_STRING
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_useragent:  
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_useragent: 
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_init_session: Not Implemented
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_dbopen: mysql_pconnect
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220163816|127.0.0.1|SQL|2011-02-20 16:38:16|SQL_logged from show_404, 43
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|_dbclose CLOSED
20110220163816|127.0.0.1|INFO|2011-02-20 16:38:16|pasteboard.Complete (0.36 seconds)
20110220163816|127.0.0.1|__ERROR_WARNING|2011-02-20 16:38:16|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|pasteboard.Started
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: useragents-config
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: dates-config
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: fopen-config
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: stopwords-config
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-database
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-useragent
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-hooks
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-sessions
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-cache
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-scaffolding
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-errors
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-uri
20110220164021|127.0.0.1|INCLUDE|2011-02-20 16:40:21|library: pb-logs
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_set_timezone: US/Pacific
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_sitewhoami: default Initialized
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_uri_segment: QUERY_STRING
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_useragent:  
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_useragent: 
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_init_session: Not Implemented
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_dbopen: mysql_pconnect
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220164021|127.0.0.1|SQL|2011-02-20 16:40:21|SQL_logged from show_404, 43
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|_dbclose CLOSED
20110220164021|127.0.0.1|INFO|2011-02-20 16:40:21|pasteboard.Complete (1.46 seconds)
20110220164021|127.0.0.1|__ERROR_WARNING|2011-02-20 16:40:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|pasteboard.Started
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: useragents-config
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: dates-config
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: fopen-config
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: stopwords-config
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-database
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-useragent
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-hooks
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-sessions
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-cache
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-scaffolding
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-errors
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-uri
20110220164129|127.0.0.1|INCLUDE|2011-02-20 16:41:29|library: pb-logs
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_set_timezone: US/Pacific
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_sitewhoami: default Initialized
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_uri_segment: QUERY_STRING
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_useragent:  
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_useragent: 
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_init_session: Not Implemented
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_dbopen: mysql_pconnect
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110220164129|127.0.0.1|SQL|2011-02-20 16:41:29|SQL_logged from show_404, 43
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|_dbclose CLOSED
20110220164129|127.0.0.1|INFO|2011-02-20 16:41:29|pasteboard.Complete (1.787 seconds)
20110220164129|127.0.0.1|__ERROR_WARNING|2011-02-20 16:41:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
