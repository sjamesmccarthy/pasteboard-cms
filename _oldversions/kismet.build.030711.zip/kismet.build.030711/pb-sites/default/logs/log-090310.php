20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|pasteboard.Started
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: useragents-config
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|pasteboard.Started
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: dates-config
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: useragents-config
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: fopen-config
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: dates-config
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: stopwords-config
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-database
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-useragent
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-hooks
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-sessions
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-cache
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-scaffolding
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-errors
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-uri
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-logs
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_set_timezone: US/Pacific
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_sitewhoami: default Initialized
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: fopen-config
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: stopwords-config
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_uri_segment: QUERY_STRING
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-database
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-useragent
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-hooks
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-sessions
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_useragent:  
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-cache
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-scaffolding
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_useragent: 
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-errors
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_init_session: Not Implemented
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-uri
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|INCLUDE|2010-09-03 17:00:00|library: pb-logs
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_set_timezone: US/Pacific
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_sitewhoami: default Initialized
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_uri_segment: QUERY_STRING
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_useragent:  
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_useragent: 
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_init_session: Not Implemented
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_dbopen: mysql_pconnect
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_dbopen: mysql_pconnect
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903170000|127.0.0.1|SQL|2010-09-03 17:00:00|SQL_logged from show_404, 43
20100903170000|127.0.0.1|SQL|2010-09-03 17:00:00|SQL_logged from show_404, 43
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_dbclose CLOSED
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|_dbclose CLOSED
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|pasteboard.Complete (2.559 seconds)
20100903170000|127.0.0.1|INFO|2010-09-03 17:00:00|pasteboard.Complete (2.559 seconds)
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903170000|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|pasteboard.Started
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: useragents-config
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: dates-config
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: fopen-config
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: stopwords-config
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-database
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-useragent
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-hooks
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-sessions
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-cache
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-scaffolding
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-errors
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-uri
20100903170053|127.0.0.1|INCLUDE|2010-09-03 17:00:53|library: pb-logs
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_set_timezone: US/Pacific
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_sitewhoami: default Initialized
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_uri_segment: QUERY_STRING
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_useragent:  
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_useragent: 
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_init_session: Not Implemented
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_dbopen: mysql_pconnect
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903170053|127.0.0.1|SQL|2010-09-03 17:00:53|SQL_logged from show_404, 43
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|_dbclose CLOSED
20100903170053|127.0.0.1|INFO|2010-09-03 17:00:53|pasteboard.Complete (0.716 seconds)
20100903170053|127.0.0.1|__ERROR_WARNING|2010-09-03 17:00:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|pasteboard.Started
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: useragents-config
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: dates-config
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: fopen-config
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: stopwords-config
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-database
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-useragent
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-hooks
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-sessions
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-cache
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-scaffolding
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-errors
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-uri
20100903170115|127.0.0.1|INCLUDE|2010-09-03 17:01:15|library: pb-logs
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_set_timezone: US/Pacific
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_sitewhoami: default Initialized
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_uri_segment: QUERY_STRING
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_useragent:  
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_useragent: 
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_init_session: Not Implemented
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_dbopen: mysql_pconnect
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903170115|127.0.0.1|SQL|2010-09-03 17:01:15|SQL_logged from show_404, 43
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|_dbclose CLOSED
20100903170115|127.0.0.1|INFO|2010-09-03 17:01:15|pasteboard.Complete (0.524 seconds)
20100903170115|127.0.0.1|__ERROR_WARNING|2010-09-03 17:01:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|pasteboard.Started
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: useragents-config
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: dates-config
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: fopen-config
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: stopwords-config
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-database
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-useragent
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-hooks
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-sessions
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-cache
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-scaffolding
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-errors
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-uri
20100903170256|127.0.0.1|INCLUDE|2010-09-03 17:02:56|library: pb-logs
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_set_timezone: US/Pacific
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_sitewhoami: default Initialized
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_uri_segment: QUERY_STRING
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_useragent:  
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_useragent: 
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_init_session: Not Implemented
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_dbopen: mysql_pconnect
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903170256|127.0.0.1|SQL|2010-09-03 17:02:56|SQL_logged from show_404, 43
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|_dbclose CLOSED
20100903170256|127.0.0.1|INFO|2010-09-03 17:02:56|pasteboard.Complete (0.666 seconds)
20100903170256|127.0.0.1|__ERROR_WARNING|2010-09-03 17:02:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|pasteboard.Started
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: useragents-config
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: dates-config
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: fopen-config
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: stopwords-config
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-database
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-useragent
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-hooks
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-sessions
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-cache
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-scaffolding
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-errors
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-uri
20100903170352|127.0.0.1|INCLUDE|2010-09-03 17:03:52|library: pb-logs
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_set_timezone: US/Pacific
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_sitewhoami: default Initialized
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_uri_segment: QUERY_STRING
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_useragent:  
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_useragent: 
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_init_session: Not Implemented
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_dbopen: mysql_pconnect
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903170352|127.0.0.1|SQL|2010-09-03 17:03:52|SQL_logged from show_404, 43
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|_dbclose CLOSED
20100903170352|127.0.0.1|INFO|2010-09-03 17:03:52|pasteboard.Complete (0.724 seconds)
20100903170352|127.0.0.1|__ERROR_WARNING|2010-09-03 17:03:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|pasteboard.Started
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: useragents-config
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: dates-config
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: fopen-config
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: stopwords-config
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-database
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-useragent
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-hooks
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-sessions
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-cache
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-scaffolding
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-errors
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-uri
20100903170916|127.0.0.1|INCLUDE|2010-09-03 17:09:16|library: pb-logs
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_set_timezone: US/Pacific
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_sitewhoami: default Initialized
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_uri_segment: QUERY_STRING
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_useragent:  
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_useragent: 
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_init_session: Not Implemented
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_dbopen: mysql_pconnect
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903170916|127.0.0.1|SQL|2010-09-03 17:09:16|SQL_logged from show_404, 43
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|_dbclose CLOSED
20100903170916|127.0.0.1|INFO|2010-09-03 17:09:16|pasteboard.Complete (0.247 seconds)
20100903170916|127.0.0.1|__ERROR_WARNING|2010-09-03 17:09:16|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|pasteboard.Started
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: useragents-config
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|pasteboard.Started
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: dates-config
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: useragents-config
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: fopen-config
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: dates-config
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: stopwords-config
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: fopen-config
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: stopwords-config
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-database
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-useragent
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-hooks
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-sessions
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-cache
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-scaffolding
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-errors
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-uri
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-logs
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_set_timezone: US/Pacific
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_sitewhoami: default Initialized
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_uri_segment: QUERY_STRING
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_useragent:  
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_useragent: 
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_init_session: Not Implemented
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-database
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-useragent
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-hooks
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-sessions
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-cache
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-scaffolding
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-errors
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-uri
20100903171002|127.0.0.1|INCLUDE|2010-09-03 17:10:02|library: pb-logs
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_set_timezone: US/Pacific
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_sitewhoami: default Initialized
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_uri_segment: QUERY_STRING
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_useragent:  
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_useragent: 
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_init_session: Not Implemented
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_dbopen: mysql_pconnect
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903171002|127.0.0.1|SQL|2010-09-03 17:10:02|SQL_logged from show_404, 43
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_dbclose CLOSED
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|pasteboard.Complete (0.644 seconds)
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_dbopen: mysql_pconnect
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903171002|127.0.0.1|SQL|2010-09-03 17:10:02|SQL_logged from show_404, 43
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|_dbclose CLOSED
20100903171002|127.0.0.1|INFO|2010-09-03 17:10:02|pasteboard.Complete (0.65 seconds)
20100903171002|127.0.0.1|__ERROR_WARNING|2010-09-03 17:10:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|pasteboard.Started
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|pasteboard.Started
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: useragents-config
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: dates-config
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: fopen-config
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: useragents-config
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: stopwords-config
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-database
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-useragent
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-hooks
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-sessions
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-cache
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-scaffolding
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-errors
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-uri
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-logs
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_set_timezone: US/Pacific
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_sitewhoami: default Initialized
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_uri_segment: QUERY_STRING
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_useragent:  
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_useragent: 
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_init_session: Not Implemented
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: dates-config
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: fopen-config
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: stopwords-config
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-database
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-useragent
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-hooks
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-sessions
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-cache
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-scaffolding
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-errors
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-uri
20100903171149|127.0.0.1|INCLUDE|2010-09-03 17:11:49|library: pb-logs
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_set_timezone: US/Pacific
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_sitewhoami: default Initialized
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_uri_segment: QUERY_STRING
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_useragent:  
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_useragent: 
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_init_session: Not Implemented
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_dbopen: mysql_pconnect
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903171149|127.0.0.1|SQL|2010-09-03 17:11:49|SQL_logged from show_404, 43
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_dbopen: mysql_pconnect
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903171149|127.0.0.1|SQL|2010-09-03 17:11:49|SQL_logged from show_404, 43
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_dbclose CLOSED
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|pasteboard.Complete (0.998 seconds)
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|_dbclose CLOSED
20100903171149|127.0.0.1|INFO|2010-09-03 17:11:49|pasteboard.Complete (1.085 seconds)
20100903171149|127.0.0.1|__ERROR_WARNING|2010-09-03 17:11:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|pasteboard.Started
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|pasteboard.Started
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: useragents-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: useragents-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: dates-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: dates-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: fopen-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: fopen-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: stopwords-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: stopwords-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-database
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-database
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-useragent
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-useragent
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-hooks
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-hooks
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-sessions
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-sessions
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-cache
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-cache
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-scaffolding
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-scaffolding
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-errors
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-errors
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-uri
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-uri
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-logs
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-logs
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_set_timezone: US/Pacific
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_set_timezone: US/Pacific
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_sitewhoami: default Initialized
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_sitewhoami: default Initialized
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|pasteboard.Started
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_uri_segment: QUERY_STRING
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: useragents-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: dates-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: fopen-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: stopwords-config
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-database
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-useragent
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-hooks
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_useragent:  
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_uri_segment: QUERY_STRING
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-sessions
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-cache
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-scaffolding
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-errors
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-uri
20100903213454|127.0.0.1|INCLUDE|2010-09-03 21:34:54|library: pb-logs
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_set_timezone: US/Pacific
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_sitewhoami: default Initialized
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_useragent:  
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_uri_segment: QUERY_STRING
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_useragent: 
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_init_session: Not Implemented
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_useragent: 
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_init_session: Not Implemented
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_useragent:  
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_useragent: 
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_init_session: Not Implemented
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_dbopen: mysql_pconnect
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903213454|127.0.0.1|SQL|2010-09-03 21:34:54|SQL_logged from show_404, 43
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_dbopen: mysql_pconnect
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903213454|127.0.0.1|SQL|2010-09-03 21:34:54|SQL_logged from show_404, 43
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_dbopen: mysql_pconnect
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903213454|127.0.0.1|SQL|2010-09-03 21:34:54|SQL_logged from show_404, 43
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_dbclose CLOSED
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_dbclose CLOSED
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|pasteboard.Complete (30.911 seconds)
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|_dbclose CLOSED
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|pasteboard.Complete (30.912 seconds)
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903213454|127.0.0.1|INFO|2010-09-03 21:34:54|pasteboard.Complete (30.911 seconds)
20100903213454|127.0.0.1|__ERROR_WARNING|2010-09-03 21:34:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|pasteboard.Started
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: useragents-config
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: dates-config
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: fopen-config
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: stopwords-config
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-database
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-useragent
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-hooks
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-sessions
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-cache
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-scaffolding
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-errors
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-uri
20100903213913|127.0.0.1|INCLUDE|2010-09-03 21:39:13|library: pb-logs
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_set_timezone: US/Pacific
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_sitewhoami: default Initialized
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_uri_segment: QUERY_STRING
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_useragent:  
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_useragent: 
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_init_session: Not Implemented
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_dbopen: mysql_pconnect
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903213913|127.0.0.1|SQL|2010-09-03 21:39:13|SQL_logged from show_404, 43
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|_dbclose CLOSED
20100903213913|127.0.0.1|INFO|2010-09-03 21:39:13|pasteboard.Complete (31.557 seconds)
20100903213913|127.0.0.1|__ERROR_WARNING|2010-09-03 21:39:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|pasteboard.Started
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: useragents-config
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: dates-config
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: fopen-config
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: stopwords-config
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-database
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-useragent
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-hooks
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-sessions
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-cache
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-scaffolding
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-errors
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-uri
20100903214007|127.0.0.1|INCLUDE|2010-09-03 21:40:07|library: pb-logs
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_set_timezone: US/Pacific
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_sitewhoami: default Initialized
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_uri_segment: QUERY_STRING
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_useragent:  
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_useragent: 
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_init_session: Not Implemented
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|pasteboard.Started
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: useragents-config
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: dates-config
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: fopen-config
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: stopwords-config
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-database
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-useragent
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-hooks
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-sessions
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-cache
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-scaffolding
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-errors
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-uri
20100903214035|127.0.0.1|INCLUDE|2010-09-03 21:40:35|library: pb-logs
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_set_timezone: US/Pacific
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_sitewhoami: default Initialized
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_uri_segment: QUERY_STRING
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_useragent:  
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_useragent: 
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_init_session: Not Implemented
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_dbopen: mysql_pconnect
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903214007|127.0.0.1|SQL|2010-09-03 21:40:07|SQL_logged from show_404, 43
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|_dbclose CLOSED
20100903214007|127.0.0.1|INFO|2010-09-03 21:40:07|pasteboard.Complete (30.737 seconds)
20100903214007|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:07|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_dbopen: mysql_pconnect
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903214035|127.0.0.1|SQL|2010-09-03 21:40:35|SQL_logged from show_404, 43
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|_dbclose CLOSED
20100903214035|127.0.0.1|INFO|2010-09-03 21:40:35|pasteboard.Complete (31.069 seconds)
20100903214035|127.0.0.1|__ERROR_WARNING|2010-09-03 21:40:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|pasteboard.Started
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: useragents-config
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: dates-config
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: fopen-config
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: stopwords-config
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-database
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-useragent
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-hooks
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-sessions
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-cache
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-scaffolding
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-errors
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-uri
20100903215038|127.0.0.1|INCLUDE|2010-09-03 21:50:38|library: pb-logs
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_set_timezone: US/Pacific
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_sitewhoami: default Initialized
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_uri_segment: QUERY_STRING
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_useragent:  
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_useragent: 
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_init_session: Not Implemented
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_dbopen: mysql_pconnect
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100903215038|127.0.0.1|SQL|2010-09-03 21:50:38|SQL_logged from show_404, 43
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|_dbclose CLOSED
20100903215038|127.0.0.1|INFO|2010-09-03 21:50:38|pasteboard.Complete (30.244 seconds)
20100903215038|127.0.0.1|__ERROR_WARNING|2010-09-03 21:50:38|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
