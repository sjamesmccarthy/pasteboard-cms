20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|pasteboard.Started
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: useragents-config
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: dates-config
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: fopen-config
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: stopwords-config
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-database
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-useragent
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-hooks
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-sessions
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-cache
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-scaffolding
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-errors
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-uri
20110306203943|127.0.0.1|INCLUDE|2011-03-06 20:39:43|library: pb-logs
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_set_timezone: US/Pacific
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_sitewhoami: default Initialized
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_uri_segment: FRONT PAGE
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_uri_segment: INDEX_WEBROOT
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_useragent: Chrome 10.0.648.127
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_useragent: Mac OS X
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_init_session: Not Implemented
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_dbopen: mysql_pconnect
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|app: page Initialized
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306203943|127.0.0.1|SQL|2011-03-06 20:39:43|SQL_logged from _get_front_page, 85
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|model: page_model.php Function: _get_front_page
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|app: page Function: view
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306203943|127.0.0.1|SQL|2011-03-06 20:39:43|SQL_logged from _get_content_index, 22
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|model: page_model.php Function: _get_content_index
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|app: page Terminated
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|_dbclose CLOSED
20110306203943|127.0.0.1|INFO|2011-03-06 20:39:43|pasteboard.Complete (2.754 seconds)
20110306203943|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|pasteboard.Started
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: useragents-config
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: dates-config
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: fopen-config
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: stopwords-config
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-database
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-useragent
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-hooks
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-sessions
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-cache
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-scaffolding
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-errors
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-uri
20110306203946|127.0.0.1|INCLUDE|2011-03-06 20:39:46|library: pb-logs
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_set_timezone: US/Pacific
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_sitewhoami: default Initialized
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_uri_segment: SEGMENT_PATH
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_useragent: Chrome 10.0.648.127
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_useragent: Mac OS X
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_init_session: Not Implemented
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_dbopen: mysql_pconnect
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306203946|127.0.0.1|SQL|2011-03-06 20:39:46|SQL_logged from show_404, 43
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|_dbclose CLOSED
20110306203946|127.0.0.1|INFO|2011-03-06 20:39:46|pasteboard.Complete (1.072 seconds)
20110306203946|127.0.0.1|__ERROR_WARNING|2011-03-06 20:39:46|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|pasteboard.Started
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: useragents-config
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: dates-config
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: fopen-config
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: stopwords-config
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-database
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-useragent
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-hooks
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-sessions
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-cache
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-scaffolding
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-errors
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-uri
20110306204103|127.0.0.1|INCLUDE|2011-03-06 20:41:03|library: pb-logs
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_set_timezone: US/Pacific
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_sitewhoami: default Initialized
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_uri_segment: FRONT PAGE
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_uri_segment: INDEX_WEBROOT
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_useragent: Chrome 10.0.648.127
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_useragent: Mac OS X
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_init_session: Not Implemented
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_dbopen: mysql_pconnect
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|app: page Initialized
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204103|127.0.0.1|SQL|2011-03-06 20:41:03|SQL_logged from _get_front_page, 85
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|model: page_model.php Function: _get_front_page
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|app: page Function: view
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204103|127.0.0.1|SQL|2011-03-06 20:41:03|SQL_logged from _get_content_index, 22
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|model: page_model.php Function: _get_content_index
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|app: page Terminated
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|_dbclose CLOSED
20110306204103|127.0.0.1|INFO|2011-03-06 20:41:03|pasteboard.Complete (2.431 seconds)
20110306204103|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:03|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|pasteboard.Started
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: useragents-config
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: dates-config
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: fopen-config
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: stopwords-config
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-database
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-useragent
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-hooks
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-sessions
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-cache
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-scaffolding
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-errors
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-uri
20110306204105|127.0.0.1|INCLUDE|2011-03-06 20:41:05|library: pb-logs
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_set_timezone: US/Pacific
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_sitewhoami: default Initialized
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_uri_segment: SEGMENT_PATH
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_useragent: Chrome 10.0.648.127
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_useragent: Mac OS X
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_init_session: Not Implemented
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_dbopen: mysql_pconnect
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204105|127.0.0.1|SQL|2011-03-06 20:41:05|SQL_logged from show_404, 43
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|_dbclose CLOSED
20110306204105|127.0.0.1|INFO|2011-03-06 20:41:05|pasteboard.Complete (0.913 seconds)
20110306204105|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|pasteboard.Started
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: useragents-config
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: dates-config
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: fopen-config
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: stopwords-config
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-database
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-useragent
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-hooks
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-sessions
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-cache
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-scaffolding
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-errors
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-uri
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-logs
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_set_timezone: US/Pacific
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_sitewhoami: default Initialized
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_uri_segment: FRONT PAGE
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_uri_segment: INDEX_WEBROOT
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_useragent: Chrome 10.0.648.127
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_useragent: Mac OS X
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_init_session: Not Implemented
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_dbopen: mysql_pconnect
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|app: page Initialized
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204109|127.0.0.1|SQL|2011-03-06 20:41:09|SQL_logged from _get_front_page, 85
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|model: page_model.php Function: _get_front_page
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|app: page Function: view
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204109|127.0.0.1|SQL|2011-03-06 20:41:09|SQL_logged from _get_content_index, 22
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|model: page_model.php Function: _get_content_index
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|app: page Terminated
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_dbclose CLOSED
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|pasteboard.Complete (0.033 seconds)
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|pasteboard.Started
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: useragents-config
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: dates-config
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: fopen-config
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: stopwords-config
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-database
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-useragent
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-hooks
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-sessions
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-cache
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-scaffolding
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-errors
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-uri
20110306204109|127.0.0.1|INCLUDE|2011-03-06 20:41:09|library: pb-logs
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_set_timezone: US/Pacific
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_sitewhoami: default Initialized
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_uri_segment: SEGMENT_PATH
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_useragent: Chrome 10.0.648.127
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_useragent: Mac OS X
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_init_session: Not Implemented
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_dbopen: mysql_pconnect
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204109|127.0.0.1|SQL|2011-03-06 20:41:09|SQL_logged from show_404, 43
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|_dbclose CLOSED
20110306204109|127.0.0.1|INFO|2011-03-06 20:41:09|pasteboard.Complete (0.411 seconds)
20110306204109|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:09|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|pasteboard.Started
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: useragents-config
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: dates-config
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: fopen-config
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: stopwords-config
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-database
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-useragent
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-hooks
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-sessions
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-cache
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-scaffolding
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-errors
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-uri
20110306204119|127.0.0.1|INCLUDE|2011-03-06 20:41:19|library: pb-logs
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_set_timezone: US/Pacific
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_sitewhoami: default Initialized
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_uri_segment: FRONT PAGE
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_uri_segment: INDEX_WEBROOT
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_useragent: Chrome 10.0.648.127
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_useragent: Mac OS X
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_init_session: Not Implemented
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_dbopen: mysql_pconnect
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|app: page Initialized
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204119|127.0.0.1|SQL|2011-03-06 20:41:19|SQL_logged from _get_front_page, 85
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|model: page_model.php Function: _get_front_page
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|app: page Function: view
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204119|127.0.0.1|SQL|2011-03-06 20:41:19|SQL_logged from _get_content_index, 22
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|model: page_model.php Function: _get_content_index
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|app: page Terminated
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|_dbclose CLOSED
20110306204119|127.0.0.1|INFO|2011-03-06 20:41:19|pasteboard.Complete (0.881 seconds)
20110306204119|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|pasteboard.Started
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: useragents-config
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: dates-config
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: fopen-config
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: stopwords-config
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-database
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-useragent
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-hooks
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-sessions
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-cache
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-scaffolding
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-errors
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-uri
20110306204120|127.0.0.1|INCLUDE|2011-03-06 20:41:20|library: pb-logs
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_set_timezone: US/Pacific
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_sitewhoami: default Initialized
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_uri_segment: SEGMENT_PATH
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_useragent: Chrome 10.0.648.127
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_useragent: Mac OS X
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_init_session: Not Implemented
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_dbopen: mysql_pconnect
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204120|127.0.0.1|SQL|2011-03-06 20:41:20|SQL_logged from show_404, 43
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|_dbclose CLOSED
20110306204120|127.0.0.1|INFO|2011-03-06 20:41:20|pasteboard.Complete (0.351 seconds)
20110306204120|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:20|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|pasteboard.Started
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: useragents-config
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: dates-config
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: fopen-config
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: stopwords-config
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-database
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-useragent
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-hooks
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-sessions
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-cache
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-scaffolding
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-errors
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-uri
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-logs
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_set_timezone: US/Pacific
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_sitewhoami: default Initialized
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_uri_segment: FRONT PAGE
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_uri_segment: INDEX_WEBROOT
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_useragent: Chrome 10.0.648.127
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_useragent: Mac OS X
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_init_session: Not Implemented
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_dbopen: mysql_pconnect
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|app: page Initialized
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204135|127.0.0.1|SQL|2011-03-06 20:41:35|SQL_logged from _get_front_page, 85
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|model: page_model.php Function: _get_front_page
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|app: page Function: view
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204135|127.0.0.1|SQL|2011-03-06 20:41:35|SQL_logged from _get_content_index, 22
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|model: page_model.php Function: _get_content_index
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|app: page Terminated
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_dbclose CLOSED
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|pasteboard.Complete (0.184 seconds)
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|pasteboard.Started
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: useragents-config
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: dates-config
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: fopen-config
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: stopwords-config
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-database
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-useragent
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-hooks
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-sessions
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-cache
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-scaffolding
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-errors
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-uri
20110306204135|127.0.0.1|INCLUDE|2011-03-06 20:41:35|library: pb-logs
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_set_timezone: US/Pacific
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_sitewhoami: default Initialized
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_uri_segment: SEGMENT_PATH
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_useragent: Chrome 10.0.648.127
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_useragent: Mac OS X
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_init_session: Not Implemented
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_dbopen: mysql_pconnect
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204135|127.0.0.1|SQL|2011-03-06 20:41:35|SQL_logged from show_404, 43
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|_dbclose CLOSED
20110306204135|127.0.0.1|INFO|2011-03-06 20:41:35|pasteboard.Complete (0.643 seconds)
20110306204135|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:35|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|pasteboard.Started
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: useragents-config
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: dates-config
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: fopen-config
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: stopwords-config
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-database
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-useragent
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-hooks
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-sessions
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-cache
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-scaffolding
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-errors
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-uri
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-logs
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_set_timezone: US/Pacific
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_sitewhoami: default Initialized
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_uri_segment: FRONT PAGE
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_uri_segment: INDEX_WEBROOT
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_useragent: Chrome 10.0.648.127
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_useragent: Mac OS X
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_init_session: Not Implemented
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_dbopen: mysql_pconnect
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|app: page Initialized
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204137|127.0.0.1|SQL|2011-03-06 20:41:37|SQL_logged from _get_front_page, 85
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|model: page_model.php Function: _get_front_page
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|app: page Function: view
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204137|127.0.0.1|SQL|2011-03-06 20:41:37|SQL_logged from _get_content_index, 22
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|model: page_model.php Function: _get_content_index
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|app: page Terminated
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_dbclose CLOSED
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|pasteboard.Complete (0.404 seconds)
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|pasteboard.Started
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: useragents-config
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: dates-config
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: fopen-config
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: stopwords-config
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-database
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-useragent
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-hooks
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-sessions
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-cache
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-scaffolding
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-errors
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-uri
20110306204137|127.0.0.1|INCLUDE|2011-03-06 20:41:37|library: pb-logs
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_set_timezone: US/Pacific
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_sitewhoami: default Initialized
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_uri_segment: SEGMENT_PATH
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_useragent: Chrome 10.0.648.127
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_useragent: Mac OS X
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_init_session: Not Implemented
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_dbopen: mysql_pconnect
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204137|127.0.0.1|SQL|2011-03-06 20:41:37|SQL_logged from show_404, 43
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|_dbclose CLOSED
20110306204137|127.0.0.1|INFO|2011-03-06 20:41:37|pasteboard.Complete (0.789 seconds)
20110306204137|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|pasteboard.Started
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: useragents-config
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: dates-config
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: fopen-config
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: stopwords-config
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-database
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-useragent
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-hooks
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-sessions
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-cache
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-scaffolding
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-errors
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-uri
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-logs
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_set_timezone: US/Pacific
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_sitewhoami: default Initialized
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_uri_segment: FRONT PAGE
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_uri_segment: INDEX_WEBROOT
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_useragent: Chrome 10.0.648.127
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_useragent: Mac OS X
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_init_session: Not Implemented
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_dbopen: mysql_pconnect
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|app: page Initialized
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204147|127.0.0.1|SQL|2011-03-06 20:41:47|SQL_logged from _get_front_page, 85
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|NO RECORDS RETURNED: 0-> Line 97-> function: _get_front_page-> file: /Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/models/page_model.php
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|model: page_model.php Function: _get_front_page
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined index: page_template [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/page_controller.php, 64]
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|app: page Function: view
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined variable: page_content [/Users/james/Dropbox/pasteboard/www/pb-sites/default/apps/page/views/view_index.php, 32]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204147|127.0.0.1|SQL|2011-03-06 20:41:47|SQL_logged from _get_content_index, 22
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|model: page_model.php Function: _get_content_index
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|app: page Terminated
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_dbclose CLOSED
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|pasteboard.Complete (0.237 seconds)
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|pasteboard.Started
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: useragents-config
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: dates-config
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: fopen-config
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: stopwords-config
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-database
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-useragent
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-hooks
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-sessions
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-cache
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-scaffolding
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-errors
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-uri
20110306204147|127.0.0.1|INCLUDE|2011-03-06 20:41:47|library: pb-logs
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_set_timezone: US/Pacific
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_sitewhoami: default Initialized
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_uri_segment: SEGMENT_PATH
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_useragent: Chrome 10.0.648.127
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_useragent: Mac OS X
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_init_session: Not Implemented
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_dbopen: mysql_pconnect
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110306204147|127.0.0.1|SQL|2011-03-06 20:41:47|SQL_logged from show_404, 43
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|_dbclose CLOSED
20110306204147|127.0.0.1|INFO|2011-03-06 20:41:47|pasteboard.Complete (1.019 seconds)
20110306204147|127.0.0.1|__ERROR_WARNING|2011-03-06 20:41:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
