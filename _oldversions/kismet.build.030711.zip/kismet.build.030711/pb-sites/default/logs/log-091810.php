20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|pasteboard.Started
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: useragents-config
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: dates-config
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: fopen-config
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: stopwords-config
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-database
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-useragent
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-hooks
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-sessions
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-cache
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-scaffolding
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-errors
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-uri
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-logs
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_set_timezone: US/Pacific
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_sitewhoami: default Initialized
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_uri_segment: QUERY_STRING
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|pasteboard.Started
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: useragents-config
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: dates-config
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: fopen-config
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: stopwords-config
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-database
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-useragent
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-hooks
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-sessions
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-cache
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-scaffolding
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-errors
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-uri
20100918182710|127.0.0.1|INCLUDE|2010-09-18 18:27:10|library: pb-logs
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_set_timezone: US/Pacific
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_sitewhoami: default Initialized
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_uri_segment: QUERY_STRING
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_useragent:  
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_useragent: 
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_init_session: Not Implemented
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_useragent:  
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_useragent: 
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_init_session: Not Implemented
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_dbopen: mysql_pconnect
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_dbopen: mysql_pconnect
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918182710|127.0.0.1|SQL|2010-09-18 18:27:10|SQL_logged from show_404, 43
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918182710|127.0.0.1|SQL|2010-09-18 18:27:10|SQL_logged from show_404, 43
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_dbclose CLOSED
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|_dbclose CLOSED
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|pasteboard.Complete (34.249 seconds)
20100918182710|127.0.0.1|INFO|2010-09-18 18:27:10|pasteboard.Complete (34.249 seconds)
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918182710|127.0.0.1|__ERROR_WARNING|2010-09-18 18:27:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|pasteboard.Started
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: useragents-config
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: dates-config
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: fopen-config
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: stopwords-config
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-database
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-useragent
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-hooks
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-sessions
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-cache
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-scaffolding
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-errors
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-uri
20100918183745|127.0.0.1|INCLUDE|2010-09-18 18:37:45|library: pb-logs
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_set_timezone: US/Pacific
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_sitewhoami: default Initialized
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_uri_segment: QUERY_STRING
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_useragent:  
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_useragent: 
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_init_session: Not Implemented
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_dbopen: mysql_pconnect
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918183745|127.0.0.1|SQL|2010-09-18 18:37:45|SQL_logged from show_404, 43
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|_dbclose CLOSED
20100918183745|127.0.0.1|INFO|2010-09-18 18:37:45|pasteboard.Complete (31.754 seconds)
20100918183745|127.0.0.1|__ERROR_WARNING|2010-09-18 18:37:45|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|pasteboard.Started
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: useragents-config
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: dates-config
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: fopen-config
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: stopwords-config
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-database
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-useragent
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-hooks
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-sessions
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-cache
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-scaffolding
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-errors
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-uri
20100918184817|127.0.0.1|INCLUDE|2010-09-18 18:48:17|library: pb-logs
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_set_timezone: US/Pacific
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_sitewhoami: default Initialized
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_uri_segment: QUERY_STRING
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_useragent:  
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_useragent: 
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_init_session: Not Implemented
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_dbopen: mysql_pconnect
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918184817|127.0.0.1|SQL|2010-09-18 18:48:17|SQL_logged from show_404, 43
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|_dbclose CLOSED
20100918184817|127.0.0.1|INFO|2010-09-18 18:48:17|pasteboard.Complete (30.526 seconds)
20100918184817|127.0.0.1|__ERROR_WARNING|2010-09-18 18:48:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|pasteboard.Started
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: useragents-config
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: dates-config
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: fopen-config
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: stopwords-config
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-database
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-useragent
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-hooks
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-sessions
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-cache
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-scaffolding
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-errors
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-uri
20100918185849|127.0.0.1|INCLUDE|2010-09-18 18:58:49|library: pb-logs
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_set_timezone: US/Pacific
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_sitewhoami: default Initialized
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_uri_segment: QUERY_STRING
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_useragent:  
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_useragent: 
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_init_session: Not Implemented
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_dbopen: mysql_pconnect
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918185849|127.0.0.1|SQL|2010-09-18 18:58:49|SQL_logged from show_404, 43
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|_dbclose CLOSED
20100918185849|127.0.0.1|INFO|2010-09-18 18:58:49|pasteboard.Complete (30.841 seconds)
20100918185849|127.0.0.1|__ERROR_WARNING|2010-09-18 18:58:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|pasteboard.Started
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: useragents-config
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: dates-config
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: fopen-config
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: stopwords-config
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-database
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-useragent
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-hooks
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-sessions
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-cache
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-scaffolding
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-errors
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-uri
20100918190122|127.0.0.1|INCLUDE|2010-09-18 19:01:22|library: pb-logs
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_set_timezone: US/Pacific
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_sitewhoami: default Initialized
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_uri_segment: QUERY_STRING
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_useragent:  
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_useragent: 
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_init_session: Not Implemented
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_dbopen: mysql_pconnect
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918190122|127.0.0.1|SQL|2010-09-18 19:01:22|SQL_logged from show_404, 43
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|_dbclose CLOSED
20100918190122|127.0.0.1|INFO|2010-09-18 19:01:22|pasteboard.Complete (30.513 seconds)
20100918190122|127.0.0.1|__ERROR_WARNING|2010-09-18 19:01:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|pasteboard.Started
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: useragents-config
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: dates-config
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: fopen-config
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: stopwords-config
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-database
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-useragent
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-hooks
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-sessions
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-cache
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-scaffolding
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-errors
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-uri
20100918190920|127.0.0.1|INCLUDE|2010-09-18 19:09:20|library: pb-logs
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_set_timezone: US/Pacific
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_sitewhoami: default Initialized
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_uri_segment: QUERY_STRING
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_useragent:  
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_useragent: 
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_init_session: Not Implemented
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_dbopen: mysql_pconnect
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918190920|127.0.0.1|SQL|2010-09-18 19:09:20|SQL_logged from show_404, 43
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|_dbclose CLOSED
20100918190920|127.0.0.1|INFO|2010-09-18 19:09:20|pasteboard.Complete (30.589 seconds)
20100918190920|127.0.0.1|__ERROR_WARNING|2010-09-18 19:09:20|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|pasteboard.Started
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: useragents-config
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: dates-config
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: fopen-config
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: stopwords-config
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-database
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-useragent
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-hooks
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-sessions
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-cache
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-scaffolding
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-errors
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-uri
20100918191951|127.0.0.1|INCLUDE|2010-09-18 19:19:51|library: pb-logs
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_set_timezone: US/Pacific
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_sitewhoami: default Initialized
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_uri_segment: QUERY_STRING
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_useragent:  
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_useragent: 
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_init_session: Not Implemented
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_dbopen: mysql_pconnect
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918191951|127.0.0.1|SQL|2010-09-18 19:19:51|SQL_logged from show_404, 43
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|_dbclose CLOSED
20100918191951|127.0.0.1|INFO|2010-09-18 19:19:51|pasteboard.Complete (35.181 seconds)
20100918191951|127.0.0.1|__ERROR_WARNING|2010-09-18 19:19:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|pasteboard.Started
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: useragents-config
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: dates-config
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: fopen-config
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: stopwords-config
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-database
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-useragent
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-hooks
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-sessions
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-cache
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-scaffolding
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-errors
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-uri
20100918193028|127.0.0.1|INCLUDE|2010-09-18 19:30:28|library: pb-logs
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_set_timezone: US/Pacific
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_sitewhoami: default Initialized
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_uri_segment: QUERY_STRING
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_useragent:  
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_useragent: 
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_init_session: Not Implemented
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_dbopen: mysql_pconnect
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918193028|127.0.0.1|SQL|2010-09-18 19:30:28|SQL_logged from show_404, 43
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|_dbclose CLOSED
20100918193028|127.0.0.1|INFO|2010-09-18 19:30:28|pasteboard.Complete (30.628 seconds)
20100918193028|127.0.0.1|__ERROR_WARNING|2010-09-18 19:30:28|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|pasteboard.Started
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: useragents-config
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: dates-config
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: fopen-config
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|pasteboard.Started
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: useragents-config
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: dates-config
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: fopen-config
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: stopwords-config
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-database
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-useragent
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-hooks
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-sessions
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-cache
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-scaffolding
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-errors
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-uri
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-logs
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_set_timezone: US/Pacific
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_sitewhoami: default Initialized
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_uri_segment: QUERY_STRING
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: stopwords-config
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-database
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-useragent
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-hooks
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-sessions
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-cache
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-scaffolding
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-errors
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-uri
20100918195322|127.0.0.1|INCLUDE|2010-09-18 19:53:22|library: pb-logs
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_set_timezone: US/Pacific
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_sitewhoami: default Initialized
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_uri_segment: QUERY_STRING
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_useragent:  
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_useragent: 
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_init_session: Not Implemented
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_useragent:  
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_useragent: 
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_init_session: Not Implemented
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_dbopen: mysql_pconnect
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918195322|127.0.0.1|SQL|2010-09-18 19:53:22|SQL_logged from show_404, 43
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_dbopen: mysql_pconnect
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918195322|127.0.0.1|SQL|2010-09-18 19:53:22|SQL_logged from show_404, 43
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_dbclose CLOSED
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|pasteboard.Complete (33.203 seconds)
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|_dbclose CLOSED
20100918195322|127.0.0.1|INFO|2010-09-18 19:53:22|pasteboard.Complete (33.21 seconds)
20100918195322|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|pasteboard.Started
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: useragents-config
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: dates-config
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: fopen-config
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: stopwords-config
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-database
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-useragent
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-hooks
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-sessions
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-cache
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-scaffolding
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-errors
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-uri
20100918195356|127.0.0.1|INCLUDE|2010-09-18 19:53:56|library: pb-logs
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_set_timezone: US/Pacific
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_sitewhoami: default Initialized
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_uri_segment: QUERY_STRING
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_useragent:  
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_useragent: 
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_init_session: Not Implemented
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_dbopen: mysql_pconnect
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918195356|127.0.0.1|SQL|2010-09-18 19:53:56|SQL_logged from show_404, 43
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|_dbclose CLOSED
20100918195356|127.0.0.1|INFO|2010-09-18 19:53:56|pasteboard.Complete (30.273 seconds)
20100918195356|127.0.0.1|__ERROR_WARNING|2010-09-18 19:53:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|pasteboard.Started
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: useragents-config
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: dates-config
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: fopen-config
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: stopwords-config
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-database
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-useragent
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-hooks
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-sessions
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-cache
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-scaffolding
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-errors
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-uri
20100918200315|127.0.0.1|INCLUDE|2010-09-18 20:03:15|library: pb-logs
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_set_timezone: US/Pacific
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_sitewhoami: default Initialized
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_uri_segment: QUERY_STRING
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_useragent:  
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_useragent: 
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_init_session: Not Implemented
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_dbopen: mysql_pconnect
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918200315|127.0.0.1|SQL|2010-09-18 20:03:15|SQL_logged from show_404, 43
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|_dbclose CLOSED
20100918200315|127.0.0.1|INFO|2010-09-18 20:03:15|pasteboard.Complete (30.228 seconds)
20100918200315|127.0.0.1|__ERROR_WARNING|2010-09-18 20:03:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|pasteboard.Started
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: useragents-config
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: dates-config
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: fopen-config
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: stopwords-config
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-database
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-useragent
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-hooks
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-sessions
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-cache
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-scaffolding
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-errors
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-uri
20100918200427|127.0.0.1|INCLUDE|2010-09-18 20:04:27|library: pb-logs
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_set_timezone: US/Pacific
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_sitewhoami: default Initialized
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_uri_segment: QUERY_STRING
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_useragent:  
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_useragent: 
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_init_session: Not Implemented
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_dbopen: mysql_pconnect
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918200427|127.0.0.1|SQL|2010-09-18 20:04:27|SQL_logged from show_404, 43
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|_dbclose CLOSED
20100918200427|127.0.0.1|INFO|2010-09-18 20:04:27|pasteboard.Complete (30.123 seconds)
20100918200427|127.0.0.1|__ERROR_WARNING|2010-09-18 20:04:27|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|pasteboard.Started
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: useragents-config
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: dates-config
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: fopen-config
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: stopwords-config
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-database
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-useragent
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-hooks
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-sessions
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-cache
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-scaffolding
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-errors
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-uri
20100918201457|127.0.0.1|INCLUDE|2010-09-18 20:14:57|library: pb-logs
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_set_timezone: US/Pacific
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_sitewhoami: default Initialized
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_uri_segment: QUERY_STRING
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_useragent:  
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_useragent: 
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_init_session: Not Implemented
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_dbopen: mysql_pconnect
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918201457|127.0.0.1|SQL|2010-09-18 20:14:57|SQL_logged from show_404, 43
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|_dbclose CLOSED
20100918201457|127.0.0.1|INFO|2010-09-18 20:14:57|pasteboard.Complete (31.107 seconds)
20100918201457|127.0.0.1|__ERROR_WARNING|2010-09-18 20:14:57|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|pasteboard.Started
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: useragents-config
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: dates-config
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: fopen-config
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: stopwords-config
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-database
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-useragent
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-hooks
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-sessions
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-cache
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-scaffolding
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-errors
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-uri
20100918202529|127.0.0.1|INCLUDE|2010-09-18 20:25:29|library: pb-logs
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_set_timezone: US/Pacific
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_sitewhoami: default Initialized
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_uri_segment: QUERY_STRING
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_useragent:  
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_useragent: 
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_init_session: Not Implemented
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_dbopen: mysql_pconnect
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918202529|127.0.0.1|SQL|2010-09-18 20:25:29|SQL_logged from show_404, 43
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|_dbclose CLOSED
20100918202529|127.0.0.1|INFO|2010-09-18 20:25:29|pasteboard.Complete (35.113 seconds)
20100918202529|127.0.0.1|__ERROR_WARNING|2010-09-18 20:25:29|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|pasteboard.Started
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: useragents-config
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: dates-config
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: fopen-config
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: stopwords-config
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-database
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-useragent
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-hooks
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-sessions
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-cache
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-scaffolding
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-errors
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-uri
20100918202715|127.0.0.1|INCLUDE|2010-09-18 20:27:15|library: pb-logs
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_set_timezone: US/Pacific
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_sitewhoami: default Initialized
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_uri_segment: QUERY_STRING
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_useragent:  
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_useragent: 
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_init_session: Not Implemented
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_dbopen: mysql_pconnect
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918202715|127.0.0.1|SQL|2010-09-18 20:27:15|SQL_logged from show_404, 43
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|_dbclose CLOSED
20100918202715|127.0.0.1|INFO|2010-09-18 20:27:15|pasteboard.Complete (30.282 seconds)
20100918202715|127.0.0.1|__ERROR_WARNING|2010-09-18 20:27:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|pasteboard.Started
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: useragents-config
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: dates-config
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: fopen-config
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: stopwords-config
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-database
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-useragent
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-hooks
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-sessions
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-cache
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-scaffolding
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-errors
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-uri
20100918203605|127.0.0.1|INCLUDE|2010-09-18 20:36:05|library: pb-logs
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_set_timezone: US/Pacific
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_sitewhoami: default Initialized
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_uri_segment: QUERY_STRING
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_useragent:  
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_useragent: 
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_init_session: Not Implemented
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_dbopen: mysql_pconnect
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918203605|127.0.0.1|SQL|2010-09-18 20:36:05|SQL_logged from show_404, 43
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|_dbclose CLOSED
20100918203605|127.0.0.1|INFO|2010-09-18 20:36:05|pasteboard.Complete (30.857 seconds)
20100918203605|127.0.0.1|__ERROR_WARNING|2010-09-18 20:36:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|pasteboard.Started
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: useragents-config
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: dates-config
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: fopen-config
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: stopwords-config
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-database
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-useragent
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-hooks
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-sessions
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-cache
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-scaffolding
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-errors
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-uri
20100918204636|127.0.0.1|INCLUDE|2010-09-18 20:46:36|library: pb-logs
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_set_timezone: US/Pacific
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_sitewhoami: default Initialized
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_uri_segment: QUERY_STRING
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_useragent:  
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_useragent: 
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_init_session: Not Implemented
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_dbopen: mysql_pconnect
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918204636|127.0.0.1|SQL|2010-09-18 20:46:36|SQL_logged from show_404, 43
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|_dbclose CLOSED
20100918204636|127.0.0.1|INFO|2010-09-18 20:46:36|pasteboard.Complete (31.017 seconds)
20100918204636|127.0.0.1|__ERROR_WARNING|2010-09-18 20:46:36|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|pasteboard.Started
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: useragents-config
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: dates-config
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: fopen-config
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: stopwords-config
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-database
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-useragent
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-hooks
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-sessions
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-cache
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-scaffolding
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-errors
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-uri
20100918205708|127.0.0.1|INCLUDE|2010-09-18 20:57:08|library: pb-logs
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_set_timezone: US/Pacific
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_sitewhoami: default Initialized
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_uri_segment: QUERY_STRING
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_useragent:  
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_useragent: 
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_init_session: Not Implemented
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_dbopen: mysql_pconnect
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918205708|127.0.0.1|SQL|2010-09-18 20:57:08|SQL_logged from show_404, 43
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|_dbclose CLOSED
20100918205708|127.0.0.1|INFO|2010-09-18 20:57:08|pasteboard.Complete (32.404 seconds)
20100918205708|127.0.0.1|__ERROR_WARNING|2010-09-18 20:57:08|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|pasteboard.Started
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: useragents-config
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: dates-config
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: fopen-config
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: stopwords-config
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-database
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-useragent
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-hooks
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-sessions
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-cache
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-scaffolding
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-errors
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-uri
20100918210006|127.0.0.1|INCLUDE|2010-09-18 21:00:06|library: pb-logs
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_set_timezone: US/Pacific
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_sitewhoami: default Initialized
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_uri_segment: QUERY_STRING
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_useragent:  
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_useragent: 
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_init_session: Not Implemented
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_dbopen: mysql_pconnect
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918210006|127.0.0.1|SQL|2010-09-18 21:00:06|SQL_logged from show_404, 43
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|_dbclose CLOSED
20100918210006|127.0.0.1|INFO|2010-09-18 21:00:06|pasteboard.Complete (30.729 seconds)
20100918210006|127.0.0.1|__ERROR_WARNING|2010-09-18 21:00:06|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|pasteboard.Started
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: useragents-config
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: dates-config
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: fopen-config
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: stopwords-config
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-database
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-useragent
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-hooks
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-sessions
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-cache
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-scaffolding
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-errors
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-uri
20100918210740|127.0.0.1|INCLUDE|2010-09-18 21:07:40|library: pb-logs
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_set_timezone: US/Pacific
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_sitewhoami: default Initialized
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_uri_segment: QUERY_STRING
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_useragent:  
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_useragent: 
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_init_session: Not Implemented
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_dbopen: mysql_pconnect
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918210740|127.0.0.1|SQL|2010-09-18 21:07:40|SQL_logged from show_404, 43
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|_dbclose CLOSED
20100918210740|127.0.0.1|INFO|2010-09-18 21:07:40|pasteboard.Complete (30.984 seconds)
20100918210740|127.0.0.1|__ERROR_WARNING|2010-09-18 21:07:40|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|pasteboard.Started
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: useragents-config
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: dates-config
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: fopen-config
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: stopwords-config
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-database
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-useragent
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-hooks
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-sessions
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-cache
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-scaffolding
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-errors
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-uri
20100918211811|127.0.0.1|INCLUDE|2010-09-18 21:18:11|library: pb-logs
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_set_timezone: US/Pacific
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_sitewhoami: default Initialized
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_uri_segment: QUERY_STRING
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_useragent:  
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_useragent: 
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_init_session: Not Implemented
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_dbopen: mysql_pconnect
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918211811|127.0.0.1|SQL|2010-09-18 21:18:11|SQL_logged from show_404, 43
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|_dbclose CLOSED
20100918211811|127.0.0.1|INFO|2010-09-18 21:18:11|pasteboard.Complete (30.76 seconds)
20100918211811|127.0.0.1|__ERROR_WARNING|2010-09-18 21:18:11|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|pasteboard.Started
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: useragents-config
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: dates-config
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: fopen-config
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: stopwords-config
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-database
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-useragent
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-hooks
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-sessions
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-cache
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-scaffolding
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-errors
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-uri
20100918212842|127.0.0.1|INCLUDE|2010-09-18 21:28:42|library: pb-logs
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_set_timezone: US/Pacific
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_sitewhoami: default Initialized
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_uri_segment: QUERY_STRING
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_useragent:  
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_useragent: 
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_init_session: Not Implemented
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_dbopen: mysql_pconnect
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918212842|127.0.0.1|SQL|2010-09-18 21:28:42|SQL_logged from show_404, 43
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|_dbclose CLOSED
20100918212842|127.0.0.1|INFO|2010-09-18 21:28:42|pasteboard.Complete (30.906 seconds)
20100918212842|127.0.0.1|__ERROR_WARNING|2010-09-18 21:28:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|pasteboard.Started
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: useragents-config
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: dates-config
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: fopen-config
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: stopwords-config
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-database
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-useragent
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-hooks
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-sessions
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-cache
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-scaffolding
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-errors
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-uri
20100918213326|127.0.0.1|INCLUDE|2010-09-18 21:33:26|library: pb-logs
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_set_timezone: US/Pacific
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_sitewhoami: default Initialized
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_uri_segment: QUERY_STRING
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_useragent:  
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_useragent: 
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_init_session: Not Implemented
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_dbopen: mysql_pconnect
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918213326|127.0.0.1|SQL|2010-09-18 21:33:26|SQL_logged from show_404, 43
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|_dbclose CLOSED
20100918213326|127.0.0.1|INFO|2010-09-18 21:33:26|pasteboard.Complete (30.247 seconds)
20100918213326|127.0.0.1|__ERROR_WARNING|2010-09-18 21:33:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|pasteboard.Started
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: useragents-config
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: dates-config
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: fopen-config
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: stopwords-config
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-database
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-useragent
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-hooks
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-sessions
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-cache
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-scaffolding
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-errors
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-uri
20100918213912|127.0.0.1|INCLUDE|2010-09-18 21:39:12|library: pb-logs
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_set_timezone: US/Pacific
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_sitewhoami: default Initialized
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_uri_segment: QUERY_STRING
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_useragent:  
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_useragent: 
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_init_session: Not Implemented
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_dbopen: mysql_pconnect
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918213912|127.0.0.1|SQL|2010-09-18 21:39:12|SQL_logged from show_404, 43
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|_dbclose CLOSED
20100918213912|127.0.0.1|INFO|2010-09-18 21:39:12|pasteboard.Complete (31.106 seconds)
20100918213912|127.0.0.1|__ERROR_WARNING|2010-09-18 21:39:12|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|pasteboard.Started
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: useragents-config
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: dates-config
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: fopen-config
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: stopwords-config
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-database
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-useragent
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-hooks
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-sessions
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-cache
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-scaffolding
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-errors
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-uri
20100918214944|127.0.0.1|INCLUDE|2010-09-18 21:49:44|library: pb-logs
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_set_timezone: US/Pacific
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_sitewhoami: default Initialized
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_uri_segment: QUERY_STRING
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_useragent:  
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_useragent: 
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_init_session: Not Implemented
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_dbopen: mysql_pconnect
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918214944|127.0.0.1|SQL|2010-09-18 21:49:44|SQL_logged from show_404, 43
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|_dbclose CLOSED
20100918214944|127.0.0.1|INFO|2010-09-18 21:49:44|pasteboard.Complete (33.698 seconds)
20100918214944|127.0.0.1|__ERROR_WARNING|2010-09-18 21:49:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|pasteboard.Started
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: useragents-config
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: dates-config
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: fopen-config
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: stopwords-config
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-database
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-useragent
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-hooks
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-sessions
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-cache
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-scaffolding
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-errors
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-uri
20100918220018|127.0.0.1|INCLUDE|2010-09-18 22:00:18|library: pb-logs
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_set_timezone: US/Pacific
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_sitewhoami: default Initialized
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_uri_segment: QUERY_STRING
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_useragent:  
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_useragent: 
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_init_session: Not Implemented
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_dbopen: mysql_pconnect
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918220018|127.0.0.1|SQL|2010-09-18 22:00:18|SQL_logged from show_404, 43
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|_dbclose CLOSED
20100918220018|127.0.0.1|INFO|2010-09-18 22:00:18|pasteboard.Complete (30.734 seconds)
20100918220018|127.0.0.1|__ERROR_WARNING|2010-09-18 22:00:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|pasteboard.Started
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: useragents-config
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: dates-config
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: fopen-config
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: stopwords-config
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-database
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-useragent
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-hooks
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-sessions
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-cache
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-scaffolding
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-errors
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-uri
20100918220613|127.0.0.1|INCLUDE|2010-09-18 22:06:13|library: pb-logs
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_set_timezone: US/Pacific
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_sitewhoami: default Initialized
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_uri_segment: QUERY_STRING
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_useragent:  
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_useragent: 
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_init_session: Not Implemented
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_dbopen: mysql_pconnect
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918220613|127.0.0.1|SQL|2010-09-18 22:06:13|SQL_logged from show_404, 43
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|_dbclose CLOSED
20100918220613|127.0.0.1|INFO|2010-09-18 22:06:13|pasteboard.Complete (30.678 seconds)
20100918220613|127.0.0.1|__ERROR_WARNING|2010-09-18 22:06:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|pasteboard.Started
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: useragents-config
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: dates-config
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: fopen-config
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: stopwords-config
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-database
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-useragent
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-hooks
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-sessions
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-cache
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-scaffolding
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-errors
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-uri
20100918221048|127.0.0.1|INCLUDE|2010-09-18 22:10:48|library: pb-logs
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_set_timezone: US/Pacific
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_sitewhoami: default Initialized
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_uri_segment: QUERY_STRING
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_useragent:  
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_useragent: 
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_init_session: Not Implemented
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_dbopen: mysql_pconnect
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918221048|127.0.0.1|SQL|2010-09-18 22:10:48|SQL_logged from show_404, 43
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|_dbclose CLOSED
20100918221048|127.0.0.1|INFO|2010-09-18 22:10:48|pasteboard.Complete (30.801 seconds)
20100918221048|127.0.0.1|__ERROR_WARNING|2010-09-18 22:10:48|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|pasteboard.Started
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: useragents-config
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: dates-config
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: fopen-config
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: stopwords-config
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-database
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-useragent
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-hooks
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-sessions
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-cache
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-scaffolding
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-errors
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-uri
20100918222118|127.0.0.1|INCLUDE|2010-09-18 22:21:18|library: pb-logs
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_set_timezone: US/Pacific
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_sitewhoami: default Initialized
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_uri_segment: QUERY_STRING
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_useragent:  
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_useragent: 
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_init_session: Not Implemented
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_dbopen: mysql_pconnect
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918222118|127.0.0.1|SQL|2010-09-18 22:21:18|SQL_logged from show_404, 43
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|_dbclose CLOSED
20100918222118|127.0.0.1|INFO|2010-09-18 22:21:18|pasteboard.Complete (32.221 seconds)
20100918222118|127.0.0.1|__ERROR_WARNING|2010-09-18 22:21:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|pasteboard.Started
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: useragents-config
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: dates-config
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: fopen-config
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: stopwords-config
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-database
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-useragent
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-hooks
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-sessions
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-cache
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-scaffolding
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-errors
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-uri
20100918223150|127.0.0.1|INCLUDE|2010-09-18 22:31:50|library: pb-logs
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_set_timezone: US/Pacific
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_sitewhoami: default Initialized
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_uri_segment: QUERY_STRING
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_useragent:  
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_useragent: 
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_init_session: Not Implemented
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_dbopen: mysql_pconnect
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918223150|127.0.0.1|SQL|2010-09-18 22:31:50|SQL_logged from show_404, 43
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|_dbclose CLOSED
20100918223150|127.0.0.1|INFO|2010-09-18 22:31:50|pasteboard.Complete (31.102 seconds)
20100918223150|127.0.0.1|__ERROR_WARNING|2010-09-18 22:31:50|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|pasteboard.Started
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: useragents-config
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: dates-config
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: fopen-config
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: stopwords-config
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-database
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-useragent
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-hooks
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-sessions
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-cache
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-scaffolding
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-errors
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-uri
20100918223902|127.0.0.1|INCLUDE|2010-09-18 22:39:02|library: pb-logs
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_set_timezone: US/Pacific
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_sitewhoami: default Initialized
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_uri_segment: QUERY_STRING
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_useragent:  
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_useragent: 
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_init_session: Not Implemented
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_dbopen: mysql_pconnect
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918223902|127.0.0.1|SQL|2010-09-18 22:39:02|SQL_logged from show_404, 43
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|_dbclose CLOSED
20100918223902|127.0.0.1|INFO|2010-09-18 22:39:02|pasteboard.Complete (30.493 seconds)
20100918223902|127.0.0.1|__ERROR_WARNING|2010-09-18 22:39:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|pasteboard.Started
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: useragents-config
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: dates-config
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: fopen-config
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: stopwords-config
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-database
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-useragent
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-hooks
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-sessions
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-cache
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-scaffolding
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-errors
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-uri
20100918224222|127.0.0.1|INCLUDE|2010-09-18 22:42:22|library: pb-logs
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_set_timezone: US/Pacific
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_sitewhoami: default Initialized
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_uri_segment: QUERY_STRING
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_useragent:  
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_useragent: 
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_init_session: Not Implemented
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_dbopen: mysql_pconnect
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918224222|127.0.0.1|SQL|2010-09-18 22:42:22|SQL_logged from show_404, 43
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|_dbclose CLOSED
20100918224222|127.0.0.1|INFO|2010-09-18 22:42:22|pasteboard.Complete (30.818 seconds)
20100918224222|127.0.0.1|__ERROR_WARNING|2010-09-18 22:42:22|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|pasteboard.Started
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: useragents-config
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: dates-config
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: fopen-config
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: stopwords-config
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-database
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-useragent
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-hooks
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-sessions
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-cache
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-scaffolding
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-errors
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-uri
20100918225252|127.0.0.1|INCLUDE|2010-09-18 22:52:52|library: pb-logs
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_set_timezone: US/Pacific
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_sitewhoami: default Initialized
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_uri_segment: QUERY_STRING
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_useragent:  
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_useragent: 
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_init_session: Not Implemented
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_dbopen: mysql_pconnect
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918225252|127.0.0.1|SQL|2010-09-18 22:52:52|SQL_logged from show_404, 43
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|_dbclose CLOSED
20100918225252|127.0.0.1|INFO|2010-09-18 22:52:52|pasteboard.Complete (31.442 seconds)
20100918225252|127.0.0.1|__ERROR_WARNING|2010-09-18 22:52:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|pasteboard.Started
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: useragents-config
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: dates-config
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: fopen-config
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: stopwords-config
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-database
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-useragent
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-hooks
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-sessions
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-cache
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-scaffolding
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-errors
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-uri
20100918230324|127.0.0.1|INCLUDE|2010-09-18 23:03:24|library: pb-logs
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_set_timezone: US/Pacific
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_sitewhoami: default Initialized
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_uri_segment: QUERY_STRING
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_useragent:  
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_useragent: 
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_init_session: Not Implemented
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_dbopen: mysql_pconnect
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918230324|127.0.0.1|SQL|2010-09-18 23:03:24|SQL_logged from show_404, 43
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|_dbclose CLOSED
20100918230324|127.0.0.1|INFO|2010-09-18 23:03:24|pasteboard.Complete (30.975 seconds)
20100918230324|127.0.0.1|__ERROR_WARNING|2010-09-18 23:03:24|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|pasteboard.Started
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: useragents-config
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: dates-config
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: fopen-config
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: stopwords-config
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-database
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-useragent
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-hooks
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-sessions
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-cache
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-scaffolding
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-errors
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-uri
20100918230933|127.0.0.1|INCLUDE|2010-09-18 23:09:33|library: pb-logs
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_set_timezone: US/Pacific
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_sitewhoami: default Initialized
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_uri_segment: QUERY_STRING
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_useragent:  
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_useragent: 
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_init_session: Not Implemented
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_dbopen: mysql_pconnect
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918230933|127.0.0.1|SQL|2010-09-18 23:09:33|SQL_logged from show_404, 43
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|_dbclose CLOSED
20100918230933|127.0.0.1|INFO|2010-09-18 23:09:33|pasteboard.Complete (30.348 seconds)
20100918230933|127.0.0.1|__ERROR_WARNING|2010-09-18 23:09:33|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|pasteboard.Started
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: useragents-config
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: dates-config
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: fopen-config
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: stopwords-config
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-database
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-useragent
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-hooks
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-sessions
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-cache
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-scaffolding
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-errors
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-uri
20100918231355|127.0.0.1|INCLUDE|2010-09-18 23:13:55|library: pb-logs
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_set_timezone: US/Pacific
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_sitewhoami: default Initialized
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_uri_segment: QUERY_STRING
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_useragent:  
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_useragent: 
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_init_session: Not Implemented
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_dbopen: mysql_pconnect
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918231355|127.0.0.1|SQL|2010-09-18 23:13:55|SQL_logged from show_404, 43
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|_dbclose CLOSED
20100918231355|127.0.0.1|INFO|2010-09-18 23:13:55|pasteboard.Complete (30.21 seconds)
20100918231355|127.0.0.1|__ERROR_WARNING|2010-09-18 23:13:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|pasteboard.Started
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: useragents-config
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: dates-config
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: fopen-config
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: stopwords-config
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-database
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-useragent
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-hooks
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-sessions
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-cache
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-scaffolding
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-errors
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-uri
20100918232426|127.0.0.1|INCLUDE|2010-09-18 23:24:26|library: pb-logs
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_set_timezone: US/Pacific
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_sitewhoami: default Initialized
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_uri_segment: QUERY_STRING
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_useragent:  
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_useragent: 
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_init_session: Not Implemented
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_dbopen: mysql_pconnect
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918232426|127.0.0.1|SQL|2010-09-18 23:24:26|SQL_logged from show_404, 43
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|_dbclose CLOSED
20100918232426|127.0.0.1|INFO|2010-09-18 23:24:26|pasteboard.Complete (31.632 seconds)
20100918232426|127.0.0.1|__ERROR_WARNING|2010-09-18 23:24:26|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|pasteboard.Started
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: useragents-config
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: dates-config
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: fopen-config
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: stopwords-config
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-database
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-useragent
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-hooks
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-sessions
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-cache
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-scaffolding
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-errors
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-uri
20100918233458|127.0.0.1|INCLUDE|2010-09-18 23:34:58|library: pb-logs
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_set_timezone: US/Pacific
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_sitewhoami: default Initialized
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_uri_segment: QUERY_STRING
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_useragent:  
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_useragent: 
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_init_session: Not Implemented
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_dbopen: mysql_pconnect
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918233458|127.0.0.1|SQL|2010-09-18 23:34:58|SQL_logged from show_404, 43
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|_dbclose CLOSED
20100918233458|127.0.0.1|INFO|2010-09-18 23:34:58|pasteboard.Complete (30.322 seconds)
20100918233458|127.0.0.1|__ERROR_WARNING|2010-09-18 23:34:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|pasteboard.Started
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: useragents-config
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: dates-config
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: fopen-config
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: stopwords-config
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-database
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-useragent
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-hooks
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-sessions
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-cache
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-scaffolding
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-errors
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-uri
20100918234316|127.0.0.1|INCLUDE|2010-09-18 23:43:16|library: pb-logs
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_set_timezone: US/Pacific
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_sitewhoami: default Initialized
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_uri_segment: QUERY_STRING
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_useragent:  
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_useragent: 
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_init_session: Not Implemented
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_dbopen: mysql_pconnect
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918234316|127.0.0.1|SQL|2010-09-18 23:43:16|SQL_logged from show_404, 43
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|_dbclose CLOSED
20100918234316|127.0.0.1|INFO|2010-09-18 23:43:16|pasteboard.Complete (30.798 seconds)
20100918234316|127.0.0.1|__ERROR_WARNING|2010-09-18 23:43:16|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|pasteboard.Started
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: useragents-config
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: dates-config
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: fopen-config
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: stopwords-config
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-database
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-useragent
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-hooks
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-sessions
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-cache
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-scaffolding
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-errors
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-uri
20100918234528|127.0.0.1|INCLUDE|2010-09-18 23:45:28|library: pb-logs
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_set_timezone: US/Pacific
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_sitewhoami: default Initialized
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_uri_segment: QUERY_STRING
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_useragent:  
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_useragent: 
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_init_session: Not Implemented
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_dbopen: mysql_pconnect
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918234528|127.0.0.1|SQL|2010-09-18 23:45:28|SQL_logged from show_404, 43
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|_dbclose CLOSED
20100918234528|127.0.0.1|INFO|2010-09-18 23:45:28|pasteboard.Complete (35.679 seconds)
20100918234528|127.0.0.1|__ERROR_WARNING|2010-09-18 23:45:28|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|pasteboard.Started
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: useragents-config
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: dates-config
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: fopen-config
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: stopwords-config
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-database
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-useragent
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-hooks
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-sessions
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-cache
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-scaffolding
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-errors
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-uri
20100918235604|127.0.0.1|INCLUDE|2010-09-18 23:56:04|library: pb-logs
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_set_timezone: US/Pacific
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_sitewhoami: default Initialized
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_uri_segment: QUERY_STRING
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_useragent:  
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_useragent: 
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_init_session: Not Implemented
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_dbopen: mysql_pconnect
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20100918235604|127.0.0.1|SQL|2010-09-18 23:56:04|SQL_logged from show_404, 43
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|_dbclose CLOSED
20100918235604|127.0.0.1|INFO|2010-09-18 23:56:04|pasteboard.Complete (30.273 seconds)
20100918235604|127.0.0.1|__ERROR_WARNING|2010-09-18 23:56:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
