20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|pasteboard.Started
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: useragents-config
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: dates-config
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: fopen-config
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: stopwords-config
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-database
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-useragent
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-hooks
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-sessions
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-cache
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-scaffolding
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-errors
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-uri
20101031113208|127.0.0.1|INCLUDE|2010-10-31 11:32:07|library: pb-logs
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_set_timezone: US/Pacific
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_sitewhoami: default Initialized
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_uri_segment: QUERY_STRING
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_useragent:  
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_useragent: 
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_init_session: Not Implemented
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_dbopen: mysql_pconnect
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031113208|127.0.0.1|SQL|2010-10-31 11:32:07|SQL_logged from show_404, 43
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|_dbclose CLOSED
20101031113208|127.0.0.1|INFO|2010-10-31 11:32:07|pasteboard.Complete (31.468 seconds)
20101031113208|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:07|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|pasteboard.Started
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: useragents-config
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: dates-config
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: fopen-config
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: stopwords-config
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-database
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-useragent
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-hooks
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-sessions
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-cache
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-scaffolding
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-errors
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-uri
20101031113239|127.0.0.1|INCLUDE|2010-10-31 11:32:39|library: pb-logs
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_set_timezone: US/Pacific
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_sitewhoami: default Initialized
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_uri_segment: QUERY_STRING
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_useragent:  
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_useragent: 
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_init_session: Not Implemented
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_dbopen: mysql_pconnect
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031113239|127.0.0.1|SQL|2010-10-31 11:32:39|SQL_logged from show_404, 43
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|_dbclose CLOSED
20101031113239|127.0.0.1|INFO|2010-10-31 11:32:39|pasteboard.Complete (31.11 seconds)
20101031113239|127.0.0.1|__ERROR_WARNING|2010-10-31 11:32:39|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|pasteboard.Started
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: useragents-config
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: dates-config
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: fopen-config
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: stopwords-config
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-database
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-useragent
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-hooks
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-sessions
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-cache
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-scaffolding
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-errors
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-uri
20101031113649|127.0.0.1|INCLUDE|2010-10-31 11:36:49|library: pb-logs
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_set_timezone: US/Pacific
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_sitewhoami: default Initialized
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_uri_segment: QUERY_STRING
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_useragent:  
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_useragent: 
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_init_session: Not Implemented
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_dbopen: mysql_pconnect
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031113649|127.0.0.1|SQL|2010-10-31 11:36:49|SQL_logged from show_404, 43
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|_dbclose CLOSED
20101031113649|127.0.0.1|INFO|2010-10-31 11:36:49|pasteboard.Complete (850.809 seconds)
20101031113649|127.0.0.1|__ERROR_WARNING|2010-10-31 11:36:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|pasteboard.Started
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: useragents-config
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: dates-config
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: fopen-config
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: stopwords-config
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-database
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-useragent
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-hooks
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-sessions
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-cache
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-scaffolding
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-errors
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-uri
20101031120242|127.0.0.1|INCLUDE|2010-10-31 12:02:42|library: pb-logs
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_set_timezone: US/Pacific
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_sitewhoami: default Initialized
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_uri_segment: QUERY_STRING
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_useragent:  
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_useragent: 
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_init_session: Not Implemented
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_dbopen: mysql_pconnect
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031120242|127.0.0.1|SQL|2010-10-31 12:02:42|SQL_logged from show_404, 43
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|_dbclose CLOSED
20101031120242|127.0.0.1|INFO|2010-10-31 12:02:42|pasteboard.Complete (31.174 seconds)
20101031120242|127.0.0.1|__ERROR_WARNING|2010-10-31 12:02:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|pasteboard.Started
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: useragents-config
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: dates-config
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: fopen-config
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: stopwords-config
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-database
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-useragent
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-hooks
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-sessions
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-cache
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-scaffolding
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-errors
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-uri
20101031122419|127.0.0.1|INCLUDE|2010-10-31 12:24:19|library: pb-logs
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_set_timezone: US/Pacific
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_sitewhoami: default Initialized
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_uri_segment: QUERY_STRING
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_useragent:  
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_useragent: 
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_init_session: Not Implemented
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_dbopen: mysql_pconnect
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031122419|127.0.0.1|SQL|2010-10-31 12:24:19|SQL_logged from show_404, 43
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|_dbclose CLOSED
20101031122419|127.0.0.1|INFO|2010-10-31 12:24:19|pasteboard.Complete (30.443 seconds)
20101031122419|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|pasteboard.Started
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: useragents-config
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: dates-config
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: fopen-config
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: stopwords-config
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-database
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-useragent
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-hooks
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-sessions
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-cache
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-scaffolding
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-errors
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-uri
20101031122450|127.0.0.1|INCLUDE|2010-10-31 12:24:50|library: pb-logs
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_set_timezone: US/Pacific
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_sitewhoami: default Initialized
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_uri_segment: QUERY_STRING
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_useragent:  
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_useragent: 
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_init_session: Not Implemented
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_dbopen: mysql_pconnect
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031122450|127.0.0.1|SQL|2010-10-31 12:24:50|SQL_logged from show_404, 43
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|_dbclose CLOSED
20101031122450|127.0.0.1|INFO|2010-10-31 12:24:50|pasteboard.Complete (30.511 seconds)
20101031122450|127.0.0.1|__ERROR_WARNING|2010-10-31 12:24:50|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|pasteboard.Started
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: useragents-config
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: dates-config
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: fopen-config
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: stopwords-config
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-database
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-useragent
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-hooks
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-sessions
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-cache
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-scaffolding
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-errors
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-uri
20101031123300|127.0.0.1|INCLUDE|2010-10-31 12:33:00|library: pb-logs
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_set_timezone: US/Pacific
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_sitewhoami: default Initialized
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_uri_segment: QUERY_STRING
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_useragent:  
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_useragent: 
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_init_session: Not Implemented
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_dbopen: mysql_pconnect
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031123300|127.0.0.1|SQL|2010-10-31 12:33:00|SQL_logged from show_404, 43
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|_dbclose CLOSED
20101031123300|127.0.0.1|INFO|2010-10-31 12:33:00|pasteboard.Complete (32.221 seconds)
20101031123300|127.0.0.1|__ERROR_WARNING|2010-10-31 12:33:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|pasteboard.Started
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: useragents-config
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: dates-config
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: fopen-config
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: stopwords-config
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-database
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-useragent
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-hooks
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-sessions
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-cache
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-scaffolding
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-errors
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-uri
20101031123708|127.0.0.1|INCLUDE|2010-10-31 12:37:08|library: pb-logs
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_set_timezone: US/Pacific
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_sitewhoami: default Initialized
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_uri_segment: QUERY_STRING
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_useragent:  
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_useragent: 
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_init_session: Not Implemented
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_dbopen: mysql_pconnect
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031123708|127.0.0.1|SQL|2010-10-31 12:37:08|SQL_logged from show_404, 43
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|_dbclose CLOSED
20101031123708|127.0.0.1|INFO|2010-10-31 12:37:08|pasteboard.Complete (30.934 seconds)
20101031123708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:37:08|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|pasteboard.Started
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: useragents-config
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: dates-config
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: fopen-config
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: stopwords-config
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-database
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-useragent
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-hooks
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-sessions
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-cache
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-scaffolding
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-errors
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-uri
20101031124333|127.0.0.1|INCLUDE|2010-10-31 12:43:33|library: pb-logs
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_set_timezone: US/Pacific
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_sitewhoami: default Initialized
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_uri_segment: QUERY_STRING
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_useragent:  
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_useragent: 
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_init_session: Not Implemented
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_dbopen: mysql_pconnect
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031124333|127.0.0.1|SQL|2010-10-31 12:43:33|SQL_logged from show_404, 43
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|_dbclose CLOSED
20101031124333|127.0.0.1|INFO|2010-10-31 12:43:33|pasteboard.Complete (30.876 seconds)
20101031124333|127.0.0.1|__ERROR_WARNING|2010-10-31 12:43:33|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|pasteboard.Started
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: useragents-config
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: dates-config
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: fopen-config
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: stopwords-config
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-database
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-useragent
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-hooks
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-sessions
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-cache
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-scaffolding
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-errors
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-uri
20101031124627|127.0.0.1|INCLUDE|2010-10-31 12:46:27|library: pb-logs
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_set_timezone: US/Pacific
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_sitewhoami: default Initialized
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_uri_segment: QUERY_STRING
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_useragent:  
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_useragent: 
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_init_session: Not Implemented
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_dbopen: mysql_pconnect
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031124627|127.0.0.1|SQL|2010-10-31 12:46:27|SQL_logged from show_404, 43
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|_dbclose CLOSED
20101031124627|127.0.0.1|INFO|2010-10-31 12:46:27|pasteboard.Complete (36.435 seconds)
20101031124627|127.0.0.1|__ERROR_WARNING|2010-10-31 12:46:27|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|pasteboard.Started
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: useragents-config
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: dates-config
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: fopen-config
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: stopwords-config
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-database
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-useragent
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-hooks
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-sessions
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-cache
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-scaffolding
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-errors
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-uri
20101031124704|127.0.0.1|INCLUDE|2010-10-31 12:47:04|library: pb-logs
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_set_timezone: US/Pacific
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_sitewhoami: default Initialized
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_uri_segment: QUERY_STRING
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_useragent:  
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_useragent: 
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_init_session: Not Implemented
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_dbopen: mysql_pconnect
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031124704|127.0.0.1|SQL|2010-10-31 12:47:04|SQL_logged from show_404, 43
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|_dbclose CLOSED
20101031124704|127.0.0.1|INFO|2010-10-31 12:47:04|pasteboard.Complete (0.782 seconds)
20101031124704|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|pasteboard.Started
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: useragents-config
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: dates-config
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: fopen-config
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: stopwords-config
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-database
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-useragent
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-hooks
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-sessions
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-cache
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-scaffolding
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-errors
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-uri
20101031124708|127.0.0.1|INCLUDE|2010-10-31 12:47:08|library: pb-logs
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_set_timezone: US/Pacific
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_sitewhoami: default Initialized
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_uri_segment: QUERY_STRING
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_useragent:  
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_useragent: 
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_init_session: Not Implemented
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_dbopen: mysql_pconnect
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031124708|127.0.0.1|SQL|2010-10-31 12:47:08|SQL_logged from show_404, 43
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|_dbclose CLOSED
20101031124708|127.0.0.1|INFO|2010-10-31 12:47:08|pasteboard.Complete (35.522 seconds)
20101031124708|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:08|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|pasteboard.Started
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: useragents-config
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: dates-config
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: fopen-config
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: stopwords-config
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-database
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-useragent
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-hooks
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-sessions
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-cache
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-scaffolding
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-errors
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-uri
20101031124744|127.0.0.1|INCLUDE|2010-10-31 12:47:44|library: pb-logs
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_set_timezone: US/Pacific
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_sitewhoami: default Initialized
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_uri_segment: QUERY_STRING
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_useragent:  
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_useragent: 
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_init_session: Not Implemented
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_dbopen: mysql_pconnect
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031124744|127.0.0.1|SQL|2010-10-31 12:47:44|SQL_logged from show_404, 43
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|_dbclose CLOSED
20101031124744|127.0.0.1|INFO|2010-10-31 12:47:44|pasteboard.Complete (30.751 seconds)
20101031124744|127.0.0.1|__ERROR_WARNING|2010-10-31 12:47:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|pasteboard.Started
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: useragents-config
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: dates-config
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: fopen-config
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: stopwords-config
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-database
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-useragent
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-hooks
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-sessions
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-cache
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-scaffolding
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-errors
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-uri
20101031124815|127.0.0.1|INCLUDE|2010-10-31 12:48:15|library: pb-logs
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_set_timezone: US/Pacific
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_sitewhoami: default Initialized
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_uri_segment: QUERY_STRING
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_useragent:  
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_useragent: 
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_init_session: Not Implemented
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_dbopen: mysql_pconnect
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031124815|127.0.0.1|SQL|2010-10-31 12:48:15|SQL_logged from show_404, 43
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|_dbclose CLOSED
20101031124815|127.0.0.1|INFO|2010-10-31 12:48:15|pasteboard.Complete (1491.867 seconds)
20101031124815|127.0.0.1|__ERROR_WARNING|2010-10-31 12:48:15|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|pasteboard.Started
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: useragents-config
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: dates-config
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: fopen-config
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: stopwords-config
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-database
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-useragent
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-hooks
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-sessions
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-cache
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-scaffolding
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-errors
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-uri
20101031131310|127.0.0.1|INCLUDE|2010-10-31 13:13:10|library: pb-logs
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_set_timezone: US/Pacific
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_sitewhoami: default Initialized
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_uri_segment: QUERY_STRING
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_useragent:  
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_useragent: 
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_init_session: Not Implemented
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_dbopen: mysql_pconnect
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031131310|127.0.0.1|SQL|2010-10-31 13:13:10|SQL_logged from show_404, 43
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|_dbclose CLOSED
20101031131310|127.0.0.1|INFO|2010-10-31 13:13:10|pasteboard.Complete (30.933 seconds)
20101031131310|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|pasteboard.Started
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: useragents-config
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: dates-config
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: fopen-config
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: stopwords-config
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-database
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-useragent
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-hooks
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-sessions
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-cache
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-scaffolding
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-errors
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-uri
20101031131341|127.0.0.1|INCLUDE|2010-10-31 13:13:41|library: pb-logs
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_set_timezone: US/Pacific
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_sitewhoami: default Initialized
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_uri_segment: QUERY_STRING
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_useragent:  
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_useragent: 
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_init_session: Not Implemented
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_dbopen: mysql_pconnect
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031131341|127.0.0.1|SQL|2010-10-31 13:13:41|SQL_logged from show_404, 43
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|_dbclose CLOSED
20101031131341|127.0.0.1|INFO|2010-10-31 13:13:41|pasteboard.Complete (31.052 seconds)
20101031131341|127.0.0.1|__ERROR_WARNING|2010-10-31 13:13:41|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|pasteboard.Started
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: useragents-config
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: dates-config
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: fopen-config
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: stopwords-config
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-database
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-useragent
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-hooks
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-sessions
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-cache
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-scaffolding
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-errors
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-uri
20101031132413|127.0.0.1|INCLUDE|2010-10-31 13:24:13|library: pb-logs
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_set_timezone: US/Pacific
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_sitewhoami: default Initialized
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_uri_segment: QUERY_STRING
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_useragent:  
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_useragent: 
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_init_session: Not Implemented
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_dbopen: mysql_pconnect
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031132413|127.0.0.1|SQL|2010-10-31 13:24:13|SQL_logged from show_404, 43
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|_dbclose CLOSED
20101031132413|127.0.0.1|INFO|2010-10-31 13:24:13|pasteboard.Complete (30.349 seconds)
20101031132413|127.0.0.1|__ERROR_WARNING|2010-10-31 13:24:13|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|pasteboard.Started
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: useragents-config
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: dates-config
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: fopen-config
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: stopwords-config
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-database
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-useragent
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-hooks
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-sessions
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-cache
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-scaffolding
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-errors
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-uri
20101031133248|127.0.0.1|INCLUDE|2010-10-31 13:32:48|library: pb-logs
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_set_timezone: US/Pacific
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_sitewhoami: default Initialized
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_uri_segment: QUERY_STRING
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_useragent:  
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_useragent: 
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_init_session: Not Implemented
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_dbopen: mysql_pconnect
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031133248|127.0.0.1|SQL|2010-10-31 13:32:48|SQL_logged from show_404, 43
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|_dbclose CLOSED
20101031133248|127.0.0.1|INFO|2010-10-31 13:32:48|pasteboard.Complete (176.082 seconds)
20101031133248|127.0.0.1|__ERROR_WARNING|2010-10-31 13:32:48|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|pasteboard.Started
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: useragents-config
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: dates-config
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: fopen-config
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: stopwords-config
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-database
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-useragent
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-hooks
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-sessions
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-cache
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-scaffolding
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-errors
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-uri
20101031134002|127.0.0.1|INCLUDE|2010-10-31 13:40:02|library: pb-logs
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_set_timezone: US/Pacific
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_sitewhoami: default Initialized
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_uri_segment: QUERY_STRING
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_useragent:  
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_useragent: 
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_init_session: Not Implemented
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_dbopen: mysql_pconnect
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031134002|127.0.0.1|SQL|2010-10-31 13:40:02|SQL_logged from show_404, 43
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|_dbclose CLOSED
20101031134002|127.0.0.1|INFO|2010-10-31 13:40:02|pasteboard.Complete (1873.922 seconds)
20101031134002|127.0.0.1|__ERROR_WARNING|2010-10-31 13:40:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|pasteboard.Started
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: useragents-config
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: dates-config
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: fopen-config
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: stopwords-config
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-database
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-useragent
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-hooks
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-sessions
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-cache
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-scaffolding
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-errors
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-uri
20101031141118|127.0.0.1|INCLUDE|2010-10-31 14:11:18|library: pb-logs
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_set_timezone: US/Pacific
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_sitewhoami: default Initialized
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_uri_segment: QUERY_STRING
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_useragent:  
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_useragent: 
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_init_session: Not Implemented
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_dbopen: mysql_pconnect
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031141118|127.0.0.1|SQL|2010-10-31 14:11:18|SQL_logged from show_404, 43
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|_dbclose CLOSED
20101031141118|127.0.0.1|INFO|2010-10-31 14:11:18|pasteboard.Complete (31.853 seconds)
20101031141118|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|pasteboard.Started
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: useragents-config
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: dates-config
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: fopen-config
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: stopwords-config
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-database
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-useragent
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-hooks
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-sessions
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-cache
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-scaffolding
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-errors
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-uri
20101031141150|127.0.0.1|INCLUDE|2010-10-31 14:11:50|library: pb-logs
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_set_timezone: US/Pacific
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_sitewhoami: default Initialized
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_uri_segment: QUERY_STRING
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_useragent:  
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_useragent: 
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_init_session: Not Implemented
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_dbopen: mysql_pconnect
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031141150|127.0.0.1|SQL|2010-10-31 14:11:50|SQL_logged from show_404, 43
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|_dbclose CLOSED
20101031141150|127.0.0.1|INFO|2010-10-31 14:11:50|pasteboard.Complete (30.927 seconds)
20101031141150|127.0.0.1|__ERROR_WARNING|2010-10-31 14:11:50|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|pasteboard.Started
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: useragents-config
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: dates-config
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: fopen-config
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: stopwords-config
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-database
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-useragent
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-hooks
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-sessions
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-cache
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-scaffolding
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-errors
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-uri
20101031141221|127.0.0.1|INCLUDE|2010-10-31 14:12:21|library: pb-logs
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_set_timezone: US/Pacific
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_sitewhoami: default Initialized
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_uri_segment: QUERY_STRING
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_useragent:  
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_useragent: 
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_init_session: Not Implemented
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_dbopen: mysql_pconnect
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031141221|127.0.0.1|SQL|2010-10-31 14:12:21|SQL_logged from show_404, 43
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|_dbclose CLOSED
20101031141221|127.0.0.1|INFO|2010-10-31 14:12:21|pasteboard.Complete (30.972 seconds)
20101031141221|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|pasteboard.Started
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: useragents-config
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: dates-config
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: fopen-config
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: stopwords-config
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-database
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-useragent
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-hooks
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-sessions
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-cache
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-scaffolding
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-errors
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-uri
20101031141252|127.0.0.1|INCLUDE|2010-10-31 14:12:52|library: pb-logs
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_set_timezone: US/Pacific
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_sitewhoami: default Initialized
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_uri_segment: QUERY_STRING
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_useragent:  
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_useragent: 
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_init_session: Not Implemented
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_dbopen: mysql_pconnect
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031141252|127.0.0.1|SQL|2010-10-31 14:12:52|SQL_logged from show_404, 43
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|_dbclose CLOSED
20101031141252|127.0.0.1|INFO|2010-10-31 14:12:52|pasteboard.Complete (31.049 seconds)
20101031141252|127.0.0.1|__ERROR_WARNING|2010-10-31 14:12:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|pasteboard.Started
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: useragents-config
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: dates-config
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: fopen-config
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: stopwords-config
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-database
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-useragent
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-hooks
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-sessions
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-cache
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-scaffolding
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-errors
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-uri
20101031141951|127.0.0.1|INCLUDE|2010-10-31 14:19:51|library: pb-logs
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_set_timezone: US/Pacific
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_sitewhoami: default Initialized
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_uri_segment: QUERY_STRING
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_useragent:  
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_useragent: 
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_init_session: Not Implemented
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_dbopen: mysql_pconnect
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031141951|127.0.0.1|SQL|2010-10-31 14:19:51|SQL_logged from show_404, 43
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|_dbclose CLOSED
20101031141951|127.0.0.1|INFO|2010-10-31 14:19:51|pasteboard.Complete (2819.448 seconds)
20101031141951|127.0.0.1|__ERROR_WARNING|2010-10-31 14:19:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|pasteboard.Started
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: useragents-config
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: dates-config
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: fopen-config
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: stopwords-config
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-database
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-useragent
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-hooks
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-sessions
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-cache
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-scaffolding
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-errors
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-uri
20101031150755|127.0.0.1|INCLUDE|2010-10-31 15:07:55|library: pb-logs
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_set_timezone: US/Pacific
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_sitewhoami: default Initialized
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_uri_segment: QUERY_STRING
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_useragent:  
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_useragent: 
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_init_session: Not Implemented
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_dbopen: mysql_pconnect
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031150755|127.0.0.1|SQL|2010-10-31 15:07:55|SQL_logged from show_404, 43
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|_dbclose CLOSED
20101031150755|127.0.0.1|INFO|2010-10-31 15:07:55|pasteboard.Complete (35.651 seconds)
20101031150755|127.0.0.1|__ERROR_WARNING|2010-10-31 15:07:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|pasteboard.Started
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: useragents-config
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: dates-config
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: fopen-config
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: stopwords-config
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-database
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-useragent
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-hooks
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-sessions
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-cache
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-scaffolding
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-errors
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-uri
20101031150831|127.0.0.1|INCLUDE|2010-10-31 15:08:31|library: pb-logs
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_set_timezone: US/Pacific
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_sitewhoami: default Initialized
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_uri_segment: QUERY_STRING
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_useragent:  
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_useragent: 
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_init_session: Not Implemented
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_dbopen: mysql_pconnect
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031150831|127.0.0.1|SQL|2010-10-31 15:08:31|SQL_logged from show_404, 43
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|_dbclose CLOSED
20101031150831|127.0.0.1|INFO|2010-10-31 15:08:31|pasteboard.Complete (31.399 seconds)
20101031150831|127.0.0.1|__ERROR_WARNING|2010-10-31 15:08:31|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|pasteboard.Started
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: useragents-config
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: dates-config
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: fopen-config
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: stopwords-config
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-database
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-useragent
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-hooks
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-sessions
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-cache
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-scaffolding
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-errors
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-uri
20101031150903|127.0.0.1|INCLUDE|2010-10-31 15:09:03|library: pb-logs
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_set_timezone: US/Pacific
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_sitewhoami: default Initialized
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_uri_segment: QUERY_STRING
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_useragent:  
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_useragent: 
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_init_session: Not Implemented
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_dbopen: mysql_pconnect
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101031150903|127.0.0.1|SQL|2010-10-31 15:09:03|SQL_logged from show_404, 43
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|_dbclose CLOSED
20101031150903|127.0.0.1|INFO|2010-10-31 15:09:03|pasteboard.Complete (30.528 seconds)
20101031150903|127.0.0.1|__ERROR_WARNING|2010-10-31 15:09:03|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
