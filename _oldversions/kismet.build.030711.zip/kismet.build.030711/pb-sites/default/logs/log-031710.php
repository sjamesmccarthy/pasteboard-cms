20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|pasteboard.Started
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: useragents-config
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: dates-config
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: fopen-config
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: stopwords-config
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-database
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-useragent
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-hooks
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-sessions
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-cache
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-scaffolding
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-errors
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-uri
20100317172806|127.0.0.1|INCLUDE|2010-03-17 17:28:06|library: pb-logs
20100317172806|127.0.0.1|__ERROR_WARNING|2010-03-17 17:28:06|pb-libraries file not found: pb-email-> Line 172-> function: __init_log-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100317172806|127.0.0.1|__ERROR_WARNING|2010-03-17 17:28:06|pb-libraries file not found: pb-cookies-> Line 172-> function: __init_log-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|_set_timezone: US/Pacific
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|_sitewhoami: default Initialized
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|_uri_segment: SEGMENT_PATH
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|_useragent: Firefox 3.6
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|_useragent: Mac OS X
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|_init_session: Not Implemented
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|_dbopen: mysql_pconnect
20100317172806|127.0.0.1|INFO|2010-03-17 17:28:06|app: admin Initialized
20100317172806|127.0.0.1|__ERROR_WARNING|2010-03-17 17:28:06|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 183]
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|pasteboard.Started
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: useragents-config
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: dates-config
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: fopen-config
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: stopwords-config
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-database
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-useragent
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-hooks
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-sessions
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-cache
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-scaffolding
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-errors
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-uri
20100317172830|127.0.0.1|INCLUDE|2010-03-17 17:28:30|library: pb-logs
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|_set_timezone: US/Pacific
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|_sitewhoami: default Initialized
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|_uri_segment: SEGMENT_PATH
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|_useragent: Firefox 3.6
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|_useragent: Mac OS X
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|_init_session: Not Implemented
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|_dbopen: mysql_pconnect
20100317172830|127.0.0.1|INFO|2010-03-17 17:28:30|app: admin Initialized
20100317172830|127.0.0.1|__ERROR_WARNING|2010-03-17 17:28:30|Helper Not Found: email,cookies_helper.php-> Line 185-> function: load_helper-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100317172830|127.0.0.1|__ERROR_WARNING|2010-03-17 17:28:30|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|pasteboard.Started
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: useragents-config
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: dates-config
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: fopen-config
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: stopwords-config
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-database
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-useragent
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-hooks
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-sessions
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-cache
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-scaffolding
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-errors
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-uri
20100317172845|127.0.0.1|INCLUDE|2010-03-17 17:28:45|library: pb-logs
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|_set_timezone: US/Pacific
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|_sitewhoami: default Initialized
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|_uri_segment: SEGMENT_PATH
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|_useragent: Firefox 3.6
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|_useragent: Mac OS X
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|_init_session: Not Implemented
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|_dbopen: mysql_pconnect
20100317172845|127.0.0.1|INFO|2010-03-17 17:28:45|app: admin Initialized
20100317172845|127.0.0.1|__ERROR_WARNING|2010-03-17 17:28:45|Helper Not Found: email,cookies_helper.php-> Line 185-> function: load_helper-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100317172845|127.0.0.1|__ERROR_WARNING|2010-03-17 17:28:45|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|pasteboard.Started
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: useragents-config
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: dates-config
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: fopen-config
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: stopwords-config
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-database
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-useragent
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-hooks
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-sessions
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-cache
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-scaffolding
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-errors
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-uri
20100317173053|127.0.0.1|INCLUDE|2010-03-17 17:30:53|library: pb-logs
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|_set_timezone: US/Pacific
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|_sitewhoami: default Initialized
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|_uri_segment: SEGMENT_PATH
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|_useragent: Firefox 3.6
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|_useragent: Mac OS X
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|_init_session: Not Implemented
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|_dbopen: mysql_pconnect
20100317173053|127.0.0.1|INFO|2010-03-17 17:30:53|app: admin Initialized
20100317173053|127.0.0.1|__ERROR_WARNING|2010-03-17 17:30:53|Helper Not Found: email,cookies_helper.php-> Line 185-> function: load_helper-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100317173053|127.0.0.1|__ERROR_WARNING|2010-03-17 17:30:53|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|pasteboard.Started
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: useragents-config
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: dates-config
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: fopen-config
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: stopwords-config
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-database
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-useragent
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-hooks
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-sessions
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-cache
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-scaffolding
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-errors
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-uri
20100317173145|127.0.0.1|INCLUDE|2010-03-17 17:31:45|library: pb-logs
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|_set_timezone: US/Pacific
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|_sitewhoami: default Initialized
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|_uri_segment: SEGMENT_PATH
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|_useragent: Firefox 3.6
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|_useragent: Mac OS X
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|_init_session: Not Implemented
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|_dbopen: mysql_pconnect
20100317173145|127.0.0.1|INFO|2010-03-17 17:31:45|app: admin Initialized
20100317173145|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:45|Helper Not Found: email,cookies_helper.php-> Line 191-> function: load_helper-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100317173145|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:45|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|pasteboard.Started
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: useragents-config
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: dates-config
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: fopen-config
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: stopwords-config
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-database
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-useragent
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-hooks
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-sessions
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-cache
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-scaffolding
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-errors
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-uri
20100317173149|127.0.0.1|INCLUDE|2010-03-17 17:31:49|library: pb-logs
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|_set_timezone: US/Pacific
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|_sitewhoami: default Initialized
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|_uri_segment: SEGMENT_PATH
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|_useragent: Firefox 3.6
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|_useragent: Mac OS X
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|_init_session: Not Implemented
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|_dbopen: mysql_pconnect
20100317173149|127.0.0.1|INFO|2010-03-17 17:31:49|app: admin Initialized
20100317173149|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:49|Helper Not Found: email,cookies_helper.php-> Line 191-> function: load_helper-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100317173149|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:49|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|pasteboard.Started
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: useragents-config
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: dates-config
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: fopen-config
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: stopwords-config
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-database
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-useragent
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-hooks
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-sessions
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-cache
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-scaffolding
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-errors
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-uri
20100317173157|127.0.0.1|INCLUDE|2010-03-17 17:31:57|library: pb-logs
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|_set_timezone: US/Pacific
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|_sitewhoami: default Initialized
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|_uri_segment: SEGMENT_PATH
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|_useragent: Firefox 3.6
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|_useragent: Mac OS X
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|_init_session: Not Implemented
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|_dbopen: mysql_pconnect
20100317173157|127.0.0.1|INFO|2010-03-17 17:31:57|app: admin Initialized
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 27]
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[2, E_WARNING] fopen() [<a href='function.fopen'>function.fopen</a>]: Filename cannot be empty [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 32]
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[2, E_WARNING] fwrite() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 33]
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 34]
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[2, E_WARNING] fclose() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 35]
20100317173157|127.0.0.1|SQL|2010-03-17 17:31:57|SQL_logged from _auth, 31
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[2, E_WARNING] Cannot modify header information - headers already sent by (output started at /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php:176) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/cookies_helper.php, 30]
20100317173157|127.0.0.1|LOGIN|2010-03-17 17:31:57|model: auth_model.php Function: _auth
20100317173157|127.0.0.1|__ERROR_WARNING|2010-03-17 17:31:57|[2, E_WARNING] Cannot modify header information - headers already sent by (output started at /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php:176) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 214]
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|pasteboard.Started
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: useragents-config
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: dates-config
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: fopen-config
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: stopwords-config
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-database
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-useragent
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-hooks
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-sessions
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-cache
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-scaffolding
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-errors
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-uri
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-logs
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_set_timezone: US/Pacific
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_sitewhoami: default Initialized
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_uri_segment: SEGMENT_PATH
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_useragent: Firefox 3.6
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_useragent: Mac OS X
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_init_session: Not Implemented
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_dbopen: mysql_pconnect
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|app: admin Initialized
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 27]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[2, E_WARNING] fopen() [<a href='function.fopen'>function.fopen</a>]: Filename cannot be empty [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 32]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[2, E_WARNING] fwrite() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 33]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 34]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[2, E_WARNING] fclose() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 35]
20100317173210|127.0.0.1|SQL|2010-03-17 17:32:10|SQL_logged from _auth, 31
20100317173210|127.0.0.1|LOGIN|2010-03-17 17:32:10|model: auth_model.php Function: _auth
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|pasteboard.Started
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: useragents-config
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: dates-config
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: fopen-config
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: stopwords-config
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-database
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-useragent
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-hooks
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-sessions
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-cache
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-scaffolding
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-errors
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-uri
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|library: pb-logs
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_set_timezone: US/Pacific
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_sitewhoami: default Initialized
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_uri_segment: SEGMENT_PATH
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_useragent: Firefox 3.6
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_useragent: Mac OS X
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_init_session: Not Implemented
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_dbopen: mysql_pconnect
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|app: admin Initialized
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|app: admin Function: dashboard
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|get_css / file: $file
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|get_css / file: $file
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|get_css / file: $file
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|app: admin Terminated
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|_dbclose CLOSED
20100317173210|127.0.0.1|INFO|2010-03-17 17:32:10|pasteboard.Complete (0.95 seconds)
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317173210|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:10|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317173210|127.0.0.1|INCLUDE|2010-03-17 17:32:10|helper: diagnostics_helper, format_diagnostics
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|pasteboard.Started
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: useragents-config
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: dates-config
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: fopen-config
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: stopwords-config
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-database
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-useragent
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-hooks
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-sessions
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-cache
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-scaffolding
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-errors
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-uri
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|library: pb-logs
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_set_timezone: US/Pacific
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_sitewhoami: default Initialized
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_uri_segment: SEGMENT_PATH
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_useragent: Firefox 3.6
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_useragent: Mac OS X
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_init_session: Not Implemented
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_dbopen: mysql_pconnect
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|app: admin Initialized
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|app: admin Function: logout
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|get_css / file: $file
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|get_css / file: $file
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|get_css / file: $file
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|get_js / file: $file
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|app: admin Terminated
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|_dbclose CLOSED
20100317173218|127.0.0.1|INFO|2010-03-17 17:32:18|pasteboard.Complete (0.488 seconds)
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317173218|127.0.0.1|__ERROR_WARNING|2010-03-17 17:32:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317173218|127.0.0.1|INCLUDE|2010-03-17 17:32:18|helper: diagnostics_helper, format_diagnostics
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|pasteboard.Started
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: useragents-config
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: dates-config
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: fopen-config
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: stopwords-config
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-database
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-useragent
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-hooks
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-sessions
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-cache
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-scaffolding
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-errors
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-uri
20100317174340|127.0.0.1|INCLUDE|2010-03-17 17:43:40|library: pb-logs
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|_set_timezone: US/Pacific
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|_sitewhoami: default Initialized
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|_uri_segment: SEGMENT_PATH
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|_useragent: Firefox 3.6
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|_useragent: Mac OS X
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|_init_session: Not Implemented
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|_dbopen: mysql_pconnect
20100317174340|127.0.0.1|INFO|2010-03-17 17:43:40|app: admin Initialized
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|pasteboard.Started
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: useragents-config
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: dates-config
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: fopen-config
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: stopwords-config
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-database
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-useragent
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-hooks
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-sessions
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-cache
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-scaffolding
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-errors
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-uri
20100317174348|127.0.0.1|INCLUDE|2010-03-17 17:43:48|library: pb-logs
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|_set_timezone: US/Pacific
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|_sitewhoami: default Initialized
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|_uri_segment: SEGMENT_PATH
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|_useragent: Firefox 3.6
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|_useragent: Mac OS X
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|_init_session: Not Implemented
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|_dbopen: mysql_pconnect
20100317174348|127.0.0.1|INFO|2010-03-17 17:43:48|app: admin Initialized
20100317174348|127.0.0.1|__ERROR_WARNING|2010-03-17 17:43:48|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174348|127.0.0.1|__ERROR_WARNING|2010-03-17 17:43:48|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174348|127.0.0.1|__ERROR_WARNING|2010-03-17 17:43:48|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174348|127.0.0.1|__ERROR_WARNING|2010-03-17 17:43:48|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174348|127.0.0.1|__ERROR_WARNING|2010-03-17 17:43:48|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174348|127.0.0.1|__ERROR_WARNING|2010-03-17 17:43:48|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|pasteboard.Started
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: useragents-config
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: dates-config
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: fopen-config
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: stopwords-config
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-database
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-useragent
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-hooks
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-sessions
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-cache
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-scaffolding
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-errors
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-uri
20100317174417|127.0.0.1|INCLUDE|2010-03-17 17:44:17|library: pb-logs
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|_set_timezone: US/Pacific
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|_sitewhoami: default Initialized
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|_uri_segment: SEGMENT_PATH
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|_useragent: Firefox 3.6
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|_useragent: Mac OS X
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|_init_session: Not Implemented
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|_dbopen: mysql_pconnect
20100317174417|127.0.0.1|INFO|2010-03-17 17:44:17|app: admin Initialized
20100317174417|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:17|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174417|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:17|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174417|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:17|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174417|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:17|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174417|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:17|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174417|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:17|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174417|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:17|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174417|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:17|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|pasteboard.Started
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: useragents-config
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: dates-config
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: fopen-config
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: stopwords-config
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-database
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-useragent
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-hooks
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-sessions
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-cache
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-scaffolding
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-errors
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-uri
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-logs
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_set_timezone: US/Pacific
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_sitewhoami: default Initialized
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_uri_segment: SEGMENT_PATH
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_useragent: Firefox 3.6
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_useragent: Mac OS X
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_init_session: Not Implemented
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_dbopen: mysql_pconnect
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|app: admin Initialized
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|pasteboard.Started
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: useragents-config
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: dates-config
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: fopen-config
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: stopwords-config
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-database
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-useragent
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-hooks
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-sessions
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-cache
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-scaffolding
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-errors
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-uri
20100317174418|127.0.0.1|INCLUDE|2010-03-17 17:44:18|library: pb-logs
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_set_timezone: US/Pacific
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_sitewhoami: default Initialized
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_uri_segment: SEGMENT_PATH
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_useragent: Firefox 3.6
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_useragent: Mac OS X
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_init_session: Not Implemented
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|_dbopen: mysql_pconnect
20100317174418|127.0.0.1|INFO|2010-03-17 17:44:18|app: admin Initialized
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174418|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:18|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|pasteboard.Started
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: useragents-config
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: dates-config
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: fopen-config
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: stopwords-config
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-database
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-useragent
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-hooks
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-sessions
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-cache
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-scaffolding
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-errors
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-uri
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-logs
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_set_timezone: US/Pacific
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_sitewhoami: default Initialized
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_uri_segment: SEGMENT_PATH
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_useragent: Firefox 3.6
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_useragent: Mac OS X
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_init_session: Not Implemented
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_dbopen: mysql_pconnect
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|app: admin Initialized
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|Function Does Not Exist: -> Line 388-> function: _check_func-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|pasteboard.Started
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: useragents-config
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: dates-config
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: fopen-config
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: stopwords-config
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-database
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-useragent
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-hooks
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-sessions
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-cache
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-scaffolding
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-errors
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-uri
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|library: pb-logs
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_set_timezone: US/Pacific
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_sitewhoami: default Initialized
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_uri_segment: SEGMENT_PATH
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_useragent: Firefox 3.6
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_useragent: Mac OS X
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_init_session: Not Implemented
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_dbopen: mysql_pconnect
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|app: admin Initialized
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|app: admin Function: login
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|get_css / file: $file
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|get_css / file: $file
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|get_css / file: $file
20100317174437|127.0.0.1|INCLUDE|2010-03-17 17:44:37|get_js / file: $file
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|app: admin Terminated
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|_dbclose CLOSED
20100317174437|127.0.0.1|INFO|2010-03-17 17:44:37|pasteboard.Complete (0.26 seconds)
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 205]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[8, E_NOTICE] Undefined variable: include_file [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once(/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174437|127.0.0.1|__ERROR_WARNING|2010-03-17 17:44:37|[2, E_WARNING] include_once() [<a href='function.include'>function.include</a>]: Failed opening '' for inclusion (include_path='.:/usr/lib/php') [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 206]
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|pasteboard.Started
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: useragents-config
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: dates-config
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: fopen-config
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: stopwords-config
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-database
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-useragent
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-hooks
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-sessions
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-cache
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-scaffolding
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-errors
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-uri
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|library: pb-logs
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_set_timezone: US/Pacific
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_sitewhoami: default Initialized
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_uri_segment: SEGMENT_PATH
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_useragent: Firefox 3.6
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_useragent: Mac OS X
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_init_session: Not Implemented
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_dbopen: mysql_pconnect
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|app: admin Initialized
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|app: admin Function: login
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|get_css / file: $file
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|get_css / file: $file
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|get_css / file: $file
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|get_js / file: $file
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|app: admin Terminated
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|_dbclose CLOSED
20100317174602|127.0.0.1|INFO|2010-03-17 17:46:02|pasteboard.Complete (0.669 seconds)
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317174602|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317174602|127.0.0.1|INCLUDE|2010-03-17 17:46:02|helper: diagnostics_helper, format_diagnostics
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|pasteboard.Started
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: useragents-config
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: dates-config
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: fopen-config
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: stopwords-config
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-database
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-useragent
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-hooks
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-sessions
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-cache
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-scaffolding
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-errors
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-uri
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-logs
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_set_timezone: US/Pacific
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_sitewhoami: default Initialized
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_uri_segment: SEGMENT_PATH
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_useragent: Firefox 3.6
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_useragent: Mac OS X
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_init_session: Not Implemented
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_dbopen: mysql_pconnect
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|app: admin Initialized
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 27]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] fopen() [<a href='function.fopen'>function.fopen</a>]: Filename cannot be empty [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 32]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] fwrite() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 33]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 34]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] fclose() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 35]
20100317174615|127.0.0.1|SQL|2010-03-17 17:46:15|SQL_logged from _auth, 31
20100317174615|127.0.0.1|LOGIN|2010-03-17 17:46:15|model: auth_model.php Function: _auth
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|pasteboard.Started
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: useragents-config
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: dates-config
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: fopen-config
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: stopwords-config
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-database
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-useragent
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-hooks
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-sessions
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-cache
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-scaffolding
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-errors
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-uri
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|library: pb-logs
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_set_timezone: US/Pacific
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_sitewhoami: default Initialized
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_uri_segment: SEGMENT_PATH
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_useragent: Firefox 3.6
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_useragent: Mac OS X
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_init_session: Not Implemented
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_dbopen: mysql_pconnect
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|app: admin Initialized
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|app: admin Function: dashboard
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|get_css / file: $file
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|get_css / file: $file
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|get_css / file: $file
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|app: admin Terminated
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|_dbclose CLOSED
20100317174615|127.0.0.1|INFO|2010-03-17 17:46:15|pasteboard.Complete (0.34 seconds)
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317174615|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317174615|127.0.0.1|INCLUDE|2010-03-17 17:46:15|helper: diagnostics_helper, format_diagnostics
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|pasteboard.Started
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: useragents-config
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: dates-config
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: fopen-config
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: stopwords-config
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-database
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-useragent
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-hooks
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-sessions
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-cache
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-scaffolding
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-errors
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-uri
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|library: pb-logs
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_set_timezone: US/Pacific
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_sitewhoami: default Initialized
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_uri_segment: SEGMENT_PATH
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_useragent: Firefox 3.6
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_useragent: Mac OS X
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_init_session: Not Implemented
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_dbopen: mysql_pconnect
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|app: admin Initialized
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|app: admin Function: logout
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|get_css / file: $file
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|get_css / file: $file
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|get_css / file: $file
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|get_js / file: $file
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|app: admin Terminated
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|_dbclose CLOSED
20100317174618|127.0.0.1|INFO|2010-03-17 17:46:18|pasteboard.Complete (0.534 seconds)
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317174618|127.0.0.1|__ERROR_WARNING|2010-03-17 17:46:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317174618|127.0.0.1|INCLUDE|2010-03-17 17:46:18|helper: diagnostics_helper, format_diagnostics
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|pasteboard.Started
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: useragents-config
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: dates-config
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: fopen-config
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: stopwords-config
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-database
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-useragent
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-hooks
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-sessions
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-cache
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-scaffolding
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-errors
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-uri
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|library: pb-logs
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_set_timezone: US/Pacific
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_sitewhoami: default Initialized
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_uri_segment: SEGMENT_PATH
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_useragent: Firefox 3.6
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_useragent: Mac OS X
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_init_session: Not Implemented
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_dbopen: mysql_pconnect
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|app: admin Initialized
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|app: admin Function: logout
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|get_css / file: $file
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|get_css / file: $file
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|get_css / file: $file
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|get_js / file: $file
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|app: admin Terminated
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|_dbclose CLOSED
20100317174729|127.0.0.1|INFO|2010-03-17 17:47:29|pasteboard.Complete (0.747 seconds)
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317174729|127.0.0.1|__ERROR_WARNING|2010-03-17 17:47:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317174729|127.0.0.1|INCLUDE|2010-03-17 17:47:29|helper: diagnostics_helper, format_diagnostics
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|pasteboard.Started
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: useragents-config
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: dates-config
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: fopen-config
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: stopwords-config
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-database
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-useragent
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-hooks
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-sessions
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-cache
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-scaffolding
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-errors
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-uri
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|library: pb-logs
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_set_timezone: US/Pacific
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_sitewhoami: default Initialized
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_uri_segment: SEGMENT_PATH
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_useragent: Firefox 3.6
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_useragent: Mac OS X
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_init_session: Not Implemented
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_dbopen: mysql_pconnect
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|app: admin Initialized
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|app: admin Function: logout
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|get_css / file: $file
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|get_css / file: $file
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|get_css / file: $file
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|get_js / file: $file
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|app: admin Terminated
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|_dbclose CLOSED
20100317175221|127.0.0.1|INFO|2010-03-17 17:52:21|pasteboard.Complete (0.322 seconds)
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175221|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:21|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175221|127.0.0.1|INCLUDE|2010-03-17 17:52:21|helper: diagnostics_helper, format_diagnostics
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|pasteboard.Started
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: useragents-config
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: dates-config
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: fopen-config
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: stopwords-config
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-database
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-useragent
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-hooks
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-sessions
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-cache
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-scaffolding
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-errors
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-uri
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|library: pb-logs
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_set_timezone: US/Pacific
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_sitewhoami: default Initialized
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_uri_segment: SEGMENT_PATH
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_useragent: Firefox 3.6
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_useragent: Mac OS X
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_init_session: Not Implemented
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_dbopen: mysql_pconnect
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|app: admin Initialized
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|app: admin Function: logout
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|get_css / file: $file
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|get_css / file: $file
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|get_css / file: $file
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|get_js / file: $file
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|app: admin Terminated
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|_dbclose CLOSED
20100317175228|127.0.0.1|INFO|2010-03-17 17:52:28|pasteboard.Complete (0.855 seconds)
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175228|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175228|127.0.0.1|INCLUDE|2010-03-17 17:52:28|helper: diagnostics_helper, format_diagnostics
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|pasteboard.Started
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: useragents-config
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: dates-config
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: fopen-config
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: stopwords-config
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-database
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-useragent
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-hooks
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-sessions
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-cache
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-scaffolding
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-errors
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-uri
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|library: pb-logs
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_set_timezone: US/Pacific
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_sitewhoami: default Initialized
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_uri_segment: SEGMENT_PATH
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_useragent: Firefox 3.6
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_useragent: Mac OS X
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_init_session: Not Implemented
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_dbopen: mysql_pconnect
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|app: admin Initialized
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|app: admin Function: logout
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|get_css / file: $file
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|get_css / file: $file
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|get_css / file: $file
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|get_js / file: $file
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|app: admin Terminated
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|_dbclose CLOSED
20100317175229|127.0.0.1|INFO|2010-03-17 17:52:29|pasteboard.Complete (0.647 seconds)
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175229|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175229|127.0.0.1|INCLUDE|2010-03-17 17:52:29|helper: diagnostics_helper, format_diagnostics
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|pasteboard.Started
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: useragents-config
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: dates-config
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: fopen-config
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: stopwords-config
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-database
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-useragent
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-hooks
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-sessions
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-cache
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-scaffolding
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-errors
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-uri
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-logs
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_set_timezone: US/Pacific
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_sitewhoami: default Initialized
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_uri_segment: SEGMENT_PATH
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_useragent: Firefox 3.6
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_useragent: Mac OS X
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_init_session: Not Implemented
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_dbopen: mysql_pconnect
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|app: admin Initialized
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|Function Does Not Exist: -> Line 393-> function: _check_func-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|pasteboard.Started
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: useragents-config
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: dates-config
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: fopen-config
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: stopwords-config
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-database
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-useragent
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-hooks
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-sessions
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-cache
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-scaffolding
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-errors
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-uri
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|library: pb-logs
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_set_timezone: US/Pacific
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_sitewhoami: default Initialized
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_uri_segment: SEGMENT_PATH
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_useragent: Firefox 3.6
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_useragent: Mac OS X
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_init_session: Not Implemented
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_dbopen: mysql_pconnect
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|app: admin Initialized
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|app: admin Function: login
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|get_css / file: $file
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|get_css / file: $file
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|get_css / file: $file
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|get_js / file: $file
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|app: admin Terminated
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|_dbclose CLOSED
20100317175247|127.0.0.1|INFO|2010-03-17 17:52:47|pasteboard.Complete (0.803 seconds)
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175247|127.0.0.1|__ERROR_WARNING|2010-03-17 17:52:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175247|127.0.0.1|INCLUDE|2010-03-17 17:52:47|helper: diagnostics_helper, format_diagnostics
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|pasteboard.Started
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: useragents-config
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: dates-config
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: fopen-config
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: stopwords-config
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-database
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-useragent
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-hooks
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-sessions
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-cache
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-scaffolding
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-errors
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-uri
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|library: pb-logs
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_set_timezone: US/Pacific
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_sitewhoami: default Initialized
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_uri_segment: SEGMENT_PATH
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_useragent: Firefox 3.6
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_useragent: Mac OS X
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_init_session: Not Implemented
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_dbopen: mysql_pconnect
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|app: admin Initialized
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|app: admin Function: login
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|get_css / file: $file
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|get_css / file: $file
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|get_css / file: $file
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|get_js / file: $file
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|app: admin Terminated
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|_dbclose CLOSED
20100317175346|127.0.0.1|INFO|2010-03-17 17:53:46|pasteboard.Complete (0.244 seconds)
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175346|127.0.0.1|__ERROR_WARNING|2010-03-17 17:53:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175346|127.0.0.1|INCLUDE|2010-03-17 17:53:46|helper: diagnostics_helper, format_diagnostics
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|pasteboard.Started
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: useragents-config
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: dates-config
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: fopen-config
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: stopwords-config
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-database
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-useragent
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-hooks
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-sessions
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-cache
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-scaffolding
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-errors
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-uri
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|library: pb-logs
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_set_timezone: US/Pacific
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_sitewhoami: default Initialized
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_uri_segment: SEGMENT_PATH
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_useragent: Firefox 3.6
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_useragent: Mac OS X
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_init_session: Not Implemented
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_dbopen: mysql_pconnect
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|app: admin Initialized
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|app: admin Function: login
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|get_css / file: $file
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|get_css / file: $file
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|get_css / file: $file
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|get_js / file: $file
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|app: admin Terminated
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|_dbclose CLOSED
20100317175454|127.0.0.1|INFO|2010-03-17 17:54:54|pasteboard.Complete (0.291 seconds)
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175454|127.0.0.1|__ERROR_WARNING|2010-03-17 17:54:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175454|127.0.0.1|INCLUDE|2010-03-17 17:54:54|helper: diagnostics_helper, format_diagnostics
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|pasteboard.Started
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: useragents-config
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: dates-config
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: fopen-config
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: stopwords-config
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-database
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-useragent
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-hooks
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-sessions
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-cache
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-scaffolding
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-errors
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-uri
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|library: pb-logs
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_set_timezone: US/Pacific
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_sitewhoami: default Initialized
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_uri_segment: SEGMENT_PATH
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_useragent: Firefox 3.6
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_useragent: Mac OS X
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_init_session: Not Implemented
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_dbopen: mysql_pconnect
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|app: admin Initialized
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|app: admin Function: login
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|get_css / file: $file
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|get_css / file: $file
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|get_css / file: $file
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|get_js / file: $file
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|app: admin Terminated
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|_dbclose CLOSED
20100317175604|127.0.0.1|INFO|2010-03-17 17:56:04|pasteboard.Complete (0.34 seconds)
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317175604|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317175604|127.0.0.1|INCLUDE|2010-03-17 17:56:04|helper: diagnostics_helper, format_diagnostics
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|pasteboard.Started
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: useragents-config
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: dates-config
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: fopen-config
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: stopwords-config
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-database
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-useragent
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-hooks
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-sessions
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-cache
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-scaffolding
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-errors
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-uri
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|library: pb-logs
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_set_timezone: US/Pacific
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_sitewhoami: default Initialized
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_uri_segment: SEGMENT_PATH
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_useragent: Firefox 3.6
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_useragent: Mac OS X
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_init_session: Not Implemented
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_dbopen: mysql_pconnect
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|app: admin Initialized
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|app: admin Function: login
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|get_css / file: $file
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|get_css / file: $file
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|get_css / file: $file
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|get_js / file: $file
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|app: admin Terminated
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|_dbclose CLOSED
20100317175629|127.0.0.1|INFO|2010-03-17 17:56:29|pasteboard.Complete (0.987 seconds)
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175629|127.0.0.1|__ERROR_WARNING|2010-03-17 17:56:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175629|127.0.0.1|INCLUDE|2010-03-17 17:56:29|helper: diagnostics_helper, format_diagnostics
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|pasteboard.Started
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: useragents-config
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: dates-config
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: fopen-config
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: stopwords-config
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-database
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-useragent
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-hooks
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-sessions
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-cache
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-scaffolding
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-errors
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-uri
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|library: pb-logs
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_set_timezone: US/Pacific
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_sitewhoami: default Initialized
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_uri_segment: SEGMENT_PATH
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_useragent: Firefox 3.6
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_useragent: Mac OS X
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_init_session: Not Implemented
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_dbopen: mysql_pconnect
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|app: admin Initialized
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|app: admin Function: login
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|get_css / file: $file
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|get_css / file: $file
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|get_css / file: $file
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|get_js / file: $file
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|app: admin Terminated
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|_dbclose CLOSED
20100317175701|127.0.0.1|INFO|2010-03-17 17:57:01|pasteboard.Complete (0.375 seconds)
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175701|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175701|127.0.0.1|INCLUDE|2010-03-17 17:57:01|helper: diagnostics_helper, format_diagnostics
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|pasteboard.Started
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: useragents-config
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: dates-config
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: fopen-config
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: stopwords-config
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-database
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-useragent
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-hooks
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-sessions
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-cache
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-scaffolding
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-errors
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-uri
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|library: pb-logs
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_set_timezone: US/Pacific
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_sitewhoami: default Initialized
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_uri_segment: SEGMENT_PATH
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_useragent: Firefox 3.6
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_useragent: Mac OS X
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_init_session: Not Implemented
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_dbopen: mysql_pconnect
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|app: admin Initialized
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|app: admin Function: login
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|get_css / file: $file
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|get_css / file: $file
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|get_css / file: $file
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|get_js / file: $file
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|app: admin Terminated
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|_dbclose CLOSED
20100317175703|127.0.0.1|INFO|2010-03-17 17:57:03|pasteboard.Complete (0.752 seconds)
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175703|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:03|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175703|127.0.0.1|INCLUDE|2010-03-17 17:57:03|helper: diagnostics_helper, format_diagnostics
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|pasteboard.Started
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: useragents-config
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: dates-config
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: fopen-config
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: stopwords-config
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-database
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-useragent
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-hooks
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-sessions
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-cache
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-scaffolding
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-errors
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-uri
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-logs
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_set_timezone: US/Pacific
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_sitewhoami: default Initialized
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_uri_segment: SEGMENT_PATH
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_useragent: Firefox 3.6
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_useragent: Mac OS X
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_init_session: Not Implemented
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_dbopen: mysql_pconnect
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|app: admin Initialized
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|app: admin Function: login
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|get_css / file: $file
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|get_css / file: $file
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|get_css / file: $file
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|get_js / file: $file
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|app: admin Terminated
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_dbclose CLOSED
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|pasteboard.Complete (0.617 seconds)
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|helper: diagnostics_helper, format_diagnostics
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|pasteboard.Started
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: useragents-config
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: dates-config
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: fopen-config
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: stopwords-config
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-database
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-useragent
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-hooks
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-sessions
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-cache
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-scaffolding
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-errors
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-uri
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|library: pb-logs
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_set_timezone: US/Pacific
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_sitewhoami: default Initialized
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_uri_segment: SEGMENT_PATH
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_useragent: Firefox 3.6
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_useragent: Mac OS X
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_init_session: Not Implemented
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_dbopen: mysql_pconnect
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|app: admin Initialized
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|app: admin Function: login
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|get_css / file: $file
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|get_css / file: $file
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|get_css / file: $file
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|get_js / file: $file
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|app: admin Terminated
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|_dbclose CLOSED
20100317175704|127.0.0.1|INFO|2010-03-17 17:57:04|pasteboard.Complete (0.833 seconds)
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175704|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175704|127.0.0.1|INCLUDE|2010-03-17 17:57:04|helper: diagnostics_helper, format_diagnostics
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|pasteboard.Started
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: useragents-config
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: dates-config
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: fopen-config
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: stopwords-config
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-database
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-useragent
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-hooks
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-sessions
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-cache
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-scaffolding
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-errors
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-uri
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|library: pb-logs
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_set_timezone: US/Pacific
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_sitewhoami: default Initialized
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_uri_segment: SEGMENT_PATH
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_useragent: Firefox 3.6
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_useragent: Mac OS X
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_init_session: Not Implemented
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_dbopen: mysql_pconnect
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|app: admin Initialized
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|app: admin Function: login
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|get_css / file: $file
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|get_css / file: $file
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|get_css / file: $file
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|get_js / file: $file
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|app: admin Terminated
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|_dbclose CLOSED
20100317175715|127.0.0.1|INFO|2010-03-17 17:57:15|pasteboard.Complete (0.699 seconds)
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175715|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175715|127.0.0.1|INCLUDE|2010-03-17 17:57:15|helper: diagnostics_helper, format_diagnostics
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|pasteboard.Started
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: useragents-config
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: dates-config
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: fopen-config
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: stopwords-config
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-database
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-useragent
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-hooks
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-sessions
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-cache
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-scaffolding
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-errors
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-uri
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|library: pb-logs
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_set_timezone: US/Pacific
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_sitewhoami: default Initialized
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_uri_segment: SEGMENT_PATH
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_useragent: Firefox 3.6
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_useragent: Mac OS X
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_init_session: Not Implemented
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_dbopen: mysql_pconnect
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|app: admin Initialized
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|app: admin Function: login
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|get_css / file: $file
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|get_css / file: $file
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|get_css / file: $file
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|get_js / file: $file
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|app: admin Terminated
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|_dbclose CLOSED
20100317175749|127.0.0.1|INFO|2010-03-17 17:57:49|pasteboard.Complete (0.626 seconds)
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175749|127.0.0.1|__ERROR_WARNING|2010-03-17 17:57:49|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175749|127.0.0.1|INCLUDE|2010-03-17 17:57:49|helper: diagnostics_helper, format_diagnostics
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|pasteboard.Started
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: useragents-config
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: dates-config
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: fopen-config
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: stopwords-config
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-database
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-useragent
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-hooks
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-sessions
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-cache
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-scaffolding
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-errors
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-uri
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|library: pb-logs
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_set_timezone: US/Pacific
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_sitewhoami: default Initialized
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_uri_segment: SEGMENT_PATH
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_useragent: Firefox 3.6
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_useragent: Mac OS X
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_init_session: Not Implemented
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_dbopen: mysql_pconnect
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|app: admin Initialized
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|app: admin Function: login
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|get_css / file: $file
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|get_css / file: $file
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|get_css / file: $file
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|get_js / file: $file
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|app: admin Terminated
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|_dbclose CLOSED
20100317175831|127.0.0.1|INFO|2010-03-17 17:58:31|pasteboard.Complete (0.208 seconds)
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317175831|127.0.0.1|__ERROR_WARNING|2010-03-17 17:58:31|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317175831|127.0.0.1|INCLUDE|2010-03-17 17:58:31|helper: diagnostics_helper, format_diagnostics
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|pasteboard.Started
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: useragents-config
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: dates-config
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: fopen-config
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: stopwords-config
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-database
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-useragent
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-hooks
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-sessions
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-cache
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-scaffolding
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-errors
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-uri
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|library: pb-logs
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_set_timezone: US/Pacific
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_sitewhoami: default Initialized
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_uri_segment: SEGMENT_PATH
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_useragent: Firefox 3.6
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_useragent: Mac OS X
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_init_session: Not Implemented
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_dbopen: mysql_pconnect
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|app: admin Initialized
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|app: admin Function: login
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|get_css / file: $file
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|get_css / file: $file
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|get_css / file: $file
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|get_js / file: $file
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|app: admin Terminated
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|_dbclose CLOSED
20100317175915|127.0.0.1|INFO|2010-03-17 17:59:15|pasteboard.Complete (0.037 seconds)
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317175915|127.0.0.1|__ERROR_WARNING|2010-03-17 17:59:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 331]
20100317175915|127.0.0.1|INCLUDE|2010-03-17 17:59:15|helper: diagnostics_helper, format_diagnostics
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|pasteboard.Started
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: useragents-config
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: dates-config
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: fopen-config
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: stopwords-config
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-database
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-useragent
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-hooks
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-sessions
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-cache
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-scaffolding
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-errors
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-uri
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|library: pb-logs
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_set_timezone: US/Pacific
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_sitewhoami: default Initialized
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_uri_segment: SEGMENT_PATH
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_useragent: Firefox 3.6
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_useragent: Mac OS X
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_init_session: Not Implemented
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_dbopen: mysql_pconnect
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|app: admin Initialized
20100317180056|127.0.0.1|__ERROR_WARNING|2010-03-17 18:00:56|[8, E_NOTICE] Undefined variable: files [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180056|127.0.0.1|__ERROR_WARNING|2010-03-17 18:00:56|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180056|127.0.0.1|__ERROR_WARNING|2010-03-17 18:00:56|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|app: admin Function: login
20100317180056|127.0.0.1|__ERROR_WARNING|2010-03-17 18:00:56|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|get_css / file: $file
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|get_css / file: $file
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|get_css / file: $file
20100317180056|127.0.0.1|INCLUDE|2010-03-17 18:00:56|get_js / file: $file
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|app: admin Terminated
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|_dbclose CLOSED
20100317180056|127.0.0.1|INFO|2010-03-17 18:00:56|pasteboard.Complete (0.467 seconds)
20100317180056|127.0.0.1|__ERROR_WARNING|2010-03-17 18:00:56|[8, E_NOTICE] Undefined variable: files [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180056|127.0.0.1|__ERROR_WARNING|2010-03-17 18:00:56|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180056|127.0.0.1|__ERROR_WARNING|2010-03-17 18:00:56|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|pasteboard.Started
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: useragents-config
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: dates-config
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: fopen-config
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: stopwords-config
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-database
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-useragent
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-hooks
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-sessions
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-cache
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-scaffolding
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-errors
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-uri
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|library: pb-logs
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_set_timezone: US/Pacific
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_sitewhoami: default Initialized
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_uri_segment: SEGMENT_PATH
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_useragent: Firefox 3.6
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_useragent: Mac OS X
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_init_session: Not Implemented
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_dbopen: mysql_pconnect
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|app: admin Initialized
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|[8, E_NOTICE] Undefined variable: files [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|[8, E_NOTICE] Undefined index: list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|app: admin Function: login
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|get_css / file: $file
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|get_css / file: $file
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|get_css / file: $file
20100317180211|127.0.0.1|INCLUDE|2010-03-17 18:02:11|get_js / file: $file
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|app: admin Terminated
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|_dbclose CLOSED
20100317180211|127.0.0.1|INFO|2010-03-17 18:02:11|pasteboard.Complete (0.657 seconds)
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|[8, E_NOTICE] Undefined variable: files [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180211|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:11|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|pasteboard.Started
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: useragents-config
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: dates-config
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: fopen-config
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: stopwords-config
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-database
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-useragent
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-hooks
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-sessions
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-cache
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-scaffolding
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-errors
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-uri
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|library: pb-logs
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_set_timezone: US/Pacific
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_sitewhoami: default Initialized
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_uri_segment: SEGMENT_PATH
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_useragent: Firefox 3.6
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_useragent: Mac OS X
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_init_session: Not Implemented
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_dbopen: mysql_pconnect
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|app: admin Initialized
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|[8, E_NOTICE] Undefined variable: files [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|[8, E_NOTICE] Undefined index: list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|app: admin Function: login
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|get_css / file: $file
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|get_css / file: $file
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|get_css / file: $file
20100317180212|127.0.0.1|INCLUDE|2010-03-17 18:02:12|get_js / file: $file
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|app: admin Terminated
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|_dbclose CLOSED
20100317180212|127.0.0.1|INFO|2010-03-17 18:02:12|pasteboard.Complete (0.712 seconds)
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|[8, E_NOTICE] Undefined variable: files [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 170]
20100317180212|127.0.0.1|__ERROR_WARNING|2010-03-17 18:02:12|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 200]
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|pasteboard.Started
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: useragents-config
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: dates-config
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: fopen-config
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: stopwords-config
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-database
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-useragent
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-hooks
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-sessions
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-cache
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-scaffolding
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-errors
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-uri
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|library: pb-logs
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_set_timezone: US/Pacific
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_sitewhoami: default Initialized
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_uri_segment: SEGMENT_PATH
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_useragent: Firefox 3.6
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_useragent: Mac OS X
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_init_session: Not Implemented
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_dbopen: mysql_pconnect
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|app: admin Initialized
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 186]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 202]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[8, E_NOTICE] Undefined index: list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 202]
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|app: admin Function: login
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|get_css / file: $file
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|get_css / file: $file
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|get_css / file: $file
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|get_js / file: $file
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|app: admin Terminated
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|_dbclose CLOSED
20100317180334|127.0.0.1|INFO|2010-03-17 18:03:34|pasteboard.Complete (0.37 seconds)
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180334|127.0.0.1|__ERROR_WARNING|2010-03-17 18:03:34|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180334|127.0.0.1|INCLUDE|2010-03-17 18:03:34|helper: diagnostics_helper, format_diagnostics
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|pasteboard.Started
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: useragents-config
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: dates-config
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: fopen-config
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: stopwords-config
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-database
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-useragent
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-hooks
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-sessions
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-cache
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-scaffolding
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-errors
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-uri
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|library: pb-logs
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_set_timezone: US/Pacific
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_sitewhoami: default Initialized
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_uri_segment: SEGMENT_PATH
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_useragent: Firefox 3.6
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_useragent: Mac OS X
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_init_session: Not Implemented
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_dbopen: mysql_pconnect
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|app: admin Initialized
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 179]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 195]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined index: list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 195]
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|app: admin Function: login
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|get_css / file: $file
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|get_css / file: $file
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|get_css / file: $file
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|get_js / file: $file
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|app: admin Terminated
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|_dbclose CLOSED
20100317180402|127.0.0.1|INFO|2010-03-17 18:04:02|pasteboard.Complete (0.365 seconds)
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 179]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180402|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180402|127.0.0.1|INCLUDE|2010-03-17 18:04:02|helper: diagnostics_helper, format_diagnostics
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|pasteboard.Started
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: useragents-config
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: dates-config
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: fopen-config
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: stopwords-config
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-database
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-useragent
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-hooks
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-sessions
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-cache
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-scaffolding
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-errors
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-uri
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|library: pb-logs
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_set_timezone: US/Pacific
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_sitewhoami: default Initialized
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_uri_segment: SEGMENT_PATH
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_useragent: Firefox 3.6
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_useragent: Mac OS X
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_init_session: Not Implemented
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_dbopen: mysql_pconnect
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|app: admin Initialized
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 179]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 191]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined index: list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 191]
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|app: admin Function: login
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|get_css / file: $file
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|get_css / file: $file
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|get_css / file: $file
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|get_js / file: $file
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|app: admin Terminated
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|_dbclose CLOSED
20100317180425|127.0.0.1|INFO|2010-03-17 18:04:25|pasteboard.Complete (0.393 seconds)
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 179]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180425|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:25|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180425|127.0.0.1|INCLUDE|2010-03-17 18:04:25|helper: diagnostics_helper, format_diagnostics
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|pasteboard.Started
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: useragents-config
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: dates-config
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: fopen-config
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: stopwords-config
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-database
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-useragent
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-hooks
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-sessions
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-cache
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-scaffolding
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-errors
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-uri
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|library: pb-logs
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_set_timezone: US/Pacific
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_sitewhoami: default Initialized
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_uri_segment: SEGMENT_PATH
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_useragent: Firefox 3.6
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_useragent: Mac OS X
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_init_session: Not Implemented
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_dbopen: mysql_pconnect
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|app: admin Initialized
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 179]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 191]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined index: list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 191]
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|app: admin Function: login
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|get_css / file: $file
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|get_css / file: $file
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|get_css / file: $file
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|get_js / file: $file
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|app: admin Terminated
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|_dbclose CLOSED
20100317180427|127.0.0.1|INFO|2010-03-17 18:04:27|pasteboard.Complete (0.702 seconds)
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined variable: helper_list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 179]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180427|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180427|127.0.0.1|INCLUDE|2010-03-17 18:04:27|helper: diagnostics_helper, format_diagnostics
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|pasteboard.Started
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: useragents-config
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: dates-config
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: fopen-config
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: stopwords-config
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-database
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-useragent
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-hooks
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-sessions
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-cache
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-scaffolding
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-errors
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-uri
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|library: pb-logs
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_set_timezone: US/Pacific
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_sitewhoami: default Initialized
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_uri_segment: SEGMENT_PATH
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_useragent: Firefox 3.6
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_useragent: Mac OS X
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_init_session: Not Implemented
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_dbopen: mysql_pconnect
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|app: admin Initialized
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[8, E_NOTICE] Undefined index: HELPERS [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 190]
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[8, E_NOTICE] Undefined index: list [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 190]
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|app: admin Function: login
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|get_css / file: $file
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|get_css / file: $file
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|get_css / file: $file
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|get_js / file: $file
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|app: admin Terminated
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|_dbclose CLOSED
20100317180438|127.0.0.1|INFO|2010-03-17 18:04:38|pasteboard.Complete (0.137 seconds)
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180438|127.0.0.1|__ERROR_WARNING|2010-03-17 18:04:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180438|127.0.0.1|INCLUDE|2010-03-17 18:04:38|helper: diagnostics_helper, format_diagnostics
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|pasteboard.Started
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: useragents-config
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: dates-config
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: fopen-config
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: stopwords-config
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-database
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-useragent
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-hooks
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-sessions
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-cache
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-scaffolding
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-errors
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-uri
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|library: pb-logs
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_set_timezone: US/Pacific
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_sitewhoami: default Initialized
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_uri_segment: SEGMENT_PATH
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_useragent: Firefox 3.6
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_useragent: Mac OS X
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_init_session: Not Implemented
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_dbopen: mysql_pconnect
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|app: admin Initialized
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|app: admin Function: login
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|get_css / file: $file
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|get_css / file: $file
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|get_css / file: $file
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|get_js / file: $file
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|app: admin Terminated
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|_dbclose CLOSED
20100317180524|127.0.0.1|INFO|2010-03-17 18:05:24|pasteboard.Complete (0.374 seconds)
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180524|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180524|127.0.0.1|INCLUDE|2010-03-17 18:05:24|helper: diagnostics_helper, format_diagnostics
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|pasteboard.Started
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: useragents-config
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: dates-config
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: fopen-config
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: stopwords-config
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-database
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-useragent
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-hooks
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-sessions
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-cache
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-scaffolding
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-errors
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-uri
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|library: pb-logs
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_set_timezone: US/Pacific
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_sitewhoami: default Initialized
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_uri_segment: SEGMENT_PATH
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_useragent: Firefox 3.6
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_useragent: Mac OS X
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_init_session: Not Implemented
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_dbopen: mysql_pconnect
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|app: admin Initialized
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|app: admin Function: login
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|get_css / file: $file
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|get_css / file: $file
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|get_css / file: $file
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|get_js / file: $file
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|app: admin Terminated
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|_dbclose CLOSED
20100317180544|127.0.0.1|INFO|2010-03-17 18:05:44|pasteboard.Complete (0.141 seconds)
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180544|127.0.0.1|__ERROR_WARNING|2010-03-17 18:05:44|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180544|127.0.0.1|INCLUDE|2010-03-17 18:05:44|helper: diagnostics_helper, format_diagnostics
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|pasteboard.Started
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: useragents-config
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: dates-config
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: fopen-config
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: stopwords-config
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-database
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-useragent
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-hooks
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-sessions
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-cache
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-scaffolding
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-errors
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-uri
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|library: pb-logs
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_set_timezone: US/Pacific
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_sitewhoami: default Initialized
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_uri_segment: SEGMENT_PATH
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_useragent: Firefox 3.6
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_useragent: Mac OS X
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_init_session: Not Implemented
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_dbopen: mysql_pconnect
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|app: admin Initialized
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|app: admin Function: login
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|get_css / file: $file
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|get_css / file: $file
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|get_css / file: $file
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|get_js / file: $file
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|app: admin Terminated
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|_dbclose CLOSED
20100317180636|127.0.0.1|INFO|2010-03-17 18:06:36|pasteboard.Complete (0.723 seconds)
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180636|127.0.0.1|__ERROR_WARNING|2010-03-17 18:06:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180636|127.0.0.1|INCLUDE|2010-03-17 18:06:36|helper: diagnostics_helper, format_diagnostics
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|pasteboard.Started
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: useragents-config
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: dates-config
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: fopen-config
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: stopwords-config
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-database
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-useragent
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-hooks
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-sessions
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-cache
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-scaffolding
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-errors
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-uri
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|library: pb-logs
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_set_timezone: US/Pacific
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_sitewhoami: default Initialized
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_uri_segment: SEGMENT_PATH
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_useragent: Firefox 3.6
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_useragent: Mac OS X
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_init_session: Not Implemented
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_dbopen: mysql_pconnect
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|app: admin Initialized
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|app: admin Function: login
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|get_css / file: $file
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|get_css / file: $file
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|get_css / file: $file
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|get_js / file: $file
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|app: admin Terminated
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|_dbclose CLOSED
20100317180707|127.0.0.1|INFO|2010-03-17 18:07:07|pasteboard.Complete (0.584 seconds)
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180707|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180707|127.0.0.1|INCLUDE|2010-03-17 18:07:07|helper: diagnostics_helper, format_diagnostics
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|pasteboard.Started
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: useragents-config
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: dates-config
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: fopen-config
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: stopwords-config
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-database
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-useragent
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-hooks
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-sessions
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-cache
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-scaffolding
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-errors
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-uri
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|library: pb-logs
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_set_timezone: US/Pacific
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_sitewhoami: default Initialized
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_uri_segment: SEGMENT_PATH
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_useragent: Firefox 3.6
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_useragent: Mac OS X
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_init_session: Not Implemented
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_dbopen: mysql_pconnect
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|app: admin Initialized
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|app: admin Function: login
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|get_css / file: $file
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|get_css / file: $file
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|get_css / file: $file
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|get_js / file: $file
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|app: admin Terminated
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|_dbclose CLOSED
20100317180708|127.0.0.1|INFO|2010-03-17 18:07:08|pasteboard.Complete (1.02 seconds)
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180708|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180708|127.0.0.1|INCLUDE|2010-03-17 18:07:08|helper: diagnostics_helper, format_diagnostics
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|pasteboard.Started
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: useragents-config
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: dates-config
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: fopen-config
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: stopwords-config
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-database
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-useragent
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-hooks
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-sessions
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-cache
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-scaffolding
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-errors
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-uri
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|library: pb-logs
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_set_timezone: US/Pacific
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_sitewhoami: default Initialized
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_uri_segment: SEGMENT_PATH
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_useragent: Firefox 3.6
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_useragent: Mac OS X
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_init_session: Not Implemented
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_dbopen: mysql_pconnect
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|app: admin Initialized
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|app: admin Function: login
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|get_css / file: $file
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|get_css / file: $file
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|get_css / file: $file
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|get_js / file: $file
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|app: admin Terminated
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|_dbclose CLOSED
20100317180709|127.0.0.1|INFO|2010-03-17 18:07:09|pasteboard.Complete (0.478 seconds)
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[8, E_NOTICE] Undefined variable: add_comma [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php, 192]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180709|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:09|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180709|127.0.0.1|INCLUDE|2010-03-17 18:07:09|helper: diagnostics_helper, format_diagnostics
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|pasteboard.Started
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: useragents-config
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: dates-config
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: fopen-config
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: stopwords-config
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-database
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-useragent
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-hooks
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-sessions
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-cache
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-scaffolding
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-errors
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-uri
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|library: pb-logs
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_set_timezone: US/Pacific
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_sitewhoami: default Initialized
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_uri_segment: SEGMENT_PATH
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_useragent: Firefox 3.6
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_useragent: Mac OS X
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_init_session: Not Implemented
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_dbopen: mysql_pconnect
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|app: admin Initialized
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|app: admin Function: login
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|get_css / file: $file
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|get_css / file: $file
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|get_css / file: $file
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|get_js / file: $file
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|app: admin Terminated
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|_dbclose CLOSED
20100317180747|127.0.0.1|INFO|2010-03-17 18:07:47|pasteboard.Complete (0.306 seconds)
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180747|127.0.0.1|__ERROR_WARNING|2010-03-17 18:07:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180747|127.0.0.1|INCLUDE|2010-03-17 18:07:47|helper: diagnostics_helper, format_diagnostics
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|pasteboard.Started
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: useragents-config
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: dates-config
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: fopen-config
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: stopwords-config
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-database
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-useragent
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-hooks
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-sessions
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-cache
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-scaffolding
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-errors
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-uri
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|library: pb-logs
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_set_timezone: US/Pacific
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_sitewhoami: default Initialized
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_uri_segment: SEGMENT_PATH
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_useragent: Firefox 3.6
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_useragent: Mac OS X
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_init_session: Not Implemented
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_dbopen: mysql_pconnect
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|app: admin Initialized
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|app: admin Function: login
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|get_css / file: $file
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|get_css / file: $file
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|get_css / file: $file
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|get_js / file: $file
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|app: admin Terminated
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|_dbclose CLOSED
20100317180817|127.0.0.1|INFO|2010-03-17 18:08:17|pasteboard.Complete (0.233 seconds)
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180817|127.0.0.1|__ERROR_WARNING|2010-03-17 18:08:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180817|127.0.0.1|INCLUDE|2010-03-17 18:08:17|helper: diagnostics_helper, format_diagnostics
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|pasteboard.Started
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: useragents-config
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: dates-config
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: fopen-config
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: stopwords-config
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-database
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-useragent
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-hooks
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-sessions
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-cache
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-scaffolding
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-errors
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-uri
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|library: pb-logs
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_set_timezone: US/Pacific
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_sitewhoami: default Initialized
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_uri_segment: SEGMENT_PATH
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_useragent: Firefox 3.6
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_useragent: Mac OS X
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_init_session: Not Implemented
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_dbopen: mysql_pconnect
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|app: admin Initialized
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|app: admin Function: login
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|get_css / file: $file
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|get_css / file: $file
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|get_css / file: $file
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|get_js / file: $file
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|app: admin Terminated
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|_dbclose CLOSED
20100317180920|127.0.0.1|INFO|2010-03-17 18:09:20|pasteboard.Complete (0.832 seconds)
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180920|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180920|127.0.0.1|INCLUDE|2010-03-17 18:09:20|helper: diagnostics_helper, format_diagnostics
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|pasteboard.Started
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: useragents-config
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: dates-config
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: fopen-config
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: stopwords-config
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-database
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-useragent
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-hooks
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-sessions
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-cache
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-scaffolding
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-errors
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-uri
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|library: pb-logs
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_set_timezone: US/Pacific
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_sitewhoami: default Initialized
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_uri_segment: SEGMENT_PATH
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_useragent: Firefox 3.6
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_useragent: Mac OS X
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_init_session: Not Implemented
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_dbopen: mysql_pconnect
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|app: admin Initialized
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|app: admin Function: login
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|get_css / file: $file
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|get_css / file: $file
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|get_css / file: $file
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|get_js / file: $file
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|app: admin Terminated
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|_dbclose CLOSED
20100317180922|127.0.0.1|INFO|2010-03-17 18:09:22|pasteboard.Complete (0.079 seconds)
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180922|127.0.0.1|__ERROR_WARNING|2010-03-17 18:09:22|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317180922|127.0.0.1|INCLUDE|2010-03-17 18:09:22|helper: diagnostics_helper, format_diagnostics
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|pasteboard.Started
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: useragents-config
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: dates-config
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: fopen-config
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: stopwords-config
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-database
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-useragent
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-hooks
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-sessions
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-cache
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-scaffolding
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-errors
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-uri
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|library: pb-logs
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_set_timezone: US/Pacific
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_sitewhoami: default Initialized
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_uri_segment: SEGMENT_PATH
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_useragent: Firefox 3.6
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_useragent: Mac OS X
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_init_session: Not Implemented
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_dbopen: mysql_pconnect
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|app: admin Initialized
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|app: admin Function: login
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|get_css / file: $file
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|get_css / file: $file
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|get_css / file: $file
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|get_js / file: $file
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|app: admin Terminated
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|_dbclose CLOSED
20100317181026|127.0.0.1|INFO|2010-03-17 18:10:26|pasteboard.Complete (0.947 seconds)
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181026|127.0.0.1|__ERROR_WARNING|2010-03-17 18:10:26|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181026|127.0.0.1|INCLUDE|2010-03-17 18:10:26|helper: diagnostics_helper, format_diagnostics
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|pasteboard.Started
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: useragents-config
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: dates-config
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: fopen-config
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: stopwords-config
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-database
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-useragent
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-hooks
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-sessions
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-cache
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-scaffolding
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-errors
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-uri
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|library: pb-logs
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_set_timezone: US/Pacific
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_sitewhoami: default Initialized
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_uri_segment: SEGMENT_PATH
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_useragent: Firefox 3.6
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_useragent: Mac OS X
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_init_session: Not Implemented
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_dbopen: mysql_pconnect
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|app: admin Initialized
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|app: admin Function: login
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|get_css / file: $file
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|get_css / file: $file
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|get_css / file: $file
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|get_js / file: $file
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|app: admin Terminated
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|_dbclose CLOSED
20100317181117|127.0.0.1|INFO|2010-03-17 18:11:17|pasteboard.Complete (0.602 seconds)
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181117|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181117|127.0.0.1|INCLUDE|2010-03-17 18:11:17|helper: diagnostics_helper, format_diagnostics
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|pasteboard.Started
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: useragents-config
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: dates-config
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: fopen-config
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: stopwords-config
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-database
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-useragent
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-hooks
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-sessions
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-cache
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-scaffolding
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-errors
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-uri
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|library: pb-logs
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_set_timezone: US/Pacific
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_sitewhoami: default Initialized
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_uri_segment: SEGMENT_PATH
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_useragent: Firefox 3.6
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_useragent: Mac OS X
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_init_session: Not Implemented
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_dbopen: mysql_pconnect
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|app: admin Initialized
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|app: admin Function: login
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|get_css / file: $file
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|get_css / file: $file
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|get_css / file: $file
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|get_js / file: $file
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|app: admin Terminated
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|_dbclose CLOSED
20100317181136|127.0.0.1|INFO|2010-03-17 18:11:36|pasteboard.Complete (0.095 seconds)
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181136|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181136|127.0.0.1|INCLUDE|2010-03-17 18:11:36|helper: diagnostics_helper, format_diagnostics
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|pasteboard.Started
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: useragents-config
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: dates-config
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: fopen-config
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: stopwords-config
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-database
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-useragent
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-hooks
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-sessions
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-cache
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-scaffolding
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-errors
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-uri
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|library: pb-logs
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_set_timezone: US/Pacific
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_sitewhoami: default Initialized
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_uri_segment: SEGMENT_PATH
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_useragent: Firefox 3.6
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_useragent: Mac OS X
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_init_session: Not Implemented
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_dbopen: mysql_pconnect
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|app: admin Initialized
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|app: admin Function: login
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|get_css / file: $file
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|get_css / file: $file
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|get_css / file: $file
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|get_js / file: $file
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|app: admin Terminated
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|_dbclose CLOSED
20100317181143|127.0.0.1|INFO|2010-03-17 18:11:43|pasteboard.Complete (1.013 seconds)
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181143|127.0.0.1|__ERROR_WARNING|2010-03-17 18:11:43|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181143|127.0.0.1|INCLUDE|2010-03-17 18:11:43|helper: diagnostics_helper, format_diagnostics
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|pasteboard.Started
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: useragents-config
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: dates-config
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: fopen-config
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: stopwords-config
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-database
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-useragent
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-hooks
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-sessions
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-cache
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-scaffolding
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-errors
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-uri
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|library: pb-logs
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_set_timezone: US/Pacific
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_sitewhoami: default Initialized
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_uri_segment: SEGMENT_PATH
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_useragent: Firefox 3.6
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_useragent: Mac OS X
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_init_session: Not Implemented
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_dbopen: mysql_pconnect
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|app: admin Initialized
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|app: admin Function: login
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|get_css / file: $file
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|get_css / file: $file
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|get_css / file: $file
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|get_js / file: $file
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|app: admin Terminated
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|_dbclose CLOSED
20100317181228|127.0.0.1|INFO|2010-03-17 18:12:28|pasteboard.Complete (0.13 seconds)
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181228|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181228|127.0.0.1|INCLUDE|2010-03-17 18:12:28|helper: diagnostics_helper, format_diagnostics
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|pasteboard.Started
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: useragents-config
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: dates-config
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: fopen-config
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: stopwords-config
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-database
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-useragent
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-hooks
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-sessions
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-cache
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-scaffolding
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-errors
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-uri
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-logs
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_set_timezone: US/Pacific
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_sitewhoami: default Initialized
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_uri_segment: SEGMENT_PATH
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_useragent: Firefox 3.6
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_useragent: Mac OS X
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_init_session: Not Implemented
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_dbopen: mysql_pconnect
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|app: admin Initialized
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 184]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 27]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[2, E_WARNING] fopen() [<a href='function.fopen'>function.fopen</a>]: Filename cannot be empty [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 32]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[2, E_WARNING] fwrite() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 33]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 34]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[2, E_WARNING] fclose() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 35]
20100317181239|127.0.0.1|SQL|2010-03-17 18:12:39|SQL_logged from _auth, 31
20100317181239|127.0.0.1|LOGIN|2010-03-17 18:12:39|model: auth_model.php Function: _auth
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|pasteboard.Started
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: useragents-config
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: dates-config
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: fopen-config
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: stopwords-config
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-database
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-useragent
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-hooks
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-sessions
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-cache
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-scaffolding
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-errors
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-uri
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|library: pb-logs
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_set_timezone: US/Pacific
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_sitewhoami: default Initialized
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_uri_segment: SEGMENT_PATH
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_useragent: Firefox 3.6
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_useragent: Mac OS X
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_init_session: Not Implemented
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_dbopen: mysql_pconnect
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|app: admin Initialized
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|app: admin Function: dashboard
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|get_css / file: $file
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|get_css / file: $file
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|get_css / file: $file
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|app: admin Terminated
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|_dbclose CLOSED
20100317181239|127.0.0.1|INFO|2010-03-17 18:12:39|pasteboard.Complete (0.176 seconds)
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181239|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:39|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181239|127.0.0.1|INCLUDE|2010-03-17 18:12:39|helper: diagnostics_helper, format_diagnostics
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|pasteboard.Started
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: useragents-config
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: dates-config
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: fopen-config
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: stopwords-config
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-database
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-useragent
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-hooks
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-sessions
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-cache
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-scaffolding
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-errors
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-uri
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|library: pb-logs
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_set_timezone: US/Pacific
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_sitewhoami: default Initialized
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_uri_segment: SEGMENT_PATH
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_useragent: Firefox 3.6
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_useragent: Mac OS X
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_init_session: Not Implemented
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_dbopen: mysql_pconnect
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|app: admin Initialized
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|app: admin Function: dashboard
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|get_css / file: $file
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|get_css / file: $file
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|get_css / file: $file
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|app: admin Terminated
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|_dbclose CLOSED
20100317181245|127.0.0.1|INFO|2010-03-17 18:12:45|pasteboard.Complete (0.61 seconds)
20100317181245|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:45|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181245|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181245|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181245|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181245|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181245|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181245|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181245|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181245|127.0.0.1|INCLUDE|2010-03-17 18:12:45|helper: diagnostics_helper, format_diagnostics
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|pasteboard.Started
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: useragents-config
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: dates-config
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: fopen-config
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: stopwords-config
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-database
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-useragent
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-hooks
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-sessions
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-cache
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-scaffolding
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-errors
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-uri
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-logs
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_set_timezone: US/Pacific
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_sitewhoami: default Initialized
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_uri_segment: SEGMENT_PATH
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_useragent: Firefox 3.6
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_useragent: Mac OS X
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_init_session: Not Implemented
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_dbopen: mysql_pconnect
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|app: admin Initialized
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|app: admin Function: dashboard
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|get_css / file: $file
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|get_css / file: $file
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|get_css / file: $file
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|app: admin Terminated
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_dbclose CLOSED
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|pasteboard.Complete (0.309 seconds)
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|helper: diagnostics_helper, format_diagnostics
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|pasteboard.Started
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: useragents-config
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: dates-config
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: fopen-config
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: stopwords-config
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-database
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-useragent
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-hooks
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-sessions
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-cache
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-scaffolding
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-errors
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-uri
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|library: pb-logs
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_set_timezone: US/Pacific
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_sitewhoami: default Initialized
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_uri_segment: SEGMENT_PATH
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_useragent: Firefox 3.6
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_useragent: Mac OS X
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_init_session: Not Implemented
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_dbopen: mysql_pconnect
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|app: admin Initialized
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|app: admin Function: dashboard
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|get_css / file: $file
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|get_css / file: $file
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|get_css / file: $file
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|app: admin Terminated
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|_dbclose CLOSED
20100317181246|127.0.0.1|INFO|2010-03-17 18:12:46|pasteboard.Complete (0.838 seconds)
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181246|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181246|127.0.0.1|INCLUDE|2010-03-17 18:12:46|helper: diagnostics_helper, format_diagnostics
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|pasteboard.Started
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: useragents-config
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: dates-config
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: fopen-config
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: stopwords-config
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-database
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-useragent
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-hooks
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-sessions
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-cache
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-scaffolding
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-errors
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-uri
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|library: pb-logs
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_set_timezone: US/Pacific
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_sitewhoami: default Initialized
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_uri_segment: SEGMENT_PATH
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_useragent: Firefox 3.6
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_useragent: Mac OS X
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_init_session: Not Implemented
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_dbopen: mysql_pconnect
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|app: admin Initialized
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|app: admin Function: logout
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|get_css / file: $file
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|get_css / file: $file
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|get_css / file: $file
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|get_js / file: $file
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|app: admin Terminated
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|_dbclose CLOSED
20100317181248|127.0.0.1|INFO|2010-03-17 18:12:48|pasteboard.Complete (0.872 seconds)
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181248|127.0.0.1|__ERROR_WARNING|2010-03-17 18:12:48|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317181248|127.0.0.1|INCLUDE|2010-03-17 18:12:48|helper: diagnostics_helper, format_diagnostics
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|pasteboard.Started
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: useragents-config
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: dates-config
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: fopen-config
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: stopwords-config
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-database
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-useragent
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-hooks
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-sessions
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-cache
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-scaffolding
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-errors
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-uri
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-logs
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_set_timezone: US/Pacific
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_sitewhoami: default Initialized
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_uri_segment: SEGMENT_PATH
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_useragent: Firefox 3.6
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_useragent: Mac OS X
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_init_session: Not Implemented
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_dbopen: mysql_pconnect
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|app: admin Initialized
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|Function Does Not Exist: -> Line 374-> function: _check_func-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|pasteboard.Started
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: useragents-config
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: dates-config
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: fopen-config
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: stopwords-config
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-database
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-useragent
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-hooks
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-sessions
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-cache
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-scaffolding
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-errors
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-uri
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|library: pb-logs
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_set_timezone: US/Pacific
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_sitewhoami: default Initialized
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_uri_segment: SEGMENT_PATH
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_useragent: Firefox 3.6
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_useragent: Mac OS X
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_init_session: Not Implemented
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_dbopen: mysql_pconnect
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|app: admin Initialized
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|app: admin Function: login
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|get_css / file: $file
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|get_css / file: $file
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|get_css / file: $file
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|get_js / file: $file
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|app: admin Terminated
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|_dbclose CLOSED
20100317182017|127.0.0.1|INFO|2010-03-17 18:20:17|pasteboard.Complete (0.72 seconds)
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317182017|127.0.0.1|__ERROR_WARNING|2010-03-17 18:20:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317182017|127.0.0.1|INCLUDE|2010-03-17 18:20:17|helper: diagnostics_helper, format_diagnostics
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|pasteboard.Started
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: useragents-config
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: dates-config
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: fopen-config
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: stopwords-config
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-database
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-useragent
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-hooks
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-sessions
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-cache
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-scaffolding
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-errors
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-uri
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|library: pb-logs
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_set_timezone: US/Pacific
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_sitewhoami: default Initialized
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_uri_segment: SEGMENT_PATH
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_useragent: Firefox 3.6
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_useragent: Mac OS X
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_init_session: Not Implemented
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_dbopen: mysql_pconnect
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|app: admin Initialized
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|app: admin Function: login
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|get_css / file: $file
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|get_css / file: $file
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|get_css / file: $file
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|get_js / file: $file
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|app: admin Terminated
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|_dbclose CLOSED
20100317182834|127.0.0.1|INFO|2010-03-17 18:28:34|pasteboard.Complete (0.791 seconds)
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317182834|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:34|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317182834|127.0.0.1|INCLUDE|2010-03-17 18:28:34|helper: diagnostics_helper, format_diagnostics
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|pasteboard.Started
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: useragents-config
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: dates-config
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: fopen-config
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: stopwords-config
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-database
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-useragent
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-hooks
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-sessions
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-cache
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-scaffolding
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-errors
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-uri
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|library: pb-logs
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_set_timezone: US/Pacific
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_sitewhoami: default Initialized
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_uri_segment: SEGMENT_PATH
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_useragent: Firefox 3.6
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_useragent: Mac OS X
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_init_session: Not Implemented
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_dbopen: mysql_pconnect
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|app: admin Initialized
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|app: admin Function: login
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|get_css / file: $file
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|get_css / file: $file
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|get_css / file: $file
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|get_js / file: $file
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|app: admin Terminated
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|_dbclose CLOSED
20100317182835|127.0.0.1|INFO|2010-03-17 18:28:35|pasteboard.Complete (0.913 seconds)
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317182835|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:35|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317182835|127.0.0.1|INCLUDE|2010-03-17 18:28:35|helper: diagnostics_helper, format_diagnostics
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|pasteboard.Started
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: useragents-config
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: dates-config
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: fopen-config
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: stopwords-config
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-database
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-useragent
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-hooks
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-sessions
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-cache
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-scaffolding
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-errors
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-uri
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|library: pb-logs
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_set_timezone: US/Pacific
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_sitewhoami: default Initialized
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_useragent: Firefox 3.6
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_useragent: Mac OS X
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_init_session: Not Implemented
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_dbopen: mysql_pconnect
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|app: admin Initialized
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|app: admin Function: login
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|get_css / file: $file
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|get_css / file: $file
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|get_css / file: $file
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|get_js / file: $file
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|app: admin Terminated
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|_dbclose CLOSED
20100317182837|127.0.0.1|INFO|2010-03-17 18:28:37|pasteboard.Complete (0.489 seconds)
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317182837|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317182837|127.0.0.1|INCLUDE|2010-03-17 18:28:37|helper: diagnostics_helper, format_diagnostics
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|pasteboard.Started
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: useragents-config
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: dates-config
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: fopen-config
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: stopwords-config
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-database
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-useragent
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-hooks
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-sessions
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-cache
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-scaffolding
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-errors
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-uri
20100317182843|127.0.0.1|INCLUDE|2010-03-17 18:28:43|library: pb-logs
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|_set_timezone: US/Pacific
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|_sitewhoami: default Initialized
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|_uri_segment: SEGMENT_PATH
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|_useragent: Firefox 3.6
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|_useragent: Mac OS X
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|_init_session: Not Implemented
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|_dbopen: mysql_pconnect
20100317182843|127.0.0.1|INFO|2010-03-17 18:28:43|app: admin Initialized
20100317182843|127.0.0.1|__ERROR_WARNING|2010-03-17 18:28:43|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317182843|127.0.0.1|SQL|2010-03-17 18:28:43|SQL_logged from _resetpswd, 80
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|pasteboard.Started
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: useragents-config
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: dates-config
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: fopen-config
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: stopwords-config
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-database
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-useragent
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-hooks
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-sessions
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-cache
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-scaffolding
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-errors
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-uri
20100317182935|127.0.0.1|INCLUDE|2010-03-17 18:29:35|library: pb-logs
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|_set_timezone: US/Pacific
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|_sitewhoami: default Initialized
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|_uri_segment: SEGMENT_PATH
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|_useragent: Firefox 3.6
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|_useragent: Mac OS X
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|_init_session: Not Implemented
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|_dbopen: mysql_pconnect
20100317182935|127.0.0.1|INFO|2010-03-17 18:29:35|app: admin Initialized
20100317182935|127.0.0.1|__ERROR_WARNING|2010-03-17 18:29:35|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317182935|127.0.0.1|SQL|2010-03-17 18:29:35|SQL_logged from _resetpswd, 79
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|pasteboard.Started
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: useragents-config
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: dates-config
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: fopen-config
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: stopwords-config
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-database
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-useragent
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-hooks
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-sessions
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-cache
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-scaffolding
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-errors
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-uri
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-logs
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_set_timezone: US/Pacific
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_sitewhoami: default Initialized
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_uri_segment: SEGMENT_PATH
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_useragent: Firefox 3.6
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_useragent: Mac OS X
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_init_session: Not Implemented
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_dbopen: mysql_pconnect
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|app: admin Initialized
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183033|127.0.0.1|SQL|2010-03-17 18:30:33|SQL_logged from _resetpswd, 79
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 330]
20100317183033|127.0.0.1|SQL|2010-03-17 18:30:33|SQL_logged from _resetpswd, 95
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|pasteboard.Started
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: useragents-config
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: dates-config
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: fopen-config
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: stopwords-config
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-database
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-useragent
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-hooks
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-sessions
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-cache
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-scaffolding
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-errors
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-uri
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|library: pb-logs
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_set_timezone: US/Pacific
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_sitewhoami: default Initialized
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_useragent: Firefox 3.6
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_useragent: Mac OS X
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_init_session: Not Implemented
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_dbopen: mysql_pconnect
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|app: admin Initialized
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|app: admin Function: login
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|get_css / file: $file
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|get_css / file: $file
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|get_css / file: $file
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|get_js / file: $file
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|app: admin Terminated
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|_dbclose CLOSED
20100317183033|127.0.0.1|INFO|2010-03-17 18:30:33|pasteboard.Complete (0.557 seconds)
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183033|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183033|127.0.0.1|INCLUDE|2010-03-17 18:30:33|helper: diagnostics_helper, format_diagnostics
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|pasteboard.Started
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: useragents-config
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: dates-config
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: fopen-config
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: stopwords-config
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-database
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-useragent
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-hooks
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-sessions
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-cache
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-scaffolding
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-errors
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-uri
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|library: pb-logs
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_set_timezone: US/Pacific
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_sitewhoami: default Initialized
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_uri_segment: SEGMENT_PATH
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_useragent: Firefox 3.6
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_useragent: Mac OS X
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_init_session: Not Implemented
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_dbopen: mysql_pconnect
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|app: admin Initialized
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|app: admin Function: login
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|get_css / file: $file
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|get_css / file: $file
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|get_css / file: $file
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|get_js / file: $file
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|app: admin Terminated
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|_dbclose CLOSED
20100317183046|127.0.0.1|INFO|2010-03-17 18:30:46|pasteboard.Complete (0.23 seconds)
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183046|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183046|127.0.0.1|INCLUDE|2010-03-17 18:30:46|helper: diagnostics_helper, format_diagnostics
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|pasteboard.Started
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: useragents-config
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: dates-config
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: fopen-config
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: stopwords-config
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-database
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-useragent
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-hooks
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-sessions
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-cache
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-scaffolding
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-errors
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-uri
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|library: pb-logs
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_set_timezone: US/Pacific
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_sitewhoami: default Initialized
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_useragent: Firefox 3.6
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_useragent: Mac OS X
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_init_session: Not Implemented
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_dbopen: mysql_pconnect
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|app: admin Initialized
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|app: admin Function: login
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|get_css / file: $file
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|get_css / file: $file
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|get_css / file: $file
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|get_js / file: $file
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|app: admin Terminated
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|_dbclose CLOSED
20100317183048|127.0.0.1|INFO|2010-03-17 18:30:48|pasteboard.Complete (0.485 seconds)
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183048|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:48|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183048|127.0.0.1|INCLUDE|2010-03-17 18:30:48|helper: diagnostics_helper, format_diagnostics
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|pasteboard.Started
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: useragents-config
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: dates-config
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: fopen-config
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: stopwords-config
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-database
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-useragent
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-hooks
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-sessions
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-cache
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-scaffolding
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-errors
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-uri
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-logs
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_set_timezone: US/Pacific
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_sitewhoami: default Initialized
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_uri_segment: SEGMENT_PATH
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_useragent: Firefox 3.6
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_useragent: Mac OS X
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_init_session: Not Implemented
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_dbopen: mysql_pconnect
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|app: admin Initialized
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183055|127.0.0.1|SQL|2010-03-17 18:30:55|SQL_logged from _resetpswd, 79
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 330]
20100317183055|127.0.0.1|SQL|2010-03-17 18:30:55|SQL_logged from _resetpswd, 95
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|pasteboard.Started
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: useragents-config
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: dates-config
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: fopen-config
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: stopwords-config
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-database
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-useragent
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-hooks
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-sessions
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-cache
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-scaffolding
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-errors
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-uri
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|library: pb-logs
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_set_timezone: US/Pacific
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_sitewhoami: default Initialized
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_useragent: Firefox 3.6
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_useragent: Mac OS X
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_init_session: Not Implemented
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_dbopen: mysql_pconnect
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|app: admin Initialized
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|app: admin Function: login
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|get_css / file: $file
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|get_css / file: $file
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|get_css / file: $file
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|get_js / file: $file
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|app: admin Terminated
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|_dbclose CLOSED
20100317183055|127.0.0.1|INFO|2010-03-17 18:30:55|pasteboard.Complete (0.46 seconds)
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183055|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183055|127.0.0.1|INCLUDE|2010-03-17 18:30:55|helper: diagnostics_helper, format_diagnostics
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|pasteboard.Started
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: useragents-config
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: dates-config
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: fopen-config
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: stopwords-config
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-database
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-useragent
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-hooks
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-sessions
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-cache
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-scaffolding
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-errors
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-uri
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|library: pb-logs
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_set_timezone: US/Pacific
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_sitewhoami: default Initialized
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_uri_segment: SEGMENT_PATH
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_useragent: Firefox 3.6
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_useragent: Mac OS X
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_init_session: Not Implemented
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_dbopen: mysql_pconnect
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|app: admin Initialized
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|app: admin Function: login
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|get_css / file: $file
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|get_css / file: $file
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|get_css / file: $file
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|get_js / file: $file
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|app: admin Terminated
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|_dbclose CLOSED
20100317183057|127.0.0.1|INFO|2010-03-17 18:30:57|pasteboard.Complete (0.93 seconds)
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183057|127.0.0.1|__ERROR_WARNING|2010-03-17 18:30:57|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183057|127.0.0.1|INCLUDE|2010-03-17 18:30:57|helper: diagnostics_helper, format_diagnostics
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|pasteboard.Started
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: useragents-config
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: dates-config
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: fopen-config
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: stopwords-config
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-database
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-useragent
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-hooks
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-sessions
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-cache
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-scaffolding
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-errors
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-uri
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|library: pb-logs
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_set_timezone: US/Pacific
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_sitewhoami: default Initialized
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_useragent: Firefox 3.6
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_useragent: Mac OS X
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_init_session: Not Implemented
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_dbopen: mysql_pconnect
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|app: admin Initialized
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|app: admin Function: login
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|get_css / file: $file
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|get_css / file: $file
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|get_css / file: $file
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|get_js / file: $file
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|app: admin Terminated
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|_dbclose CLOSED
20100317183133|127.0.0.1|INFO|2010-03-17 18:31:33|pasteboard.Complete (0.907 seconds)
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183133|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183133|127.0.0.1|INCLUDE|2010-03-17 18:31:33|helper: diagnostics_helper, format_diagnostics
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|pasteboard.Started
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: useragents-config
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: dates-config
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: fopen-config
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: stopwords-config
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-database
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-useragent
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-hooks
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-sessions
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-cache
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-scaffolding
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-errors
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-uri
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-logs
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_set_timezone: US/Pacific
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_sitewhoami: default Initialized
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_uri_segment: SEGMENT_PATH
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_useragent: Firefox 3.6
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_useragent: Mac OS X
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_init_session: Not Implemented
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_dbopen: mysql_pconnect
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|app: admin Initialized
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183138|127.0.0.1|SQL|2010-03-17 18:31:38|SQL_logged from _resetpswd, 79
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 330]
20100317183138|127.0.0.1|SQL|2010-03-17 18:31:38|SQL_logged from _resetpswd, 95
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|pasteboard.Started
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: useragents-config
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: dates-config
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: fopen-config
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: stopwords-config
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-database
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-useragent
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-hooks
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-sessions
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-cache
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-scaffolding
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-errors
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-uri
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|library: pb-logs
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_set_timezone: US/Pacific
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_sitewhoami: default Initialized
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_useragent: Firefox 3.6
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_useragent: Mac OS X
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_init_session: Not Implemented
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_dbopen: mysql_pconnect
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|app: admin Initialized
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|app: admin Function: login
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|get_css / file: $file
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|get_css / file: $file
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|get_css / file: $file
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|get_js / file: $file
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|app: admin Terminated
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|_dbclose CLOSED
20100317183138|127.0.0.1|INFO|2010-03-17 18:31:38|pasteboard.Complete (0.902 seconds)
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183138|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183138|127.0.0.1|INCLUDE|2010-03-17 18:31:38|helper: diagnostics_helper, format_diagnostics
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|pasteboard.Started
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: useragents-config
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: dates-config
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: fopen-config
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: stopwords-config
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-database
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-useragent
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-hooks
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-sessions
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-cache
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-scaffolding
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-errors
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-uri
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|library: pb-logs
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_set_timezone: US/Pacific
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_sitewhoami: default Initialized
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_uri_segment: SEGMENT_PATH
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_useragent: Firefox 3.6
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_useragent: Mac OS X
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_init_session: Not Implemented
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_dbopen: mysql_pconnect
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|app: admin Initialized
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|app: admin Function: login
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|get_css / file: $file
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|get_css / file: $file
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|get_css / file: $file
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|get_js / file: $file
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|app: admin Terminated
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|_dbclose CLOSED
20100317183149|127.0.0.1|INFO|2010-03-17 18:31:49|pasteboard.Complete (0.805 seconds)
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183149|127.0.0.1|__ERROR_WARNING|2010-03-17 18:31:49|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183149|127.0.0.1|INCLUDE|2010-03-17 18:31:49|helper: diagnostics_helper, format_diagnostics
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|pasteboard.Started
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: useragents-config
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: dates-config
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: fopen-config
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: stopwords-config
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-database
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-useragent
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-hooks
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-sessions
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-cache
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-scaffolding
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-errors
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-uri
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|library: pb-logs
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_set_timezone: US/Pacific
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_sitewhoami: default Initialized
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_useragent: Firefox 3.6
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_useragent: Mac OS X
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_init_session: Not Implemented
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_dbopen: mysql_pconnect
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|app: admin Initialized
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|app: admin Function: login
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|get_css / file: $file
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|get_css / file: $file
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|get_css / file: $file
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|get_js / file: $file
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|app: admin Terminated
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|_dbclose CLOSED
20100317183232|127.0.0.1|INFO|2010-03-17 18:32:32|pasteboard.Complete (0.364 seconds)
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183232|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183232|127.0.0.1|INCLUDE|2010-03-17 18:32:32|helper: diagnostics_helper, format_diagnostics
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|pasteboard.Started
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: useragents-config
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: dates-config
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: fopen-config
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: stopwords-config
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-database
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-useragent
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-hooks
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-sessions
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-cache
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-scaffolding
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-errors
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-uri
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|library: pb-logs
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_set_timezone: US/Pacific
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_sitewhoami: default Initialized
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_useragent: Firefox 3.6
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_useragent: Mac OS X
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_init_session: Not Implemented
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_dbopen: mysql_pconnect
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|app: admin Initialized
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|app: admin Function: login
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|get_css / file: $file
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|get_css / file: $file
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|get_css / file: $file
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|get_js / file: $file
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|app: admin Terminated
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|_dbclose CLOSED
20100317183233|127.0.0.1|INFO|2010-03-17 18:32:33|pasteboard.Complete (0.326 seconds)
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183233|127.0.0.1|__ERROR_WARNING|2010-03-17 18:32:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183233|127.0.0.1|INCLUDE|2010-03-17 18:32:33|helper: diagnostics_helper, format_diagnostics
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|pasteboard.Started
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: useragents-config
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: dates-config
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: fopen-config
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: stopwords-config
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-database
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-useragent
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-hooks
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-sessions
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-cache
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-scaffolding
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-errors
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-uri
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|library: pb-logs
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_set_timezone: US/Pacific
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_sitewhoami: default Initialized
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_useragent: Firefox 3.6
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_useragent: Mac OS X
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_init_session: Not Implemented
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_dbopen: mysql_pconnect
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|app: admin Initialized
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|app: admin Function: login
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|get_css / file: $file
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|get_css / file: $file
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|get_css / file: $file
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|get_js / file: $file
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|app: admin Terminated
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|_dbclose CLOSED
20100317183353|127.0.0.1|INFO|2010-03-17 18:33:53|pasteboard.Complete (0.128 seconds)
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183353|127.0.0.1|__ERROR_WARNING|2010-03-17 18:33:53|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183353|127.0.0.1|INCLUDE|2010-03-17 18:33:53|helper: diagnostics_helper, format_diagnostics
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|pasteboard.Started
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: useragents-config
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: dates-config
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: fopen-config
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: stopwords-config
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-database
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-useragent
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-hooks
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-sessions
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-cache
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-scaffolding
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-errors
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-uri
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|library: pb-logs
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_set_timezone: US/Pacific
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_sitewhoami: default Initialized
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_useragent: Firefox 3.6
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_useragent: Mac OS X
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_init_session: Not Implemented
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_dbopen: mysql_pconnect
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|app: admin Initialized
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|app: admin Function: login
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|get_css / file: $file
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|get_css / file: $file
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|get_css / file: $file
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|get_js / file: $file
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|app: admin Terminated
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|_dbclose CLOSED
20100317183415|127.0.0.1|INFO|2010-03-17 18:34:15|pasteboard.Complete (0.731 seconds)
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183415|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:15|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183415|127.0.0.1|INCLUDE|2010-03-17 18:34:15|helper: diagnostics_helper, format_diagnostics
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|pasteboard.Started
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: useragents-config
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: dates-config
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: fopen-config
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: stopwords-config
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-database
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-useragent
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-hooks
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-sessions
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-cache
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-scaffolding
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-errors
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-uri
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|library: pb-logs
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_set_timezone: US/Pacific
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_sitewhoami: default Initialized
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_useragent: Firefox 3.6
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_useragent: Mac OS X
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_init_session: Not Implemented
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_dbopen: mysql_pconnect
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|app: admin Initialized
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|app: admin Function: login
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|get_css / file: $file
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|get_css / file: $file
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|get_css / file: $file
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|get_js / file: $file
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|app: admin Terminated
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|_dbclose CLOSED
20100317183416|127.0.0.1|INFO|2010-03-17 18:34:16|pasteboard.Complete (0.97 seconds)
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183416|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:16|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183416|127.0.0.1|INCLUDE|2010-03-17 18:34:16|helper: diagnostics_helper, format_diagnostics
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|pasteboard.Started
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: useragents-config
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: dates-config
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: fopen-config
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: stopwords-config
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-database
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-useragent
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-hooks
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-sessions
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-cache
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-scaffolding
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-errors
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-uri
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|library: pb-logs
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_set_timezone: US/Pacific
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_sitewhoami: default Initialized
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_useragent: Firefox 3.6
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_useragent: Mac OS X
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_init_session: Not Implemented
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_dbopen: mysql_pconnect
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|app: admin Initialized
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|app: admin Function: login
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|get_css / file: $file
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|get_css / file: $file
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|get_css / file: $file
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|get_js / file: $file
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|app: admin Terminated
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|_dbclose CLOSED
20100317183417|127.0.0.1|INFO|2010-03-17 18:34:17|pasteboard.Complete (0.758 seconds)
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183417|127.0.0.1|__ERROR_WARNING|2010-03-17 18:34:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183417|127.0.0.1|INCLUDE|2010-03-17 18:34:17|helper: diagnostics_helper, format_diagnostics
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|pasteboard.Started
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: useragents-config
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: dates-config
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: fopen-config
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: stopwords-config
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-database
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-useragent
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-hooks
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-sessions
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-cache
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-scaffolding
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-errors
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-uri
20100317183541|127.0.0.1|INCLUDE|2010-03-17 18:35:41|library: pb-logs
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|_set_timezone: US/Pacific
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|_sitewhoami: default Initialized
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|_useragent: Firefox 3.6
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|_useragent: Mac OS X
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|_init_session: Not Implemented
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|_dbopen: mysql_pconnect
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|app: admin Initialized
20100317183541|127.0.0.1|INFO|2010-03-17 18:35:41|app: admin Function: login
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|pasteboard.Started
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: useragents-config
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: dates-config
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: fopen-config
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: stopwords-config
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-database
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-useragent
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-hooks
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-sessions
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-cache
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-scaffolding
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-errors
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-uri
20100317183551|127.0.0.1|INCLUDE|2010-03-17 18:35:51|library: pb-logs
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|_set_timezone: US/Pacific
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|_sitewhoami: default Initialized
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|_useragent: Firefox 3.6
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|_useragent: Mac OS X
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|_init_session: Not Implemented
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|_dbopen: mysql_pconnect
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|app: admin Initialized
20100317183551|127.0.0.1|INFO|2010-03-17 18:35:51|app: admin Function: login
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|pasteboard.Started
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: useragents-config
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: dates-config
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: fopen-config
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: stopwords-config
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-database
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-useragent
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-hooks
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-sessions
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-cache
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-scaffolding
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-errors
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-uri
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-logs
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_set_timezone: US/Pacific
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_sitewhoami: default Initialized
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_useragent: Firefox 3.6
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_useragent: Mac OS X
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_init_session: Not Implemented
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_dbopen: mysql_pconnect
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|app: admin Initialized
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|app: admin Function: login
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|pasteboard.Started
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: useragents-config
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: dates-config
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: fopen-config
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: stopwords-config
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-database
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-useragent
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-hooks
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-sessions
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-cache
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-scaffolding
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-errors
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-uri
20100317183552|127.0.0.1|INCLUDE|2010-03-17 18:35:52|library: pb-logs
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_set_timezone: US/Pacific
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_sitewhoami: default Initialized
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_useragent: Firefox 3.6
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_useragent: Mac OS X
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_init_session: Not Implemented
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|_dbopen: mysql_pconnect
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|app: admin Initialized
20100317183552|127.0.0.1|INFO|2010-03-17 18:35:52|app: admin Function: login
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|pasteboard.Started
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: useragents-config
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: dates-config
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: fopen-config
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: stopwords-config
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-database
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-useragent
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-hooks
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-sessions
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-cache
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-scaffolding
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-errors
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-uri
20100317183614|127.0.0.1|INCLUDE|2010-03-17 18:36:14|library: pb-logs
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|_set_timezone: US/Pacific
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|_sitewhoami: default Initialized
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|_useragent: Firefox 3.6
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|_useragent: Mac OS X
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|_init_session: Not Implemented
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|_dbopen: mysql_pconnect
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|app: admin Initialized
20100317183614|127.0.0.1|INFO|2010-03-17 18:36:14|app: admin Function: login
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|pasteboard.Started
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: useragents-config
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: dates-config
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: fopen-config
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: stopwords-config
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-database
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-useragent
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-hooks
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-sessions
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-cache
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-scaffolding
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-errors
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-uri
20100317183615|127.0.0.1|INCLUDE|2010-03-17 18:36:15|library: pb-logs
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|_set_timezone: US/Pacific
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|_sitewhoami: default Initialized
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|_useragent: Firefox 3.6
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|_useragent: Mac OS X
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|_init_session: Not Implemented
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|_dbopen: mysql_pconnect
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|app: admin Initialized
20100317183615|127.0.0.1|INFO|2010-03-17 18:36:15|app: admin Function: login
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|pasteboard.Started
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: useragents-config
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: dates-config
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: fopen-config
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: stopwords-config
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-database
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-useragent
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-hooks
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-sessions
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-cache
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-scaffolding
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-errors
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-uri
20100317183655|127.0.0.1|INCLUDE|2010-03-17 18:36:55|library: pb-logs
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|_set_timezone: US/Pacific
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|_sitewhoami: default Initialized
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|_useragent: Firefox 3.6
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|_useragent: Mac OS X
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|_init_session: Not Implemented
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|_dbopen: mysql_pconnect
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|app: admin Initialized
20100317183655|127.0.0.1|INFO|2010-03-17 18:36:55|app: admin Function: login
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|pasteboard.Started
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: useragents-config
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: dates-config
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: fopen-config
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: stopwords-config
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-database
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-useragent
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-hooks
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-sessions
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-cache
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-scaffolding
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-errors
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-uri
20100317183656|127.0.0.1|INCLUDE|2010-03-17 18:36:56|library: pb-logs
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|_set_timezone: US/Pacific
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|_sitewhoami: default Initialized
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|_useragent: Firefox 3.6
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|_useragent: Mac OS X
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|_init_session: Not Implemented
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|_dbopen: mysql_pconnect
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|app: admin Initialized
20100317183656|127.0.0.1|INFO|2010-03-17 18:36:56|app: admin Function: login
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|pasteboard.Started
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: useragents-config
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: dates-config
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: fopen-config
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: stopwords-config
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-database
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-useragent
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-hooks
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-sessions
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-cache
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-scaffolding
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-errors
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-uri
20100317183702|127.0.0.1|INCLUDE|2010-03-17 18:37:02|library: pb-logs
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|_set_timezone: US/Pacific
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|_sitewhoami: default Initialized
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|_useragent: Firefox 3.6
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|_useragent: Mac OS X
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|_init_session: Not Implemented
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|_dbopen: mysql_pconnect
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|app: admin Initialized
20100317183702|127.0.0.1|INFO|2010-03-17 18:37:02|app: admin Function: login
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|pasteboard.Started
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: useragents-config
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: dates-config
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: fopen-config
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: stopwords-config
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-database
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-useragent
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-hooks
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-sessions
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-cache
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-scaffolding
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-errors
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-uri
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|library: pb-logs
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_set_timezone: US/Pacific
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_sitewhoami: default Initialized
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_useragent: Firefox 3.6
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_useragent: Mac OS X
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_init_session: Not Implemented
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_dbopen: mysql_pconnect
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|app: admin Initialized
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|app: admin Function: login
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|get_css / file: $file
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|get_css / file: $file
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|get_css / file: $file
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|get_js / file: $file
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|app: admin Terminated
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|_dbclose CLOSED
20100317183737|127.0.0.1|INFO|2010-03-17 18:37:37|pasteboard.Complete (0.722 seconds)
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183737|127.0.0.1|INCLUDE|2010-03-17 18:37:37|helper: diagnostics_helper, format_diagnostics
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|pasteboard.Started
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: useragents-config
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: dates-config
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: fopen-config
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: stopwords-config
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-database
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-useragent
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-hooks
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-sessions
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-cache
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-scaffolding
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-errors
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-uri
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|library: pb-logs
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_set_timezone: US/Pacific
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_sitewhoami: default Initialized
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_useragent: Firefox 3.6
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_useragent: Mac OS X
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_init_session: Not Implemented
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_dbopen: mysql_pconnect
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|app: admin Initialized
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|app: admin Function: login
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|get_css / file: $file
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|get_css / file: $file
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|get_css / file: $file
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|get_js / file: $file
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|app: admin Terminated
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|_dbclose CLOSED
20100317183745|127.0.0.1|INFO|2010-03-17 18:37:45|pasteboard.Complete (0.44 seconds)
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183745|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183745|127.0.0.1|INCLUDE|2010-03-17 18:37:45|helper: diagnostics_helper, format_diagnostics
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|pasteboard.Started
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: useragents-config
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: dates-config
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: fopen-config
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: stopwords-config
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-database
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-useragent
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-hooks
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-sessions
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-cache
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-scaffolding
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-errors
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-uri
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|library: pb-logs
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_set_timezone: US/Pacific
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_sitewhoami: default Initialized
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_uri_segment: SEGMENT_PATH
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_useragent: Firefox 3.6
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_useragent: Mac OS X
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_init_session: Not Implemented
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_dbopen: mysql_pconnect
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|app: admin Initialized
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|app: admin Function: login
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|get_css / file: $file
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|get_css / file: $file
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|get_css / file: $file
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|get_js / file: $file
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|app: admin Terminated
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|_dbclose CLOSED
20100317183751|127.0.0.1|INFO|2010-03-17 18:37:51|pasteboard.Complete (0.266 seconds)
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183751|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183751|127.0.0.1|INCLUDE|2010-03-17 18:37:51|helper: diagnostics_helper, format_diagnostics
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|pasteboard.Started
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: useragents-config
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: dates-config
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: fopen-config
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: stopwords-config
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-database
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-useragent
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-hooks
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-sessions
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-cache
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-scaffolding
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-errors
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-uri
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|library: pb-logs
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_set_timezone: US/Pacific
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_sitewhoami: default Initialized
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_useragent: Firefox 3.6
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_useragent: Mac OS X
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_init_session: Not Implemented
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_dbopen: mysql_pconnect
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|app: admin Initialized
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|app: admin Function: login
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|get_css / file: $file
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|get_css / file: $file
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|get_css / file: $file
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|get_js / file: $file
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|app: admin Terminated
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|_dbclose CLOSED
20100317183752|127.0.0.1|INFO|2010-03-17 18:37:52|pasteboard.Complete (1.009 seconds)
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183752|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:52|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183752|127.0.0.1|INCLUDE|2010-03-17 18:37:52|helper: diagnostics_helper, format_diagnostics
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|pasteboard.Started
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: useragents-config
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: dates-config
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: fopen-config
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: stopwords-config
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-database
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-useragent
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-hooks
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-sessions
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-cache
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-scaffolding
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-errors
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-uri
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|library: pb-logs
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_set_timezone: US/Pacific
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_sitewhoami: default Initialized
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_uri_segment: SEGMENT_PATH
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_useragent: Firefox 3.6
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_useragent: Mac OS X
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_init_session: Not Implemented
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_dbopen: mysql_pconnect
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|app: admin Initialized
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|app: admin Function: login
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|get_css / file: $file
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|get_css / file: $file
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|get_css / file: $file
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|get_js / file: $file
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|app: admin Terminated
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|_dbclose CLOSED
20100317183755|127.0.0.1|INFO|2010-03-17 18:37:55|pasteboard.Complete (0.199 seconds)
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183755|127.0.0.1|__ERROR_WARNING|2010-03-17 18:37:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183755|127.0.0.1|INCLUDE|2010-03-17 18:37:55|helper: diagnostics_helper, format_diagnostics
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|pasteboard.Started
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: useragents-config
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: dates-config
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: fopen-config
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: stopwords-config
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-database
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-useragent
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-hooks
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-sessions
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-cache
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-scaffolding
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-errors
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-uri
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|library: pb-logs
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_set_timezone: US/Pacific
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_sitewhoami: default Initialized
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_uri_segment: SEGMENT_PATH
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_useragent: Firefox 3.6
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_useragent: Mac OS X
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_init_session: Not Implemented
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_dbopen: mysql_pconnect
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|app: admin Initialized
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|app: admin Function: login
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|get_css / file: $file
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|get_css / file: $file
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|get_css / file: $file
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|get_js / file: $file
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|app: admin Terminated
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|_dbclose CLOSED
20100317183824|127.0.0.1|INFO|2010-03-17 18:38:24|pasteboard.Complete (1.025 seconds)
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183824|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183824|127.0.0.1|INCLUDE|2010-03-17 18:38:24|helper: diagnostics_helper, format_diagnostics
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|pasteboard.Started
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: useragents-config
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: dates-config
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: fopen-config
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: stopwords-config
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-database
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-useragent
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-hooks
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-sessions
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-cache
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-scaffolding
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-errors
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-uri
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|library: pb-logs
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_set_timezone: US/Pacific
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_sitewhoami: default Initialized
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_uri_segment: SEGMENT_PATH
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_useragent: Firefox 3.6
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_useragent: Mac OS X
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_init_session: Not Implemented
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_dbopen: mysql_pconnect
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|app: admin Initialized
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|app: admin Function: login
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|get_css / file: $file
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|get_css / file: $file
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|get_css / file: $file
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|get_js / file: $file
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|app: admin Terminated
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|_dbclose CLOSED
20100317183825|127.0.0.1|INFO|2010-03-17 18:38:25|pasteboard.Complete (0.99 seconds)
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183825|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:25|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183825|127.0.0.1|INCLUDE|2010-03-17 18:38:25|helper: diagnostics_helper, format_diagnostics
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|pasteboard.Started
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: useragents-config
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: dates-config
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: fopen-config
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: stopwords-config
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-database
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-useragent
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-hooks
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-sessions
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-cache
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-scaffolding
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-errors
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-uri
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|library: pb-logs
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_set_timezone: US/Pacific
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_sitewhoami: default Initialized
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_uri_segment: SEGMENT_PATH
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_useragent: Firefox 3.6
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_useragent: Mac OS X
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_init_session: Not Implemented
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_dbopen: mysql_pconnect
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|app: admin Initialized
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|app: admin Function: login
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|get_css / file: $file
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|get_css / file: $file
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|get_css / file: $file
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|get_js / file: $file
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|app: admin Terminated
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|_dbclose CLOSED
20100317183826|127.0.0.1|INFO|2010-03-17 18:38:26|pasteboard.Complete (0.587 seconds)
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183826|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:26|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183826|127.0.0.1|INCLUDE|2010-03-17 18:38:26|helper: diagnostics_helper, format_diagnostics
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|pasteboard.Started
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: useragents-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: dates-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: fopen-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: stopwords-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-database
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-useragent
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-hooks
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-sessions
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-cache
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-scaffolding
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-errors
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-uri
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-logs
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_set_timezone: US/Pacific
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_sitewhoami: default Initialized
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_uri_segment: SEGMENT_PATH
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_useragent: Firefox 3.6
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_useragent: Mac OS X
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_init_session: Not Implemented
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_dbopen: mysql_pconnect
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Initialized
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Function: login
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_js / file: $file
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Terminated
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_dbclose CLOSED
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|pasteboard.Complete (0.215 seconds)
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|helper: diagnostics_helper, format_diagnostics
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|pasteboard.Started
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: useragents-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: dates-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: fopen-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: stopwords-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-database
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-useragent
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-hooks
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-sessions
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-cache
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-scaffolding
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-errors
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-uri
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-logs
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_set_timezone: US/Pacific
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_sitewhoami: default Initialized
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_uri_segment: SEGMENT_PATH
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_useragent: Firefox 3.6
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_useragent: Mac OS X
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_init_session: Not Implemented
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_dbopen: mysql_pconnect
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Initialized
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Function: login
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_js / file: $file
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Terminated
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_dbclose CLOSED
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|pasteboard.Complete (0.655 seconds)
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|helper: diagnostics_helper, format_diagnostics
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|pasteboard.Started
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: useragents-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: dates-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: fopen-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: stopwords-config
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-database
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-useragent
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-hooks
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-sessions
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-cache
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-scaffolding
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-errors
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-uri
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|library: pb-logs
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_set_timezone: US/Pacific
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_sitewhoami: default Initialized
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_uri_segment: SEGMENT_PATH
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_useragent: Firefox 3.6
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_useragent: Mac OS X
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_init_session: Not Implemented
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_dbopen: mysql_pconnect
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Initialized
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Function: login
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_css / file: $file
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|get_js / file: $file
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|app: admin Terminated
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|_dbclose CLOSED
20100317183827|127.0.0.1|INFO|2010-03-17 18:38:27|pasteboard.Complete (0.884 seconds)
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183827|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183827|127.0.0.1|INCLUDE|2010-03-17 18:38:27|helper: diagnostics_helper, format_diagnostics
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|pasteboard.Started
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: useragents-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: dates-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: fopen-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: stopwords-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-database
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-useragent
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-hooks
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-sessions
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-cache
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-scaffolding
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-errors
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-uri
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-logs
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_set_timezone: US/Pacific
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_sitewhoami: default Initialized
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_uri_segment: SEGMENT_PATH
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_useragent: Firefox 3.6
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_useragent: Mac OS X
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_init_session: Not Implemented
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_dbopen: mysql_pconnect
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Initialized
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Function: login
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_js / file: $file
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Terminated
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_dbclose CLOSED
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|pasteboard.Complete (0.054 seconds)
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|helper: diagnostics_helper, format_diagnostics
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|pasteboard.Started
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: useragents-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: dates-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: fopen-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: stopwords-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-database
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-useragent
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-hooks
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-sessions
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-cache
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-scaffolding
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-errors
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-uri
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-logs
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_set_timezone: US/Pacific
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_sitewhoami: default Initialized
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_uri_segment: SEGMENT_PATH
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_useragent: Firefox 3.6
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_useragent: Mac OS X
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_init_session: Not Implemented
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_dbopen: mysql_pconnect
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Initialized
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Function: login
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_js / file: $file
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Terminated
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_dbclose CLOSED
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|pasteboard.Complete (0.401 seconds)
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|helper: diagnostics_helper, format_diagnostics
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|pasteboard.Started
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: useragents-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: dates-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: fopen-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: stopwords-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-database
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-useragent
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-hooks
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-sessions
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-cache
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-scaffolding
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-errors
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-uri
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-logs
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_set_timezone: US/Pacific
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_sitewhoami: default Initialized
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_uri_segment: SEGMENT_PATH
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_useragent: Firefox 3.6
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_useragent: Mac OS X
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_init_session: Not Implemented
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_dbopen: mysql_pconnect
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Initialized
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Function: login
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_js / file: $file
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Terminated
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_dbclose CLOSED
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|pasteboard.Complete (0.577 seconds)
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|helper: diagnostics_helper, format_diagnostics
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|pasteboard.Started
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: useragents-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: dates-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: fopen-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: stopwords-config
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-database
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-useragent
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-hooks
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-sessions
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-cache
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-scaffolding
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-errors
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-uri
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|library: pb-logs
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_set_timezone: US/Pacific
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_sitewhoami: default Initialized
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_uri_segment: SEGMENT_PATH
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_useragent: Firefox 3.6
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_useragent: Mac OS X
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_init_session: Not Implemented
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_dbopen: mysql_pconnect
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Initialized
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Function: login
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_css / file: $file
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|get_js / file: $file
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|app: admin Terminated
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|_dbclose CLOSED
20100317183828|127.0.0.1|INFO|2010-03-17 18:38:28|pasteboard.Complete (0.8 seconds)
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183828|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183828|127.0.0.1|INCLUDE|2010-03-17 18:38:28|helper: diagnostics_helper, format_diagnostics
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|pasteboard.Started
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: useragents-config
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: dates-config
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: fopen-config
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: stopwords-config
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-database
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-useragent
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-hooks
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-sessions
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-cache
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-scaffolding
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-errors
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-uri
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|library: pb-logs
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_set_timezone: US/Pacific
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_sitewhoami: default Initialized
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_useragent: Firefox 3.6
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_useragent: Mac OS X
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_init_session: Not Implemented
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_dbopen: mysql_pconnect
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|app: admin Initialized
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|app: admin Function: login
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|get_css / file: $file
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|get_css / file: $file
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|get_css / file: $file
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|get_js / file: $file
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|app: admin Terminated
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|_dbclose CLOSED
20100317183833|127.0.0.1|INFO|2010-03-17 18:38:33|pasteboard.Complete (0.12 seconds)
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183833|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:33|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183833|127.0.0.1|INCLUDE|2010-03-17 18:38:33|helper: diagnostics_helper, format_diagnostics
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|pasteboard.Started
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: useragents-config
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: dates-config
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: fopen-config
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: stopwords-config
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-database
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-useragent
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-hooks
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-sessions
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-cache
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-scaffolding
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-errors
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-uri
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-logs
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_set_timezone: US/Pacific
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_sitewhoami: default Initialized
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_uri_segment: SEGMENT_PATH
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_useragent: Firefox 3.6
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_useragent: Mac OS X
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_init_session: Not Implemented
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_dbopen: mysql_pconnect
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|app: admin Initialized
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183838|127.0.0.1|SQL|2010-03-17 18:38:38|SQL_logged from _resetpswd, 79
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 330]
20100317183838|127.0.0.1|SQL|2010-03-17 18:38:38|SQL_logged from _resetpswd, 95
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|pasteboard.Started
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: useragents-config
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: dates-config
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: fopen-config
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: stopwords-config
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-database
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-useragent
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-hooks
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-sessions
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-cache
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-scaffolding
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-errors
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-uri
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|library: pb-logs
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_set_timezone: US/Pacific
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_sitewhoami: default Initialized
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_useragent: Firefox 3.6
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_useragent: Mac OS X
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_init_session: Not Implemented
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_dbopen: mysql_pconnect
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|app: admin Initialized
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|app: admin Function: login
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|get_css / file: $file
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|get_css / file: $file
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|get_css / file: $file
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|get_js / file: $file
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|app: admin Terminated
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|_dbclose CLOSED
20100317183838|127.0.0.1|INFO|2010-03-17 18:38:38|pasteboard.Complete (0.916 seconds)
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183838|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183838|127.0.0.1|INCLUDE|2010-03-17 18:38:38|helper: diagnostics_helper, format_diagnostics
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|pasteboard.Started
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: useragents-config
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: dates-config
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: fopen-config
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: stopwords-config
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-database
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-useragent
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-hooks
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-sessions
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-cache
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-scaffolding
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-errors
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-uri
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|library: pb-logs
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_set_timezone: US/Pacific
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_sitewhoami: default Initialized
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_uri_segment: SEGMENT_PATH
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_useragent: Firefox 3.6
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_useragent: Mac OS X
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_init_session: Not Implemented
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_dbopen: mysql_pconnect
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|app: admin Initialized
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|app: admin Function: login
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|get_css / file: $file
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|get_css / file: $file
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|get_css / file: $file
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|get_js / file: $file
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|app: admin Terminated
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|_dbclose CLOSED
20100317183845|127.0.0.1|INFO|2010-03-17 18:38:45|pasteboard.Complete (0.578 seconds)
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183845|127.0.0.1|__ERROR_WARNING|2010-03-17 18:38:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183845|127.0.0.1|INCLUDE|2010-03-17 18:38:45|helper: diagnostics_helper, format_diagnostics
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|pasteboard.Started
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: useragents-config
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: dates-config
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: fopen-config
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: stopwords-config
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-database
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-useragent
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-hooks
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-sessions
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-cache
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-scaffolding
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-errors
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-uri
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|library: pb-logs
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_set_timezone: US/Pacific
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_sitewhoami: default Initialized
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_uri_segment: SEGMENT_PATH
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_useragent: Firefox 3.6
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_useragent: Mac OS X
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_init_session: Not Implemented
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_dbopen: mysql_pconnect
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|app: admin Initialized
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|app: admin Function: login
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|get_css / file: $file
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|get_css / file: $file
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|get_css / file: $file
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|get_js / file: $file
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|app: admin Terminated
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|_dbclose CLOSED
20100317183908|127.0.0.1|INFO|2010-03-17 18:39:08|pasteboard.Complete (0.285 seconds)
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183908|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183908|127.0.0.1|INCLUDE|2010-03-17 18:39:08|helper: diagnostics_helper, format_diagnostics
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|pasteboard.Started
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: useragents-config
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: dates-config
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: fopen-config
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: stopwords-config
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-database
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-useragent
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-hooks
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-sessions
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-cache
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-scaffolding
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-errors
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-uri
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|library: pb-logs
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_set_timezone: US/Pacific
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_sitewhoami: default Initialized
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_useragent: Firefox 3.6
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_useragent: Mac OS X
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_init_session: Not Implemented
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_dbopen: mysql_pconnect
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|app: admin Initialized
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|app: admin Function: login
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|get_css / file: $file
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|get_css / file: $file
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|get_css / file: $file
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|get_js / file: $file
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|app: admin Terminated
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|_dbclose CLOSED
20100317183940|127.0.0.1|INFO|2010-03-17 18:39:40|pasteboard.Complete (0.333 seconds)
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183940|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183940|127.0.0.1|INCLUDE|2010-03-17 18:39:40|helper: diagnostics_helper, format_diagnostics
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|pasteboard.Started
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: useragents-config
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: dates-config
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: fopen-config
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: stopwords-config
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-database
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-useragent
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-hooks
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-sessions
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-cache
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-scaffolding
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-errors
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-uri
20100317183945|127.0.0.1|INCLUDE|2010-03-17 18:39:45|library: pb-logs
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|_set_timezone: US/Pacific
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|_sitewhoami: default Initialized
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|_uri_segment: SEGMENT_PATH
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|_useragent: Firefox 3.6
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|_useragent: Mac OS X
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|_init_session: Not Implemented
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|_dbopen: mysql_pconnect
20100317183945|127.0.0.1|INFO|2010-03-17 18:39:45|app: admin Initialized
20100317183945|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:45|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183945|127.0.0.1|SQL|2010-03-17 18:39:45|SQL_logged from _resetpswd, 79
20100317183945|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:45|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 330]
20100317183945|127.0.0.1|SQL|2010-03-17 18:39:45|SQL_logged from _resetpswd, 95
20100317183945|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:45|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183945|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:45|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|pasteboard.Started
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: useragents-config
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: dates-config
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: fopen-config
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: stopwords-config
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-database
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-useragent
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-hooks
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-sessions
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-cache
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-scaffolding
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-errors
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-uri
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|library: pb-logs
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_set_timezone: US/Pacific
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_sitewhoami: default Initialized
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_useragent: Firefox 3.6
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_useragent: Mac OS X
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_init_session: Not Implemented
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_dbopen: mysql_pconnect
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|app: admin Initialized
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|app: admin Function: login
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|get_css / file: $file
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|get_css / file: $file
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|get_css / file: $file
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|get_js / file: $file
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|app: admin Terminated
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|_dbclose CLOSED
20100317183946|127.0.0.1|INFO|2010-03-17 18:39:46|pasteboard.Complete (0.081 seconds)
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183946|127.0.0.1|__ERROR_WARNING|2010-03-17 18:39:46|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317183946|127.0.0.1|INCLUDE|2010-03-17 18:39:46|helper: diagnostics_helper, format_diagnostics
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|pasteboard.Started
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: useragents-config
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: dates-config
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: fopen-config
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: stopwords-config
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-database
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-useragent
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-hooks
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-sessions
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-cache
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-scaffolding
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-errors
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-uri
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|library: pb-logs
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_set_timezone: US/Pacific
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_sitewhoami: default Initialized
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_uri_segment: SEGMENT_PATH
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_useragent: Firefox 3.6
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_useragent: Mac OS X
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_init_session: Not Implemented
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_dbopen: mysql_pconnect
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|app: admin Initialized
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|app: admin Function: login
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|get_css / file: $file
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|get_css / file: $file
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|get_css / file: $file
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|get_js / file: $file
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|app: admin Terminated
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|_dbclose CLOSED
20100317184002|127.0.0.1|INFO|2010-03-17 18:40:02|pasteboard.Complete (0.862 seconds)
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184002|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:02|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184002|127.0.0.1|INCLUDE|2010-03-17 18:40:02|helper: diagnostics_helper, format_diagnostics
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|pasteboard.Started
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: useragents-config
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: dates-config
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: fopen-config
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: stopwords-config
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-database
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-useragent
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-hooks
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-sessions
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-cache
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-scaffolding
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-errors
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-uri
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|library: pb-logs
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_set_timezone: US/Pacific
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_sitewhoami: default Initialized
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_uri_segment: SEGMENT_PATH
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_useragent: Firefox 3.6
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_useragent: Mac OS X
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_init_session: Not Implemented
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_dbopen: mysql_pconnect
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|app: admin Initialized
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|app: admin Function: login
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|get_css / file: $file
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|get_css / file: $file
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|get_css / file: $file
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|get_js / file: $file
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|app: admin Terminated
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|_dbclose CLOSED
20100317184053|127.0.0.1|INFO|2010-03-17 18:40:53|pasteboard.Complete (0.388 seconds)
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184053|127.0.0.1|__ERROR_WARNING|2010-03-17 18:40:53|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184053|127.0.0.1|INCLUDE|2010-03-17 18:40:53|helper: diagnostics_helper, format_diagnostics
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|pasteboard.Started
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: useragents-config
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: dates-config
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: fopen-config
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: stopwords-config
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-database
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-useragent
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-hooks
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-sessions
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-cache
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-scaffolding
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-errors
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-uri
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|library: pb-logs
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_set_timezone: US/Pacific
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_sitewhoami: default Initialized
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_uri_segment: SEGMENT_PATH
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_useragent: Firefox 3.6
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_useragent: Mac OS X
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_init_session: Not Implemented
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_dbopen: mysql_pconnect
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|app: admin Initialized
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|app: admin Function: login
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|get_css / file: $file
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|get_css / file: $file
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|get_css / file: $file
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|get_js / file: $file
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|app: admin Terminated
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|_dbclose CLOSED
20100317184114|127.0.0.1|INFO|2010-03-17 18:41:14|pasteboard.Complete (0.595 seconds)
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184114|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:14|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184114|127.0.0.1|INCLUDE|2010-03-17 18:41:14|helper: diagnostics_helper, format_diagnostics
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|pasteboard.Started
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: useragents-config
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: dates-config
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: fopen-config
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: stopwords-config
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-database
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-useragent
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-hooks
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-sessions
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-cache
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-scaffolding
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-errors
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-uri
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|library: pb-logs
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_set_timezone: US/Pacific
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_sitewhoami: default Initialized
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_uri_segment: FRONT PAGE
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_uri_segment: INDEX_WEBROOT
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_useragent: Firefox 3.6
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_useragent: Mac OS X
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_init_session: Not Implemented
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_dbopen: mysql_pconnect
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|app: page Initialized
20100317184151|127.0.0.1|SQL|2010-03-17 18:41:51|SQL_logged from _get_front_page, 85
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|model: page_model.php Function: _get_front_page
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|app: page Function: view
20100317184151|127.0.0.1|SQL|2010-03-17 18:41:51|SQL_logged from _get_content_index, 22
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|model: page_model.php Function: _get_content_index
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|get_css / file: $file
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|get_css / file: $file
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|app: page Terminated
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|_dbclose CLOSED
20100317184151|127.0.0.1|INFO|2010-03-17 18:41:51|pasteboard.Complete (0.761 seconds)
20100317184151|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:51|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184151|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184151|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:51|[8, E_NOTICE] Undefined index: CREATE [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184151|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:51|[8, E_NOTICE] Undefined index: CREATE [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184151|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184151|127.0.0.1|INCLUDE|2010-03-17 18:41:51|helper: diagnostics_helper, format_diagnostics
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|pasteboard.Started
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: useragents-config
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: dates-config
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: fopen-config
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: stopwords-config
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-database
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-useragent
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-hooks
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-sessions
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-cache
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-scaffolding
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-errors
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-uri
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|library: pb-logs
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_set_timezone: US/Pacific
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_sitewhoami: default Initialized
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_uri_segment: SECONDARY PAGE FOUND w/ID: kismet-article
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_uri_segment: SEGMENT_PATH
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_useragent: Firefox 3.6
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_useragent: Mac OS X
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_init_session: Not Implemented
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_dbopen: mysql_pconnect
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|app: page Initialized
20100317184157|127.0.0.1|SQL|2010-03-17 18:41:57|SQL_logged from _get_content, 57
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|model: page_model.php Function: _get_content
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|app: page Function: view
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|get_css / file: $file
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|get_css / file: $file
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|app: page Terminated
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|_dbclose CLOSED
20100317184157|127.0.0.1|INFO|2010-03-17 18:41:57|pasteboard.Complete (0.423 seconds)
20100317184157|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:57|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184157|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:57|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184157|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:57|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184157|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:57|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184157|127.0.0.1|__ERROR_WARNING|2010-03-17 18:41:57|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184157|127.0.0.1|INCLUDE|2010-03-17 18:41:57|helper: diagnostics_helper, format_diagnostics
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|pasteboard.Started
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: useragents-config
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: dates-config
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: fopen-config
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: stopwords-config
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-database
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-useragent
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-hooks
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-sessions
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-cache
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-scaffolding
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-errors
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-uri
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|library: pb-logs
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_set_timezone: US/Pacific
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_sitewhoami: default Initialized
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_uri_segment: SECONDARY PAGE FOUND w/ID: kismet-article
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_uri_segment: SEGMENT_PATH
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_useragent: Firefox 3.6
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_useragent: Mac OS X
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_init_session: Not Implemented
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_dbopen: mysql_pconnect
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|app: page Initialized
20100317184442|127.0.0.1|SQL|2010-03-17 18:44:42|SQL_logged from _get_content, 57
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|model: page_model.php Function: _get_content
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|app: page Function: view
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|get_css / file: $file
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|get_css / file: $file
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|app: page Terminated
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|_dbclose CLOSED
20100317184442|127.0.0.1|INFO|2010-03-17 18:44:42|pasteboard.Complete (0.926 seconds)
20100317184442|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:42|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184442|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:42|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184442|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:42|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184442|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:42|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184442|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:42|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184442|127.0.0.1|INCLUDE|2010-03-17 18:44:42|helper: diagnostics_helper, format_diagnostics
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|pasteboard.Started
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: useragents-config
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: dates-config
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: fopen-config
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: stopwords-config
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-database
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-useragent
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-hooks
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-sessions
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-cache
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-scaffolding
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-errors
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-uri
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|library: pb-logs
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_set_timezone: US/Pacific
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_sitewhoami: default Initialized
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_uri_segment: SECONDARY PAGE FOUND w/ID: kismet-article
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_uri_segment: SEGMENT_PATH
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_useragent: Firefox 3.6
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_useragent: Mac OS X
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_init_session: Not Implemented
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_dbopen: mysql_pconnect
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|app: page Initialized
20100317184444|127.0.0.1|SQL|2010-03-17 18:44:44|SQL_logged from _get_content, 57
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|model: page_model.php Function: _get_content
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|app: page Function: view
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|get_css / file: $file
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|get_css / file: $file
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|app: page Terminated
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|_dbclose CLOSED
20100317184444|127.0.0.1|INFO|2010-03-17 18:44:44|pasteboard.Complete (0.472 seconds)
20100317184444|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:44|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184444|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:44|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184444|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:44|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184444|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:44|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184444|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:44|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184444|127.0.0.1|INCLUDE|2010-03-17 18:44:44|helper: diagnostics_helper, format_diagnostics
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|pasteboard.Started
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: useragents-config
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: dates-config
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: fopen-config
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: stopwords-config
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-database
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-useragent
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-hooks
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-sessions
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-cache
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-scaffolding
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-errors
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-uri
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|library: pb-logs
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_set_timezone: US/Pacific
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_sitewhoami: default Initialized
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_uri_segment: SECONDARY PAGE FOUND w/ID: kismet-article
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_uri_segment: SEGMENT_PATH
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_useragent: Firefox 3.6
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_useragent: Mac OS X
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_init_session: Not Implemented
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_dbopen: mysql_pconnect
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|app: page Initialized
20100317184445|127.0.0.1|SQL|2010-03-17 18:44:45|SQL_logged from _get_content, 57
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|model: page_model.php Function: _get_content
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|app: page Function: view
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|get_css / file: $file
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|get_css / file: $file
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|app: page Terminated
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|_dbclose CLOSED
20100317184445|127.0.0.1|INFO|2010-03-17 18:44:45|pasteboard.Complete (0.783 seconds)
20100317184445|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:45|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184445|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184445|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184445|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184445|127.0.0.1|__ERROR_WARNING|2010-03-17 18:44:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184445|127.0.0.1|INCLUDE|2010-03-17 18:44:45|helper: diagnostics_helper, format_diagnostics
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|pasteboard.Started
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: useragents-config
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: dates-config
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: fopen-config
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: stopwords-config
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-database
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-useragent
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-hooks
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-sessions
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-cache
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-scaffolding
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-errors
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-uri
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|library: pb-logs
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_set_timezone: US/Pacific
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_sitewhoami: default Initialized
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_uri_segment: SECONDARY PAGE FOUND w/ID: kismet-article
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_uri_segment: SEGMENT_PATH
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_useragent: Firefox 3.6
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_useragent: Mac OS X
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_init_session: Not Implemented
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_dbopen: mysql_pconnect
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|app: page Initialized
20100317184512|127.0.0.1|SQL|2010-03-17 18:45:12|SQL_logged from _get_content, 57
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|model: page_model.php Function: _get_content
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|app: page Function: view
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|get_css / file: $file
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|get_css / file: $file
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|app: page Terminated
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|_dbclose CLOSED
20100317184512|127.0.0.1|INFO|2010-03-17 18:45:12|pasteboard.Complete (0.558 seconds)
20100317184512|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:12|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184512|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:12|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184512|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:12|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184512|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:12|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184512|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:12|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184512|127.0.0.1|INCLUDE|2010-03-17 18:45:12|helper: diagnostics_helper, format_diagnostics
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|pasteboard.Started
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: useragents-config
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: dates-config
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: fopen-config
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: stopwords-config
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-database
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-useragent
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-hooks
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-sessions
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-cache
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-scaffolding
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-errors
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-uri
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|library: pb-logs
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_set_timezone: US/Pacific
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_sitewhoami: default Initialized
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_uri_segment: SECONDARY PAGE FOUND w/ID: kismet-article
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_uri_segment: SEGMENT_PATH
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_useragent: Firefox 3.6
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_useragent: Mac OS X
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_init_session: Not Implemented
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_dbopen: mysql_pconnect
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|app: page Initialized
20100317184534|127.0.0.1|SQL|2010-03-17 18:45:34|SQL_logged from _get_content, 57
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|model: page_model.php Function: _get_content
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|app: page Function: view
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|get_css / file: $file
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|get_css / file: $file
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|app: page Terminated
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|_dbclose CLOSED
20100317184534|127.0.0.1|INFO|2010-03-17 18:45:34|pasteboard.Complete (0.128 seconds)
20100317184534|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:34|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184534|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:34|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184534|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:34|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184534|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:34|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184534|127.0.0.1|__ERROR_WARNING|2010-03-17 18:45:34|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184534|127.0.0.1|INCLUDE|2010-03-17 18:45:34|helper: diagnostics_helper, format_diagnostics
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|pasteboard.Started
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: useragents-config
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: dates-config
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: fopen-config
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: stopwords-config
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-database
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-useragent
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-hooks
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-sessions
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-cache
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-scaffolding
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-errors
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-uri
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|library: pb-logs
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_set_timezone: US/Pacific
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_sitewhoami: default Initialized
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_uri_segment: SECONDARY PAGE FOUND w/ID: kismet-article
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_uri_segment: SEGMENT_PATH
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_useragent: Firefox 3.6
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_useragent: Mac OS X
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_init_session: Not Implemented
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_dbopen: mysql_pconnect
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|app: page Initialized
20100317184624|127.0.0.1|SQL|2010-03-17 18:46:24|SQL_logged from _get_content, 57
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|model: page_model.php Function: _get_content
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|app: page Function: view
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|get_css / file: $file
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|get_css / file: $file
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|app: page Terminated
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|_dbclose CLOSED
20100317184624|127.0.0.1|INFO|2010-03-17 18:46:24|pasteboard.Complete (0.279 seconds)
20100317184624|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:24|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184624|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184624|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184624|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184624|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184624|127.0.0.1|INCLUDE|2010-03-17 18:46:24|helper: diagnostics_helper, format_diagnostics
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|pasteboard.Started
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: useragents-config
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: dates-config
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: fopen-config
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: stopwords-config
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-database
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-useragent
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-hooks
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-sessions
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-cache
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-scaffolding
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-errors
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-uri
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|library: pb-logs
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_set_timezone: US/Pacific
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_sitewhoami: default Initialized
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_uri_segment: FRONT PAGE
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_uri_segment: INDEX_WEBROOT
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_useragent: Firefox 3.6
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_useragent: Mac OS X
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_init_session: Not Implemented
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_dbopen: mysql_pconnect
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|app: page Initialized
20100317184626|127.0.0.1|SQL|2010-03-17 18:46:26|SQL_logged from _get_front_page, 85
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|model: page_model.php Function: _get_front_page
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|app: page Function: view
20100317184626|127.0.0.1|SQL|2010-03-17 18:46:26|SQL_logged from _get_content_index, 22
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|model: page_model.php Function: _get_content_index
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|get_css / file: $file
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|get_css / file: $file
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|app: page Terminated
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|_dbclose CLOSED
20100317184626|127.0.0.1|INFO|2010-03-17 18:46:26|pasteboard.Complete (0.487 seconds)
20100317184626|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:26|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184626|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:26|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184626|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:26|[8, E_NOTICE] Undefined index: CREATE [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184626|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:26|[8, E_NOTICE] Undefined index: CREATE [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184626|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:26|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184626|127.0.0.1|INCLUDE|2010-03-17 18:46:26|helper: diagnostics_helper, format_diagnostics
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|pasteboard.Started
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: useragents-config
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: dates-config
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: fopen-config
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: stopwords-config
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-database
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-useragent
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-hooks
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-sessions
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-cache
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-scaffolding
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-errors
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-uri
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|library: pb-logs
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_set_timezone: US/Pacific
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_sitewhoami: default Initialized
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_uri_segment: FRONT PAGE
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_uri_segment: INDEX_WEBROOT
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_useragent: Firefox 3.6
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_useragent: Mac OS X
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_init_session: Not Implemented
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_dbopen: mysql_pconnect
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|app: page Initialized
20100317184627|127.0.0.1|SQL|2010-03-17 18:46:27|SQL_logged from _get_front_page, 85
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|model: page_model.php Function: _get_front_page
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|app: page Function: view
20100317184627|127.0.0.1|SQL|2010-03-17 18:46:27|SQL_logged from _get_content_index, 22
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|model: page_model.php Function: _get_content_index
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|get_css / file: $file
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|get_css / file: $file
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|app: page Terminated
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|_dbclose CLOSED
20100317184627|127.0.0.1|INFO|2010-03-17 18:46:27|pasteboard.Complete (0.801 seconds)
20100317184627|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:27|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184627|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184627|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:27|[8, E_NOTICE] Undefined index: CREATE [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184627|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:27|[8, E_NOTICE] Undefined index: CREATE [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184627|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184627|127.0.0.1|INCLUDE|2010-03-17 18:46:27|helper: diagnostics_helper, format_diagnostics
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|pasteboard.Started
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: useragents-config
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: dates-config
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: fopen-config
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: stopwords-config
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-database
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-useragent
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-hooks
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-sessions
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-cache
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-scaffolding
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-errors
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-uri
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|library: pb-logs
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_set_timezone: US/Pacific
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_sitewhoami: default Initialized
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_uri_segment: SEGMENT_PATH
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_useragent: Firefox 3.6
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_useragent: Mac OS X
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_init_session: Not Implemented
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_dbopen: mysql_pconnect
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|app: admin Initialized
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|app: admin Function: login
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|get_css / file: $file
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|get_css / file: $file
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|get_css / file: $file
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|get_js / file: $file
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|app: admin Terminated
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|_dbclose CLOSED
20100317184637|127.0.0.1|INFO|2010-03-17 18:46:37|pasteboard.Complete (0.556 seconds)
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184637|127.0.0.1|__ERROR_WARNING|2010-03-17 18:46:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184637|127.0.0.1|INCLUDE|2010-03-17 18:46:37|helper: diagnostics_helper, format_diagnostics
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|pasteboard.Started
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: useragents-config
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: dates-config
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: fopen-config
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: stopwords-config
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-database
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-useragent
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-hooks
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-sessions
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-cache
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-scaffolding
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-errors
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-uri
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|library: pb-logs
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_set_timezone: US/Pacific
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_sitewhoami: default Initialized
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_uri_segment: SEGMENT_PATH
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_useragent: Firefox 3.6
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_useragent: Mac OS X
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_init_session: Not Implemented
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_dbopen: mysql_pconnect
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|app: admin Initialized
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|app: admin Function: login
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|get_css / file: $file
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|get_css / file: $file
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|get_css / file: $file
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|get_js / file: $file
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|app: admin Terminated
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|_dbclose CLOSED
20100317184737|127.0.0.1|INFO|2010-03-17 18:47:37|pasteboard.Complete (0.643 seconds)
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184737|127.0.0.1|__ERROR_WARNING|2010-03-17 18:47:37|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317184737|127.0.0.1|INCLUDE|2010-03-17 18:47:37|helper: diagnostics_helper, format_diagnostics
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|pasteboard.Started
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: useragents-config
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: dates-config
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: fopen-config
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: stopwords-config
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-database
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-useragent
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-hooks
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-sessions
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-cache
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-scaffolding
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-errors
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-uri
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|library: pb-logs
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_set_timezone: US/Pacific
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_sitewhoami: default Initialized
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_uri_segment: FRONT PAGE
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_uri_segment: INDEX_WEBROOT
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_useragent: Chrome 5.0.307.11
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_useragent: Mac OS X
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_init_session: Not Implemented
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_dbopen: mysql_pconnect
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|app: page Initialized
20100317191200|127.0.0.1|SQL|2010-03-17 19:12:00|SQL_logged from _get_front_page, 85
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|model: page_model.php Function: _get_front_page
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|app: page Function: view
20100317191200|127.0.0.1|SQL|2010-03-17 19:12:00|SQL_logged from _get_content_index, 22
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|model: page_model.php Function: _get_content_index
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|get_css / file: $file
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|get_css / file: $file
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|app: page Terminated
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|_dbclose CLOSED
20100317191200|127.0.0.1|INFO|2010-03-17 19:12:00|pasteboard.Complete (1.882 seconds)
20100317191200|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:00|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191200|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:00|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191200|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:00|[8, E_NOTICE] Undefined index: CREATE [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317191200|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:00|[8, E_NOTICE] Undefined index: CREATE [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191200|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:00|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191200|127.0.0.1|INCLUDE|2010-03-17 19:12:00|helper: diagnostics_helper, format_diagnostics
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|pasteboard.Started
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: useragents-config
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: dates-config
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: fopen-config
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: stopwords-config
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-database
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-useragent
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-hooks
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-sessions
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-cache
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-scaffolding
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-errors
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-uri
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|library: pb-logs
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_set_timezone: US/Pacific
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_sitewhoami: default Initialized
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_uri_segment: SEGMENT_PATH
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_useragent: Chrome 5.0.307.11
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_useragent: Mac OS X
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_init_session: Not Implemented
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_dbopen: mysql_pconnect
20100317191201|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:01|File Not Found: favicon.ico_controller.php-> Line 199-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100317191201|127.0.0.1|SQL|2010-03-17 19:12:01|SQL_logged from show_404, 30
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|get_css / file: $file
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|get_css / file: $file
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|_dbclose CLOSED
20100317191201|127.0.0.1|INFO|2010-03-17 19:12:01|pasteboard.Complete (0.819 seconds)
20100317191201|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:01|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191201|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191201|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317191201|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191201|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191201|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:01|[8, E_NOTICE] Undefined index: PAGE_CONTROLLER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 303]
20100317191201|127.0.0.1|__ERROR_WARNING|2010-03-17 19:12:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 303]
20100317191201|127.0.0.1|INCLUDE|2010-03-17 19:12:01|helper: diagnostics_helper, format_diagnostics
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|pasteboard.Started
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: useragents-config
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: dates-config
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: fopen-config
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: stopwords-config
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-database
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-useragent
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-hooks
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-sessions
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-cache
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-scaffolding
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-errors
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-uri
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|library: pb-logs
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_set_timezone: US/Pacific
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_sitewhoami: default Initialized
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_uri_segment: SEGMENT_PATH
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_useragent: Firefox 3.6
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_useragent: Mac OS X
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_init_session: Not Implemented
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_dbopen: mysql_pconnect
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|app: admin Initialized
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|app: admin Function: login
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|get_css / file: $file
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|get_css / file: $file
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|get_css / file: $file
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|get_js / file: $file
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|app: admin Terminated
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|_dbclose CLOSED
20100317191800|127.0.0.1|INFO|2010-03-17 19:18:00|pasteboard.Complete (1.145 seconds)
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317191800|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:00|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317191800|127.0.0.1|INCLUDE|2010-03-17 19:18:00|helper: diagnostics_helper, format_diagnostics
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|pasteboard.Started
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: useragents-config
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: dates-config
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: fopen-config
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: stopwords-config
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-database
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-useragent
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-hooks
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-sessions
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-cache
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-scaffolding
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-errors
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-uri
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|library: pb-logs
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_set_timezone: US/Pacific
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_sitewhoami: default Initialized
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_uri_segment: SEGMENT_PATH
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_useragent: Firefox 3.6
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_useragent: Mac OS X
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_init_session: Not Implemented
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_dbopen: mysql_pconnect
20100317191801|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:01|File Not Found: favicon.ico_controller.php-> Line 199-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100317191801|127.0.0.1|SQL|2010-03-17 19:18:01|SQL_logged from show_404, 30
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|get_css / file: $file
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|get_css / file: $file
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|_dbclose CLOSED
20100317191801|127.0.0.1|INFO|2010-03-17 19:18:01|pasteboard.Complete (0.761 seconds)
20100317191801|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:01|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191801|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191801|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317191801|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191801|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191801|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:01|[8, E_NOTICE] Undefined index: PAGE_CONTROLLER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 303]
20100317191801|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 303]
20100317191801|127.0.0.1|INCLUDE|2010-03-17 19:18:01|helper: diagnostics_helper, format_diagnostics
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|pasteboard.Started
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: useragents-config
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: dates-config
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: fopen-config
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: stopwords-config
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-database
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-useragent
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-hooks
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-sessions
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-cache
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-scaffolding
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-errors
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-uri
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|library: pb-logs
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_set_timezone: US/Pacific
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_sitewhoami: default Initialized
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_uri_segment: SEGMENT_PATH
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_useragent: Firefox 3.6
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_useragent: Mac OS X
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_init_session: Not Implemented
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_dbopen: mysql_pconnect
20100317191804|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:04|File Not Found: favicon.ico_controller.php-> Line 199-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100317191804|127.0.0.1|SQL|2010-03-17 19:18:04|SQL_logged from show_404, 30
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|get_css / file: $file
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|get_css / file: $file
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|_dbclose CLOSED
20100317191804|127.0.0.1|INFO|2010-03-17 19:18:04|pasteboard.Complete (0.668 seconds)
20100317191804|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:04|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191804|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317191804|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317191804|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191804|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317191804|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:04|[8, E_NOTICE] Undefined index: PAGE_CONTROLLER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 303]
20100317191804|127.0.0.1|__ERROR_WARNING|2010-03-17 19:18:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 303]
20100317191804|127.0.0.1|INCLUDE|2010-03-17 19:18:04|helper: diagnostics_helper, format_diagnostics
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|pasteboard.Started
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: useragents-config
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: dates-config
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: fopen-config
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: stopwords-config
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-database
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-useragent
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-hooks
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-sessions
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-cache
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-scaffolding
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-errors
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-uri
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|library: pb-logs
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_set_timezone: US/Pacific
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_sitewhoami: default Initialized
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_uri_segment: SEGMENT_PATH
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_useragent: Firefox 3.6
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_useragent: Mac OS X
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_init_session: Not Implemented
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_dbopen: mysql_pconnect
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|app: admin Initialized
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|app: admin Function: login
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|get_css / file: $file
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|get_css / file: $file
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|get_css / file: $file
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|get_js / file: $file
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|app: admin Terminated
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|_dbclose CLOSED
20100317192436|127.0.0.1|INFO|2010-03-17 19:24:36|pasteboard.Complete (0.785 seconds)
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317192436|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317192436|127.0.0.1|INCLUDE|2010-03-17 19:24:36|helper: diagnostics_helper, format_diagnostics
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|pasteboard.Started
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: useragents-config
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: dates-config
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: fopen-config
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: stopwords-config
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-database
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-useragent
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-hooks
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-sessions
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-cache
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-scaffolding
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-errors
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-uri
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|library: pb-logs
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_set_timezone: US/Pacific
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_sitewhoami: default Initialized
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_uri_segment: SEGMENT_PATH
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_useragent: Firefox 3.6
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_useragent: Mac OS X
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_init_session: Not Implemented
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_dbopen: mysql_pconnect
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|app: admin Initialized
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|app: admin Function: login
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|get_css / file: $file
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|get_css / file: $file
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|get_css / file: $file
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|get_js / file: $file
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|app: admin Terminated
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|_dbclose CLOSED
20100317192440|127.0.0.1|INFO|2010-03-17 19:24:40|pasteboard.Complete (0.054 seconds)
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317192440|127.0.0.1|__ERROR_WARNING|2010-03-17 19:24:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317192440|127.0.0.1|INCLUDE|2010-03-17 19:24:40|helper: diagnostics_helper, format_diagnostics
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|pasteboard.Started
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: useragents-config
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: dates-config
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: fopen-config
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: stopwords-config
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-database
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-useragent
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-hooks
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-sessions
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-cache
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-scaffolding
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-errors
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-uri
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|library: pb-logs
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_set_timezone: US/Pacific
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_sitewhoami: default Initialized
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_uri_segment: SEGMENT_PATH
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_useragent: Firefox 3.6
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_useragent: Mac OS X
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_init_session: Not Implemented
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_dbopen: mysql_pconnect
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|app: admin Initialized
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|app: admin Function: login
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|get_css / file: $file
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|get_css / file: $file
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|get_css / file: $file
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|get_js / file: $file
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|app: admin Terminated
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|_dbclose CLOSED
20100317202339|127.0.0.1|INFO|2010-03-17 20:23:39|pasteboard.Complete (1.039 seconds)
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 231]
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 250]
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317202339|127.0.0.1|__ERROR_WARNING|2010-03-17 20:23:39|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317202339|127.0.0.1|INCLUDE|2010-03-17 20:23:39|helper: diagnostics_helper, format_diagnostics
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|pasteboard.Started
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: useragents-config
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: dates-config
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: fopen-config
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: stopwords-config
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-database
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-useragent
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-hooks
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-sessions
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-cache
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-scaffolding
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-errors
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-uri
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|library: pb-logs
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_set_timezone: US/Pacific
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_sitewhoami: default Initialized
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_uri_segment: SEGMENT_PATH
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_useragent: Firefox 3.6
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_useragent: Mac OS X
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_init_session: Not Implemented
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_dbopen: mysql_pconnect
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|app: admin Initialized
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|app: admin Function: login
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|get_css / file: $file
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|get_css / file: $file
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|get_css / file: $file
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|get_js / file: $file
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|app: admin Terminated
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|_dbclose CLOSED
20100317202420|127.0.0.1|INFO|2010-03-17 20:24:20|pasteboard.Complete (0.179 seconds)
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 231]
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 250]
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317202420|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317202420|127.0.0.1|INCLUDE|2010-03-17 20:24:20|helper: diagnostics_helper, format_diagnostics
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|pasteboard.Started
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: useragents-config
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: dates-config
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: fopen-config
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: stopwords-config
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-database
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-useragent
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-hooks
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-sessions
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-cache
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-scaffolding
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-errors
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-uri
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|library: pb-logs
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_set_timezone: US/Pacific
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_sitewhoami: default Initialized
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_uri_segment: SEGMENT_PATH
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_useragent: Firefox 3.6
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_useragent: Mac OS X
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_init_session: Not Implemented
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_dbopen: mysql_pconnect
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|app: admin Initialized
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|app: admin Function: login
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|get_css / file: $file
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|get_css / file: $file
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|get_css / file: $file
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|get_js / file: $file
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|app: admin Terminated
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|_dbclose CLOSED
20100317202440|127.0.0.1|INFO|2010-03-17 20:24:40|pasteboard.Complete (0.959 seconds)
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202440|127.0.0.1|__ERROR_WARNING|2010-03-17 20:24:40|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202440|127.0.0.1|INCLUDE|2010-03-17 20:24:40|helper: diagnostics_helper, format_diagnostics
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|pasteboard.Started
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: useragents-config
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: dates-config
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: fopen-config
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: stopwords-config
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-database
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-useragent
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-hooks
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-sessions
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-cache
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-scaffolding
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-errors
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-uri
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|library: pb-logs
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_set_timezone: US/Pacific
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_sitewhoami: default Initialized
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_uri_segment: SEGMENT_PATH
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_useragent: Firefox 3.6
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_useragent: Mac OS X
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_init_session: Not Implemented
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_dbopen: mysql_pconnect
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|app: admin Initialized
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|app: admin Function: login
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|get_css / file: $file
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|get_css / file: $file
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|get_css / file: $file
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|get_js / file: $file
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|app: admin Terminated
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|_dbclose CLOSED
20100317202536|127.0.0.1|INFO|2010-03-17 20:25:36|pasteboard.Complete (0.103 seconds)
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202536|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202536|127.0.0.1|INCLUDE|2010-03-17 20:25:36|helper: diagnostics_helper, format_diagnostics
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|pasteboard.Started
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: useragents-config
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: dates-config
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: fopen-config
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: stopwords-config
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-database
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-useragent
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-hooks
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-sessions
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-cache
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-scaffolding
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-errors
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-uri
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|library: pb-logs
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_set_timezone: US/Pacific
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_sitewhoami: default Initialized
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_uri_segment: SEGMENT_PATH
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_useragent: Firefox 3.6
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_useragent: Mac OS X
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_init_session: Not Implemented
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_dbopen: mysql_pconnect
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|app: admin Initialized
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|app: admin Function: login
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|get_css / file: $file
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|get_css / file: $file
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|get_css / file: $file
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|get_js / file: $file
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|app: admin Terminated
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|_dbclose CLOSED
20100317202538|127.0.0.1|INFO|2010-03-17 20:25:38|pasteboard.Complete (0.271 seconds)
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202538|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:38|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202538|127.0.0.1|INCLUDE|2010-03-17 20:25:38|helper: diagnostics_helper, format_diagnostics
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|pasteboard.Started
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: useragents-config
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: dates-config
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: fopen-config
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: stopwords-config
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-database
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-useragent
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-hooks
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-sessions
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-cache
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-scaffolding
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-errors
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-uri
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|library: pb-logs
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_set_timezone: US/Pacific
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_sitewhoami: default Initialized
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_uri_segment: SEGMENT_PATH
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_useragent: Firefox 3.6
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_useragent: Mac OS X
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_init_session: Not Implemented
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_dbopen: mysql_pconnect
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|app: admin Initialized
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|app: admin Function: login
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|get_css / file: $file
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|get_css / file: $file
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|get_css / file: $file
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|get_js / file: $file
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|app: admin Terminated
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|_dbclose CLOSED
20100317202554|127.0.0.1|INFO|2010-03-17 20:25:54|pasteboard.Complete (0.443 seconds)
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202554|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202554|127.0.0.1|INCLUDE|2010-03-17 20:25:54|helper: diagnostics_helper, format_diagnostics
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|pasteboard.Started
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: useragents-config
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: dates-config
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: fopen-config
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: stopwords-config
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-database
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-useragent
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-hooks
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-sessions
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-cache
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-scaffolding
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-errors
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-uri
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|library: pb-logs
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_set_timezone: US/Pacific
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_sitewhoami: default Initialized
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_uri_segment: SEGMENT_PATH
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_useragent: Firefox 3.6
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_useragent: Mac OS X
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_init_session: Not Implemented
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_dbopen: mysql_pconnect
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|app: admin Initialized
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|app: admin Function: login
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|get_css / file: $file
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|get_css / file: $file
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|get_css / file: $file
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|get_js / file: $file
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|app: admin Terminated
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|_dbclose CLOSED
20100317202555|127.0.0.1|INFO|2010-03-17 20:25:55|pasteboard.Complete (1.007 seconds)
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202555|127.0.0.1|__ERROR_WARNING|2010-03-17 20:25:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202555|127.0.0.1|INCLUDE|2010-03-17 20:25:55|helper: diagnostics_helper, format_diagnostics
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|pasteboard.Started
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: useragents-config
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: dates-config
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: fopen-config
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: stopwords-config
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-database
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-useragent
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-hooks
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-sessions
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-cache
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-scaffolding
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-errors
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-uri
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|library: pb-logs
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_set_timezone: US/Pacific
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_sitewhoami: default Initialized
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_uri_segment: SEGMENT_PATH
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_useragent: Firefox 3.6
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_useragent: Mac OS X
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_init_session: Not Implemented
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_dbopen: mysql_pconnect
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|app: admin Initialized
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|app: admin Function: login
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|get_css / file: $file
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|get_css / file: $file
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|get_css / file: $file
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|get_js / file: $file
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|app: admin Terminated
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|_dbclose CLOSED
20100317202624|127.0.0.1|INFO|2010-03-17 20:26:24|pasteboard.Complete (0.93 seconds)
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202624|127.0.0.1|__ERROR_WARNING|2010-03-17 20:26:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202624|127.0.0.1|INCLUDE|2010-03-17 20:26:24|helper: diagnostics_helper, format_diagnostics
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|pasteboard.Started
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: useragents-config
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: dates-config
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: fopen-config
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: stopwords-config
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-database
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-useragent
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-hooks
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-sessions
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-cache
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-scaffolding
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-errors
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-uri
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|library: pb-logs
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_set_timezone: US/Pacific
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_sitewhoami: default Initialized
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_uri_segment: SEGMENT_PATH
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_useragent: Firefox 3.6
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_useragent: Mac OS X
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_init_session: Not Implemented
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_dbopen: mysql_pconnect
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|app: admin Initialized
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|app: admin Function: login
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|get_css / file: $file
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|get_css / file: $file
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|get_css / file: $file
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|get_js / file: $file
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|app: admin Terminated
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|_dbclose CLOSED
20100317202744|127.0.0.1|INFO|2010-03-17 20:27:44|pasteboard.Complete (0.546 seconds)
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202744|127.0.0.1|__ERROR_WARNING|2010-03-17 20:27:44|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202744|127.0.0.1|INCLUDE|2010-03-17 20:27:44|helper: diagnostics_helper, format_diagnostics
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|pasteboard.Started
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: useragents-config
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: dates-config
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: fopen-config
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: stopwords-config
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-database
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-useragent
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-hooks
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-sessions
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-cache
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-scaffolding
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-errors
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-uri
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|library: pb-logs
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_set_timezone: US/Pacific
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_sitewhoami: default Initialized
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_uri_segment: SEGMENT_PATH
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_useragent: Firefox 3.6
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_useragent: Mac OS X
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_init_session: Not Implemented
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_dbopen: mysql_pconnect
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|app: admin Initialized
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|app: admin Function: login
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|get_css / file: $file
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|get_css / file: $file
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|get_css / file: $file
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|get_js / file: $file
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|app: admin Terminated
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|_dbclose CLOSED
20100317202916|127.0.0.1|INFO|2010-03-17 20:29:16|pasteboard.Complete (0.362 seconds)
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202916|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:16|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202916|127.0.0.1|INCLUDE|2010-03-17 20:29:16|helper: diagnostics_helper, format_diagnostics
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|pasteboard.Started
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: useragents-config
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: dates-config
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: fopen-config
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: stopwords-config
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-database
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-useragent
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-hooks
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-sessions
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-cache
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-scaffolding
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-errors
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-uri
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|library: pb-logs
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_set_timezone: US/Pacific
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_sitewhoami: default Initialized
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_uri_segment: SEGMENT_PATH
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_useragent: Firefox 3.6
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_useragent: Mac OS X
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_init_session: Not Implemented
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_dbopen: mysql_pconnect
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|app: admin Initialized
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|app: admin Function: login
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|get_css / file: $file
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|get_css / file: $file
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|get_css / file: $file
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|get_js / file: $file
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|app: admin Terminated
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|_dbclose CLOSED
20100317202959|127.0.0.1|INFO|2010-03-17 20:29:59|pasteboard.Complete (0.676 seconds)
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 178]
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 229]
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 235]
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 248]
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202959|127.0.0.1|__ERROR_WARNING|2010-03-17 20:29:59|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 257]
20100317202959|127.0.0.1|INCLUDE|2010-03-17 20:29:59|helper: diagnostics_helper, format_diagnostics
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|pasteboard.Started
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: useragents-config
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: dates-config
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: fopen-config
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: stopwords-config
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-database
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-useragent
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-hooks
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-sessions
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-cache
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-scaffolding
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-errors
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-uri
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|library: pb-logs
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_set_timezone: US/Pacific
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_sitewhoami: default Initialized
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_uri_segment: SEGMENT_PATH
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_useragent: Firefox 3.6
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_useragent: Mac OS X
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_init_session: Not Implemented
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_dbopen: mysql_pconnect
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|app: admin Initialized
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|app: admin Function: login
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|get_css / file: $file
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|get_css / file: $file
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|get_css / file: $file
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|get_js / file: $file
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|app: admin Terminated
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|_dbclose CLOSED
20100317203727|127.0.0.1|INFO|2010-03-17 20:37:27|pasteboard.Complete (0.982 seconds)
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317203727|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317203727|127.0.0.1|INCLUDE|2010-03-17 20:37:27|helper: diagnostics_helper, format_diagnostics
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|pasteboard.Started
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: useragents-config
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: dates-config
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: fopen-config
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: stopwords-config
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-database
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-useragent
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-hooks
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-sessions
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-cache
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-scaffolding
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-errors
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-uri
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|library: pb-logs
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_set_timezone: US/Pacific
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_sitewhoami: default Initialized
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_uri_segment: SEGMENT_PATH
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_useragent: Firefox 3.6
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_useragent: Mac OS X
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_init_session: Not Implemented
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_dbopen: mysql_pconnect
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|app: admin Initialized
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|app: admin Function: login
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|get_css / file: $file
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|get_css / file: $file
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|get_css / file: $file
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|get_js / file: $file
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|app: admin Terminated
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|_dbclose CLOSED
20100317203729|127.0.0.1|INFO|2010-03-17 20:37:29|pasteboard.Complete (0.19 seconds)
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317203729|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:29|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317203729|127.0.0.1|INCLUDE|2010-03-17 20:37:29|helper: diagnostics_helper, format_diagnostics
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|pasteboard.Started
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: useragents-config
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: dates-config
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: fopen-config
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: stopwords-config
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-database
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-useragent
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-hooks
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-sessions
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-cache
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-scaffolding
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-errors
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-uri
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|library: pb-logs
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_set_timezone: US/Pacific
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_sitewhoami: default Initialized
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_uri_segment: SEGMENT_PATH
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_useragent: Firefox 3.6
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_useragent: Mac OS X
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_init_session: Not Implemented
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_dbopen: mysql_pconnect
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|app: admin Initialized
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|app: admin Function: login
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|get_css / file: $file
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|get_css / file: $file
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|get_css / file: $file
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|get_js / file: $file
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|app: admin Terminated
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|_dbclose CLOSED
20100317203755|127.0.0.1|INFO|2010-03-17 20:37:55|pasteboard.Complete (0.155 seconds)
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317203755|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317203755|127.0.0.1|INCLUDE|2010-03-17 20:37:55|helper: diagnostics_helper, format_diagnostics
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|pasteboard.Started
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: useragents-config
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: dates-config
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: fopen-config
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: stopwords-config
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-database
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-useragent
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-hooks
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-sessions
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-cache
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-scaffolding
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-errors
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-uri
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|library: pb-logs
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_set_timezone: US/Pacific
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_sitewhoami: default Initialized
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_uri_segment: SEGMENT_PATH
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_useragent: Firefox 3.6
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_useragent: Mac OS X
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_init_session: Not Implemented
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_dbopen: mysql_pconnect
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|app: admin Initialized
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|app: admin Function: login
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|get_css / file: $file
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|get_css / file: $file
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|get_css / file: $file
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|get_js / file: $file
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|app: admin Terminated
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|_dbclose CLOSED
20100317203756|127.0.0.1|INFO|2010-03-17 20:37:56|pasteboard.Complete (0.036 seconds)
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317203756|127.0.0.1|__ERROR_WARNING|2010-03-17 20:37:56|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317203756|127.0.0.1|INCLUDE|2010-03-17 20:37:56|helper: diagnostics_helper, format_diagnostics
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|pasteboard.Started
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: useragents-config
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: dates-config
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: fopen-config
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: stopwords-config
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-database
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-useragent
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-hooks
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-sessions
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-cache
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-scaffolding
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-errors
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-uri
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|library: pb-logs
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_set_timezone: US/Pacific
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_sitewhoami: default Initialized
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_uri_segment: SEGMENT_PATH
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_useragent: Firefox 3.6
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_useragent: Mac OS X
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_init_session: Not Implemented
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_dbopen: mysql_pconnect
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|app: admin Initialized
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|app: admin Function: login
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|get_css / file: $file
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|get_css / file: $file
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|get_css / file: $file
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|get_js / file: $file
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|app: admin Terminated
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|_dbclose CLOSED
20100317203820|127.0.0.1|INFO|2010-03-17 20:38:20|pasteboard.Complete (0.028 seconds)
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 231]
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 250]
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317203820|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:20|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317203820|127.0.0.1|INCLUDE|2010-03-17 20:38:20|helper: diagnostics_helper, format_diagnostics
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|pasteboard.Started
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: useragents-config
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: dates-config
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: fopen-config
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: stopwords-config
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-database
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-useragent
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-hooks
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-sessions
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-cache
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-scaffolding
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-errors
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-uri
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|library: pb-logs
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_set_timezone: US/Pacific
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_sitewhoami: default Initialized
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_uri_segment: SEGMENT_PATH
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_useragent: Firefox 3.6
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_useragent: Mac OS X
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_init_session: Not Implemented
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_dbopen: mysql_pconnect
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|app: admin Initialized
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|app: admin Function: login
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|get_css / file: $file
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|get_css / file: $file
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|get_css / file: $file
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|get_js / file: $file
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|app: admin Terminated
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|_dbclose CLOSED
20100317203850|127.0.0.1|INFO|2010-03-17 20:38:50|pasteboard.Complete (0.452 seconds)
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 231]
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 250]
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317203850|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:50|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317203850|127.0.0.1|INCLUDE|2010-03-17 20:38:50|helper: diagnostics_helper, format_diagnostics
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|pasteboard.Started
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: useragents-config
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: dates-config
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: fopen-config
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: stopwords-config
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-database
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-useragent
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-hooks
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-sessions
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-cache
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-scaffolding
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-errors
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-uri
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|library: pb-logs
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_set_timezone: US/Pacific
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_sitewhoami: default Initialized
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_uri_segment: SEGMENT_PATH
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_useragent: Firefox 3.6
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_useragent: Mac OS X
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_init_session: Not Implemented
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_dbopen: mysql_pconnect
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|app: admin Initialized
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|app: admin Function: login
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|get_css / file: $file
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|get_css / file: $file
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|get_css / file: $file
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|get_js / file: $file
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|app: admin Terminated
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|_dbclose CLOSED
20100317203851|127.0.0.1|INFO|2010-03-17 20:38:51|pasteboard.Complete (0.354 seconds)
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 180]
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 231]
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 237]
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 250]
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317203851|127.0.0.1|__ERROR_WARNING|2010-03-17 20:38:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 259]
20100317203851|127.0.0.1|INCLUDE|2010-03-17 20:38:51|helper: diagnostics_helper, format_diagnostics
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|pasteboard.Started
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: useragents-config
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: dates-config
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: fopen-config
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: stopwords-config
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-database
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-useragent
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-hooks
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-sessions
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-cache
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-scaffolding
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-errors
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-uri
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|library: pb-logs
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_set_timezone: US/Pacific
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_sitewhoami: default Initialized
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_uri_segment: SEGMENT_PATH
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_useragent: Firefox 3.6
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_useragent: Mac OS X
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_init_session: Not Implemented
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_dbopen: mysql_pconnect
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|app: admin Initialized
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|app: admin Function: login
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|get_css / file: $file
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|get_css / file: $file
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|get_css / file: $file
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|get_js / file: $file
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|app: admin Terminated
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|_dbclose CLOSED
20100317203923|127.0.0.1|INFO|2010-03-17 20:39:23|pasteboard.Complete (0.068 seconds)
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317203923|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:23|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317203923|127.0.0.1|INCLUDE|2010-03-17 20:39:23|helper: diagnostics_helper, format_diagnostics
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|pasteboard.Started
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: useragents-config
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: dates-config
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: fopen-config
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: stopwords-config
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-database
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-useragent
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-hooks
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-sessions
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-cache
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-scaffolding
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-errors
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-uri
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|library: pb-logs
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_set_timezone: US/Pacific
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_sitewhoami: default Initialized
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_uri_segment: SEGMENT_PATH
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_useragent: Firefox 3.6
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_useragent: Mac OS X
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_init_session: Not Implemented
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_dbopen: mysql_pconnect
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|app: admin Initialized
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|app: admin Function: login
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|get_css / file: $file
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|get_css / file: $file
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|get_css / file: $file
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|get_js / file: $file
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|app: admin Terminated
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|_dbclose CLOSED
20100317203924|127.0.0.1|INFO|2010-03-17 20:39:24|pasteboard.Complete (0.135 seconds)
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317203924|127.0.0.1|__ERROR_WARNING|2010-03-17 20:39:24|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317203924|127.0.0.1|INCLUDE|2010-03-17 20:39:24|helper: diagnostics_helper, format_diagnostics
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|pasteboard.Started
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: useragents-config
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: dates-config
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: fopen-config
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: stopwords-config
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-database
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-useragent
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-hooks
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-sessions
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-cache
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-scaffolding
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-errors
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-uri
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|library: pb-logs
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_set_timezone: US/Pacific
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_sitewhoami: default Initialized
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_uri_segment: SEGMENT_PATH
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_useragent: Firefox 3.6
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_useragent: Mac OS X
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_init_session: Not Implemented
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_dbopen: mysql_pconnect
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|app: admin Initialized
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|app: admin Function: login
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|get_css / file: $file
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|get_css / file: $file
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|get_css / file: $file
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|get_js / file: $file
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|app: admin Terminated
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|_dbclose CLOSED
20100317204501|127.0.0.1|INFO|2010-03-17 20:45:01|pasteboard.Complete (0.561 seconds)
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317204501|127.0.0.1|__ERROR_WARNING|2010-03-17 20:45:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317204501|127.0.0.1|INCLUDE|2010-03-17 20:45:01|helper: diagnostics_helper, format_diagnostics
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|pasteboard.Started
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: useragents-config
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: dates-config
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: fopen-config
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: stopwords-config
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-database
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-useragent
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-hooks
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-sessions
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-cache
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-scaffolding
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-errors
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-uri
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|library: pb-logs
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_set_timezone: US/Pacific
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_sitewhoami: default Initialized
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_uri_segment: SEGMENT_PATH
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_useragent: Firefox 3.6
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_useragent: Mac OS X
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_init_session: Not Implemented
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_dbopen: mysql_pconnect
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|app: admin Initialized
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|app: admin Function: login
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|get_css / file: $file
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|get_css / file: $file
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|get_css / file: $file
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|get_js / file: $file
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|app: admin Terminated
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|_dbclose CLOSED
20100317204607|127.0.0.1|INFO|2010-03-17 20:46:07|pasteboard.Complete (0.457 seconds)
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317204607|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317204607|127.0.0.1|INCLUDE|2010-03-17 20:46:07|helper: diagnostics_helper, format_diagnostics
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|pasteboard.Started
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: useragents-config
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: dates-config
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: fopen-config
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: stopwords-config
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-database
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-useragent
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-hooks
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-sessions
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-cache
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-scaffolding
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-errors
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-uri
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|library: pb-logs
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_set_timezone: US/Pacific
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_sitewhoami: default Initialized
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_uri_segment: SEGMENT_PATH
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_useragent: Firefox 3.6
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_useragent: Mac OS X
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_init_session: Not Implemented
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_dbopen: mysql_pconnect
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|app: admin Initialized
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|app: admin Function: login
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|get_css / file: $file
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|get_css / file: $file
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|get_css / file: $file
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|get_js / file: $file
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|app: admin Terminated
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|_dbclose CLOSED
20100317204632|127.0.0.1|INFO|2010-03-17 20:46:32|pasteboard.Complete (0.392 seconds)
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317204632|127.0.0.1|__ERROR_WARNING|2010-03-17 20:46:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317204632|127.0.0.1|INCLUDE|2010-03-17 20:46:32|helper: diagnostics_helper, format_diagnostics
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|pasteboard.Started
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: useragents-config
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: dates-config
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: fopen-config
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: stopwords-config
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-database
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-useragent
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-hooks
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-sessions
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-cache
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-scaffolding
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-errors
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-uri
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|library: pb-logs
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_set_timezone: US/Pacific
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_sitewhoami: default Initialized
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_uri_segment: SEGMENT_PATH
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_useragent: Firefox 3.6
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_useragent: Mac OS X
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_init_session: Not Implemented
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_dbopen: mysql_pconnect
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|app: admin Initialized
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|app: admin Function: login
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|get_css / file: $file
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|get_css / file: $file
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|get_css / file: $file
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|get_js / file: $file
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|app: admin Terminated
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|_dbclose CLOSED
20100317204745|127.0.0.1|INFO|2010-03-17 20:47:45|pasteboard.Complete (1.022 seconds)
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317204745|127.0.0.1|__ERROR_WARNING|2010-03-17 20:47:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317204745|127.0.0.1|INCLUDE|2010-03-17 20:47:45|helper: diagnostics_helper, format_diagnostics
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|pasteboard.Started
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: useragents-config
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: dates-config
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: fopen-config
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: stopwords-config
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-database
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-useragent
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-hooks
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-sessions
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-cache
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-scaffolding
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-errors
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-uri
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|library: pb-logs
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_set_timezone: US/Pacific
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_sitewhoami: default Initialized
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_uri_segment: SEGMENT_PATH
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_useragent: Firefox 3.6
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_useragent: Mac OS X
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_init_session: Not Implemented
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_dbopen: mysql_pconnect
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|app: admin Initialized
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|app: admin Function: login
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|get_css / file: $file
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|get_css / file: $file
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|get_css / file: $file
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|get_js / file: $file
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|app: admin Terminated
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|_dbclose CLOSED
20100317205011|127.0.0.1|INFO|2010-03-17 20:50:11|pasteboard.Complete (0.716 seconds)
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205011|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:11|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205011|127.0.0.1|INCLUDE|2010-03-17 20:50:11|helper: diagnostics_helper, format_diagnostics
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|pasteboard.Started
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: useragents-config
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: dates-config
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: fopen-config
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: stopwords-config
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-database
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-useragent
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-hooks
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-sessions
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-cache
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-scaffolding
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-errors
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-uri
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|library: pb-logs
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_set_timezone: US/Pacific
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_sitewhoami: default Initialized
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_uri_segment: SEGMENT_PATH
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_useragent: Firefox 3.6
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_useragent: Mac OS X
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_init_session: Not Implemented
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_dbopen: mysql_pconnect
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|app: admin Initialized
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|app: admin Function: login
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|get_css / file: $file
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|get_css / file: $file
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|get_css / file: $file
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|get_js / file: $file
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|app: admin Terminated
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|_dbclose CLOSED
20100317205013|127.0.0.1|INFO|2010-03-17 20:50:13|pasteboard.Complete (0.14 seconds)
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205013|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:13|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205013|127.0.0.1|INCLUDE|2010-03-17 20:50:13|helper: diagnostics_helper, format_diagnostics
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|pasteboard.Started
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: useragents-config
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: dates-config
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: fopen-config
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: stopwords-config
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-database
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-useragent
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-hooks
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-sessions
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-cache
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-scaffolding
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-errors
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-uri
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|library: pb-logs
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_set_timezone: US/Pacific
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_sitewhoami: default Initialized
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_uri_segment: SEGMENT_PATH
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_useragent: Firefox 3.6
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_useragent: Mac OS X
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_init_session: Not Implemented
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_dbopen: mysql_pconnect
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|app: admin Initialized
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|app: admin Function: login
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|get_css / file: $file
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|get_css / file: $file
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|get_css / file: $file
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|get_js / file: $file
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|app: admin Terminated
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|_dbclose CLOSED
20100317205036|127.0.0.1|INFO|2010-03-17 20:50:36|pasteboard.Complete (0.489 seconds)
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205036|127.0.0.1|__ERROR_WARNING|2010-03-17 20:50:36|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205036|127.0.0.1|INCLUDE|2010-03-17 20:50:36|helper: diagnostics_helper, format_diagnostics
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|pasteboard.Started
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: useragents-config
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: dates-config
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: fopen-config
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: stopwords-config
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-database
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-useragent
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-hooks
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-sessions
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-cache
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-scaffolding
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-errors
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-uri
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|library: pb-logs
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_set_timezone: US/Pacific
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_sitewhoami: default Initialized
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_uri_segment: SEGMENT_PATH
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_useragent: Firefox 3.6
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_useragent: Mac OS X
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_init_session: Not Implemented
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_dbopen: mysql_pconnect
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|app: admin Initialized
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|app: admin Function: login
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|get_css / file: $file
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|get_css / file: $file
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|get_css / file: $file
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|get_js / file: $file
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|app: admin Terminated
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|_dbclose CLOSED
20100317205108|127.0.0.1|INFO|2010-03-17 20:51:08|pasteboard.Complete (0.939 seconds)
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205108|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:08|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205108|127.0.0.1|INCLUDE|2010-03-17 20:51:08|helper: diagnostics_helper, format_diagnostics
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|pasteboard.Started
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: useragents-config
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: dates-config
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: fopen-config
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: stopwords-config
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-database
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-useragent
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-hooks
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-sessions
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-cache
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-scaffolding
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-errors
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-uri
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|library: pb-logs
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_set_timezone: US/Pacific
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_sitewhoami: default Initialized
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_uri_segment: SEGMENT_PATH
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_useragent: Firefox 3.6
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_useragent: Mac OS X
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_init_session: Not Implemented
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_dbopen: mysql_pconnect
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|app: admin Initialized
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|app: admin Function: login
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|get_css / file: $file
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|get_css / file: $file
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|get_css / file: $file
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|get_js / file: $file
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|app: admin Terminated
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|_dbclose CLOSED
20100317205122|127.0.0.1|INFO|2010-03-17 20:51:22|pasteboard.Complete (0.637 seconds)
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205122|127.0.0.1|__ERROR_WARNING|2010-03-17 20:51:22|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205122|127.0.0.1|INCLUDE|2010-03-17 20:51:22|helper: diagnostics_helper, format_diagnostics
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|pasteboard.Started
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: useragents-config
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: dates-config
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: fopen-config
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: stopwords-config
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-database
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-useragent
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-hooks
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-sessions
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-cache
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-scaffolding
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-errors
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-uri
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|library: pb-logs
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_set_timezone: US/Pacific
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_sitewhoami: default Initialized
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_uri_segment: SEGMENT_PATH
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_useragent: Firefox 3.6
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_useragent: Mac OS X
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_init_session: Not Implemented
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_dbopen: mysql_pconnect
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|app: admin Initialized
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|app: admin Function: login
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|get_css / file: $file
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|get_css / file: $file
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|get_css / file: $file
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|get_js / file: $file
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|app: admin Terminated
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|_dbclose CLOSED
20100317205254|127.0.0.1|INFO|2010-03-17 20:52:54|pasteboard.Complete (0.583 seconds)
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205254|127.0.0.1|__ERROR_WARNING|2010-03-17 20:52:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205254|127.0.0.1|INCLUDE|2010-03-17 20:52:54|helper: diagnostics_helper, format_diagnostics
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|pasteboard.Started
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: useragents-config
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: dates-config
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: fopen-config
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: stopwords-config
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-database
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-useragent
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-hooks
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-sessions
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-cache
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-scaffolding
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-errors
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-uri
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|library: pb-logs
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_set_timezone: US/Pacific
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_sitewhoami: default Initialized
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_uri_segment: SEGMENT_PATH
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_useragent: Firefox 3.6
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_useragent: Mac OS X
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_init_session: Not Implemented
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_dbopen: mysql_pconnect
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|app: admin Initialized
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|app: admin Function: login
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|get_css / file: $file
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|get_css / file: $file
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|get_css / file: $file
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|get_js / file: $file
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|app: admin Terminated
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|_dbclose CLOSED
20100317205354|127.0.0.1|INFO|2010-03-17 20:53:54|pasteboard.Complete (0.715 seconds)
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205354|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205354|127.0.0.1|INCLUDE|2010-03-17 20:53:54|helper: diagnostics_helper, format_diagnostics
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|pasteboard.Started
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: useragents-config
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: dates-config
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: fopen-config
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: stopwords-config
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-database
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-useragent
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-hooks
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-sessions
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-cache
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-scaffolding
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-errors
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-uri
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|library: pb-logs
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_set_timezone: US/Pacific
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_sitewhoami: default Initialized
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_uri_segment: SEGMENT_PATH
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_useragent: Firefox 3.6
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_useragent: Mac OS X
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_init_session: Not Implemented
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_dbopen: mysql_pconnect
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|app: admin Initialized
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|app: admin Function: login
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|get_css / file: $file
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|get_css / file: $file
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|get_css / file: $file
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|get_js / file: $file
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|app: admin Terminated
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|_dbclose CLOSED
20100317205355|127.0.0.1|INFO|2010-03-17 20:53:55|pasteboard.Complete (0.802 seconds)
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205355|127.0.0.1|__ERROR_WARNING|2010-03-17 20:53:55|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205355|127.0.0.1|INCLUDE|2010-03-17 20:53:55|helper: diagnostics_helper, format_diagnostics
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|pasteboard.Started
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: useragents-config
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: dates-config
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: fopen-config
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: stopwords-config
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-database
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-useragent
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-hooks
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-sessions
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-cache
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-scaffolding
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-errors
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-uri
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|library: pb-logs
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_set_timezone: US/Pacific
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_sitewhoami: default Initialized
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_uri_segment: SEGMENT_PATH
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_useragent: Firefox 3.6
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_useragent: Mac OS X
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_init_session: Not Implemented
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_dbopen: mysql_pconnect
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|app: admin Initialized
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|app: admin Function: login
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|get_css / file: $file
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|get_css / file: $file
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|get_css / file: $file
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|get_js / file: $file
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|app: admin Terminated
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|_dbclose CLOSED
20100317205658|127.0.0.1|INFO|2010-03-17 20:56:58|pasteboard.Complete (0.915 seconds)
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205658|127.0.0.1|__ERROR_WARNING|2010-03-17 20:56:58|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205658|127.0.0.1|INCLUDE|2010-03-17 20:56:58|helper: diagnostics_helper, format_diagnostics
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|pasteboard.Started
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: useragents-config
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: dates-config
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: fopen-config
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: stopwords-config
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-database
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-useragent
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-hooks
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-sessions
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-cache
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-scaffolding
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-errors
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-uri
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|library: pb-logs
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_set_timezone: US/Pacific
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_sitewhoami: default Initialized
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_uri_segment: SEGMENT_PATH
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_useragent: Firefox 3.6
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_useragent: Mac OS X
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_init_session: Not Implemented
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_dbopen: mysql_pconnect
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|app: admin Initialized
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|app: admin Function: login
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|get_css / file: $file
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|get_css / file: $file
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|get_css / file: $file
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|get_js / file: $file
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|app: admin Terminated
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|_dbclose CLOSED
20100317205707|127.0.0.1|INFO|2010-03-17 20:57:07|pasteboard.Complete (0.989 seconds)
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 179]
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 230]
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 236]
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 249]
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205707|127.0.0.1|__ERROR_WARNING|2010-03-17 20:57:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 258]
20100317205707|127.0.0.1|INCLUDE|2010-03-17 20:57:07|helper: diagnostics_helper, format_diagnostics
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|pasteboard.Started
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: useragents-config
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: dates-config
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: fopen-config
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: stopwords-config
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-database
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-useragent
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-hooks
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-sessions
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-cache
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-scaffolding
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-errors
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-uri
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-logs
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_set_timezone: US/Pacific
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_sitewhoami: default Initialized
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_uri_segment: SEGMENT_PATH
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_useragent: Firefox 3.6
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_useragent: Mac OS X
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_init_session: Not Implemented
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_dbopen: mysql_pconnect
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|app: admin Initialized
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317213451|127.0.0.1|SQL|2010-03-17 21:34:51|SQL_logged from _auth, 31
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|BAD_LOGIN_ATTEMPT-> Line 57-> function: _auth-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|pasteboard.Started
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: useragents-config
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: dates-config
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: fopen-config
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: stopwords-config
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-database
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-useragent
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-hooks
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-sessions
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-cache
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-scaffolding
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-errors
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-uri
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|library: pb-logs
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_set_timezone: US/Pacific
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_sitewhoami: default Initialized
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_useragent: Firefox 3.6
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_useragent: Mac OS X
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_init_session: Not Implemented
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_dbopen: mysql_pconnect
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|app: admin Initialized
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|app: admin Function: login
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|get_css / file: $file
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|get_css / file: $file
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|get_css / file: $file
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|get_js / file: $file
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|app: admin Terminated
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|_dbclose CLOSED
20100317213451|127.0.0.1|INFO|2010-03-17 21:34:51|pasteboard.Complete (0.687 seconds)
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317213451|127.0.0.1|__ERROR_WARNING|2010-03-17 21:34:51|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317213451|127.0.0.1|INCLUDE|2010-03-17 21:34:51|helper: diagnostics_helper, format_diagnostics
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|pasteboard.Started
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: useragents-config
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: dates-config
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: fopen-config
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: stopwords-config
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-database
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-useragent
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-hooks
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-sessions
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-cache
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-scaffolding
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-errors
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-uri
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-logs
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_set_timezone: US/Pacific
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_sitewhoami: default Initialized
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_uri_segment: SEGMENT_PATH
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_useragent: Firefox 3.6
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_useragent: Mac OS X
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_init_session: Not Implemented
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_dbopen: mysql_pconnect
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|app: admin Initialized
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317215128|127.0.0.1|SQL|2010-03-17 21:51:28|SQL_logged from _auth, 31
20100317215128|127.0.0.1|LOGIN|2010-03-17 21:51:28|model: auth_model.php Function: _auth
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|pasteboard.Started
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: useragents-config
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: dates-config
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: fopen-config
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: stopwords-config
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-database
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-useragent
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-hooks
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-sessions
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-cache
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-scaffolding
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-errors
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-uri
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|library: pb-logs
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_set_timezone: US/Pacific
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_sitewhoami: default Initialized
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_uri_segment: SEGMENT_PATH
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_useragent: Firefox 3.6
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_useragent: Mac OS X
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_init_session: Not Implemented
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_dbopen: mysql_pconnect
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|app: admin Initialized
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|app: admin Function: dashboard
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|get_css / file: $file
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|get_css / file: $file
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|get_css / file: $file
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|app: admin Terminated
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|_dbclose CLOSED
20100317215128|127.0.0.1|INFO|2010-03-17 21:51:28|pasteboard.Complete (0.288 seconds)
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215128|127.0.0.1|__ERROR_WARNING|2010-03-17 21:51:28|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215128|127.0.0.1|INCLUDE|2010-03-17 21:51:28|helper: diagnostics_helper, format_diagnostics
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|pasteboard.Started
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: useragents-config
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: dates-config
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: fopen-config
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: stopwords-config
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-database
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-useragent
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-hooks
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-sessions
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-cache
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-scaffolding
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-errors
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-uri
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|library: pb-logs
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_set_timezone: US/Pacific
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_sitewhoami: default Initialized
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_uri_segment: SEGMENT_PATH
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_useragent: Firefox 3.6
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_useragent: Mac OS X
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_init_session: Not Implemented
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_dbopen: mysql_pconnect
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|app: admin Initialized
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|app: admin Function: dashboard
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|get_css / file: $file
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|get_css / file: $file
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|get_css / file: $file
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|app: admin Terminated
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|_dbclose CLOSED
20100317215345|127.0.0.1|INFO|2010-03-17 21:53:45|pasteboard.Complete (1.009 seconds)
20100317215345|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:45|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215345|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215345|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317215345|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215345|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215345|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317215345|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215345|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215345|127.0.0.1|INCLUDE|2010-03-17 21:53:45|helper: diagnostics_helper, format_diagnostics
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|pasteboard.Started
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: useragents-config
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: dates-config
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: fopen-config
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: stopwords-config
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-database
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-useragent
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-hooks
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-sessions
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-cache
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-scaffolding
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-errors
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-uri
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|library: pb-logs
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_set_timezone: US/Pacific
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_sitewhoami: default Initialized
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_uri_segment: SEGMENT_PATH
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_useragent: Firefox 3.6
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_useragent: Mac OS X
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_init_session: Not Implemented
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_dbopen: mysql_pconnect
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|app: admin Initialized
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|app: admin Function: logout
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|get_css / file: $file
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|get_css / file: $file
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|get_css / file: $file
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|get_js / file: $file
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|app: admin Terminated
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|_dbclose CLOSED
20100317215347|127.0.0.1|INFO|2010-03-17 21:53:47|pasteboard.Complete (0.544 seconds)
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215347|127.0.0.1|__ERROR_WARNING|2010-03-17 21:53:47|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215347|127.0.0.1|INCLUDE|2010-03-17 21:53:47|helper: diagnostics_helper, format_diagnostics
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|pasteboard.Started
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: useragents-config
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: dates-config
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: fopen-config
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: stopwords-config
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-database
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-useragent
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-hooks
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-sessions
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-cache
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-scaffolding
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-errors
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-uri
20100317215403|127.0.0.1|INCLUDE|2010-03-17 21:54:03|library: pb-logs
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|_set_timezone: US/Pacific
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|_sitewhoami: default Initialized
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|_uri_segment: SEGMENT_PATH
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|_useragent: Firefox 3.6
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|_useragent: Mac OS X
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|_init_session: Not Implemented
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|_dbopen: mysql_pconnect
20100317215403|127.0.0.1|INFO|2010-03-17 21:54:03|app: admin Initialized
20100317215403|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:03|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317215403|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:03|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317215403|127.0.0.1|SQL|2010-03-17 21:54:03|SQL_logged from _auth, 31
20100317215403|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:03|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 40]
20100317215403|127.0.0.1|LOGIN|2010-03-17 21:54:03|model: auth_model.php Function: _auth
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|pasteboard.Started
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: useragents-config
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: dates-config
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: fopen-config
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: stopwords-config
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-database
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-useragent
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-hooks
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-sessions
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-cache
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-scaffolding
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-errors
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-uri
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|library: pb-logs
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_set_timezone: US/Pacific
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_sitewhoami: default Initialized
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_uri_segment: SEGMENT_PATH
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_useragent: Firefox 3.6
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_useragent: Mac OS X
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_init_session: Not Implemented
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_dbopen: mysql_pconnect
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|app: admin Initialized
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|app: admin Function: dashboard
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|get_css / file: $file
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|get_css / file: $file
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|get_css / file: $file
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|app: admin Terminated
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|_dbclose CLOSED
20100317215404|127.0.0.1|INFO|2010-03-17 21:54:04|pasteboard.Complete (0.114 seconds)
20100317215404|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:04|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215404|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215404|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317215404|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:04|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215404|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215404|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:04|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317215404|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:04|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215404|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:04|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215404|127.0.0.1|INCLUDE|2010-03-17 21:54:04|helper: diagnostics_helper, format_diagnostics
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|pasteboard.Started
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: useragents-config
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: dates-config
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: fopen-config
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: stopwords-config
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-database
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-useragent
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-hooks
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-sessions
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-cache
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-scaffolding
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-errors
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-uri
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|library: pb-logs
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_set_timezone: US/Pacific
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_sitewhoami: default Initialized
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_uri_segment: SEGMENT_PATH
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_useragent: Firefox 3.6
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_useragent: Mac OS X
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_init_session: Not Implemented
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_dbopen: mysql_pconnect
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|app: admin Initialized
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|app: admin Function: logout
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|get_css / file: $file
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|get_css / file: $file
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|get_css / file: $file
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|get_js / file: $file
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|app: admin Terminated
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|_dbclose CLOSED
20100317215421|127.0.0.1|INFO|2010-03-17 21:54:21|pasteboard.Complete (0.697 seconds)
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215421|127.0.0.1|__ERROR_WARNING|2010-03-17 21:54:21|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215421|127.0.0.1|INCLUDE|2010-03-17 21:54:21|helper: diagnostics_helper, format_diagnostics
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|pasteboard.Started
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: useragents-config
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: dates-config
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: fopen-config
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: stopwords-config
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-database
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-useragent
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-hooks
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-sessions
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-cache
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-scaffolding
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-errors
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-uri
20100317215549|127.0.0.1|INCLUDE|2010-03-17 21:55:49|library: pb-logs
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|_set_timezone: US/Pacific
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|_sitewhoami: default Initialized
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|_uri_segment: SEGMENT_PATH
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|_useragent: Firefox 3.6
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|_useragent: Mac OS X
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|_init_session: Not Implemented
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|_dbopen: mysql_pconnect
20100317215549|127.0.0.1|INFO|2010-03-17 21:55:49|app: admin Initialized
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|pasteboard.Started
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: useragents-config
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: dates-config
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: fopen-config
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: stopwords-config
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-database
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-useragent
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-hooks
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-sessions
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-cache
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-scaffolding
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-errors
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-uri
20100317215637|127.0.0.1|INCLUDE|2010-03-17 21:56:37|library: pb-logs
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|_set_timezone: US/Pacific
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|_sitewhoami: default Initialized
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|_uri_segment: SEGMENT_PATH
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|_useragent: Firefox 3.6
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|_useragent: Mac OS X
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|_init_session: Not Implemented
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|_dbopen: mysql_pconnect
20100317215637|127.0.0.1|INFO|2010-03-17 21:56:37|app: admin Initialized
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|pasteboard.Started
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: useragents-config
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: dates-config
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: fopen-config
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: stopwords-config
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-database
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-useragent
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-hooks
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-sessions
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-cache
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-scaffolding
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-errors
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-uri
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-logs
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_set_timezone: US/Pacific
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_sitewhoami: default Initialized
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_uri_segment: SEGMENT_PATH
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_useragent: Firefox 3.6
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_useragent: Mac OS X
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_init_session: Not Implemented
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_dbopen: mysql_pconnect
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|app: admin Initialized
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 27]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: LOG [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[2, E_WARNING] fopen() [<a href='function.fopen'>function.fopen</a>]: Filename cannot be empty [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 31]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 32]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[2, E_WARNING] fwrite() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 33]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[2, E_WARNING] flock() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 34]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[2, E_WARNING] fclose() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-logs.php, 35]
20100317215707|127.0.0.1|SQL|2010-03-17 21:57:07|SQL_logged from _auth, 31
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 40]
20100317215707|127.0.0.1|LOGIN|2010-03-17 21:57:07|model: auth_model.php Function: _auth
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|pasteboard.Started
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: useragents-config
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: dates-config
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: fopen-config
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: stopwords-config
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-database
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-useragent
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-hooks
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-sessions
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-cache
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-scaffolding
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-errors
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-uri
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|library: pb-logs
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_set_timezone: US/Pacific
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_sitewhoami: default Initialized
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_uri_segment: SEGMENT_PATH
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_useragent: Firefox 3.6
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_useragent: Mac OS X
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_init_session: Not Implemented
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_dbopen: mysql_pconnect
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|app: admin Initialized
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|app: admin Function: dashboard
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|get_css / file: $file
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|get_css / file: $file
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|get_css / file: $file
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|app: admin Terminated
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|_dbclose CLOSED
20100317215707|127.0.0.1|INFO|2010-03-17 21:57:07|pasteboard.Complete (0.998 seconds)
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215707|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:07|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215707|127.0.0.1|INCLUDE|2010-03-17 21:57:07|helper: diagnostics_helper, format_diagnostics
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|pasteboard.Started
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: useragents-config
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: dates-config
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: fopen-config
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: stopwords-config
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-database
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-useragent
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-hooks
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-sessions
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-cache
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-scaffolding
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-errors
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-uri
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|library: pb-logs
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_set_timezone: US/Pacific
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_sitewhoami: default Initialized
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_uri_segment: SEGMENT_PATH
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_useragent: Firefox 3.6
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_useragent: Mac OS X
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_init_session: Not Implemented
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_dbopen: mysql_pconnect
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|app: admin Initialized
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|app: admin Function: logout
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|get_css / file: $file
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|get_css / file: $file
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|get_css / file: $file
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|get_js / file: $file
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|app: admin Terminated
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|_dbclose CLOSED
20100317215732|127.0.0.1|INFO|2010-03-17 21:57:32|pasteboard.Complete (0.34 seconds)
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215732|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:32|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215732|127.0.0.1|INCLUDE|2010-03-17 21:57:32|helper: diagnostics_helper, format_diagnostics
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|pasteboard.Started
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: useragents-config
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: dates-config
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: fopen-config
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: stopwords-config
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-database
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-useragent
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-hooks
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-sessions
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-cache
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-scaffolding
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-errors
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-uri
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-logs
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_set_timezone: US/Pacific
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_sitewhoami: default Initialized
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_uri_segment: SEGMENT_PATH
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_useragent: Firefox 3.6
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_useragent: Mac OS X
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_init_session: Not Implemented
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_dbopen: mysql_pconnect
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|app: admin Initialized
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317215742|127.0.0.1|SQL|2010-03-17 21:57:42|SQL_logged from _auth, 31
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 40]
20100317215742|127.0.0.1|LOGIN|2010-03-17 21:57:42|model: auth_model.php Function: _auth
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|pasteboard.Started
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: useragents-config
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: dates-config
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: fopen-config
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: stopwords-config
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-database
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-useragent
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-hooks
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-sessions
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-cache
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-scaffolding
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-errors
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-uri
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|library: pb-logs
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_set_timezone: US/Pacific
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_sitewhoami: default Initialized
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_uri_segment: SEGMENT_PATH
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_useragent: Firefox 3.6
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_useragent: Mac OS X
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_init_session: Not Implemented
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_dbopen: mysql_pconnect
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|app: admin Initialized
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|app: admin Function: dashboard
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|get_css / file: $file
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|get_css / file: $file
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|get_css / file: $file
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|app: admin Terminated
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|_dbclose CLOSED
20100317215742|127.0.0.1|INFO|2010-03-17 21:57:42|pasteboard.Complete (0.521 seconds)
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215742|127.0.0.1|__ERROR_WARNING|2010-03-17 21:57:42|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317215742|127.0.0.1|INCLUDE|2010-03-17 21:57:42|helper: diagnostics_helper, format_diagnostics
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|pasteboard.Started
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: useragents-config
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: dates-config
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: fopen-config
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: stopwords-config
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-database
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-useragent
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-hooks
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-sessions
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-cache
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-scaffolding
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-errors
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-uri
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|library: pb-logs
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_set_timezone: US/Pacific
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_sitewhoami: default Initialized
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_uri_segment: SEGMENT_PATH
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_useragent: Firefox 3.6
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_useragent: Mac OS X
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_init_session: Not Implemented
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_dbopen: mysql_pconnect
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|app: admin Initialized
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|app: admin Function: logout
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|get_css / file: $file
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|get_css / file: $file
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|get_css / file: $file
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|get_js / file: $file
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|app: admin Terminated
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|_dbclose CLOSED
20100317220114|127.0.0.1|INFO|2010-03-17 22:01:14|pasteboard.Complete (1.032 seconds)
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220114|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:14|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220114|127.0.0.1|INCLUDE|2010-03-17 22:01:14|helper: diagnostics_helper, format_diagnostics
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|pasteboard.Started
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: useragents-config
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: dates-config
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: fopen-config
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: stopwords-config
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-database
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-useragent
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-hooks
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-sessions
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-cache
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-scaffolding
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-errors
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-uri
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-logs
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_set_timezone: US/Pacific
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_sitewhoami: default Initialized
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_uri_segment: SEGMENT_PATH
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_useragent: Firefox 3.6
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_useragent: Mac OS X
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_init_session: Not Implemented
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_dbopen: mysql_pconnect
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|app: admin Initialized
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317220127|127.0.0.1|SQL|2010-03-17 22:01:27|SQL_logged from _auth, 32
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|BAD_LOGIN_ATTEMPT-> Line 62-> function: _auth-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|pasteboard.Started
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: useragents-config
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: dates-config
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: fopen-config
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: stopwords-config
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-database
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-useragent
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-hooks
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-sessions
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-cache
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-scaffolding
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-errors
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-uri
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|library: pb-logs
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_set_timezone: US/Pacific
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_sitewhoami: default Initialized
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_uri_segment: SEGMENT_PATH_WITH_QUERY_STRING
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_useragent: Firefox 3.6
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_useragent: Mac OS X
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_init_session: Not Implemented
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_dbopen: mysql_pconnect
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|app: admin Initialized
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|app: admin Function: login
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|get_css / file: $file
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|get_css / file: $file
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|get_css / file: $file
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|get_js / file: $file
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|app: admin Terminated
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|_dbclose CLOSED
20100317220127|127.0.0.1|INFO|2010-03-17 22:01:27|pasteboard.Complete (1.02 seconds)
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220127|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220127|127.0.0.1|INCLUDE|2010-03-17 22:01:27|helper: diagnostics_helper, format_diagnostics
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|pasteboard.Started
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: useragents-config
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: dates-config
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: fopen-config
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: stopwords-config
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-database
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-useragent
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-hooks
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-sessions
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-cache
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-scaffolding
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-errors
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-uri
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-logs
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_set_timezone: US/Pacific
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_sitewhoami: default Initialized
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_uri_segment: SEGMENT_PATH
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_useragent: Firefox 3.6
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_useragent: Mac OS X
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_init_session: Not Implemented
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_dbopen: mysql_pconnect
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|app: admin Initialized
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317220135|127.0.0.1|SQL|2010-03-17 22:01:35|SQL_logged from _auth, 32
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 42]
20100317220135|127.0.0.1|LOGIN|2010-03-17 22:01:35|model: auth_model.php Function: _auth
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|pasteboard.Started
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: useragents-config
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: dates-config
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: fopen-config
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: stopwords-config
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-database
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-useragent
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-hooks
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-sessions
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-cache
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-scaffolding
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-errors
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-uri
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|library: pb-logs
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_set_timezone: US/Pacific
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_sitewhoami: default Initialized
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_uri_segment: SEGMENT_PATH
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_useragent: Firefox 3.6
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_useragent: Mac OS X
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_init_session: Not Implemented
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_dbopen: mysql_pconnect
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|app: admin Initialized
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|app: admin Function: dashboard
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|get_css / file: $file
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|get_css / file: $file
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|get_css / file: $file
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|app: admin Terminated
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|_dbclose CLOSED
20100317220135|127.0.0.1|INFO|2010-03-17 22:01:35|pasteboard.Complete (0.197 seconds)
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220135|127.0.0.1|__ERROR_WARNING|2010-03-17 22:01:35|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220135|127.0.0.1|INCLUDE|2010-03-17 22:01:35|helper: diagnostics_helper, format_diagnostics
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|pasteboard.Started
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: useragents-config
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: dates-config
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: fopen-config
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: stopwords-config
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-database
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-useragent
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-hooks
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-sessions
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-cache
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-scaffolding
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-errors
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-uri
20100317220449|127.0.0.1|INCLUDE|2010-03-17 22:04:49|library: pb-logs
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|_set_timezone: US/Pacific
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|_sitewhoami: default Initialized
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|_uri_segment: SEGMENT_PATH
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|_useragent: Firefox 3.6
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|_useragent: Mac OS X
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|_init_session: Not Implemented
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|_dbopen: mysql_pconnect
20100317220449|127.0.0.1|INFO|2010-03-17 22:04:49|app: admin Initialized
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|pasteboard.Started
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: useragents-config
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: dates-config
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: fopen-config
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: stopwords-config
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-database
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-useragent
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-hooks
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-sessions
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-cache
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-scaffolding
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-errors
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-uri
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|library: pb-logs
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_set_timezone: US/Pacific
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_sitewhoami: default Initialized
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_uri_segment: SEGMENT_PATH
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_useragent: Firefox 3.6
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_useragent: Mac OS X
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_init_session: Not Implemented
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_dbopen: mysql_pconnect
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|app: admin Initialized
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|app: admin Function: logout
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|get_css / file: $file
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|get_css / file: $file
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|get_css / file: $file
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|get_js / file: $file
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|app: admin Terminated
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|_dbclose CLOSED
20100317220518|127.0.0.1|INFO|2010-03-17 22:05:18|pasteboard.Complete (0.843 seconds)
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220518|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:18|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220518|127.0.0.1|INCLUDE|2010-03-17 22:05:18|helper: diagnostics_helper, format_diagnostics
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|pasteboard.Started
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: useragents-config
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: dates-config
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: fopen-config
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: stopwords-config
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-database
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-useragent
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-hooks
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-sessions
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-cache
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-scaffolding
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-errors
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-uri
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-logs
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_set_timezone: US/Pacific
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_sitewhoami: default Initialized
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_uri_segment: SEGMENT_PATH
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_useragent: Firefox 3.6
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_useragent: Mac OS X
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_init_session: Not Implemented
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_dbopen: mysql_pconnect
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|app: admin Initialized
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317220527|127.0.0.1|SQL|2010-03-17 22:05:27|SQL_logged from _auth, 32
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 49]
20100317220527|127.0.0.1|LOGIN|2010-03-17 22:05:27|model: auth_model.php Function: _auth
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|pasteboard.Started
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: useragents-config
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: dates-config
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: fopen-config
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: stopwords-config
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-database
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-useragent
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-hooks
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-sessions
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-cache
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-scaffolding
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-errors
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-uri
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|library: pb-logs
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_set_timezone: US/Pacific
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_sitewhoami: default Initialized
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_uri_segment: SEGMENT_PATH
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_useragent: Firefox 3.6
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_useragent: Mac OS X
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_init_session: Not Implemented
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_dbopen: mysql_pconnect
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|app: admin Initialized
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|app: admin Function: dashboard
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|get_css / file: $file
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|get_css / file: $file
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|get_css / file: $file
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|app: admin Terminated
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|_dbclose CLOSED
20100317220527|127.0.0.1|INFO|2010-03-17 22:05:27|pasteboard.Complete (0.431 seconds)
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220527|127.0.0.1|__ERROR_WARNING|2010-03-17 22:05:27|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220527|127.0.0.1|INCLUDE|2010-03-17 22:05:27|helper: diagnostics_helper, format_diagnostics
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|pasteboard.Started
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: useragents-config
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: dates-config
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: fopen-config
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: stopwords-config
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-database
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-useragent
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-hooks
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-sessions
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-cache
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-scaffolding
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-errors
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-uri
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|library: pb-logs
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_set_timezone: US/Pacific
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_sitewhoami: default Initialized
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_uri_segment: SEGMENT_PATH
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_useragent: Firefox 3.6
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_useragent: Mac OS X
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_init_session: Not Implemented
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_dbopen: mysql_pconnect
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|app: admin Initialized
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|app: admin Function: dashboard
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|get_css / file: $file
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|get_css / file: $file
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|get_css / file: $file
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|app: admin Terminated
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|_dbclose CLOSED
20100317220913|127.0.0.1|INFO|2010-03-17 22:09:13|pasteboard.Complete (0.656 seconds)
20100317220913|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:13|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220913|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:13|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220913|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:13|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317220913|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:13|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220913|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:13|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220913|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:13|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317220913|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:13|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220913|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:13|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220913|127.0.0.1|INCLUDE|2010-03-17 22:09:13|helper: diagnostics_helper, format_diagnostics
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|pasteboard.Started
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: useragents-config
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: dates-config
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: fopen-config
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: stopwords-config
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-database
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-useragent
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-hooks
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-sessions
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-cache
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-scaffolding
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-errors
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-uri
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|library: pb-logs
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_set_timezone: US/Pacific
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_sitewhoami: default Initialized
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_uri_segment: SEGMENT_PATH
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_useragent: Firefox 3.6
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_useragent: Mac OS X
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_init_session: Not Implemented
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_dbopen: mysql_pconnect
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|app: admin Initialized
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|app: admin Function: logout
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|get_css / file: $file
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|get_css / file: $file
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|get_css / file: $file
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|get_js / file: $file
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|app: admin Terminated
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|_dbclose CLOSED
20100317220917|127.0.0.1|INFO|2010-03-17 22:09:17|pasteboard.Complete (0.283 seconds)
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220917|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:17|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220917|127.0.0.1|INCLUDE|2010-03-17 22:09:17|helper: diagnostics_helper, format_diagnostics
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|pasteboard.Started
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: useragents-config
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: dates-config
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: fopen-config
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: stopwords-config
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-database
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-useragent
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-hooks
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-sessions
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-cache
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-scaffolding
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-errors
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-uri
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-logs
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_set_timezone: US/Pacific
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_sitewhoami: default Initialized
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_uri_segment: SEGMENT_PATH
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_useragent: Firefox 3.6
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_useragent: Mac OS X
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_init_session: Not Implemented
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_dbopen: mysql_pconnect
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|app: admin Initialized
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317220923|127.0.0.1|SQL|2010-03-17 22:09:23|SQL_logged from _auth, 32
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 49]
20100317220923|127.0.0.1|LOGIN|2010-03-17 22:09:23|model: auth_model.php Function: _auth
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|pasteboard.Started
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: useragents-config
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: dates-config
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: fopen-config
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: stopwords-config
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-database
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-useragent
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-hooks
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-sessions
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-cache
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-scaffolding
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-errors
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-uri
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|library: pb-logs
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_set_timezone: US/Pacific
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_sitewhoami: default Initialized
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_uri_segment: SEGMENT_PATH
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_useragent: Firefox 3.6
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_useragent: Mac OS X
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_init_session: Not Implemented
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_dbopen: mysql_pconnect
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|app: admin Initialized
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|app: admin Function: dashboard
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|get_css / file: $file
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|get_css / file: $file
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|get_css / file: $file
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|app: admin Terminated
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|_dbclose CLOSED
20100317220923|127.0.0.1|INFO|2010-03-17 22:09:23|pasteboard.Complete (0.48 seconds)
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220923|127.0.0.1|__ERROR_WARNING|2010-03-17 22:09:23|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317220923|127.0.0.1|INCLUDE|2010-03-17 22:09:23|helper: diagnostics_helper, format_diagnostics
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|pasteboard.Started
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: useragents-config
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: dates-config
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: fopen-config
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: stopwords-config
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-database
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-useragent
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-hooks
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-sessions
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-cache
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-scaffolding
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-errors
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-uri
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|library: pb-logs
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_set_timezone: US/Pacific
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_sitewhoami: default Initialized
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_uri_segment: SEGMENT_PATH
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_useragent: Firefox 3.6
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_useragent: Mac OS X
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_init_session: Not Implemented
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_dbopen: mysql_pconnect
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|app: admin Initialized
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|app: admin Function: logout
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|get_css / file: $file
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|get_css / file: $file
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|get_css / file: $file
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|get_js / file: $file
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|app: admin Terminated
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|_dbclose CLOSED
20100317221054|127.0.0.1|INFO|2010-03-17 22:10:54|pasteboard.Complete (0.091 seconds)
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221054|127.0.0.1|__ERROR_WARNING|2010-03-17 22:10:54|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221054|127.0.0.1|INCLUDE|2010-03-17 22:10:54|helper: diagnostics_helper, format_diagnostics
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|pasteboard.Started
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: useragents-config
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: dates-config
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: fopen-config
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: stopwords-config
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-database
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-useragent
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-hooks
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-sessions
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-cache
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-scaffolding
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-errors
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-uri
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-logs
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_set_timezone: US/Pacific
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_sitewhoami: default Initialized
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_uri_segment: SEGMENT_PATH
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_useragent: Firefox 3.6
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_useragent: Mac OS X
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_init_session: Not Implemented
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_dbopen: mysql_pconnect
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|app: admin Initialized
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317221101|127.0.0.1|SQL|2010-03-17 22:11:01|SQL_logged from _auth, 32
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 49]
20100317221101|127.0.0.1|LOGIN|2010-03-17 22:11:01|model: auth_model.php Function: _auth
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|pasteboard.Started
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: useragents-config
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: dates-config
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: fopen-config
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: stopwords-config
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-database
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-useragent
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-hooks
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-sessions
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-cache
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-scaffolding
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-errors
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-uri
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|library: pb-logs
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_set_timezone: US/Pacific
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_sitewhoami: default Initialized
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_uri_segment: SEGMENT_PATH
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_useragent: Firefox 3.6
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_useragent: Mac OS X
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_init_session: Not Implemented
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_dbopen: mysql_pconnect
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|app: admin Initialized
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|app: admin Function: dashboard
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|get_css / file: $file
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|get_css / file: $file
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|get_css / file: $file
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|app: admin Terminated
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|_dbclose CLOSED
20100317221101|127.0.0.1|INFO|2010-03-17 22:11:01|pasteboard.Complete (0.599 seconds)
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221101|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:01|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221101|127.0.0.1|INCLUDE|2010-03-17 22:11:01|helper: diagnostics_helper, format_diagnostics
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|pasteboard.Started
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: useragents-config
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: dates-config
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: fopen-config
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: stopwords-config
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-database
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-useragent
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-hooks
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-sessions
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-cache
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-scaffolding
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-errors
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-uri
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|library: pb-logs
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_set_timezone: US/Pacific
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_sitewhoami: default Initialized
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_uri_segment: SEGMENT_PATH
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_useragent: Firefox 3.6
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_useragent: Mac OS X
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_init_session: Not Implemented
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_dbopen: mysql_pconnect
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|app: admin Initialized
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|app: admin Function: logout
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|get_css / file: $file
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|get_css / file: $file
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|get_css / file: $file
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|get_js / file: $file
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|app: admin Terminated
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|_dbclose CLOSED
20100317221145|127.0.0.1|INFO|2010-03-17 22:11:45|pasteboard.Complete (0.408 seconds)
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221145|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:45|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221145|127.0.0.1|INCLUDE|2010-03-17 22:11:45|helper: diagnostics_helper, format_diagnostics
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|pasteboard.Started
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: useragents-config
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: dates-config
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: fopen-config
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: stopwords-config
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-database
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-useragent
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-hooks
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-sessions
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-cache
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-scaffolding
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-errors
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-uri
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-logs
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_set_timezone: US/Pacific
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_sitewhoami: default Initialized
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_uri_segment: SEGMENT_PATH
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_useragent: Firefox 3.6
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_useragent: Mac OS X
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_init_session: Not Implemented
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_dbopen: mysql_pconnect
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|app: admin Initialized
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8, E_NOTICE] Undefined index: result [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/admin_controller.php, 189]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8192, UNKNOWN_ERROR_TYPE] Function ereg() is deprecated [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/email_helper.php, 47]
20100317221150|127.0.0.1|SQL|2010-03-17 22:11:50|SQL_logged from _auth, 32
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 49]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8, E_NOTICE] Undefined index: password [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-sites/default/apps/admin/models/auth_model.php, 49]
20100317221150|127.0.0.1|LOGIN|2010-03-17 22:11:50|model: auth_model.php Function: _auth
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|pasteboard.Started
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: useragents-config
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: dates-config
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: fopen-config
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: stopwords-config
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-database
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-useragent
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-hooks
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-sessions
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-cache
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-scaffolding
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-errors
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-uri
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|library: pb-logs
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_set_timezone: US/Pacific
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_sitewhoami: default Initialized
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_uri_segment: SEGMENT_PATH
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_useragent: Firefox 3.6
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_useragent: Mac OS X
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_init_session: Not Implemented
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_dbopen: mysql_pconnect
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|app: admin Initialized
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|app: admin Function: dashboard
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|get_css / file: $file
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|get_css / file: $file
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|get_css / file: $file
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|app: admin Terminated
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|_dbclose CLOSED
20100317221150|127.0.0.1|INFO|2010-03-17 22:11:50|pasteboard.Complete (0.64 seconds)
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221150|127.0.0.1|__ERROR_WARNING|2010-03-17 22:11:50|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221150|127.0.0.1|INCLUDE|2010-03-17 22:11:50|helper: diagnostics_helper, format_diagnostics
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|pasteboard.Started
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: useragents-config
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: dates-config
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: fopen-config
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: stopwords-config
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-database
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-useragent
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-hooks
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-sessions
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-cache
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-scaffolding
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-errors
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-uri
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|library: pb-logs
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_set_timezone: US/Pacific
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_sitewhoami: default Initialized
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_uri_segment: SEGMENT_PATH
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_useragent: Firefox 3.6
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_useragent: Mac OS X
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_init_session: Not Implemented
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_dbopen: mysql_pconnect
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|app: admin Initialized
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|app: admin Function: logout
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|No favicon FILE FOUND-> Line 352-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|get_css / file: $file
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|get_css / file: $file
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|get_css / file: $file
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|get_js / file: $file
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|app: admin Terminated
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|_dbclose CLOSED
20100317221211|127.0.0.1|INFO|2010-03-17 22:12:11|pasteboard.Complete (0.108 seconds)
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|[8, E_NOTICE] Undefined index: SESSION [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 177]
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 228]
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|[8, E_NOTICE] Undefined index: SQL [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 234]
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 247]
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|[8, E_NOTICE] Undefined index: SQLog [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221211|127.0.0.1|__ERROR_WARNING|2010-03-17 22:12:11|[2, E_WARNING] Invalid argument supplied for foreach() [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-helpers/diagnostics_helper.php, 256]
20100317221211|127.0.0.1|INCLUDE|2010-03-17 22:12:11|helper: diagnostics_helper, format_diagnostics
