20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|pasteboard.Started
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: useragents-config
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: dates-config
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: fopen-config
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: stopwords-config
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-database
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-useragent
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-hooks
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-sessions
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-cache
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-scaffolding
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-errors
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-uri
20101028122548|127.0.0.1|INCLUDE|2010-10-28 12:25:48|library: pb-logs
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_set_timezone: US/Pacific
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_sitewhoami: default Initialized
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_uri_segment: QUERY_STRING
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_useragent:  
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_useragent: 
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_init_session: Not Implemented
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_dbopen: mysql_pconnect
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028122548|127.0.0.1|SQL|2010-10-28 12:25:48|SQL_logged from show_404, 43
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|_dbclose CLOSED
20101028122548|127.0.0.1|INFO|2010-10-28 12:25:48|pasteboard.Complete (1.818 seconds)
20101028122548|127.0.0.1|__ERROR_WARNING|2010-10-28 12:25:48|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|pasteboard.Started
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: useragents-config
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: dates-config
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: fopen-config
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: stopwords-config
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-database
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-useragent
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-hooks
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-sessions
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-cache
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-scaffolding
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-errors
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-uri
20101028122640|127.0.0.1|INCLUDE|2010-10-28 12:26:40|library: pb-logs
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_set_timezone: US/Pacific
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_sitewhoami: default Initialized
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_uri_segment: QUERY_STRING
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_useragent:  
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_useragent: 
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_init_session: Not Implemented
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_dbopen: mysql_pconnect
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028122640|127.0.0.1|SQL|2010-10-28 12:26:40|SQL_logged from show_404, 43
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|_dbclose CLOSED
20101028122640|127.0.0.1|INFO|2010-10-28 12:26:40|pasteboard.Complete (1.141 seconds)
20101028122640|127.0.0.1|__ERROR_WARNING|2010-10-28 12:26:40|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|pasteboard.Started
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: useragents-config
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: dates-config
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: fopen-config
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: stopwords-config
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-database
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-useragent
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-hooks
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-sessions
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-cache
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-scaffolding
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-errors
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-uri
20101028123551|127.0.0.1|INCLUDE|2010-10-28 12:35:51|library: pb-logs
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_set_timezone: US/Pacific
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_sitewhoami: default Initialized
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_uri_segment: QUERY_STRING
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_useragent:  
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_useragent: 
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_init_session: Not Implemented
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_dbopen: mysql_pconnect
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028123551|127.0.0.1|SQL|2010-10-28 12:35:51|SQL_logged from show_404, 43
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|_dbclose CLOSED
20101028123551|127.0.0.1|INFO|2010-10-28 12:35:51|pasteboard.Complete (0.833 seconds)
20101028123551|127.0.0.1|__ERROR_WARNING|2010-10-28 12:35:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|pasteboard.Started
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: useragents-config
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: dates-config
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: fopen-config
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: stopwords-config
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-database
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-useragent
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-hooks
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-sessions
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-cache
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-scaffolding
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-errors
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-uri
20101028124552|127.0.0.1|INCLUDE|2010-10-28 12:45:52|library: pb-logs
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_set_timezone: US/Pacific
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_sitewhoami: default Initialized
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_uri_segment: QUERY_STRING
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_useragent:  
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_useragent: 
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_init_session: Not Implemented
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_dbopen: mysql_pconnect
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028124552|127.0.0.1|SQL|2010-10-28 12:45:52|SQL_logged from show_404, 43
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|_dbclose CLOSED
20101028124552|127.0.0.1|INFO|2010-10-28 12:45:52|pasteboard.Complete (0.126 seconds)
20101028124552|127.0.0.1|__ERROR_WARNING|2010-10-28 12:45:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|pasteboard.Started
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: useragents-config
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: dates-config
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: fopen-config
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: stopwords-config
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-database
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-useragent
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-hooks
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-sessions
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-cache
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-scaffolding
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-errors
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-uri
20101028125553|127.0.0.1|INCLUDE|2010-10-28 12:55:53|library: pb-logs
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_set_timezone: US/Pacific
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_sitewhoami: default Initialized
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_uri_segment: QUERY_STRING
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_useragent:  
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_useragent: 
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_init_session: Not Implemented
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_dbopen: mysql_pconnect
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028125553|127.0.0.1|SQL|2010-10-28 12:55:53|SQL_logged from show_404, 43
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|_dbclose CLOSED
20101028125553|127.0.0.1|INFO|2010-10-28 12:55:53|pasteboard.Complete (0.395 seconds)
20101028125553|127.0.0.1|__ERROR_WARNING|2010-10-28 12:55:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|pasteboard.Started
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: useragents-config
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: dates-config
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: fopen-config
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: stopwords-config
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-database
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-useragent
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-hooks
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-sessions
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-cache
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-scaffolding
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-errors
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-uri
20101028125642|127.0.0.1|INCLUDE|2010-10-28 12:56:42|library: pb-logs
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_set_timezone: US/Pacific
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_sitewhoami: default Initialized
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_uri_segment: QUERY_STRING
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_useragent:  
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_useragent: 
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_init_session: Not Implemented
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_dbopen: mysql_pconnect
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028125642|127.0.0.1|SQL|2010-10-28 12:56:42|SQL_logged from show_404, 43
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|_dbclose CLOSED
20101028125642|127.0.0.1|INFO|2010-10-28 12:56:42|pasteboard.Complete (0.534 seconds)
20101028125642|127.0.0.1|__ERROR_WARNING|2010-10-28 12:56:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|pasteboard.Started
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: useragents-config
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: dates-config
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: fopen-config
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: stopwords-config
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-database
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-useragent
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-hooks
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-sessions
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-cache
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-scaffolding
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-errors
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-uri
20101028130554|127.0.0.1|INCLUDE|2010-10-28 13:05:54|library: pb-logs
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_set_timezone: US/Pacific
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_sitewhoami: default Initialized
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_uri_segment: QUERY_STRING
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_useragent:  
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_useragent: 
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_init_session: Not Implemented
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_dbopen: mysql_pconnect
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028130554|127.0.0.1|SQL|2010-10-28 13:05:54|SQL_logged from show_404, 43
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|_dbclose CLOSED
20101028130554|127.0.0.1|INFO|2010-10-28 13:05:54|pasteboard.Complete (0.815 seconds)
20101028130554|127.0.0.1|__ERROR_WARNING|2010-10-28 13:05:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|pasteboard.Started
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: useragents-config
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: dates-config
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: fopen-config
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: stopwords-config
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-database
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-useragent
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-hooks
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-sessions
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-cache
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-scaffolding
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-errors
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-uri
20101028131555|127.0.0.1|INCLUDE|2010-10-28 13:15:55|library: pb-logs
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_set_timezone: US/Pacific
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_sitewhoami: default Initialized
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_uri_segment: QUERY_STRING
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_useragent:  
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_useragent: 
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_init_session: Not Implemented
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_dbopen: mysql_pconnect
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028131555|127.0.0.1|SQL|2010-10-28 13:15:55|SQL_logged from show_404, 43
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|_dbclose CLOSED
20101028131555|127.0.0.1|INFO|2010-10-28 13:15:55|pasteboard.Complete (1.247 seconds)
20101028131555|127.0.0.1|__ERROR_WARNING|2010-10-28 13:15:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|pasteboard.Started
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: useragents-config
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: dates-config
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: fopen-config
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: stopwords-config
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-database
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-useragent
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-hooks
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-sessions
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-cache
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-scaffolding
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-errors
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-uri
20101028132556|127.0.0.1|INCLUDE|2010-10-28 13:25:56|library: pb-logs
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_set_timezone: US/Pacific
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_sitewhoami: default Initialized
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_uri_segment: QUERY_STRING
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_useragent:  
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_useragent: 
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_init_session: Not Implemented
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_dbopen: mysql_pconnect
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028132556|127.0.0.1|SQL|2010-10-28 13:25:56|SQL_logged from show_404, 43
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|_dbclose CLOSED
20101028132556|127.0.0.1|INFO|2010-10-28 13:25:56|pasteboard.Complete (0.971 seconds)
20101028132556|127.0.0.1|__ERROR_WARNING|2010-10-28 13:25:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|pasteboard.Started
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: useragents-config
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: dates-config
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: fopen-config
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: stopwords-config
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-database
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-useragent
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-hooks
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-sessions
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-cache
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-scaffolding
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-errors
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-uri
20101028132643|127.0.0.1|INCLUDE|2010-10-28 13:26:43|library: pb-logs
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_set_timezone: US/Pacific
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_sitewhoami: default Initialized
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_uri_segment: QUERY_STRING
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_useragent:  
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_useragent: 
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_init_session: Not Implemented
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_dbopen: mysql_pconnect
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028132643|127.0.0.1|SQL|2010-10-28 13:26:43|SQL_logged from show_404, 43
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|_dbclose CLOSED
20101028132643|127.0.0.1|INFO|2010-10-28 13:26:43|pasteboard.Complete (0.167 seconds)
20101028132643|127.0.0.1|__ERROR_WARNING|2010-10-28 13:26:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|pasteboard.Started
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: useragents-config
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: dates-config
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: fopen-config
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: stopwords-config
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-database
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-useragent
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-hooks
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-sessions
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-cache
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-scaffolding
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-errors
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-uri
20101028133501|127.0.0.1|INCLUDE|2010-10-28 13:35:01|library: pb-logs
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_set_timezone: US/Pacific
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_sitewhoami: default Initialized
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_uri_segment: QUERY_STRING
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_useragent:  
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_useragent: 
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_init_session: Not Implemented
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_dbopen: mysql_pconnect
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101028133501|127.0.0.1|SQL|2010-10-28 13:35:01|SQL_logged from show_404, 43
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|_dbclose CLOSED
20101028133501|127.0.0.1|INFO|2010-10-28 13:35:01|pasteboard.Complete (0.411 seconds)
20101028133501|127.0.0.1|__ERROR_WARNING|2010-10-28 13:35:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
