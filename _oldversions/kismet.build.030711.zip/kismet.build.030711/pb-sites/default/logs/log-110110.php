20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|pasteboard.Started
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: useragents-config
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: dates-config
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: fopen-config
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: stopwords-config
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-database
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-useragent
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-hooks
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-sessions
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-cache
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-scaffolding
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-errors
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-uri
20101101095008|127.0.0.1|INCLUDE|2010-11-01 09:50:08|library: pb-logs
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_set_timezone: US/Pacific
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_sitewhoami: default Initialized
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_uri_segment: QUERY_STRING
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_useragent:  
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_useragent: 
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_init_session: Not Implemented
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_dbopen: mysql_pconnect
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101101095008|127.0.0.1|SQL|2010-11-01 09:50:08|SQL_logged from show_404, 43
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|_dbclose CLOSED
20101101095008|127.0.0.1|INFO|2010-11-01 09:50:08|pasteboard.Complete (1.08 seconds)
20101101095008|127.0.0.1|__ERROR_WARNING|2010-11-01 09:50:08|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|pasteboard.Started
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: useragents-config
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: dates-config
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: fopen-config
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: stopwords-config
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-database
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-useragent
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-hooks
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-sessions
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-cache
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-scaffolding
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-errors
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-uri
20101101095100|127.0.0.1|INCLUDE|2010-11-01 09:51:00|library: pb-logs
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_set_timezone: US/Pacific
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_sitewhoami: default Initialized
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_uri_segment: QUERY_STRING
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_useragent:  
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_useragent: 
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_init_session: Not Implemented
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_dbopen: mysql_pconnect
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101101095100|127.0.0.1|SQL|2010-11-01 09:51:00|SQL_logged from show_404, 43
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|_dbclose CLOSED
20101101095100|127.0.0.1|INFO|2010-11-01 09:51:00|pasteboard.Complete (0.127 seconds)
20101101095100|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|pasteboard.Started
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: useragents-config
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: dates-config
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: fopen-config
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: stopwords-config
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-database
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-useragent
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-hooks
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-sessions
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-cache
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-scaffolding
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-errors
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-uri
20101101095118|127.0.0.1|INCLUDE|2010-11-01 09:51:18|library: pb-logs
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_set_timezone: US/Pacific
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_sitewhoami: default Initialized
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_uri_segment: QUERY_STRING
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_useragent:  
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_useragent: 
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_init_session: Not Implemented
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_dbopen: mysql_pconnect
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101101095118|127.0.0.1|SQL|2010-11-01 09:51:18|SQL_logged from show_404, 43
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|_dbclose CLOSED
20101101095118|127.0.0.1|INFO|2010-11-01 09:51:18|pasteboard.Complete (0.216 seconds)
20101101095118|127.0.0.1|__ERROR_WARNING|2010-11-01 09:51:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|pasteboard.Started
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: useragents-config
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: dates-config
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: fopen-config
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: stopwords-config
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-database
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-useragent
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-hooks
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-sessions
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-cache
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-scaffolding
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-errors
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-uri
20101101100010|127.0.0.1|INCLUDE|2010-11-01 10:00:10|library: pb-logs
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_set_timezone: US/Pacific
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_sitewhoami: default Initialized
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_uri_segment: QUERY_STRING
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_useragent:  
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_useragent: 
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_init_session: Not Implemented
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_dbopen: mysql_pconnect
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101101100010|127.0.0.1|SQL|2010-11-01 10:00:10|SQL_logged from show_404, 43
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|_dbclose CLOSED
20101101100010|127.0.0.1|INFO|2010-11-01 10:00:10|pasteboard.Complete (0.755 seconds)
20101101100010|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:10|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|pasteboard.Started
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: useragents-config
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: dates-config
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: fopen-config
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: stopwords-config
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-database
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-useragent
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-hooks
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-sessions
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-cache
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-scaffolding
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-errors
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-uri
20101101100042|127.0.0.1|INCLUDE|2010-11-01 10:00:42|library: pb-logs
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_set_timezone: US/Pacific
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_sitewhoami: default Initialized
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_uri_segment: QUERY_STRING
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_useragent:  
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_useragent: 
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_init_session: Not Implemented
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:0) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_dbopen: mysql_pconnect
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20101101100042|127.0.0.1|SQL|2010-11-01 10:00:42|SQL_logged from show_404, 43
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|_dbclose CLOSED
20101101100042|127.0.0.1|INFO|2010-11-01 10:00:42|pasteboard.Complete (0.807 seconds)
20101101100042|127.0.0.1|__ERROR_WARNING|2010-11-01 10:00:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
