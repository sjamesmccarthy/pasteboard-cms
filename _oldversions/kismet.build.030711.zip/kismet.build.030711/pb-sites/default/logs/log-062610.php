20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|pasteboard.Started
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: useragents-config
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: dates-config
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: fopen-config
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: stopwords-config
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-database
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-useragent
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-hooks
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-sessions
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-cache
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-scaffolding
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-errors
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-uri
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|library: pb-logs
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_set_timezone: US/Pacific
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_sitewhoami: default Initialized
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_uri_segment: SEGMENT_PATH
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_useragent: Opera 9.80
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_useragent: Mac OS X
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_init_session: Not Implemented
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_dbopen: mysql_pconnect
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|app: admin Initialized
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|app: admin Function: login
20100626163103|127.0.0.1|__ERROR_WARNING|2010-06-26 16:31:03|No favicon FILE FOUND-> Line 354-> function: get_fav_icon-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|get_css / file: $file
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|get_css / file: $file
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|get_css / file: $file
20100626163103|127.0.0.1|INCLUDE|2010-06-26 16:31:03|get_js / file: $file
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|app: admin Terminated
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|_dbclose CLOSED
20100626163103|127.0.0.1|INFO|2010-06-26 16:31:03|pasteboard.Complete (1.969 seconds)
20100626163103|127.0.0.1|__ERROR_WARNING|2010-06-26 16:31:03|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|pasteboard.Started
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: useragents-config
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: dates-config
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: fopen-config
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: stopwords-config
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-database
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-useragent
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-hooks
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-sessions
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-cache
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-scaffolding
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-errors
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-uri
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|library: pb-logs
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_set_timezone: US/Pacific
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_sitewhoami: default Initialized
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_uri_segment: SEGMENT_PATH
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_useragent: Opera 9.80
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_useragent: Mac OS X
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_init_session: Not Implemented
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_dbopen: mysql_pconnect
20100626163106|127.0.0.1|__ERROR_WARNING|2010-06-26 16:31:06|File Not Found: favicon.ico_controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100626163106|127.0.0.1|SQL|2010-06-26 16:31:06|SQL_logged from show_404, 43
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|get_css / file: $file
20100626163106|127.0.0.1|INCLUDE|2010-06-26 16:31:06|get_css / file: $file
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|_dbclose CLOSED
20100626163106|127.0.0.1|INFO|2010-06-26 16:31:06|pasteboard.Complete (0.434 seconds)
20100626163106|127.0.0.1|__ERROR_WARNING|2010-06-26 16:31:06|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|pasteboard.Started
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: useragents-config
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: dates-config
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: fopen-config
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: stopwords-config
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-database
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-useragent
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-hooks
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-sessions
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-cache
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-scaffolding
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-errors
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-uri
20100626163958|127.0.0.1|INCLUDE|2010-06-26 16:39:58|library: pb-logs
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_set_timezone: US/Pacific
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_sitewhoami: default Initialized
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_uri_segment: QUERY_STRING
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_useragent:  
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_useragent: 
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_init_session: Not Implemented
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_dbopen: mysql_pconnect
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100626163958|127.0.0.1|SQL|2010-06-26 16:39:58|SQL_logged from show_404, 43
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|_dbclose CLOSED
20100626163958|127.0.0.1|INFO|2010-06-26 16:39:58|pasteboard.Complete (2.198 seconds)
20100626163958|127.0.0.1|__ERROR_WARNING|2010-06-26 16:39:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|pasteboard.Started
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: useragents-config
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: dates-config
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: fopen-config
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: stopwords-config
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-database
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-useragent
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-hooks
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-sessions
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-cache
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-scaffolding
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-errors
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-uri
20100626164237|127.0.0.1|INCLUDE|2010-06-26 16:42:37|library: pb-logs
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_set_timezone: US/Pacific
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_sitewhoami: default Initialized
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_uri_segment: QUERY_STRING
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_useragent:  
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_useragent: 
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_init_session: Not Implemented
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_dbopen: mysql_pconnect
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100626164237|127.0.0.1|SQL|2010-06-26 16:42:37|SQL_logged from show_404, 43
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|_dbclose CLOSED
20100626164237|127.0.0.1|INFO|2010-06-26 16:42:37|pasteboard.Complete (0.947 seconds)
20100626164237|127.0.0.1|__ERROR_WARNING|2010-06-26 16:42:37|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|pasteboard.Started
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: useragents-config
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: dates-config
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: fopen-config
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: stopwords-config
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-database
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-useragent
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-hooks
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-sessions
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-cache
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-scaffolding
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-errors
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-uri
20100626165001|127.0.0.1|INCLUDE|2010-06-26 16:50:01|library: pb-logs
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_set_timezone: US/Pacific
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_sitewhoami: default Initialized
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_uri_segment: QUERY_STRING
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_useragent:  
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_useragent: 
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_init_session: Not Implemented
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_dbopen: mysql_pconnect
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100626165001|127.0.0.1|SQL|2010-06-26 16:50:01|SQL_logged from show_404, 43
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|_dbclose CLOSED
20100626165001|127.0.0.1|INFO|2010-06-26 16:50:01|pasteboard.Complete (1.45 seconds)
20100626165001|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|pasteboard.Started
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: useragents-config
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: dates-config
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: fopen-config
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: stopwords-config
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-database
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-useragent
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-hooks
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-sessions
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-cache
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-scaffolding
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-errors
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-uri
20100626165049|127.0.0.1|INCLUDE|2010-06-26 16:50:49|library: pb-logs
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_set_timezone: US/Pacific
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_sitewhoami: default Initialized
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_uri_segment: QUERY_STRING
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 124]
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_useragent:  
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-useragent.php, 125]
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_useragent: 
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_init_session: Not Implemented
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'DB_HOST' (1) [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 300]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 306]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 308]
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_dbopen: mysql_pconnect
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-bootstrap.php
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 331]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 332]
20100626165049|127.0.0.1|SQL|2010-06-26 16:50:49|SQL_logged from show_404, 43
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 67]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 68]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 69]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 71]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-errors.php, 72]
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|Template Not Found: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-system.php
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-database.php, 318]
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|_dbclose CLOSED
20100626165049|127.0.0.1|INFO|2010-06-26 16:50:49|pasteboard.Complete (0.713 seconds)
20100626165049|127.0.0.1|__ERROR_WARNING|2010-06-26 16:50:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/PASTEBOARD_FRAMEWORK/www/pb-libraries/pb-scaffolding.php, 56]
