20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|pasteboard.Started
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|pasteboard.Started
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: useragents-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: dates-config
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|pasteboard.Started
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: fopen-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: useragents-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: stopwords-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: dates-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-database
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: fopen-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-useragent
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: stopwords-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-hooks
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-database
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-sessions
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-useragent
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-cache
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-hooks
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-scaffolding
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-sessions
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-errors
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-cache
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-uri
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-scaffolding
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-logs
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-errors
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_set_timezone: US/Pacific
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-uri
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_sitewhoami: default Initialized
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-logs
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_set_timezone: US/Pacific
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_sitewhoami: default Initialized
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_uri_segment: QUERY_STRING
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_uri_segment: QUERY_STRING
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|pasteboard.Started
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_useragent:  
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: useragents-config
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: dates-config
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_useragent: 
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: fopen-config
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_init_session: Not Implemented
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: stopwords-config
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-database
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-useragent
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-hooks
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-sessions
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-cache
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-scaffolding
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-errors
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-uri
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-logs
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_set_timezone: US/Pacific
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_sitewhoami: default Initialized
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_uri_segment: QUERY_STRING
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: useragents-config
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: dates-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: fopen-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: stopwords-config
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-database
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-useragent
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-hooks
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-sessions
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-cache
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-scaffolding
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-errors
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-uri
20110103182905|127.0.0.1|INCLUDE|2011-01-03 18:29:04|library: pb-logs
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_set_timezone: US/Pacific
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_sitewhoami: default Initialized
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_uri_segment: QUERY_STRING
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_useragent:  
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_useragent: 
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_init_session: Not Implemented
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_useragent:  
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_useragent: 
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_init_session: Not Implemented
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_useragent:  
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_useragent: 
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_init_session: Not Implemented
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_dbopen: mysql_pconnect
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_dbopen: mysql_pconnect
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103182905|127.0.0.1|SQL|2011-01-03 18:29:04|SQL_logged from show_404, 43
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103182905|127.0.0.1|SQL|2011-01-03 18:29:04|SQL_logged from show_404, 43
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_dbopen: mysql_pconnect
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103182905|127.0.0.1|SQL|2011-01-03 18:29:04|SQL_logged from show_404, 43
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_dbopen: mysql_pconnect
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103182905|127.0.0.1|SQL|2011-01-03 18:29:04|SQL_logged from show_404, 43
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_dbclose CLOSED
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|pasteboard.Complete (3.243 seconds)
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_dbclose CLOSED
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|pasteboard.Complete (3.244 seconds)
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_dbclose CLOSED
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|pasteboard.Complete (3.245 seconds)
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|_dbclose CLOSED
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103182905|127.0.0.1|INFO|2011-01-03 18:29:04|pasteboard.Complete (3.245 seconds)
20110103182905|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:04|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|pasteboard.Started
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: useragents-config
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: dates-config
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: fopen-config
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: stopwords-config
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-database
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-useragent
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-hooks
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-sessions
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-cache
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-scaffolding
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-errors
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-uri
20110103182948|127.0.0.1|INCLUDE|2011-01-03 18:29:48|library: pb-logs
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_set_timezone: US/Pacific
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_sitewhoami: default Initialized
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_uri_segment: QUERY_STRING
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_useragent:  
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_useragent: 
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_init_session: Not Implemented
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_dbopen: mysql_pconnect
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103182948|127.0.0.1|SQL|2011-01-03 18:29:48|SQL_logged from show_404, 43
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|_dbclose CLOSED
20110103182948|127.0.0.1|INFO|2011-01-03 18:29:48|pasteboard.Complete (0.561 seconds)
20110103182948|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:48|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|pasteboard.Started
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: useragents-config
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: dates-config
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: fopen-config
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: stopwords-config
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-database
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-useragent
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-hooks
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-sessions
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-cache
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-scaffolding
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-errors
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-uri
20110103182958|127.0.0.1|INCLUDE|2011-01-03 18:29:58|library: pb-logs
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_set_timezone: US/Pacific
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_sitewhoami: default Initialized
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_uri_segment: QUERY_STRING
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_useragent:  
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_useragent: 
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_init_session: Not Implemented
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_dbopen: mysql_pconnect
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103182958|127.0.0.1|SQL|2011-01-03 18:29:58|SQL_logged from show_404, 43
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|_dbclose CLOSED
20110103182958|127.0.0.1|INFO|2011-01-03 18:29:58|pasteboard.Complete (0.67 seconds)
20110103182958|127.0.0.1|__ERROR_WARNING|2011-01-03 18:29:58|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|pasteboard.Started
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: useragents-config
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: dates-config
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: fopen-config
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: stopwords-config
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-database
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-useragent
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-hooks
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-sessions
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-cache
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-scaffolding
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-errors
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-uri
20110103183142|127.0.0.1|INCLUDE|2011-01-03 18:31:42|library: pb-logs
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_set_timezone: US/Pacific
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_sitewhoami: default Initialized
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_uri_segment: QUERY_STRING
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_useragent:  
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_useragent: 
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_init_session: Not Implemented
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_dbopen: mysql_pconnect
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183142|127.0.0.1|SQL|2011-01-03 18:31:42|SQL_logged from show_404, 43
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|_dbclose CLOSED
20110103183142|127.0.0.1|INFO|2011-01-03 18:31:42|pasteboard.Complete (2.578 seconds)
20110103183142|127.0.0.1|__ERROR_WARNING|2011-01-03 18:31:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|pasteboard.Started
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: useragents-config
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: dates-config
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: fopen-config
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: stopwords-config
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-database
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-useragent
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-hooks
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-sessions
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-cache
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-scaffolding
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-errors
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-uri
20110103183248|127.0.0.1|INCLUDE|2011-01-03 18:32:48|library: pb-logs
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_set_timezone: US/Pacific
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_sitewhoami: default Initialized
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_uri_segment: QUERY_STRING
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_useragent:  
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_useragent: 
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_init_session: Not Implemented
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|pasteboard.Started
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: useragents-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: dates-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: fopen-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: stopwords-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-database
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-useragent
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-hooks
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-sessions
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-cache
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-scaffolding
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-errors
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-uri
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-logs
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_set_timezone: US/Pacific
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_sitewhoami: default Initialized
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_uri_segment: QUERY_STRING
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_useragent:  
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_useragent: 
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_init_session: Not Implemented
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|pasteboard.Started
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: useragents-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: dates-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: fopen-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: stopwords-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-database
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-useragent
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-hooks
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-sessions
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-cache
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-scaffolding
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-errors
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-uri
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-logs
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_set_timezone: US/Pacific
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_sitewhoami: default Initialized
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_uri_segment: QUERY_STRING
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_useragent:  
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_useragent: 
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_init_session: Not Implemented
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|pasteboard.Started
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: useragents-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: dates-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: fopen-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: stopwords-config
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-database
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-useragent
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-hooks
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-sessions
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-cache
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-scaffolding
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-errors
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-uri
20110103183249|127.0.0.1|INCLUDE|2011-01-03 18:32:49|library: pb-logs
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_set_timezone: US/Pacific
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_sitewhoami: default Initialized
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_uri_segment: QUERY_STRING
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_useragent:  
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_useragent: 
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_init_session: Not Implemented
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_dbopen: mysql_pconnect
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183249|127.0.0.1|SQL|2011-01-03 18:32:49|SQL_logged from show_404, 43
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_dbclose CLOSED
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|pasteboard.Complete (0.715 seconds)
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_dbopen: mysql_pconnect
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_dbopen: mysql_pconnect
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183249|127.0.0.1|SQL|2011-01-03 18:32:49|SQL_logged from show_404, 43
20110103183249|127.0.0.1|SQL|2011-01-03 18:32:49|SQL_logged from show_404, 43
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_dbclose CLOSED
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|_dbclose CLOSED
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|pasteboard.Complete (0.718 seconds)
20110103183249|127.0.0.1|INFO|2011-01-03 18:32:49|pasteboard.Complete (0.718 seconds)
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183249|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_dbopen: mysql_pconnect
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183248|127.0.0.1|SQL|2011-01-03 18:32:48|SQL_logged from show_404, 43
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|_dbclose CLOSED
20110103183248|127.0.0.1|INFO|2011-01-03 18:32:48|pasteboard.Complete (2.407 seconds)
20110103183248|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:48|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|pasteboard.Started
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: useragents-config
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: dates-config
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: fopen-config
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: stopwords-config
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-database
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-useragent
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-hooks
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-sessions
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-cache
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-scaffolding
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-errors
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-uri
20110103183251|127.0.0.1|INCLUDE|2011-01-03 18:32:51|library: pb-logs
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_set_timezone: US/Pacific
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_sitewhoami: default Initialized
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_uri_segment: QUERY_STRING
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_useragent:  
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_useragent: 
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_init_session: Not Implemented
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_dbopen: mysql_pconnect
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183251|127.0.0.1|SQL|2011-01-03 18:32:51|SQL_logged from show_404, 43
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|_dbclose CLOSED
20110103183251|127.0.0.1|INFO|2011-01-03 18:32:51|pasteboard.Complete (0.784 seconds)
20110103183251|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:51|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|pasteboard.Started
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: useragents-config
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: dates-config
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: fopen-config
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: stopwords-config
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-database
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-useragent
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-hooks
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-sessions
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-cache
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-scaffolding
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-errors
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-uri
20110103183252|127.0.0.1|INCLUDE|2011-01-03 18:32:52|library: pb-logs
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_set_timezone: US/Pacific
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_sitewhoami: default Initialized
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_uri_segment: QUERY_STRING
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_useragent:  
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_useragent: 
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_init_session: Not Implemented
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_dbopen: mysql_pconnect
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183252|127.0.0.1|SQL|2011-01-03 18:32:52|SQL_logged from show_404, 43
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|_dbclose CLOSED
20110103183252|127.0.0.1|INFO|2011-01-03 18:32:52|pasteboard.Complete (0.835 seconds)
20110103183252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:32:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|pasteboard.Started
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: useragents-config
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: dates-config
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: fopen-config
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: stopwords-config
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-database
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-useragent
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-hooks
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-sessions
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-cache
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-scaffolding
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-errors
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-uri
20110103183342|127.0.0.1|INCLUDE|2011-01-03 18:33:42|library: pb-logs
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_set_timezone: US/Pacific
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_sitewhoami: default Initialized
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_uri_segment: QUERY_STRING
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_useragent:  
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_useragent: 
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_init_session: Not Implemented
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_dbopen: mysql_pconnect
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183342|127.0.0.1|SQL|2011-01-03 18:33:42|SQL_logged from show_404, 43
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|_dbclose CLOSED
20110103183342|127.0.0.1|INFO|2011-01-03 18:33:42|pasteboard.Complete (0.278 seconds)
20110103183342|127.0.0.1|__ERROR_WARNING|2011-01-03 18:33:42|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|pasteboard.Started
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: useragents-config
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: dates-config
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: fopen-config
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: stopwords-config
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-database
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-useragent
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-hooks
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-sessions
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-cache
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-scaffolding
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-errors
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-uri
20110103183417|127.0.0.1|INCLUDE|2011-01-03 18:34:17|library: pb-logs
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_set_timezone: US/Pacific
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_sitewhoami: default Initialized
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_uri_segment: QUERY_STRING
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_useragent:  
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_useragent: 
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_init_session: Not Implemented
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_dbopen: mysql_pconnect
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183417|127.0.0.1|SQL|2011-01-03 18:34:17|SQL_logged from show_404, 43
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|_dbclose CLOSED
20110103183417|127.0.0.1|INFO|2011-01-03 18:34:17|pasteboard.Complete (1.319 seconds)
20110103183417|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:17|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|pasteboard.Started
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: useragents-config
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: dates-config
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: fopen-config
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: stopwords-config
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-database
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-useragent
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-hooks
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-sessions
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-cache
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-scaffolding
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-errors
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-uri
20110103183418|127.0.0.1|INCLUDE|2011-01-03 18:34:18|library: pb-logs
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_set_timezone: US/Pacific
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_sitewhoami: default Initialized
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_uri_segment: QUERY_STRING
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_useragent:  
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_useragent: 
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_init_session: Not Implemented
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_dbopen: mysql_pconnect
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183418|127.0.0.1|SQL|2011-01-03 18:34:18|SQL_logged from show_404, 43
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|_dbclose CLOSED
20110103183418|127.0.0.1|INFO|2011-01-03 18:34:18|pasteboard.Complete (0.6 seconds)
20110103183418|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:18|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|pasteboard.Started
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: useragents-config
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: dates-config
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: fopen-config
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: stopwords-config
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-database
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-useragent
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-hooks
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-sessions
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-cache
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-scaffolding
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-errors
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-uri
20110103183419|127.0.0.1|INCLUDE|2011-01-03 18:34:19|library: pb-logs
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_set_timezone: US/Pacific
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_sitewhoami: default Initialized
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_uri_segment: QUERY_STRING
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_useragent:  
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_useragent: 
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_init_session: Not Implemented
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_dbopen: mysql_pconnect
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183419|127.0.0.1|SQL|2011-01-03 18:34:19|SQL_logged from show_404, 43
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|_dbclose CLOSED
20110103183419|127.0.0.1|INFO|2011-01-03 18:34:19|pasteboard.Complete (1.071 seconds)
20110103183419|127.0.0.1|__ERROR_WARNING|2011-01-03 18:34:19|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|pasteboard.Started
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: useragents-config
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: dates-config
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: fopen-config
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: stopwords-config
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-database
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-useragent
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-hooks
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-sessions
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-cache
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-scaffolding
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-errors
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-uri
20110103183538|127.0.0.1|INCLUDE|2011-01-03 18:35:38|library: pb-logs
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_set_timezone: US/Pacific
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_sitewhoami: default Initialized
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_uri_segment: QUERY_STRING
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_useragent:  
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_useragent: 
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_init_session: Not Implemented
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_dbopen: mysql_pconnect
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183538|127.0.0.1|SQL|2011-01-03 18:35:38|SQL_logged from show_404, 43
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|_dbclose CLOSED
20110103183538|127.0.0.1|INFO|2011-01-03 18:35:38|pasteboard.Complete (2.101 seconds)
20110103183538|127.0.0.1|__ERROR_WARNING|2011-01-03 18:35:38|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|pasteboard.Started
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: useragents-config
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: dates-config
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: fopen-config
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: stopwords-config
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-database
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-useragent
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-hooks
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-sessions
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-cache
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-scaffolding
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-errors
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-uri
20110103183621|127.0.0.1|INCLUDE|2011-01-03 18:36:21|library: pb-logs
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_set_timezone: US/Pacific
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_sitewhoami: default Initialized
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_uri_segment: QUERY_STRING
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_useragent:  
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_useragent: 
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_init_session: Not Implemented
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_dbopen: mysql_pconnect
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183621|127.0.0.1|SQL|2011-01-03 18:36:21|SQL_logged from show_404, 43
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|_dbclose CLOSED
20110103183621|127.0.0.1|INFO|2011-01-03 18:36:21|pasteboard.Complete (1.048 seconds)
20110103183621|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:21|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|pasteboard.Started
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: useragents-config
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: dates-config
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: fopen-config
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: stopwords-config
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-database
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-useragent
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-hooks
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-sessions
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-cache
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-scaffolding
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-errors
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-uri
20110103183641|127.0.0.1|INCLUDE|2011-01-03 18:36:41|library: pb-logs
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_set_timezone: US/Pacific
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_sitewhoami: default Initialized
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_uri_segment: QUERY_STRING
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_useragent:  
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_useragent: 
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_init_session: Not Implemented
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_dbopen: mysql_pconnect
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103183641|127.0.0.1|SQL|2011-01-03 18:36:41|SQL_logged from show_404, 43
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|_dbclose CLOSED
20110103183641|127.0.0.1|INFO|2011-01-03 18:36:41|pasteboard.Complete (2.036 seconds)
20110103183641|127.0.0.1|__ERROR_WARNING|2011-01-03 18:36:41|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|pasteboard.Started
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: useragents-config
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: dates-config
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: fopen-config
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: stopwords-config
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-database
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-useragent
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-hooks
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-sessions
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-cache
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-scaffolding
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-errors
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-uri
20110103184250|127.0.0.1|INCLUDE|2011-01-03 18:42:50|library: pb-logs
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_set_timezone: US/Pacific
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_sitewhoami: default Initialized
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_uri_segment: QUERY_STRING
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_useragent:  
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_useragent: 
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_init_session: Not Implemented
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_dbopen: mysql_pconnect
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103184250|127.0.0.1|SQL|2011-01-03 18:42:50|SQL_logged from show_404, 43
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|_dbclose CLOSED
20110103184250|127.0.0.1|INFO|2011-01-03 18:42:50|pasteboard.Complete (1.255 seconds)
20110103184250|127.0.0.1|__ERROR_WARNING|2011-01-03 18:42:50|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|pasteboard.Started
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: useragents-config
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: dates-config
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: fopen-config
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: stopwords-config
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-database
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-useragent
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-hooks
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-sessions
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-cache
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-scaffolding
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-errors
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-uri
20110103185252|127.0.0.1|INCLUDE|2011-01-03 18:52:52|library: pb-logs
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_set_timezone: US/Pacific
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_sitewhoami: default Initialized
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_uri_segment: QUERY_STRING
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_useragent:  
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_useragent: 
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_init_session: Not Implemented
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_dbopen: mysql_pconnect
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103185252|127.0.0.1|SQL|2011-01-03 18:52:52|SQL_logged from show_404, 43
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|_dbclose CLOSED
20110103185252|127.0.0.1|INFO|2011-01-03 18:52:52|pasteboard.Complete (2.019 seconds)
20110103185252|127.0.0.1|__ERROR_WARNING|2011-01-03 18:52:52|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|pasteboard.Started
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: useragents-config
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: dates-config
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: fopen-config
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: stopwords-config
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-database
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-useragent
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-hooks
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-sessions
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-cache
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-scaffolding
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-errors
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-uri
20110103190253|127.0.0.1|INCLUDE|2011-01-03 19:02:53|library: pb-logs
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_set_timezone: US/Pacific
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_sitewhoami: default Initialized
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_uri_segment: QUERY_STRING
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_useragent:  
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_useragent: 
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_init_session: Not Implemented
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|pasteboard.Started
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: useragents-config
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: dates-config
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: fopen-config
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: stopwords-config
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-database
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-useragent
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-hooks
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-sessions
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-cache
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-scaffolding
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-errors
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-uri
20110103190254|127.0.0.1|INCLUDE|2011-01-03 19:02:54|library: pb-logs
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_set_timezone: US/Pacific
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_sitewhoami: default Initialized
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_uri_segment: QUERY_STRING
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_useragent:  
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_useragent: 
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_init_session: Not Implemented
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_dbopen: mysql_pconnect
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_dbopen: mysql_pconnect
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103190254|127.0.0.1|SQL|2011-01-03 19:02:54|SQL_logged from show_404, 43
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|_dbclose CLOSED
20110103190254|127.0.0.1|INFO|2011-01-03 19:02:54|pasteboard.Complete (1.346 seconds)
20110103190254|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:54|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103190253|127.0.0.1|SQL|2011-01-03 19:02:53|SQL_logged from show_404, 43
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|_dbclose CLOSED
20110103190253|127.0.0.1|INFO|2011-01-03 19:02:53|pasteboard.Complete (2.362 seconds)
20110103190253|127.0.0.1|__ERROR_WARNING|2011-01-03 19:02:53|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|pasteboard.Started
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: useragents-config
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: dates-config
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: fopen-config
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: stopwords-config
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-database
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-useragent
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-hooks
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-sessions
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-cache
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-scaffolding
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-errors
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-uri
20110103190343|127.0.0.1|INCLUDE|2011-01-03 19:03:43|library: pb-logs
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_set_timezone: US/Pacific
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_sitewhoami: default Initialized
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_uri_segment: QUERY_STRING
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_useragent:  
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_useragent: 
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_init_session: Not Implemented
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_dbopen: mysql_pconnect
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103190343|127.0.0.1|SQL|2011-01-03 19:03:43|SQL_logged from show_404, 43
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|_dbclose CLOSED
20110103190343|127.0.0.1|INFO|2011-01-03 19:03:43|pasteboard.Complete (0.393 seconds)
20110103190343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:03:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|pasteboard.Started
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: useragents-config
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: dates-config
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: fopen-config
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: stopwords-config
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-database
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-useragent
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-hooks
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-sessions
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-cache
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-scaffolding
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-errors
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-uri
20110103190540|127.0.0.1|INCLUDE|2011-01-03 19:05:40|library: pb-logs
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_set_timezone: US/Pacific
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_sitewhoami: default Initialized
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_uri_segment: QUERY_STRING
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_useragent:  
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_useragent: 
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_init_session: Not Implemented
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_dbopen: mysql_pconnect
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103190540|127.0.0.1|SQL|2011-01-03 19:05:40|SQL_logged from show_404, 43
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|_dbclose CLOSED
20110103190540|127.0.0.1|INFO|2011-01-03 19:05:40|pasteboard.Complete (2.124 seconds)
20110103190540|127.0.0.1|__ERROR_WARNING|2011-01-03 19:05:40|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|pasteboard.Started
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: useragents-config
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: dates-config
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: fopen-config
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: stopwords-config
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-database
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-useragent
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-hooks
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-sessions
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-cache
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-scaffolding
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-errors
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-uri
20110103190623|127.0.0.1|INCLUDE|2011-01-03 19:06:23|library: pb-logs
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_set_timezone: US/Pacific
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_sitewhoami: default Initialized
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_uri_segment: QUERY_STRING
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_useragent:  
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_useragent: 
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_init_session: Not Implemented
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_dbopen: mysql_pconnect
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103190623|127.0.0.1|SQL|2011-01-03 19:06:23|SQL_logged from show_404, 43
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|_dbclose CLOSED
20110103190623|127.0.0.1|INFO|2011-01-03 19:06:23|pasteboard.Complete (0.436 seconds)
20110103190623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|pasteboard.Started
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: useragents-config
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: dates-config
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: fopen-config
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: stopwords-config
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-database
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-useragent
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-hooks
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-sessions
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-cache
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-scaffolding
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-errors
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-uri
20110103190644|127.0.0.1|INCLUDE|2011-01-03 19:06:44|library: pb-logs
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_set_timezone: US/Pacific
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_sitewhoami: default Initialized
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_uri_segment: QUERY_STRING
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_useragent:  
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_useragent: 
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_init_session: Not Implemented
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_dbopen: mysql_pconnect
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103190644|127.0.0.1|SQL|2011-01-03 19:06:44|SQL_logged from show_404, 43
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|_dbclose CLOSED
20110103190644|127.0.0.1|INFO|2011-01-03 19:06:44|pasteboard.Complete (1.738 seconds)
20110103190644|127.0.0.1|__ERROR_WARNING|2011-01-03 19:06:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|pasteboard.Started
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: useragents-config
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: dates-config
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: fopen-config
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: stopwords-config
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-database
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-useragent
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-hooks
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-sessions
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-cache
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-scaffolding
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-errors
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-uri
20110103191256|127.0.0.1|INCLUDE|2011-01-03 19:12:56|library: pb-logs
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_set_timezone: US/Pacific
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_sitewhoami: default Initialized
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_uri_segment: QUERY_STRING
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_useragent:  
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_useragent: 
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_init_session: Not Implemented
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_dbopen: mysql_pconnect
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103191256|127.0.0.1|SQL|2011-01-03 19:12:56|SQL_logged from show_404, 43
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|_dbclose CLOSED
20110103191256|127.0.0.1|INFO|2011-01-03 19:12:56|pasteboard.Complete (2.135 seconds)
20110103191256|127.0.0.1|__ERROR_WARNING|2011-01-03 19:12:56|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|pasteboard.Started
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: useragents-config
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: dates-config
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: fopen-config
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: stopwords-config
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-database
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-useragent
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-hooks
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-sessions
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-cache
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-scaffolding
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-errors
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-uri
20110103192259|127.0.0.1|INCLUDE|2011-01-03 19:22:59|library: pb-logs
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_set_timezone: US/Pacific
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_sitewhoami: default Initialized
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_uri_segment: QUERY_STRING
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_useragent:  
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_useragent: 
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_init_session: Not Implemented
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_dbopen: mysql_pconnect
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103192259|127.0.0.1|SQL|2011-01-03 19:22:59|SQL_logged from show_404, 43
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|_dbclose CLOSED
20110103192259|127.0.0.1|INFO|2011-01-03 19:22:59|pasteboard.Complete (1.64 seconds)
20110103192259|127.0.0.1|__ERROR_WARNING|2011-01-03 19:22:59|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|pasteboard.Started
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: useragents-config
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: dates-config
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: fopen-config
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: stopwords-config
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-database
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-useragent
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-hooks
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-sessions
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-cache
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-scaffolding
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-errors
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-uri
20110103193255|127.0.0.1|INCLUDE|2011-01-03 19:32:55|library: pb-logs
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_set_timezone: US/Pacific
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_sitewhoami: default Initialized
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_uri_segment: QUERY_STRING
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_useragent:  
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_useragent: 
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_init_session: Not Implemented
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_dbopen: mysql_pconnect
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103193255|127.0.0.1|SQL|2011-01-03 19:32:55|SQL_logged from show_404, 43
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|_dbclose CLOSED
20110103193255|127.0.0.1|INFO|2011-01-03 19:32:55|pasteboard.Complete (2.289 seconds)
20110103193255|127.0.0.1|__ERROR_WARNING|2011-01-03 19:32:55|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|pasteboard.Started
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: useragents-config
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: dates-config
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: fopen-config
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: stopwords-config
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-database
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-useragent
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-hooks
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-sessions
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-cache
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-scaffolding
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-errors
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-uri
20110103193300|127.0.0.1|INCLUDE|2011-01-03 19:33:00|library: pb-logs
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_set_timezone: US/Pacific
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_sitewhoami: default Initialized
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_uri_segment: QUERY_STRING
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_useragent:  
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_useragent: 
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_init_session: Not Implemented
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_dbopen: mysql_pconnect
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103193300|127.0.0.1|SQL|2011-01-03 19:33:00|SQL_logged from show_404, 43
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|_dbclose CLOSED
20110103193300|127.0.0.1|INFO|2011-01-03 19:33:00|pasteboard.Complete (0.43 seconds)
20110103193300|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|pasteboard.Started
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: useragents-config
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: dates-config
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: fopen-config
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: stopwords-config
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-database
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-useragent
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-hooks
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-sessions
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-cache
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-scaffolding
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-errors
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-uri
20110103193343|127.0.0.1|INCLUDE|2011-01-03 19:33:43|library: pb-logs
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_set_timezone: US/Pacific
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_sitewhoami: default Initialized
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_uri_segment: QUERY_STRING
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_useragent:  
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_useragent: 
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_init_session: Not Implemented
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_dbopen: mysql_pconnect
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103193343|127.0.0.1|SQL|2011-01-03 19:33:43|SQL_logged from show_404, 43
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|_dbclose CLOSED
20110103193343|127.0.0.1|INFO|2011-01-03 19:33:43|pasteboard.Complete (0.638 seconds)
20110103193343|127.0.0.1|__ERROR_WARNING|2011-01-03 19:33:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|pasteboard.Started
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: useragents-config
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: dates-config
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: fopen-config
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: stopwords-config
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-database
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-useragent
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-hooks
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-sessions
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-cache
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-scaffolding
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-errors
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-uri
20110103193543|127.0.0.1|INCLUDE|2011-01-03 19:35:43|library: pb-logs
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_set_timezone: US/Pacific
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_sitewhoami: default Initialized
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_uri_segment: QUERY_STRING
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_useragent:  
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_useragent: 
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_init_session: Not Implemented
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_dbopen: mysql_pconnect
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103193543|127.0.0.1|SQL|2011-01-03 19:35:43|SQL_logged from show_404, 43
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|_dbclose CLOSED
20110103193543|127.0.0.1|INFO|2011-01-03 19:35:43|pasteboard.Complete (1.419 seconds)
20110103193543|127.0.0.1|__ERROR_WARNING|2011-01-03 19:35:43|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|pasteboard.Started
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: useragents-config
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: dates-config
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: fopen-config
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: stopwords-config
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-database
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-useragent
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-hooks
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-sessions
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-cache
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-scaffolding
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-errors
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-uri
20110103193623|127.0.0.1|INCLUDE|2011-01-03 19:36:23|library: pb-logs
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_set_timezone: US/Pacific
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_sitewhoami: default Initialized
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_uri_segment: QUERY_STRING
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_useragent:  
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_useragent: 
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_init_session: Not Implemented
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_dbopen: mysql_pconnect
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103193623|127.0.0.1|SQL|2011-01-03 19:36:23|SQL_logged from show_404, 43
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|_dbclose CLOSED
20110103193623|127.0.0.1|INFO|2011-01-03 19:36:23|pasteboard.Complete (0.616 seconds)
20110103193623|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|pasteboard.Started
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: useragents-config
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: dates-config
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: fopen-config
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: stopwords-config
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-database
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-useragent
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-hooks
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-sessions
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-cache
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-scaffolding
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-errors
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-uri
20110103193645|127.0.0.1|INCLUDE|2011-01-03 19:36:45|library: pb-logs
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_set_timezone: US/Pacific
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_sitewhoami: default Initialized
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_uri_segment: QUERY_STRING
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_useragent:  
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_useragent: 
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_init_session: Not Implemented
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_dbopen: mysql_pconnect
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103193645|127.0.0.1|SQL|2011-01-03 19:36:45|SQL_logged from show_404, 43
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|_dbclose CLOSED
20110103193645|127.0.0.1|INFO|2011-01-03 19:36:45|pasteboard.Complete (1.712 seconds)
20110103193645|127.0.0.1|__ERROR_WARNING|2011-01-03 19:36:45|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|pasteboard.Started
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: useragents-config
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: dates-config
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: fopen-config
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: stopwords-config
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-database
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-useragent
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-hooks
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-sessions
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-cache
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-scaffolding
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-errors
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-uri
20110103194301|127.0.0.1|INCLUDE|2011-01-03 19:43:01|library: pb-logs
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_set_timezone: US/Pacific
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_sitewhoami: default Initialized
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_uri_segment: QUERY_STRING
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_useragent:  
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_useragent: 
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_init_session: Not Implemented
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_dbopen: mysql_pconnect
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103194301|127.0.0.1|SQL|2011-01-03 19:43:01|SQL_logged from show_404, 43
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|_dbclose CLOSED
20110103194301|127.0.0.1|INFO|2011-01-03 19:43:01|pasteboard.Complete (1.639 seconds)
20110103194301|127.0.0.1|__ERROR_WARNING|2011-01-03 19:43:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|pasteboard.Started
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: useragents-config
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: dates-config
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: fopen-config
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: stopwords-config
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-database
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-useragent
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-hooks
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-sessions
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-cache
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-scaffolding
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-errors
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-uri
20110103195302|127.0.0.1|INCLUDE|2011-01-03 19:53:02|library: pb-logs
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_set_timezone: US/Pacific
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_sitewhoami: default Initialized
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_uri_segment: QUERY_STRING
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_useragent:  
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_useragent: 
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_init_session: Not Implemented
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_dbopen: mysql_pconnect
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103195302|127.0.0.1|SQL|2011-01-03 19:53:02|SQL_logged from show_404, 43
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|_dbclose CLOSED
20110103195302|127.0.0.1|INFO|2011-01-03 19:53:02|pasteboard.Complete (2.081 seconds)
20110103195302|127.0.0.1|__ERROR_WARNING|2011-01-03 19:53:02|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|pasteboard.Started
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: useragents-config
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: dates-config
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: fopen-config
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: stopwords-config
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-database
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-useragent
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-hooks
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-sessions
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-cache
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-scaffolding
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-errors
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-uri
20110103200257|127.0.0.1|INCLUDE|2011-01-03 20:02:57|library: pb-logs
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_set_timezone: US/Pacific
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_sitewhoami: default Initialized
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_uri_segment: QUERY_STRING
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_useragent:  
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_useragent: 
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_init_session: Not Implemented
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_dbopen: mysql_pconnect
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103200257|127.0.0.1|SQL|2011-01-03 20:02:57|SQL_logged from show_404, 43
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|_dbclose CLOSED
20110103200257|127.0.0.1|INFO|2011-01-03 20:02:57|pasteboard.Complete (2.685 seconds)
20110103200257|127.0.0.1|__ERROR_WARNING|2011-01-03 20:02:57|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|pasteboard.Started
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: useragents-config
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: dates-config
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: fopen-config
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: stopwords-config
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-database
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-useragent
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-hooks
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-sessions
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-cache
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-scaffolding
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-errors
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-uri
20110103200305|127.0.0.1|INCLUDE|2011-01-03 20:03:05|library: pb-logs
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_set_timezone: US/Pacific
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_sitewhoami: default Initialized
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_uri_segment: QUERY_STRING
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_useragent:  
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_useragent: 
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_init_session: Not Implemented
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_dbopen: mysql_pconnect
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103200305|127.0.0.1|SQL|2011-01-03 20:03:05|SQL_logged from show_404, 43
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|_dbclose CLOSED
20110103200305|127.0.0.1|INFO|2011-01-03 20:03:05|pasteboard.Complete (1.12 seconds)
20110103200305|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|pasteboard.Started
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: useragents-config
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: dates-config
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: fopen-config
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: stopwords-config
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-database
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-useragent
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-hooks
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-sessions
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-cache
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-scaffolding
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-errors
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-uri
20110103200345|127.0.0.1|INCLUDE|2011-01-03 20:03:45|library: pb-logs
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_set_timezone: US/Pacific
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_sitewhoami: default Initialized
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_uri_segment: QUERY_STRING
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_useragent:  
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_useragent: 
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_init_session: Not Implemented
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_dbopen: mysql_pconnect
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103200345|127.0.0.1|SQL|2011-01-03 20:03:45|SQL_logged from show_404, 43
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|_dbclose CLOSED
20110103200345|127.0.0.1|INFO|2011-01-03 20:03:45|pasteboard.Complete (1.244 seconds)
20110103200345|127.0.0.1|__ERROR_WARNING|2011-01-03 20:03:45|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|pasteboard.Started
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: useragents-config
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: dates-config
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: fopen-config
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: stopwords-config
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-database
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-useragent
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-hooks
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-sessions
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-cache
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-scaffolding
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-errors
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-uri
20110103200544|127.0.0.1|INCLUDE|2011-01-03 20:05:44|library: pb-logs
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_set_timezone: US/Pacific
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_sitewhoami: default Initialized
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_uri_segment: QUERY_STRING
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_useragent:  
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_useragent: 
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_init_session: Not Implemented
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_dbopen: mysql_pconnect
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103200544|127.0.0.1|SQL|2011-01-03 20:05:44|SQL_logged from show_404, 43
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|_dbclose CLOSED
20110103200544|127.0.0.1|INFO|2011-01-03 20:05:44|pasteboard.Complete (2.634 seconds)
20110103200544|127.0.0.1|__ERROR_WARNING|2011-01-03 20:05:44|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|pasteboard.Started
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: useragents-config
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: dates-config
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: fopen-config
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: stopwords-config
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-database
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-useragent
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-hooks
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-sessions
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-cache
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-scaffolding
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-errors
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-uri
20110103200623|127.0.0.1|INCLUDE|2011-01-03 20:06:23|library: pb-logs
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_set_timezone: US/Pacific
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_sitewhoami: default Initialized
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_uri_segment: QUERY_STRING
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_useragent:  
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_useragent: 
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_init_session: Not Implemented
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_dbopen: mysql_pconnect
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103200623|127.0.0.1|SQL|2011-01-03 20:06:23|SQL_logged from show_404, 43
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|_dbclose CLOSED
20110103200623|127.0.0.1|INFO|2011-01-03 20:06:23|pasteboard.Complete (1.211 seconds)
20110103200623|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:23|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|pasteboard.Started
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: useragents-config
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: dates-config
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: fopen-config
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: stopwords-config
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-database
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-useragent
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-hooks
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-sessions
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-cache
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-scaffolding
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-errors
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-uri
20110103200647|127.0.0.1|INCLUDE|2011-01-03 20:06:47|library: pb-logs
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_set_timezone: US/Pacific
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_sitewhoami: default Initialized
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_uri_segment: QUERY_STRING
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_useragent:  
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_useragent: 
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_init_session: Not Implemented
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_dbopen: mysql_pconnect
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103200647|127.0.0.1|SQL|2011-01-03 20:06:47|SQL_logged from show_404, 43
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|_dbclose CLOSED
20110103200647|127.0.0.1|INFO|2011-01-03 20:06:47|pasteboard.Complete (1.8 seconds)
20110103200647|127.0.0.1|__ERROR_WARNING|2011-01-03 20:06:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|pasteboard.Started
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: useragents-config
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: dates-config
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: fopen-config
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: stopwords-config
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-database
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-useragent
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-hooks
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-sessions
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-cache
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-scaffolding
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-errors
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-uri
20110103201307|127.0.0.1|INCLUDE|2011-01-03 20:13:07|library: pb-logs
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_set_timezone: US/Pacific
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_sitewhoami: default Initialized
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_uri_segment: QUERY_STRING
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_useragent:  
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_useragent: 
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_init_session: Not Implemented
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_dbopen: mysql_pconnect
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103201307|127.0.0.1|SQL|2011-01-03 20:13:07|SQL_logged from show_404, 43
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|_dbclose CLOSED
20110103201307|127.0.0.1|INFO|2011-01-03 20:13:07|pasteboard.Complete (2.331 seconds)
20110103201307|127.0.0.1|__ERROR_WARNING|2011-01-03 20:13:07|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|pasteboard.Started
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: useragents-config
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: dates-config
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: fopen-config
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: stopwords-config
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-database
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-useragent
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-hooks
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-sessions
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-cache
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-scaffolding
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-errors
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-uri
20110103202309|127.0.0.1|INCLUDE|2011-01-03 20:23:09|library: pb-logs
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_set_timezone: US/Pacific
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_sitewhoami: default Initialized
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_uri_segment: QUERY_STRING
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_useragent:  
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_useragent: 
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_init_session: Not Implemented
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_dbopen: mysql_pconnect
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103202309|127.0.0.1|SQL|2011-01-03 20:23:09|SQL_logged from show_404, 43
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|_dbclose CLOSED
20110103202309|127.0.0.1|INFO|2011-01-03 20:23:09|pasteboard.Complete (2.664 seconds)
20110103202309|127.0.0.1|__ERROR_WARNING|2011-01-03 20:23:09|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|pasteboard.Started
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: useragents-config
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: dates-config
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: fopen-config
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: stopwords-config
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-database
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-useragent
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-hooks
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-sessions
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-cache
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-scaffolding
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-errors
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-uri
20110103203300|127.0.0.1|INCLUDE|2011-01-03 20:33:00|library: pb-logs
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_set_timezone: US/Pacific
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_sitewhoami: default Initialized
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_uri_segment: QUERY_STRING
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_useragent:  
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_useragent: 
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_init_session: Not Implemented
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_dbopen: mysql_pconnect
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103203300|127.0.0.1|SQL|2011-01-03 20:33:00|SQL_logged from show_404, 43
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|_dbclose CLOSED
20110103203300|127.0.0.1|INFO|2011-01-03 20:33:00|pasteboard.Complete (3.003 seconds)
20110103203300|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:00|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|pasteboard.Started
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: useragents-config
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: dates-config
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: fopen-config
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: stopwords-config
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-database
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-useragent
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-hooks
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-sessions
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-cache
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-scaffolding
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-errors
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-uri
20110103203312|127.0.0.1|INCLUDE|2011-01-03 20:33:12|library: pb-logs
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_set_timezone: US/Pacific
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_sitewhoami: default Initialized
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_uri_segment: QUERY_STRING
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_useragent:  
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_useragent: 
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_init_session: Not Implemented
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_dbopen: mysql_pconnect
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103203312|127.0.0.1|SQL|2011-01-03 20:33:12|SQL_logged from show_404, 43
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|_dbclose CLOSED
20110103203312|127.0.0.1|INFO|2011-01-03 20:33:12|pasteboard.Complete (0.182 seconds)
20110103203312|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:12|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|pasteboard.Started
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: useragents-config
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: dates-config
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: fopen-config
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: stopwords-config
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-database
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-useragent
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-hooks
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-sessions
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-cache
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-scaffolding
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-errors
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-uri
20110103203347|127.0.0.1|INCLUDE|2011-01-03 20:33:47|library: pb-logs
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_set_timezone: US/Pacific
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_sitewhoami: default Initialized
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_uri_segment: QUERY_STRING
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_useragent:  
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_useragent: 
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_init_session: Not Implemented
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_dbopen: mysql_pconnect
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103203347|127.0.0.1|SQL|2011-01-03 20:33:47|SQL_logged from show_404, 43
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|_dbclose CLOSED
20110103203347|127.0.0.1|INFO|2011-01-03 20:33:47|pasteboard.Complete (0.272 seconds)
20110103203347|127.0.0.1|__ERROR_WARNING|2011-01-03 20:33:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|pasteboard.Started
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: useragents-config
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: dates-config
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: fopen-config
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: stopwords-config
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-database
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-useragent
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-hooks
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-sessions
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-cache
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-scaffolding
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-errors
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-uri
20110103203547|127.0.0.1|INCLUDE|2011-01-03 20:35:47|library: pb-logs
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_set_timezone: US/Pacific
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_sitewhoami: default Initialized
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_uri_segment: QUERY_STRING
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_useragent:  
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_useragent: 
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_init_session: Not Implemented
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_dbopen: mysql_pconnect
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103203547|127.0.0.1|SQL|2011-01-03 20:35:47|SQL_logged from show_404, 43
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|_dbclose CLOSED
20110103203547|127.0.0.1|INFO|2011-01-03 20:35:47|pasteboard.Complete (2.172 seconds)
20110103203547|127.0.0.1|__ERROR_WARNING|2011-01-03 20:35:47|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|pasteboard.Started
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: useragents-config
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: dates-config
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: fopen-config
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: stopwords-config
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-database
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-useragent
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-hooks
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-sessions
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-cache
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-scaffolding
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-errors
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-uri
20110103203625|127.0.0.1|INCLUDE|2011-01-03 20:36:25|library: pb-logs
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_set_timezone: US/Pacific
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_sitewhoami: default Initialized
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_uri_segment: QUERY_STRING
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_useragent:  
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_useragent: 
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_init_session: Not Implemented
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_dbopen: mysql_pconnect
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103203625|127.0.0.1|SQL|2011-01-03 20:36:25|SQL_logged from show_404, 43
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|_dbclose CLOSED
20110103203625|127.0.0.1|INFO|2011-01-03 20:36:25|pasteboard.Complete (0.878 seconds)
20110103203625|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:25|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|pasteboard.Started
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: useragents-config
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: dates-config
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: fopen-config
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: stopwords-config
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-database
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-useragent
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-hooks
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-sessions
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-cache
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-scaffolding
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-errors
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-uri
20110103203649|127.0.0.1|INCLUDE|2011-01-03 20:36:49|library: pb-logs
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_set_timezone: US/Pacific
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_sitewhoami: default Initialized
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_uri_segment: QUERY_STRING
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_useragent:  
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_useragent: 
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_init_session: Not Implemented
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_dbopen: mysql_pconnect
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103203649|127.0.0.1|SQL|2011-01-03 20:36:49|SQL_logged from show_404, 43
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|_dbclose CLOSED
20110103203649|127.0.0.1|INFO|2011-01-03 20:36:49|pasteboard.Complete (1.902 seconds)
20110103203649|127.0.0.1|__ERROR_WARNING|2011-01-03 20:36:49|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|pasteboard.Started
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: useragents-config
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: dates-config
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: fopen-config
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: stopwords-config
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-database
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-useragent
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-hooks
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-sessions
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-cache
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-scaffolding
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-errors
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-uri
20110103203705|127.0.0.1|INCLUDE|2011-01-03 20:37:05|library: pb-logs
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_set_timezone: US/Pacific
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_sitewhoami: default Initialized
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_uri_segment: QUERY_STRING
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_useragent:  
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_useragent: 
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_init_session: Not Implemented
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_dbopen: mysql_pconnect
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103203705|127.0.0.1|SQL|2011-01-03 20:37:05|SQL_logged from show_404, 43
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|_dbclose CLOSED
20110103203705|127.0.0.1|INFO|2011-01-03 20:37:05|pasteboard.Complete (0.941 seconds)
20110103203705|127.0.0.1|__ERROR_WARNING|2011-01-03 20:37:05|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|pasteboard.Started
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: useragents-config
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: dates-config
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: fopen-config
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: stopwords-config
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-database
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-useragent
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-hooks
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-sessions
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-cache
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-scaffolding
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-errors
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-uri
20110103203901|127.0.0.1|INCLUDE|2011-01-03 20:39:01|library: pb-logs
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_set_timezone: US/Pacific
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_sitewhoami: default Initialized
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_uri_segment: SECONDARY PAGE FOUND w/ID: 
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_uri_segment: QUERY_STRING
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined index: name [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined index: version [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 124]
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_useragent:  
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined index: os_platform [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-useragent.php, 125]
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_useragent: 
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_init_session: Not Implemented
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Use of undefined constant DB_HOST - assumed 'DB_HOST' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Use of undefined constant DB_USER - assumed 'DB_USER' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Use of undefined constant DB_PSWD - assumed 'DB_PSWD' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] php_network_getaddresses: getaddrinfo failed: nodename nor servn (trying to connect via tcp://DB_HOST:3306) [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[2, E_WARNING] mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 300]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|DATABASE CONNECTION FAILED-> Line 303-> function: _dbopen-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[2, E_WARNING] mysql_select_db() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 306]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Use of undefined constant DB_NAME - assumed 'DB_NAME' [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 308]
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_dbopen: mysql_pconnect
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|File Not Found: _controller.php-> Line 202-> function: __init_app-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-bootstrap.php
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[2, E_WARNING] mysql_query() expects parameter 2 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 331]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[2, E_WARNING] mysql_num_rows() expects parameter 1 to be resource, null given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 332]
20110103203901|127.0.0.1|SQL|2011-01-03 20:39:01|SQL_logged from show_404, 43
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|404-NO RECORDS RETURNED-> Line 57-> function: show_404-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 67]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 68]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 69]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 71]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined variable: data [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-errors.php, 72]
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|Template Not Found: /Users/james/Dropbox/pasteboard/www//pb-sites/default/themes/serendipity/templates/.php-> Line 141-> function: load_template-> file: /Users/james/Dropbox/pasteboard/www/pb-libraries/pb-system.php
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[2, E_WARNING] mysql_close() expects parameter 1 to be resource, boolean given [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-database.php, 318]
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|_dbclose CLOSED
20110103203901|127.0.0.1|INFO|2011-01-03 20:39:01|pasteboard.Complete (1.924 seconds)
20110103203901|127.0.0.1|__ERROR_WARNING|2011-01-03 20:39:01|[8, E_NOTICE] Undefined index: PROFILER [/Users/james/Dropbox/pasteboard/www/pb-libraries/pb-scaffolding.php, 56]
